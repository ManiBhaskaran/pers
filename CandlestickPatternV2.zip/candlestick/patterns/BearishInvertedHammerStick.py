from candlestick.patterns.candlestick_finder import CandlestickFinder


class BearishInvertedHammerStick1(CandlestickFinder):
    def __init__(self, target=None):
        super().__init__(self.get_class_name(), 2, target=target)

    def logic(self, idx):
        candle = self.data.iloc[idx]
        prev_candle = self.data.iloc[idx + 1 * self.multi_coeff]

        daysClose = candle[self.close_column]
        daysOpen = candle[self.open_column]
        daysHigh = candle[self.high_column]
        daysLow = candle[self.low_column]

        prev_close = prev_candle[self.close_column]
        prev_open = prev_candle[self.open_column]
        prev_high = prev_candle[self.high_column]
        prev_low = prev_candle[self.low_column]
        
		#let daysOpen  = data.open[0];
        #let daysClose = data.close[0];
        #let daysHigh  = data.high[0];
        #let daysLow   = data.low[0];

        isBearishInvertedHammer = daysOpen > daysClose;
        isBearishInvertedHammer = isBearishInvertedHammer && (daysClose==daysLow);
        isBearishInvertedHammer = isBearishInvertedHammer && (daysOpen - daysClose) <= 2 * (daysHigh - daysOpen);

        return(isBearishInvertedHammer)
        
        # return (prev_close > prev_open and
        #         0.3 > abs(prev_close - prev_open) / (prev_high - prev_low) >= 0.1 and
        #         close < open and
        #         abs(close - open) / (high - low) >= 0.7 and
        #         prev_high < open and
        #         prev_low > close)
