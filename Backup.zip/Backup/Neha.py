import urllib.request
import json
import time

mylist=['a']
delay=30*15
close_time=time.time()+delay

proxies = {'https': 'http://web-proxy.houston.hpecorp.net:8080'}
#print "Using HTTP proxy %s" % proxies['http']
#urllib.urlopen("http://www.google.com", proxies=proxies)

t_end = time.time() + 60 * 15
while time.time() < t_end:
#while True:
      ##bla bla
      ###bla bla
	
 #   if time.time()>close_time :
#		break
			 
	x = urllib.request.urlopen('http://mmb.moneycontrol.com/index.php?q=boarder/ajax_call&section=get_messages&is_boarder_page=1&offset=&lmid=&isp=0&gmt=my_post&uid=neha0103&pgno=1',proxies)
	#x = urllib.request.urlopen('http://mmb.moneycontrol.com/index.php?q=boarder/ajax_call&section=get_messages&is_boarder_page=1&offset=10&lmid=&isp=0&gmt=my_post&uid=neha0103&pgno=1')
	#http://mmb.moneycontrol.com/index.php?q=boarder/ajax_call&section=get_messages&is_boarder_page=1&offset=50&lmid=58017099&isp=1&gmt=my_post&uid=neha0103&pgno=3
	input_dict = json.loads(x.read())
	output_dict1 = [x for x in input_dict if x['repost_by_user'] == None]
	for res3 in output_dict1:  
		if any(res3['user_id']+'  ----  '+res3['message'] in s for s in mylist):
			t=23
		else:
			mylist.append(res3['user_id']+'  ----  '+res3['message'])
			print(res3['user_id']+'  ----  '+res3['date_str']+'  ----  '+res3['topic']+'  ----  '+res3['message'])
#		print(res3['user_id']+'  ----  '+res3['date_str']+'  ----  '+res3['topic'] +'  ----  '+ res3['message'])
	output_dict = [x for x in input_dict if x['replyto_user'] == '']
	for res3 in output_dict:  
		#if mylist.index(res3['message']) <= 0:
		if any(res3['user_id']+'  ----  '+res3['message'] in s for s in mylist):
			t=23
		else:
			mylist.append(res3['user_id']+'  ----  '+res3['message'])
			print(res3['user_id']+'  ----  '+res3['date_str']+'  ----  '+res3['topic']+'  ----  '+res3['message'])
			

	x = urllib.request.urlopen('http://mmb.moneycontrol.com/index.php?q=boarder/ajax_call&section=get_messages&is_boarder_page=1&offset=&lmid=&isp=0&gmt=my_post&uid=girijaequities&pgno=1',proxies)
	input_dict = json.loads(x.read())
	output_dict = [x for x in input_dict if x['replyto_user'] == '']
	for res3 in output_dict:  print(res3['user_id']+'  ----  '+res3['date_str']+'  ----  '+res3['topic']+'  ----  '+res3['message'])
	output_dict1 = [x for x in input_dict if x['repost_by_user'] == None]
	for res3 in output_dict1:  print(res3['user_id']+'  ----  '+res3['date_str']+'  ----  '+res3['topic'] +'  ----  '+ res3['message'])

	x = urllib.request.urlopen('http://mmb.moneycontrol.com/index.php?q=boarder/ajax_call&section=get_messages&is_boarder_page=1&offset=&lmid=&isp=0&gmt=my_post&uid=joshy969&pgno=1',proxies)
	input_dict = json.loads(x.read())
	output_dict = [x for x in input_dict if x['replyto_user'] == '']
	for res3 in output_dict:  print(res3['user_id']+'  ----  '+res3['date_str']+'  ----  '+res3['topic']+'  ----  '+res3['message'])
	output_dict1 = [x for x in input_dict if x['repost_by_user'] == None]
	for res3 in output_dict1:  print(res3['user_id']+'  ----  '+res3['date_str']+'  ----  '+res3['topic'] +'  ----  '+ res3['message'])


	x = urllib.request.urlopen('http://www.mmb.moneycontrol.com/index.php?q=boarder/ajax_call&section=get_messages&is_boarder_page=1&offset=&lmid=&isp=0&gmt=my_post&uid=ankita-jackpotpicks&pgno=1',proxies)
	input_dict = json.loads(x.read())
	output_dict = [x for x in input_dict if x['replyto_user'] == '']
	for res3 in output_dict:  print(res3['user_id']+'  ----  '+res3['date_str']+'  ----  '+res3['topic']+'  ----  '+res3['message'])
	output_dict1 = [x for x in input_dict if x['repost_by_user'] == None]
	for res3 in output_dict1:  print(res3['user_id']+'  ----  '+res3['date_str']+'  ----  '+res3['topic'] +'  ----  '+ res3['message'])
	time.sleep (30)