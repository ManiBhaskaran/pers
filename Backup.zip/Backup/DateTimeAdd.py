import datetime
now = datetime.datetime.now()
now_plus_10 = now + datetime.timedelta(minutes = 10)
day=15
month=2
year=2018
do = datetime.datetime(year,month,day,9,15)
i=1
while(i<20):
    ndate = do + datetime.timedelta(minutes = 60)
    print(ndate.strftime("%m-%d-%Y %H:%M"))
    do=ndate
    i=i+1
    #print(do.weekday())
    #print(str(do.hour)+ " - " + str(do.minute))
    if do.hour>=15 or (do.hour>=15 and do.minute>30):
        d1=1
        if(do.weekday()==4):
            d1=3
        tdo=do+datetime.timedelta(days=d1)
        do = datetime.datetime(tdo.year, tdo.month, tdo.day, 8, 15)

