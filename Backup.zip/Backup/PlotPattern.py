import numpy as np
import matplotlib.pyplot as pp
import pandas as pd
import seaborn
import urllib.request
#%matplotlib inline
#data = read_datafile('C:/Temp/DataSets/Fortis.csv')
spy = pd.read_csv('C:/Temp/DataSets/Fortis.csv',parse_dates=['Date'])
spy.head()
spy = spy.sort_values(by='Date')
spy.set_index('Date',inplace=True)
spy['Close'].plot(figsize=(16, 12))

#spy.truncate(before='2015-01-01')['Close'].plot(figsize=(16, 12))