from candlestick import candlestick

import pandas as pd
import datetime
import json
from datetime import timedelta  
import requests
from dateutil.parser import parse
import jhtalib as ta
from pyquery import PyQuery    
from ehp import *
from dateutil.parser import parse
import numpy as np


def Check(tdaily,Signal,DateIndex,Margin,Stoploss,SearchData):
    global Profit
    #tdaily=CrudeDf30Min
    #SearchData=CrudeDf15Min
    #Margin=0.005
    #DateIndex=482
    #Signal="Buy"
    DefaultDate=datetime.datetime.now()
    tdaily['BuyTime']=pd.Series(DefaultDate,index=tdaily.index)
    tdaily['BuyTargetTime']=pd.Series(DefaultDate,index=tdaily.index)
    tdaily['BuyStopLossTime']=pd.Series(DefaultDate,index=tdaily.index)
    tdaily['SellTime']=pd.Series(DefaultDate,index=tdaily.index)
    tdaily['SellTargetTime']=pd.Series(DefaultDate,index=tdaily.index)
    tdaily['SellStopLossTime']=pd.Series(DefaultDate,index=tdaily.index)
    tdaily['LastPrice']=pd.Series(None,index=tdaily.index)
    tdaily['BuyHit']=pd.Series(0,index=tdaily.index)
    tdaily['SellHit']=pd.Series(0,index=tdaily.index)
#if True:
    #daily.iloc[DateIndex]['Date']
    tdaily.iloc[DateIndex]
    aDate=list(tdaily[DateIndex+1:][:1]['Date'])[0]
    #SpecificDate=data[ (data['Date/Time']>daily.iloc[DateIndex-1]['Date']) 
    #& (data['Date/Time']<daily.iloc[DateIndex-2]['Date'])]
    SpecificDate=SearchData[SearchData['Date']>=aDate]
    #(data['Date']>daily.iloc[100]['Date'] and
    #data.set_index('Date/Time')
    #SpecificDate['Date/Time']
    #print(len(SpecificDate))
    isBuyProcess=True
    isSellProcess=True
    
    Tollerance=.01
    #if(Signal=="Buy"):
    #BuyP=tdaily.iloc[DateIndex]['close']+Tollerance
    BuyP=tdaily.iloc[DateIndex+1]['open']
    BuyT=BuyP*(1+Margin)
    #BuySL=tdaily.iloc[DateIndex-2]['low']
    BuySL=BuyP*(1-Stoploss)
    
    BuyPT=SpecificDate[(SpecificDate['high']>=BuyP-Tollerance) & (SpecificDate['low']<=BuyP+Tollerance)]
    BuyTT=SpecificDate[(SpecificDate['high']>=BuyT-Tollerance) & (SpecificDate['low']<=BuyT+Tollerance)]
    BuySLT=SpecificDate[(SpecificDate['high']>=BuySL-Tollerance) & (SpecificDate['low']<=BuySL+Tollerance)]
    
#else:    
    #SellP=tdaily.iloc[DateIndex]['close']-Tollerance
    SellP=tdaily.iloc[DateIndex+1]['open']
    SellT=SellP*(1-Margin)
    #SellSL=tdaily.iloc[DateIndex-2]['high']
    SellSL=SellP*(1+Stoploss)
    
    SellPT=SpecificDate[(SpecificDate['high']>=SellP-Tollerance) & (SpecificDate['low']<=SellP+Tollerance)]
    SellTT=SpecificDate[(SpecificDate['high']>=SellT-Tollerance) & (SpecificDate['low']<=SellT+Tollerance)]
    SellSLT=SpecificDate[(SpecificDate['high']>=SellSL-Tollerance) & (SpecificDate['low']<=SellSL+Tollerance)]
    #data=data1
    #data.loc[SpecificDate]['Date/Time']
    
    
    if(Signal=="Buy"):
        isSellProcess=False
        print(str(BuyP) +  "  ===============  " + str(BuyT) + " ======== "+ str(BuySL))
    else:
        isBuyProcess=False
        print(str(SellP) +  "  ===============  " + str(SellT) + " ======== "+ str(SellSL))
    
    
    
    BuyHit=False
    SellHit=False
    #if len(BuyPT)>0:
    #    print("Buy Price At : " + str(BuyPT.iloc[0]['Date/Time']))
    #    if len(BuyTT)>0:
    #        print("Buy Target At : "+ str(BuyTT.iloc[0]['Date/Time']))
    #        print("Total Profit :" + str(BuyT-BuyP))
    #    if len(BuySLT)>0:
    #        print("Buy Stop loss At : " + str(BuySLT.iloc[0]['Date']))
    #        print("Total Loss:" + str(BuySL-BuyP))
    
    

    #if( len(BuyPT)>0 and len(SellPT)>0):
    #    isBuyProcess=(BuyPT.iloc[0]['Date']<SellPT.iloc[0]['Date'])
    #    isSellProcess=(BuyPT.iloc[0]['Date']>SellPT.iloc[0]['Date'])
   
    if(len(BuyPT)>0):
        tdaily['BuyTime'][DateIndex]=BuyPT.iloc[0]['Date']
    if(len(BuyTT)>0):
        tdaily['BuyTargetTime'][DateIndex]=BuyTT.iloc[0]['Date']
    if(len(BuySLT)>0):
        tdaily['BuyStopLossTime'][DateIndex]=BuySLT.iloc[0]['Date']    
    if(len(SellPT)>0):
        tdaily['SellTime'][DateIndex]=SellPT.iloc[0]['Date']
    if(len(SellTT)>0):
        tdaily['SellTargetTime'][DateIndex]=SellTT.iloc[0]['Date']
    if(len(SellSLT)>0):
        tdaily['SellStopLossTime'][DateIndex]=SellSLT.iloc[0]['Date']    
            
        
    if (len(BuyPT)>0 and isBuyProcess):
        print("Buy Price at : " + str(BuyPT.iloc[0]['Date']))
        tdaily['BuyTime'][DateIndex]=BuyPT.iloc[0]['Date']
        if len(BuyTT)>0:
            print("Buy Target at : " + str(BuyTT.iloc[0]['Date']))
            tdaily['BuyTargetTime'][DateIndex]=BuyTT.iloc[0]['Date']
            if len(BuySLT)<=0:
                if(BuyPT.iloc[0]['Date']<=BuyTT.iloc[0]['Date']):
                    print("*********Buy Total Profit :" + str(BuyT-BuyP))
                    BuyHit=True
                    tdaily['BuyHit'][DateIndex]=BuyT-BuyP
                else:
                    print("Total Value : "+ str(SpecificDate.iloc[len(SpecificDate)-30]['open']-BuyP))
                    tdaily['BuyHit'][DateIndex]=SpecificDate.iloc[len(SpecificDate)-30]['open']-BuyP
            else:
                if(BuyPT.iloc[0]['Date']<=BuyTT.iloc[0]['Date']) and (BuyTT.iloc[0]['Date']<=BuySLT.iloc[0]['Date']):
                    print("*****Buy Total Profit :" + str(BuyT-BuyP))
                    BuyHit=True
                    tdaily['BuyHit'][DateIndex]=BuyT-BuyP
                else:
                    print("Buy Stop Losst at : "+str(BuySLT.iloc[0]['Date']))
                    tdaily['BuyStopLossTime'][DateIndex]=BuySLT.iloc[0]['Date']
                    if((BuyPT.iloc[0]['Date']<=BuyTT.iloc[0]['Date']) and (BuySLT.iloc[0]['Date']<=BuyTT.iloc[0]['Date'])):
                        print("Buy Total Profit :" + str(BuyT-BuyP))
                        BuyHit=True
                        tdaily['BuyHit'][DateIndex]=BuyT-BuyP
                    else:
                        print("Buy Total loss :" + str(BuySL-BuyP))
                        tdaily['BuyHit'][DateIndex]=BuySL-BuyP
            
        elif (len(BuySLT)>0):
            print("Buy Stop Loss at : " + str(BuySLT.iloc[0]['Date']))
            tdaily['BuyStopLossTime'][DateIndex]=BuySLT.iloc[0]['Date']
            print("Buy Total loss :" + str(BuySL-BuyP))
            tdaily['BuyHit'][DateIndex]=BuySL-BuyP
            if len(BuyTT)>0:
                if(BuySLT.iloc[0]['Date']<=BuyTT.iloc[0]['Date']):
                    print("Buy Total loss :" + str(BuySL-BuyP))
                    tdaily['BuyHit'][DateIndex]=BuySL-BuyP
                    tdaily['BuyStopLossTime'][DateIndex]=BuySLT.iloc[0]['Date']
        else:
            print("Total Value : "+ str(SpecificDate.iloc[len(SpecificDate)-30]['open']-BuyP))
            tdaily['BuyHit'][DateIndex]=SpecificDate.iloc[len(SpecificDate)-30]['open']-BuyP
            
    if len(SpecificDate) >0:       
        tdaily['LastPrice'][DateIndex]=SpecificDate.iloc[len(SpecificDate)-30]['open']
    
    if (isSellProcess and len(SellPT)>0):
        print("Sell Price at : " + str(SellPT.iloc[0]['Date']))
        tdaily['SellTime'][DateIndex]=SellPT.iloc[0]['Date']
        if len(SellTT)>0:
            print("Sell Target at : " + str(SellTT.iloc[0]['Date']))
            
            tdaily['SellTargetTime'][DateIndex]=SellTT.iloc[0]['Date']
            if len(SellSLT)<=0:
                if(SellPT.iloc[0]['Date']<=SellTT.iloc[0]['Date']):
                    print("Sell Total Profit :" + str(SellP-SellT))
                    SellHit=True
                    tdaily['SellHit'][DateIndex]=SellP-SellT
                else:
                    print("Total Value : "+ str(SellP-SpecificDate.iloc[len(SpecificDate)-30]['open']))
                    tdaily['SellHit'][DateIndex]=SpecificDate.iloc[len(SpecificDate)-30]['open']-SellP
            else:                
                if(SellPT.iloc[0]['Date']<=SellTT.iloc[0]['Date']) and (SellTT.iloc[0]['Date']<=SellSLT.iloc[0]['Date']):
                    print("Sell Total Profit :" + str(SellP-SellT))
                    SellHit=True
                    tdaily['SellHit'][DateIndex]=SellP-SellT
                else:    
                    print("Sell Stop Losst at 6: "+str(SellSLT.iloc[0]['Date']))
                    tdaily['SellStopLossTime'][DateIndex]=SellSLT.iloc[0]['Date']
                    if((SellPT.iloc[0]['Date']<=SellTT.iloc[0]['Date']) & (SellSLT.iloc[0]['Date']<=SellTT.iloc[0]['Date'])):
                        print("Sell Total Profit :-" + str(SellP-SellT))                        
                        tdaily['SellHit'][DateIndex]=SellP-SellT
                    else:
                        print("Sell Total loss 7:" + str(SellSL-SellP))
                        tdaily['SellHit'][DateIndex]=SellP-SellSL
            
        elif (len(SellSLT)>0):
            print("Sell Stop Loss at : " + str(SellSLT.iloc[0]['Date']))
            tdaily['SellStopLossTime'][DateIndex]=SellSLT.iloc[0]['Date']
            print("Sell Total loss 8:" + str(SellP-SellSL))
            tdaily['SellHit'][DateIndex]=SellP-SellSL
            if len(SellTT)>0:
                if(SellSLT.iloc[0]['Date']<=SellTT.iloc[0]['Date']):
                    print("Sell Total loss 9:" + str(SellP-SellSL))
                    tdaily['SellHit'][DateIndex]=SellP-SellSL
        else:
            print("Total Value : "+ str(SellP-SpecificDate.iloc[len(SpecificDate)-30]['open']))
            tdaily['SellHit'][DateIndex]=SpecificDate.iloc[len(SpecificDate)-30]['open']-SellP
    
    if(Signal=="Buy"):
        if(BuyHit==True):
            Profit=Profit+(BuyT-BuyP)
        else:
            Profit=Profit+(BuySL-BuyP)
        return BuyHit
    else:
        if(SellHit==True):
            Profit=Profit+(SellP-SellT)
        else:
            Profit=Profit+(SellP-SellSL)
        return SellHit
    #return tdaily
        #print("No Target hit")


def approximateEqual1(a, b):
    left=abs(round((a-b)*100)/100)
    right=round(a*100)/100000    
    return left <= right;


seconds_per_unit = {"S": 1, "M": 60, "H": 3600, "D": 86400, "W": 604800}
def N1(date,s,Operation):
    if (Operation=="+"):
        return date+datetime.timedelta(seconds=int(s[:-1]) * seconds_per_unit[s[-1]])
    else:
        return date-datetime.timedelta(seconds=int(s[:-1]) * seconds_per_unit[s[-1]])
        
def ProcessCandles(Df):
    Df = candlestick.bearish_engulfing(Df)
    Df = candlestick.bullish_engulfing(Df)
    Df = candlestick.three_inside_up(Df)
    Df = candlestick.three_inside_down(Df)
    Df = candlestick.three_outside_up(Df)
    Df = candlestick.three_outside_down(Df)
    Df['MovingAverageDown']=Df['low'].rolling(window=10).mean()
    Df['MovingAverageUp']=Df['high'].rolling(window=10).mean()
    Df['MovingAverage']=Df['close'].rolling(window=10).mean()
    return Df

TimeIntervals=[900]
TimeIntervals=[900,1800,3600,18000]
URLDict={}
StrTimeIntervals=['15M','30M','1H','5H']
CrudeURL='https://in.investing.com/common/modules/js_instrument_chart/api/data.php?pair_id=8849&pair_id_for_news=8849&chart_type=candlestick&pair_interval=INTERVAL&candle_count=CNT&events=patterns_only&volume_series=yes&period='
ZincURL='https://in.investing.com/common/modules/js_instrument_chart/api/data.php?pair_id=49794&pair_id_for_news=49794&chart_type=candlestick&pair_interval=INTERVAL&candle_count=CNT&events=patterns_only&volume_series=yes'
LeadURL='https://in.investing.com/common/modules/js_instrument_chart/api/data.php?pair_id=49784&pair_id_for_news=49784&chart_type=candlestick&pair_interval=INTERVAL&candle_count=CNT&events=patterns_only&volume_series=yes'
GoldURL='https://in.investing.com/common/modules/js_instrument_chart/api/data.php?pair_id=49778&pair_id_for_news=49778&chart_type=candlestick&pair_interval=INTERVAL&candle_count=CNT&events=patterns_only&volume_series=yes'
URL=GoldURL
#URL=LeadURL
#URL=CrudeURL
URLDict['Crude']=CrudeURL
#URLDict['Lead']=LeadURL
#URLDict['Zinc']=ZincURL
#URLDict['Gold']=GoldURL

for URL1 in URLDict:
    #print(URLDict[URL1])
    URL=URLDict[URL1]
    #N1(Res.index[0],'15M','-')
    
    # Find candles where inverted hammer is detected
    cnt=500
    Index=-1
    #if(True):
    for TimeInterval in TimeIntervals:
        Index=Index+1
        #TimeInterval=TimeIntervals[Index]
        rURL=URL.replace('INTERVAL',str(TimeInterval))
        rURL=rURL.replace('CNT',str(cnt))
        #print(rURL)
        PatternRead= requests.get(rURL,
                                  headers={#'Cookie':'adBlockerNewUserDomains=1545933873; optimizelyEndUserId=oeu1545933885326r0.8381196045732737; _ga=GA1.2.1293495785.1545933889; __gads=ID=d6c605f22775c384:T=1545933894:S=ALNI_MbV20pH_Ga4kGvz2QBdrKhnTQtDsg; __qca=P0-530564802-1545933894749; r_p_s_n=1; G_ENABLED_IDPS=google; _gid=GA1.2.2065111802.1547570711; SideBlockUser=a%3A2%3A%7Bs%3A10%3A%22stack_size%22%3Ba%3A1%3A%7Bs%3A11%3A%22last_quotes%22%3Bi%3A8%3B%7Ds%3A6%3A%22stacks%22%3Ba%3A1%3A%7Bs%3A11%3A%22last_quotes%22%3Ba%3A3%3A%7Bi%3A0%3Ba%3A3%3A%7Bs%3A7%3A%22pair_ID%22%3Bi%3A49774%3Bs%3A10%3A%22pair_title%22%3Bs%3A0%3A%22%22%3Bs%3A9%3A%22pair_link%22%3Bs%3A32%3A%22%2Fcommodities%2Fcrude-oil%3Fcid%3D49774%22%3B%7Di%3A1%3Ba%3A3%3A%7Bs%3A7%3A%22pair_ID%22%3Bs%3A4%3A%228849%22%3Bs%3A10%3A%22pair_title%22%3Bs%3A0%3A%22%22%3Bs%3A9%3A%22pair_link%22%3Bs%3A22%3A%22%2Fcommodities%2Fcrude-oil%22%3B%7Di%3A2%3Ba%3A3%3A%7Bs%3A7%3A%22pair_ID%22%3Bs%3A4%3A%228830%22%3Bs%3A10%3A%22pair_title%22%3Bs%3A0%3A%22%22%3Bs%3A9%3A%22pair_link%22%3Bs%3A17%3A%22%2Fcommodities%2Fgold%22%3B%7D%7D%7D%7D; PHPSESSID=t127q9ns2htigac1b5j8lr2tdg; geoC=IN; comment_notification_204870192=1; gtmFired=OK; StickySession=id.51537812219.831in.investing.com; billboardCounter_56=1; nyxDorf=MDFkNWcvMG03YGBtN3pmZTJnNGs0LTI5YGY%3D; _fbp=fb.1.1547680426904.1355133887; ses_id=Nng3dm5hMDg0cGpsNGU1NzRhZDcyMmFjYmJhazo%2FZHJlcTQ6ZTIwdmFuaiRubTklMjQ3NjM3ZmYxM2JrO2xnMjZlNzZuPTBtNDdqZTQzNWE0Y2Q5MjJhamIxYWo6aWQ%2FZTc0N2UxMGZhZGpgbjM5YzIgNyszd2Z3MWNiMjt6ZyA2OTd2bj0wPzRhajA0NTVlNGFkOTI1YTJiamEwOmtkfGUu',
                                           'Referer':'https://in.investing.com/commodities/crude-oil-candlestick',
                                           'User-Agent':'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36'
                                           ,'X-Requested-With': 'XMLHttpRequest'
                                           }
                                  ) #GOLD
        #from lxml.html import parse
        
        PatternJson=PatternRead.json()
        
        JsonAr=[]
        for candle in PatternJson['candles']:
            JsonDict={}
            sTime=candle[0]/1000
            JsonDict['Date']=datetime.datetime.fromtimestamp(sTime).strftime('%Y-%m-%d %H:%M:%S')
            JsonDict['open']=candle[1]
            JsonDict['high']=candle[2]
            JsonDict['low']=candle[3]
            JsonDict['close']=candle[4]
            JsonDict['Interval']=StrTimeIntervals[Index]
            JsonAr.append(JsonDict)
        if(Index==0):
            CrudeDf15Min=pd.read_json(json.dumps(JsonAr))
        elif(Index==1):
            CrudeDf30Min=pd.read_json(json.dumps(JsonAr))
        elif(Index==2):
            CrudeDf1H=pd.read_json(json.dumps(JsonAr))        
        else:
            CrudeDf5H=pd.read_json(json.dumps(JsonAr))

CrudeDf15Min=ProcessCandles(CrudeDf15Min)
CrudeDf30Min=ProcessCandles(CrudeDf30Min)
CrudeDf1H=ProcessCandles(CrudeDf1H)
CrudeDf5H=ProcessCandles(CrudeDf5H)

# =============================================================================
#         JsonAr=[]
#         for event in PatternJson['events']['news']:   
#         #event=PatternJson['events']['news'][0]
#         #event=PatternJson['events']['news'][3]
#             JsonDict={}
#             htmltext=event['text']
#             html = Html()
#             dom = html.feed(htmltext)
#             strTime=datetime.datetime.fromtimestamp(event['time']).strftime('%Y-%m-%d %H:%M:%S')
#             Patterns=[]
#             for ind in dom.find('table'):
#                 
#                 PatternString=ind.text().replace('Bearish reversal','\tBearish reversal\t').replace('Bullish reversal','\tBullish reversal\t').replace('Reliability:','').replace('\xa0','').replace('Bullish continuation','\tBullish continuation\t').replace('Bearish continuation','\tBearish continuation\t')
#                 Patterns.append(PatternString)
#                 print(StrTimeIntervals[Index]+"\t"+strTime+"\t"+PatternString)            
#             JsonDict['Interval']=StrTimeIntervals[Index]
#             JsonDict['Date']=strTime
#             PatternI=0
#             JsonDict['TotalPattern']=len(Patterns)
#             #if(len(Patterns)>0):
#                 #JsonDict['PatternType']=Patterns[0].split('\t')[1]
#             for Pattern in Patterns:
#                 PatternI=PatternI+1
#                 PatternAr=Pattern.split('\t')
#                 JsonDict['Pattern'+str(PatternI)+'Name']=PatternAr[0]
#                 JsonDict['Pattern'+str(PatternI)+'Type']=PatternAr[1]
#                 JsonDict['Pattern'+str(PatternI)+'Reliability']=PatternAr[2]
#                 
#             JsonAr.append(JsonDict)
#             
#         df1=pd.read_json(json.dumps(JsonAr))
#         if(Index!=0):
#             df=df.append(df1)
#         else:
#             df=df1
#     df1=df.sort_values(by='Date')
#     df1['PDate']=False
#     df1['NDate']=False
#     
#     #df1[N1(df1['Date'],df1['Interval'],'-').isin(df1['Date'])]
#     for Interval in StrTimeIntervals:   
#         df0=df1[df1['Interval']==Interval]
#         i=0
#         while i<len(df0):
#             df1['PDate'] = np.where((df1['Date']==N1(df0.iloc[i]['Date'],df0.iloc[i]['Interval'],'+')) & (df1['Interval']==df0.iloc[i]['Interval'])  & (df1['Pattern1Type']==df0.iloc[i]['Pattern1Type']), True,df1['PDate'])
#             df1['NDate'] = np.where((df1['Date']==N1(df0.iloc[i]['Date'],df0.iloc[i]['Interval'],'-')) & (df1['Interval']==df0.iloc[i]['Interval']) & (df1['Pattern1Type']==df0.iloc[i]['Pattern1Type']), True,df1['NDate'])
#             i=i+1        
#         #df1['NDate'] 
#         #df10=df0[(df0['Date']==N1(df0.iloc[i]['Date'],df0.iloc[i]['Interval'],'+')) ]
#         #df11=df0[df0['Date']==N1(df0.iloc[i]['Date'],df0.iloc[i]['Interval'],'-')]
#         #print(len(df10))            
#     #N1(Res.index[0],'15M','-')
#     #df[['Interval','Date','PatternType']].sort_values(by='Date')
#     #df[['Date','Pattern1Name','Interval']].sort_values(by='Date')
#     #df.to_csv('C:/ReadMoneycontrol/Crude/Patterns.csv',sep=',',encoding='utf-8')    
#     f = open("C:\\ReadMoneycontrol\\Crude\\"+URL1+"_Output.html", "w")
#     f.write(df1.to_html(classes=None, border=None, justify=None))    
#     f.close()
#     #df1.to_csv("C:\ReadMoneycontrol\Crude\\"+URL1+"_Output.csv',sep=',',encoding='utf-8')    
#     df2=df1[(df1['Pattern1Reliability']=='High')]
#     df2=df2[df2['Pattern1Type']==df2['Pattern2Type']]    
#     #f1 = open("C:\\ReadMoneycontrol\\Crude\Output2.html", "w")
#     #f1.write(df1.to_html(classes=None, border=None, justify=None))
#     #f1.close()   
#     Res=df1.groupby(['Date'])['Date'].size()
#     Res=Res[Res>1]
#     Res.index
#     df3=df1[df1['Date'].isin(Res.index)]
#     f1 = open("C:\\ReadMoneycontrol\\Crude\\"+URL1+"_Output1.html", "w")
#     f1.write(df3.to_html(classes=None, border=None, justify=None))
#     f1.write("<HR>")
#     f1.write(df2.to_html(classes=None, border=None, justify=None))
#     
#     for Interval in StrTimeIntervals:   
#         df0=df1[(df1['Interval']==Interval) & (df1['PDate'] | df1['NDate'])]
#         f1.write("<HR>")   
#         f1.write("<Center><H4>"+Interval+"</Center></H4>")   
#         f1.write(df0.to_html(classes=None, border=None, justify=None))    
#     f1.close()
# 
# =============================================================================
#pq = PyQuery(html)
#tag = pq('div#class')
#tag.text()
#htmli=parse(html)
#for div in doc.cssselect('a'):
#    print '%s: %s' % (div.text_content(), div.get('href'))

#================================
        
        


CrudeDf30Min.iloc[27]
CrudeDf30Min.iloc[88]

CrudeDf15Min.iloc[355]

CrudeDf30Min['MovingAverageDown']=CrudeDf30Min['low'].rolling(window=10).mean()
CrudeDf30Min['MovingAverageUp']=CrudeDf30Min['high'].rolling(window=10).mean()
CrudeDf30Min['MovingAverage']=CrudeDf30Min['close'].rolling(window=10).mean()

CrudeDf30Min[CrudeDf30Min['ThreeInsideUp']==True]
CrudeDf30Min[CrudeDf30Min['ThreeInsideDown']==True]

CrudeDf30Min[(CrudeDf30Min['ThreeInsideDown']==True) &
             (CrudeDf30Min['MovingAverage'] < CrudeDf30Min['close'])]


CrudeDf30Min[ (CrudeDf30Min['ThreeInsideUp']==True) &
             (CrudeDf30Min['MovingAverage'] > CrudeDf30Min['open'])
             ]


TempData=CrudeDf15Min[ (CrudeDf15Min['ThreeInsideUp']==True) &
             (CrudeDf15Min['MovingAverage'] > CrudeDf15Min['open'])
             ]

TempData=CrudeDf15Min[ (CrudeDf15Min['ThreeInsideUp']==True) &
             (CrudeDf15Min['MovingAverage'] > CrudeDf15Min['open'])
             ]

TempData=CrudeDf15Min[ (CrudeDf15Min['ThreeInsideUp']==True) 
             ]


TempData=CrudeDf15Min[(CrudeDf15Min['ThreeInsideDown']==True) &
             (CrudeDf15Min['MovingAverage'] < CrudeDf15Min['close'])]


TempData=CrudeDf15Min[ (CrudeDf15Min['ThreeOutsideUp']==True) &
             (CrudeDf15Min['MovingAverage'] > CrudeDf15Min['open'])
             ]
TempData=CrudeDf15Min[(CrudeDf15Min['ThreeOutsideDown']==True) &
             (CrudeDf15Min['MovingAverage'] < CrudeDf15Min['close'])]



TotalTempData=len(TempData)
PriceDiff={}
ProfitPerPercent={}
Price=0.0025
while(Price<0.02):
    Profit=0
    i=0
    BuySucceed=0
    while(i<TotalTempData-1):        
        print(str(i) + " -- "+ str(TempData.index[i]))
        SignalStatus=Check(CrudeDf15Min,"Buy",TempData.index[i],Price,Price*1.5,CrudeDf15Min)
        if(SignalStatus==True):
            BuySucceed=BuySucceed+1        
        i=i+1
    PriceDiff[Price]=BuySucceed/(TotalTempData-1)*100
    ProfitPerPercent[Price]=Profit
    Price=Price+0.0025

    #print("Out of " + str(TotalTempData) + " Buy Signals " + str(BuySucceed)+" got achieved")    



Check(CrudeDf30Min,"Sell",431,0.0025,CrudeDf15Min)

Check(CrudeDf30Min,"Sell",372,0.005,CrudeDf15Min)

CrudeDf30Min = candlestick.doji_star(CrudeDf30Min)
CrudeDf30Min = candlestick.bearish_harami(CrudeDf30Min)
CrudeDf30Min = candlestick.bullish_harami(CrudeDf30Min)
CrudeDf30Min = candlestick.doji(CrudeDf30Min)

CrudeDf30Min[CrudeDf30Min['Date']>=CrudeDf15Min.iloc[163]['Date']][:1]
CrudeDf30Min.iloc[427]
CrudeDf30Min.iloc[428]

CrudeDf30Min[ (CrudeDf30Min['ThreeOutsideUp']==True) &
             (CrudeDf30Min['MovingAverage'] > CrudeDf30Min['open'])
             ]

        
#=================

    
CrudeDf15Min = candlestick.bearish_engulfing(CrudeDf15Min)
CrudeDf15Min = candlestick.bullish_engulfing(CrudeDf15Min)
CrudeDf15Min = candlestick.three_inside_up(CrudeDf15Min)
CrudeDf15Min = candlestick.three_inside_down(CrudeDf15Min)
CrudeDf15Min = candlestick.three_outside_up(CrudeDf15Min)
CrudeDf15Min = candlestick.three_outside_down(CrudeDf15Min)

CrudeDf15Min.iloc[163]['Date']
CrudeDf15Min.iloc[88]

CrudeDf15Min['MovingAverageDown']=CrudeDf15Min['low'].rolling(window=10).mean()
CrudeDf15Min['MovingAverageUp']=CrudeDf15Min['high'].rolling(window=10).mean()
CrudeDf15Min['MovingAverage']=CrudeDf15Min['close'].rolling(window=10).mean()

CrudeDf15Min[CrudeDf15Min['ThreeInsideUp']==True]
CrudeDf15Min[CrudeDf15Min['ThreeInsideDown']==True]

CrudeDf15Min[(CrudeDf15Min['ThreeInsideDown']==True) &
             (CrudeDf15Min['MovingAverage'] < CrudeDf15Min['close'])]


CrudeDf15Min[ (CrudeDf15Min['ThreeInsideUp']==True) &
             (CrudeDf15Min['MovingAverage'] > CrudeDf15Min['open'])
             ]

CrudeDf15Min = candlestick.doji_star(CrudeDf15Min)
CrudeDf15Min = candlestick.bearish_harami(CrudeDf15Min)
CrudeDf15Min = candlestick.bullish_harami(CrudeDf15Min)
CrudeDf15Min = candlestick.doji(CrudeDf15Min)

CrudeDf15Min[CrudeDf15Min['ThreeOutsideUp']==True]
CrudeDf15Min[ (CrudeDf15Min['ThreeOutsideUp']==True) &
             (CrudeDf15Min['MovingAverage'] > CrudeDf15Min['open'])
             ]
CrudeDf15Min.iloc[464]
CrudeDf15Min.iloc[478]
CrudeDf15Min[CrudeDf15Min['ThreeOutsideDown']==True]

CrudeDf15Min
CrudeDf15Min[CrudeDf15Min['BullishEngulfing']==True]
CrudeDf15Min.columns
CrudeDf15Min[CrudeDf15Min['BearishEngulfing']==True]
CrudeDf15Min[CrudeDf15Min['BullishEngulfing']==True]
CrudeDf15Min['high']
CrudeDf15Min['high'][:-5]

#/******

pd.options.mode.chained_assignment = "warn"
Check(CrudeDf15Min,"Buy",201,0.005)
CrudeDf15Min.iloc[201]

#/***
CandleID=478    
candle=CrudeDf15Min.iloc[CandleID]
prev_candle=CrudeDf15Min.iloc[CandleID-1]
prev1_candle=CrudeDf15Min.iloc[CandleID-2]
C = candle['close']
O = candle['open']
H = candle['high']
L = candle['low']

C1 = prev_candle['close']
O1 = prev_candle['open']
H1 = prev_candle['high']
L1 = prev_candle['low']

C2 = prev1_candle['close']
O2 = prev1_candle['open']
H2 = prev1_candle['high']
L2 = prev1_candle['low']
        
#CrudeDf15Min.iloc[478]['Date']
isThreeOutsideUp=((O2>C2) and (C1>O1) and (C1>=O2) and (C2>=O1) and ((C1-O1)>(O2-C2)) and  (C>O) and  (C>C1))



#for event in PatternJson['events']

# =============================================================================
# 
# #candles5min = requests.get('https://kitecharts-aws.zerodha.com/api/chart/54177543/5minute?public_token=xvRMm5wUcxEw5Vild2RBkk0m9KVhdqg9&user_id=XE8692&api_key=kitefront&access_token=Todn6f7bOopy64LBvwyyNM7i5U412AD5&from=2018-12-29&to=2019-01-04&ciqrandom=1546533870063')
# candles5min = requests.get('https://kitecharts-aws.zerodha.com/api/chart/53750791/5minute?public_token=SkZ0ia2EC0fQfDpN8yp9pH0A0oKWrHoi&user_id=XE8692&api_key=kitefront&access_token=HSQso4YdNMdAOS86Qpa447WO9XleWEpZ&from=2019-01-10&to=2019-01-15&ciqrandom=1547568611167') #GOLD
# candles5min_dict = candles5min.json()['data']['candles']
# 
# candles5min_df = pd.DataFrame(candles5min_dict,
#                           columns=['T', 'open', 'high', 'low', 'close', 'V'])
# 
# #candles5min_df['T'] = pd.to_datetime(candles5min_df['T'], unit='ms')
# List_ = list(candles5min_df['T'])
# List_ = [parse(x) for x in List_]
# candles5min_df['T']=pd.Series([x for x in List_],index=candles5min_df.index)
# 
# #ta.CDLSHOOTINGSTAR(candles5min_df)
# #print(ta.RSI(candles5min_df,10))
# #print(ta.SMA(candles5min_df,10))
# #upper, middle, lower = ta.BBANDS(candles5min_df,50)
# 
# candles5min_df.iloc[len(candles5min_df)-1]
# 
# target = 'InvertedHammers'
# candles5min_df = candlestick.inverted_hammer(candles5min_df, target='InvertedHammers')
# candles5min_df = candlestick.bearish_inverted_hammer_stick(candles5min_df)
# #candlestick.bearish_inverted_hammer_stick(candles5min_df)
# candlestick.bearish_marbozu(candles5min_df)
# #ba=candles15min_df
# 
# #ba=candles10min_df
# #test=candles15min_df[len(candles15min_df)-30:]
# #ba=candlestick.bearish_harami_cross(test)
# #ba=candlestick.bearish_spinning_top(candles15min_df)
# #ba1[ba1['BearishSpinningTop']==True]
# #ba['MovingAverageDown']=ba['low'].rolling(window=10).mean()
# #ba['MovingAverageUp']=ba['high'].rolling(window=10).mean()
# #ba1.dtypes
# 
# #ba1=candlestick.bearish_spinning_top(ba)
# 
# #ba[['open','MovingAverageDown']]
# candles5min_df['MovingAverageDown']=candles5min_df['low'].rolling(window=10).mean()
# candles5min_df['MovingAverageUp']=candles5min_df['high'].rolling(window=10).mean()
# candles5min_df=candlestick.bearish_spinning_top(ba)
# candles5min_df = candlestick.doji_star(candles5min_df)
# candles5min_df = candlestick.bearish_harami(candles5min_df)
# candles5min_df = candlestick.bullish_harami(candles5min_df)
# candles5min_df = candlestick.dark_cloud_cover(candles5min_df)
# candles5min_df = candlestick.doji(candles5min_df)
# candles5min_df = candlestick.dragonfly_doji(candles5min_df)
# candles5min_df = candlestick.hanging_man(candles5min_df)
# candles5min_df = candlestick.gravestone_doji(candles5min_df)
# candles5min_df = candlestick.bearish_engulfing(candles5min_df)
# candles5min_df = candlestick.bullish_engulfing(candles5min_df)
# candles5min_df = candlestick.hammer(candles5min_df)
# candles5min_df = candlestick.morning_star(candles5min_df)
# candles5min_df = candlestick.morning_star_doji(candles5min_df)
# candles5min_df = candlestick.piercing_pattern(candles5min_df)
# candles5min_df = candlestick.rain_drop(candles5min_df)
# candles5min_df = candlestick.rain_drop_doji(candles5min_df)
# candles5min_df = candlestick.star(candles5min_df)
# candles5min_df = candlestick.shooting_star(candles5min_df)
# 
# 
# candles10min = requests.get('https://kitecharts-aws.zerodha.com/api/chart/54177543/10minute?public_token=xvRMm5wUcxEw5Vild2RBkk0m9KVhdqg9&user_id=XE8692&api_key=kitefront&access_token=Todn6f7bOopy64LBvwyyNM7i5U412AD5&from=2018-12-29&to=2019-01-04&ciqrandom=1546533870063')
# candles10min_dict = candles10min.json()['data']['candles']
# 
# candles10min_df = pd.DataFrame(candles10min_dict,
#                           columns=['T', 'open', 'high', 'low', 'close', 'V'])
# 
# #candles10min_df['T'] = pd.to_datetime(candles10min_df['T'], unit='ms')
# List_ = list(candles10min_df['T'])
# List_ = [parse(x) for x in List_]
# candles10min_df['T']=pd.Series([x for x in List_],index=candles10min_df.index)
# 
# 
# 
# target = 'InvertedHammers'
# candles10min_df = candlestick.inverted_hammer(candles10min_df, target='InvertedHammers')
# candles10min_df = candlestick.doji_star(candles10min_df)
# candles10min_df = candlestick.bearish_harami(candles10min_df)
# candles10min_df = candlestick.bullish_harami(candles10min_df)
# candles10min_df = candlestick.dark_cloud_cover(candles10min_df)
# candles10min_df = candlestick.doji(candles10min_df)
# candles10min_df = candlestick.dragonfly_doji(candles10min_df)
# candles10min_df = candlestick.hanging_man(candles10min_df)
# candles10min_df = candlestick.gravestone_doji(candles10min_df)
# candles10min_df = candlestick.bearish_engulfing(candles10min_df)
# candles10min_df = candlestick.bullish_engulfing(candles10min_df)
# candles10min_df = candlestick.hammer(candles10min_df)
# candles10min_df = candlestick.morning_star(candles10min_df)
# candles10min_df = candlestick.morning_star_doji(candles10min_df)
# candles10min_df = candlestick.piercing_pattern(candles10min_df)
# candles10min_df = candlestick.rain_drop(candles10min_df)
# candles10min_df = candlestick.rain_drop_doji(candles10min_df)
# candles10min_df = candlestick.star(candles10min_df)
# candles10min_df = candlestick.shooting_star(candles10min_df)
# 
# 
# #candles15min = requests.get('https://kitecharts-aws.zerodha.com/api/chart/54177543/15minute?public_token=xvRMm5wUcxEw5Vild2RBkk0m9KVhdqg9&user_id=XE8692&api_key=kitefront&access_token=Todn6f7bOopy64LBvwyyNM7i5U412AD5&from=2018-12-29&to=2019-01-04&ciqrandom=1546533870063') #Crude
# candles15min = requests.get('https://kitecharts-aws.zerodha.com/api/chart/53750791/15minute?public_token=SkZ0ia2EC0fQfDpN8yp9pH0A0oKWrHoi&user_id=XE8692&api_key=kitefront&access_token=HSQso4YdNMdAOS86Qpa447WO9XleWEpZ&from=2019-01-10&to=2019-01-15&ciqrandom=1547568611167') #GOLD
# candles15min_dict = candles15min.json()['data']['candles']
# 
# candles15min_df = pd.DataFrame(candles15min_dict,
#                           columns=['T', 'open', 'high', 'low', 'close', 'V'])
# 
# #candles15min_df['T'] = pd.to_datetime(candles15min_df['T'], unit='ms')
# List_ = list(candles15min_df['T'])
# List_ = [parse(x) for x in List_]
# candles15min_df['T']=pd.Series([x for x in List_],index=candles15min_df.index)
# 
# candles15min_df = candlestick.inverted_hammer(candles15min_df, target='InvertedHammers')
# candles15min_df = candlestick.bearish_inverted_hammer_stick(candles15min_df)
# #candlestick.bearish_inverted_hammer_stick(candles5min_df)
# candlestick.bearish_marbozu(candles15min_df)
# 
# target = 'InvertedHammers'
# candles15min_df = candlestick.inverted_hammer(candles15min_df, target='InvertedHammers')
# candles15min_df = candlestick.doji_star(candles15min_df)
# candles15min_df = candlestick.bearish_harami(candles15min_df)
# candles15min_df = candlestick.bullish_harami(candles15min_df)
# candles15min_df = candlestick.dark_cloud_cover(candles15min_df)
# candles15min_df = candlestick.doji(candles15min_df)
# candles15min_df = candlestick.dragonfly_doji(candles15min_df)
# candles15min_df = candlestick.hanging_man(candles15min_df)
# candles15min_df = candlestick.gravestone_doji(candles15min_df)
# candles15min_df = candlestick.bearish_engulfing(candles15min_df)
# candles15min_df = candlestick.bullish_engulfing(candles15min_df)
# candles15min_df = candlestick.hammer(candles15min_df)
# candles15min_df = candlestick.morning_star(candles15min_df)
# candles15min_df = candlestick.morning_star_doji(candles15min_df)
# candles15min_df = candlestick.piercing_pattern(candles15min_df)
# candles15min_df = candlestick.rain_drop(candles15min_df)
# candles15min_df = candlestick.rain_drop_doji(candles15min_df)
# candles15min_df = candlestick.star(candles15min_df)
# candles15min_df = candlestick.shooting_star(candles15min_df)
# 
# print(candles15min_df[candles15min_df[target] == True][['T', target]])
# candles15min_df.iloc[171]['T']
# candles10min_df.iloc[257]['T']
# candles5min_df.iloc[513]['T']
# 
# 
# candles15min_df.iloc[201]['T']
# candles10min_df.iloc[302]['T']
# candles5min_df.iloc[601]['T']
# 
# candles15min_df.iloc[195]['T']
# candles10min_df.iloc[292]['T']
# candles5min_df.iloc[583]['T']
# 
# =============================================================================


