from candlestick.patterns.candlestick_finder import CandlestickFinder
from candlestick import candlestick

class BearishSpinningTop(CandlestickFinder):
    def __init__(self, target=None):
        super().__init__(self.get_class_name(), 2, target=target)

    def logic(self, idx):
        candle = self.data.iloc[idx]
        prev_candle = self.data.iloc[idx + 1 * self.multi_coeff]
        prev1_candle = self.data.iloc[idx + 2 * self.multi_coeff]

        close = candle[self.close_column]
        open = candle[self.open_column]
        high = candle[self.high_column]
        low = candle[self.low_column]
        
        C=close
        O=open
        H=high
        L=low
        #print(candle)
        Downtrend =  L < candle['MovingAverageDown'];
        Uptrend =  H > candle['MovingAverageUp'];

        prev_close = prev_candle[self.close_column]
        prev_open = prev_candle[self.open_column]
        prev_high = prev_candle[self.high_column]
        prev_low = prev_candle[self.low_column]

        bodyLength           = abs(close-open);
        upperShadowLength    = abs(high-open);
        lowerShadowLength    = abs(high-low);
        #isBearishSpinningTop = bodyLength < upperShadowLength and bodyLength < lowerShadowLength

        #isBearishSpinningTop = ((C>O) and ((H-L)>(3*(C-O))) and (((H-C)/(H-L))<.5) and (((O-L)/(H-L))<.5)) 
        isBearishSpinningTop = ((O>C) and ((H-L)>(3*(O-C))) and (((H-O)/(H-L))<.5) and (((C-L)/(H-L))<.5)) and Uptrend
        if(isBearishSpinningTop):
            print(candle)
        #AND Downtrend; 
        return isBearishSpinningTop;
    
        
        #candlestick.approximateEqual
        # return (prev_close > prev_open and
        #        abs(prev_close - prev_open) / (prev_high - prev_low) >= 0.7 and
        #        0.3 > abs(close - open) / (high - low) >= 0.1 and
        #        high < prev_close and
        #        low > prev_open)

        #return (prev_close > prev_open and
        #        prev_open <= close < open <= prev_close and
        #        open - close < prev_close - prev_open)