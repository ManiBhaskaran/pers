def fib(vdelta,input):
    return vdelta*input

def fibupper(vdelta,Low):
    ulimit={}
    i=200
    while(i<=2000):
        ulimit[i]=round(Low+(vdelta*i/1000),2)
        i=i+1
    return ulimit

def fiblower(vdelta,Low):
    llimit={}
    i=200
    while(i<=2000):
        llimit[i]=round(Low-(vdelta*i/1000),2)
        i=i+1
    return llimit
def mround(m):
    a=m*100
    b=a%10
    c=0
    if(b>=5 and b<=7):
        c=-1
        d=.05
    elif(b>=7):
        c=0
        d = 0
    else:
        c=0
        d=0
    return (round(a/10)+c)/10+d

Low=416.35
High=421.95
delta=High-Low
fupper=fibupper(delta,Low)
mround (100.28)
#print("23.6="+str(fupper[236]))
#print("138="+str(fupper[1380]))
#print("23.0=" + str(round(High-fib(delta,.236),2)))
#print("38.2=" + str(round(High-fib(delta,.382),2)))
#print("50=" + str(round(High-fib(delta,.5),2)))
#print("61.8=" + str(round(High-fib(delta,.618),2)))
#print("78.6=" + str(round(High-fib(delta,.786),2)))

#print("H23.0=" + str(round(Low+fib(delta,.236),2)))
#print("H38.2=" + str(round(Low+fib(delta,.382),2)))
#print("H50=" + str(round(Low+fib(delta,.5),2)))
#print("H61.8=" + str(round(Low+fib(delta,.618),2)))
#print("H78.6=" + str(round(Low+fib(delta,.786),2)))

#print("l23.0=" + str(round(Low-fib(delta,.236),2)))
#print("l38.2=" + str(round(Low-fib(delta,.382),2)))
#print("l50=" + str(round(Low-fib(delta,.5),2)))
#print("l61.8=" + str(round(Low-fib(delta,.618),2)))
#print("l78.6=" + str(round(Low-fib(delta,.786),2)))