# -*- coding: utf-8 -*-
"""
Created on Sun Jan 20 22:51:16 2019

@author: lalitha
"""


import pandas as pd
import datetime
import json
from datetime import timedelta  
import requests
from dateutil.parser import parse
import jhtalib as ta
from pyquery import PyQuery    
from ehp import *
from dateutil.parser import parse
import numpy as np

def approximateEqual1(a, b):
    left=abs(round((a-b)*100)/100)
    right=round(a*100)/100000    
    return left <= right;


seconds_per_unit = {"S": 1, "M": 60, "H": 3600, "D": 86400, "W": 604800}
def N1(date,s,Operation):
    if (Operation=="+"):
        return date+datetime.timedelta(seconds=int(s[:-1]) * seconds_per_unit[s[-1]])
    else:
        return date-datetime.timedelta(seconds=int(s[:-1]) * seconds_per_unit[s[-1]])
        
    


TimeIntervals=[900,1800,3600,18000]
URLDict={}
StrTimeIntervals=['15M','30M','1H','5H']
CrudeURL='https://in.investing.com/common/modules/js_instrument_chart/api/data.php?pair_id=8849&pair_id_for_news=8849&chart_type=candlestick&pair_interval=INTERVAL&candle_count=CNT&events=patterns_only&volume_series=yes&period='
ZincURL='https://in.investing.com/common/modules/js_instrument_chart/api/data.php?pair_id=49794&pair_id_for_news=49794&chart_type=candlestick&pair_interval=INTERVAL&candle_count=CNT&events=patterns_only&volume_series=yes'
LeadURL='https://in.investing.com/common/modules/js_instrument_chart/api/data.php?pair_id=49784&pair_id_for_news=49784&chart_type=candlestick&pair_interval=INTERVAL&candle_count=CNT&events=patterns_only&volume_series=yes'
GoldURL='https://in.investing.com/common/modules/js_instrument_chart/api/data.php?pair_id=49778&pair_id_for_news=49778&chart_type=candlestick&pair_interval=INTERVAL&candle_count=CNT&events=patterns_only&volume_series=yes'
URL=GoldURL
#URL=LeadURL
#URL=CrudeURL
URLDict['Crude']=CrudeURL
URLDict['Lead']=LeadURL
URLDict['Zinc']=ZincURL
URLDict['Gold']=GoldURL
FirstDataSet=True
for URL1 in URLDict:
    #print(URLDict[URL1])
    URL=URLDict[URL1]
    #N1(Res.index[0],'15M','-')
    
    # Find candles where inverted hammer is detected
    cnt=500
    Index=-1
    #if(True):
    for TimeInterval in TimeIntervals:
        Index=Index+1
        #TimeInterval=TimeIntervals[Index]
        rURL=URL.replace('INTERVAL',str(TimeInterval))
        rURL=rURL.replace('CNT',str(cnt))
        #print(rURL)
        PatternRead= requests.get(rURL,
                                  headers={#'Cookie':'adBlockerNewUserDomains=1545933873; optimizelyEndUserId=oeu1545933885326r0.8381196045732737; _ga=GA1.2.1293495785.1545933889; __gads=ID=d6c605f22775c384:T=1545933894:S=ALNI_MbV20pH_Ga4kGvz2QBdrKhnTQtDsg; __qca=P0-530564802-1545933894749; r_p_s_n=1; G_ENABLED_IDPS=google; _gid=GA1.2.2065111802.1547570711; SideBlockUser=a%3A2%3A%7Bs%3A10%3A%22stack_size%22%3Ba%3A1%3A%7Bs%3A11%3A%22last_quotes%22%3Bi%3A8%3B%7Ds%3A6%3A%22stacks%22%3Ba%3A1%3A%7Bs%3A11%3A%22last_quotes%22%3Ba%3A3%3A%7Bi%3A0%3Ba%3A3%3A%7Bs%3A7%3A%22pair_ID%22%3Bi%3A49774%3Bs%3A10%3A%22pair_title%22%3Bs%3A0%3A%22%22%3Bs%3A9%3A%22pair_link%22%3Bs%3A32%3A%22%2Fcommodities%2Fcrude-oil%3Fcid%3D49774%22%3B%7Di%3A1%3Ba%3A3%3A%7Bs%3A7%3A%22pair_ID%22%3Bs%3A4%3A%228849%22%3Bs%3A10%3A%22pair_title%22%3Bs%3A0%3A%22%22%3Bs%3A9%3A%22pair_link%22%3Bs%3A22%3A%22%2Fcommodities%2Fcrude-oil%22%3B%7Di%3A2%3Ba%3A3%3A%7Bs%3A7%3A%22pair_ID%22%3Bs%3A4%3A%228830%22%3Bs%3A10%3A%22pair_title%22%3Bs%3A0%3A%22%22%3Bs%3A9%3A%22pair_link%22%3Bs%3A17%3A%22%2Fcommodities%2Fgold%22%3B%7D%7D%7D%7D; PHPSESSID=t127q9ns2htigac1b5j8lr2tdg; geoC=IN; comment_notification_204870192=1; gtmFired=OK; StickySession=id.51537812219.831in.investing.com; billboardCounter_56=1; nyxDorf=MDFkNWcvMG03YGBtN3pmZTJnNGs0LTI5YGY%3D; _fbp=fb.1.1547680426904.1355133887; ses_id=Nng3dm5hMDg0cGpsNGU1NzRhZDcyMmFjYmJhazo%2FZHJlcTQ6ZTIwdmFuaiRubTklMjQ3NjM3ZmYxM2JrO2xnMjZlNzZuPTBtNDdqZTQzNWE0Y2Q5MjJhamIxYWo6aWQ%2FZTc0N2UxMGZhZGpgbjM5YzIgNyszd2Z3MWNiMjt6ZyA2OTd2bj0wPzRhajA0NTVlNGFkOTI1YTJiamEwOmtkfGUu',
                                           'Referer':'https://in.investing.com/commodities/crude-oil-candlestick',
                                           'User-Agent':'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36'
                                           ,'X-Requested-With': 'XMLHttpRequest'
                                           }
                                  ) #GOLD
        #from lxml.html import parse
        
        PatternJson=PatternRead.json()
        JsonAr=[]
        for event in PatternJson['events']['news']:   
        #event=PatternJson['events']['news'][0]
        #event=PatternJson['events']['news'][3]
            JsonDict={}
            htmltext=event['text']
            html = Html()
            dom = html.feed(htmltext)
            strTime=datetime.datetime.fromtimestamp(event['time']).strftime('%Y-%m-%d %H:%M:%S')
            Patterns=[]
            for ind in dom.find('table'):
                
                PatternString=ind.text().replace('Bearish reversal','\tBearish reversal\t').replace('Bullish reversal','\tBullish reversal\t').replace('Reliability:','').replace('\xa0','').replace('Bullish continuation','\tBullish continuation\t').replace('Bearish continuation','\tBearish continuation\t')
                Patterns.append(PatternString)
                print(StrTimeIntervals[Index]+"\t"+strTime+"\t"+PatternString)            
            JsonDict['Interval']=StrTimeIntervals[Index]
            JsonDict['Date']=strTime
            PatternI=0
            JsonDict['TotalPattern']=len(Patterns)
            #if(len(Patterns)>0):
                #JsonDict['PatternType']=Patterns[0].split('\t')[1]
            for Pattern in Patterns:
                PatternI=PatternI+1
                PatternAr=Pattern.split('\t')
                JsonDict['Pattern'+str(PatternI)+'Name']=PatternAr[0]
                JsonDict['Pattern'+str(PatternI)+'Type']=PatternAr[1]
                JsonDict['Pattern'+str(PatternI)+'Reliability']=PatternAr[2]
                
            JsonAr.append(JsonDict)
            
        df1=pd.read_json(json.dumps(JsonAr))
        if(Index!=0):
            df=df.append(df1)
        else:
            df=df1
    df1=df.sort_values(by='Date')
    if(("Pattern2Type" in list(df1.columns))==False):
        df1['Pattern2Type']=""
        df1['Pattern2Reliability']=""
        df1['Pattern2Name']=""
    df1['PDate']=False
    df1['NDate']=False
    
    #df1[N1(df1['Date'],df1['Interval'],'-').isin(df1['Date'])]
    for Interval in StrTimeIntervals:   
        df0=df1[df1['Interval']==Interval]
        i=0
        while i<len(df0):
            df1['PDate'] = np.where((df1['Date']==N1(df0.iloc[i]['Date'],df0.iloc[i]['Interval'],'+')) & (df1['Interval']==df0.iloc[i]['Interval'])  & (df1['Pattern1Type']==df0.iloc[i]['Pattern1Type']), True,df1['PDate'])
            df1['NDate'] = np.where((df1['Date']==N1(df0.iloc[i]['Date'],df0.iloc[i]['Interval'],'-')) & (df1['Interval']==df0.iloc[i]['Interval']) & (df1['Pattern1Type']==df0.iloc[i]['Pattern1Type']), True,df1['NDate'])
            i=i+1        
        #df1['NDate'] 
        #df10=df0[(df0['Date']==N1(df0.iloc[i]['Date'],df0.iloc[i]['Interval'],'+')) ]
        #df11=df0[df0['Date']==N1(df0.iloc[i]['Date'],df0.iloc[i]['Interval'],'-')]
        #print(len(df10))            
    #N1(Res.index[0],'15M','-')
    #df[['Interval','Date','PatternType']].sort_values(by='Date')
    #df[['Date','Pattern1Name','Interval']].sort_values(by='Date')
    #df.to_csv('C:/ReadMoneycontrol/Crude/Patterns.csv',sep=',',encoding='utf-8')    
    f = open("C:\\ReadMoneycontrol\\Crude\\"+URL1+"_Output.html", "w")
    if(len(df1)>0):
        f.write(df1.to_html(classes=None, border=None, justify=None))    
    f.close()
    #df1.to_csv("C:\ReadMoneycontrol\Crude\\"+URL1+"_Output.csv',sep=',',encoding='utf-8')    
    df2=df1[(df1['Pattern1Reliability']=='High')]
    df2=df2[df2['Pattern1Type']==df2['Pattern2Type']]    
    #f1 = open("C:\\ReadMoneycontrol\\Crude\Output2.html", "w")
    #f1.write(df1.to_html(classes=None, border=None, justify=None))
    #f1.close()   
    Res=df1.groupby(['Date'])['Date'].size()
    Res=Res[Res>1]
    Res.index
    df3=df1[df1['Date'].isin(Res.index)]
    f1 = open("C:\\ReadMoneycontrol\\Crude\\"+URL1+"_Output1.html", "w")
    if(len(df3)>0):
        f1.write(df3.to_html(classes=None, border=None, justify=None))
    if(len(df2)>0):
        f1.write("<HR>")
        f1.write(df2.to_html(classes=None, border=None, justify=None))
        
    for Interval in StrTimeIntervals:   
        df0=df1[(df1['Interval']==Interval) & (df1['PDate'] | df1['NDate'])]
        if(len(df0)>0):
            f1.write("<HR>")   
            f1.write("<Center><H4>"+Interval+"</Center></H4>")   
            f1.write(df0.to_html(classes=None, border=None, justify=None))    
    f1.close()
df3['Symbol']=URL1
cols = df3.columns.tolist()
cols = cols[0:1]+ cols[-1:] + cols[1:-1]
df3 = df3[cols]