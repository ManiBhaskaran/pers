__author__ = 'Liana'

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import statsmodels.api as sm
import scipy.stats as st
import numpy as np
import statsmodels.tsa.arima_process as ap
from statsmodels.tsa.arima_model import ARIMA
from math import sqrt
#from pyramid.arima import auto_arima
from statsmodels.graphics.api import qqplot
from dateutil import parser
# Important: It might be necessary to install xlrd
# pip install xlrd
from sklearn.metrics import mean_squared_error


newdf = pd.read_csv('C:/ReadMoneycontrol/Crude/CrudeOilPricesTimeSeriesAnalysis_Python-master/CrudeOilPricesTimeSeriesAnalysis_Python-master/data/Data.csv')

newdf['Date'] = pd.Series([pd.to_datetime(date) for date in newdf['Date']])


dates= pd.Series([pd.to_datetime(date) for date in newdf['Date']])
fig, ax = plt.subplots(figsize=(10,5))
plt.title('Crude Oil Prices')
plt.xlabel('Year')
plt.ylabel('Price [USD]')
ax.plot(dates, newdf['Open'], c='b', label='WTI')    #np.log()
plt.legend(loc='upper left')
plt.show()

newdf=newdf.sort_values(by='Date')
newdf['Pivot']=np.round(newdf['Low']+(newdf['High']-newdf['Low'])/2)
newdf['PredictedLow']=np.round(0)
newdf['PredictedHigh']=np.round(0)
newdf['PivotDiff']=np.round(newdf['High']-newdf['Low'])

#print newdf.head()


#===========================
#    TIME SERIES ANALYSIS
#===========================

# Building ARIMA model



from statsmodels.tsa.base.datetools import dates_from_range
AnewDF=newdf
trainWTI = newdf[:int(0.95*len(newdf))]
newdf.index
# 2012m12 means to start counting months from the 12th month of 2012
# To know the starting month, print trainWTI.head()
dates1 = dates_from_range('2001m1', length=len(trainWTI.Open))
dates_from_range('2001m1', length=100)[0]
dates1=AnewDF[0:len(trainWTI.Open)]['ID']
trainWTI.index = dates1 #newdf['Date'][:len(trainWTI.Open)]
trainWTI = trainWTI[['Open']]

AnewDF['ID']=pd.Series(a,index=newdf.index)
AnewDF[0:5]['ID']
print trainWTI.tail()

a=newdf.reset_index().index
TrainData=newdf['High'] #TrainData=newdf['Pivot']
TrainData.index=a
# Determine whether AR or MA terms are needed to correct any
# autocorrelation that remains in the series.
# Looking at the autocorrelation function (ACF) and partial autocorrelation (PACF) plots of the series,
# it's possible to identify the numbers of AR and/or MA terms that are needed
# In this example, the autocorrelations are significant for a large number of lags,
# but perhaps the autocorrelations at lags 2 and above are merely due to the propagation of the autocorrelation at lag 1.
# This is confirmed by the PACF plot.
# RULES OF THUMB:
# Rule 1: If the PACF of the differenced series displays a sharp cutoff and/or the lag-1 autocorrelation is positive,
# then consider adding an AR term to the model. The lag at which the PACF cuts off is the indicated number of AR terms.
# Rule 2: If the ACF of the differenced series displays a sharp cutoff and/or the lag-1 autocorrelation is negative,
# then consider adding an MA term to the model. The lag at which the ACF cuts off is the indicated number of MA terms.
fig1 = sm.graphics.tsa.plot_acf(trainWTI['Open'])
ax = fig1.add_subplot(111)
ax.set_xlabel("Lag")
ax.set_ylabel("ACF")
plt.show()

fig2 = sm.graphics.tsa.plot_pacf(trainWTI['Open'])
ax = fig2.add_subplot(111)
ax.set_xlabel("Lag")
ax.set_ylabel("PACF")
plt.show()


# Parameter freq indicates that monthly statistics is used
arima_mod100 = ARIMA(trainWTI, (2,0,0), freq='M').fit()  # try (1,0,1)
print(arima_mod100.summary())

# Check assumptions:
# 1) The residuals are not correlated serially from one observation to the next.
# The Durbin-Watson Statistic is used to test for the presence of serial correlation among the residuals
# The value of the Durbin-Watson statistic ranges from 0 to 4.
# As a general rule of thumb, the residuals are uncorrelated is the Durbin-Watson statistic is approximately 2.
# A value close to 0 indicates strong positive correlation, while a value of 4 indicates strong negative correlation.
print "==================== Durbin-Watson ====================="
print(sm.stats.durbin_watson(arima_mod100.resid.values))
print "========================================================"

fig = plt.figure(figsize=(10,5))
ax = fig.add_subplot(111)
ax = arima_mod100.resid.plot(ax=ax)
ax.set_title("Residual series")
plt.show()

resid = arima_mod100.resid

print "============== Residuals normality test ================"
print(st.normaltest(resid))
print "========================================================"

fig = plt.figure(figsize=(10,5))
ax = fig.add_subplot(111)
ax.set_title("Residuals test for normality")
fig = qqplot(resid, line='q', ax=ax, fit=True)
plt.show()

fig = plt.figure(figsize=(10,5))
ax = fig.add_subplot(111)
trainWTI.iloc[20]
#idt=parser.parse("Jan 31 2012")
output=arima_mod100.forecast()
output[0]
#train=trainWTI.loc['2018-01-01':'2110-01-01']
#test=trainWTI.loc['2110-01-01':]

#from statsmodels.tsa.seasonal import seasonal_decompose
#stepwise_model = arima_mod100(trainWTI, start_p=1, start_q=1,
#                           max_p=3, max_q=3, m=12,
#                           start_P=0, seasonal=True,
#                           d=1, D=1, trace=True,
#                           error_action='ignore',  
#                           suppress_warnings=True, 
#                           stepwise=True)


a=newdf.reset_index().index
TrainData=newdf['High'] #TrainData=newdf['Pivot']
TrainData.index=a

def predict(coef, history):
	yhat = 0.0
	for i in range(1, len(coef)+1):
		yhat += coef[i-1] * history[-i]
	return yhat

X = TrainData.values
size = int(len(X) * 0.98)
train, test = X[0:size], X[size:len(X)]
history = [x for x in train]
predictions = list()
for t in range(len(test)):
	model = ARIMA(history, order=(2,0,0)) #5,1,0
   #arima_mod100 = ARIMA(trainWTI, (2,0,0), freq='M').fit() 
	model_fit = model.fit(trend='nc', disp=False)
	ar_coef, ma_coef = model_fit.arparams, model_fit.maparams
	resid = model_fit.resid
	yhat = predict(ar_coef, history) + predict(ma_coef, resid)
	#output = model_fit.forecast()
	#yhat = output[0]
	predictions.append(yhat)
	obs = test[t]
	history.append(obs)
	newdf['PredictedLow'][size+t]=yhat-newdf.iloc[size+t]['PivotDiff']
	newdf['PredictedHigh'][size+t]=yhat+newdf.iloc[size+t]['PivotDiff']
	print('predicted=%f, expected=%f' % (yhat, obs))
error = sqrt(mean_squared_error(test, predictions))
print('Test MSE: %.3f' % error)
plt.plot(test,color='blue')
plt.plot(predictions, color='green')
plt.show()

a=newdf.reset_index().index
TrainData=newdf['High'] #TrainData=newdf['Pivot']
TrainData.index=a

X = TrainData.values
size = int(len(X) * 0.98)
train, test1 = X[0:size], X[size:len(X)]
history1 = [x for x in train]
predictions1 = list()
for t in range(len(test)):
	model = ARIMA(history1, order=(2,0,0)) #5,1,0
   #arima_mod100 = ARIMA(trainWTI, (2,0,0), freq='M').fit() 
	model_fit = model.fit(disp=0)
	output = model_fit.forecast()
	yhat = output[0]
	predictions1.append(yhat)
	obs = test1[t]
	history1.append(obs)
	#newdf['PredictedLow'][size+t]=yhat-newdf.iloc[size+t]['PivotDiff']
	#newdf['PredictedHigh'][size+t]=yhat+newdf.iloc[size+t]['PivotDiff']
	#print('predicted=%f, expected=%f' % (yhat, obs))
error = sqrt(mean_squared_error(test, predictions))
print('Test MSE: %.3f' % error)
# plot
az=newdf['Open'][size+1:len(X)]
ar=az.reset_index().index
az.index=ar
TrainData=newdf['Low'] #TrainData=newdf['Pivot']
TrainData.index=a

plt.plot(test,color='blue')
plt.plot(predictions, color='green')
plt.plot(az,color='yellow')
plt.plot(test1,color='black')
plt.plot(predictions1, color='red')
plt.show()



history[-5:]
predictions[-5:]

ax = trainWTI.ix[100:]
fig = arima_mod100.plot_predict(dates_from_range('2156m1', length=2), dates_from_range('2175m12', length=1), dynamic=True, ax=ax, plot_insample=False)
fig = arima_mod100.plot_predict('2014m1', '2018m12', dynamic=True, ax=ax, plot_insample=False)
ax.set_title("Prediction of spot prices")
ax.set_xlabel("Dates")
ax.set_ylabel("Price [USD]")
plt.show()



#python -m pip install --upgrade https://storage.googleapis.com/tensorflow/mac/cpu/tensorflow-0.12.0-py3-none-any.whl
#importing required libraries
from sklearn.preprocessing import MinMaxScaler
from keras.models import Sequential
from keras.layers import Dense, Dropout, LSTM

#creating dataframe
newdf['Date'] = pd.Series([pd.to_datetime(date) for date in newdf['Date']])
newdf=newdf.sort_values(by='Date')
data = newdf.sort_index(ascending=True, axis=0)
a=newdf.reset_index().index
TrainData=newdf['Date']
TrainData['High']=newdf['High'] #TrainData=newdf['Pivot']
TrainData.index=a
new_data = newdf.DataFrame(index=range(0,len(newdf)),columns=['Date', 'Close'])
new_data = newdf[['Date', 'Open']]
new_data.index=a
for i in range(0,len(data)):
    new_data['Date'][i] = data['Date'][i]
    new_data['Open'][i] = data['Open'][i]

#setting index
new_data.index = new_data.Date
new_data.drop('Date', axis=1, inplace=True)

#creating train and test sets
dataset = new_data.values

train = dataset[0:987,:]
valid = dataset[987:,:]

#converting dataset into x_train and y_train
scaler = MinMaxScaler(feature_range=(0, 1))
scaled_data = scaler.fit_transform(dataset)

x_train, y_train = [], []
for i in range(60,len(train)):
    x_train.append(scaled_data[i-60:i,0])
    y_train.append(scaled_data[i,0])
x_train, y_train = np.array(x_train), np.array(y_train)

x_train = np.reshape(x_train, (x_train.shape[0],x_train.shape[1],1))

# create and fit the LSTM network
model = Sequential()
model.add(LSTM(units=50, return_sequences=True, input_shape=(x_train.shape[1],1)))
model.add(LSTM(units=50))
model.add(Dense(1))

model.compile(loss='mean_squared_error', optimizer='adam')
model.fit(x_train, y_train, epochs=1, batch_size=1, verbose=2)

#predicting 246 values, using past 60 from the train data
inputs = new_data[len(new_data) - len(valid) - 60:].values
inputs = inputs.reshape(-1,1)
inputs  = scaler.transform(inputs)

X_test = []
for i in range(60,inputs.shape[0]):
    X_test.append(inputs[i-60:i,0])
X_test = np.array(X_test)

X_test = np.reshape(X_test, (X_test.shape[0],X_test.shape[1],1))
closing_price = model.predict(X_test)
closing_price = scaler.inverse_transform(closing_price)