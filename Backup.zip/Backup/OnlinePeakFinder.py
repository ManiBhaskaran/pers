import pandas as pd
import pandas as pdhl
import pandas as pdc
import pandas as fibpd
import peakutils
import matplotlib.pyplot as plt
import pypyodbc
import json
import time
import datetime
connection = pypyodbc.connect('Driver={SQL Server};Server=localhost;Database=Stock;uid=sa;pwd=admin4$bmo')
#cursor = connection.cursor()

def mround(m):
    a=m*100
    b=a%10
    c=0
    if(b>=5 and b<=7):
        c=-1
        d=.05
    elif(b>=7):
        c=0
        d = 0
    else:
        c=0
        d=0
    return (round(a/10)+c)/10+d

def fibupper(vdelta,Low):
    ulimit={}
    i=1
    while(i<=2000):
        ulimit[i]=mround(round(Low+(vdelta*i/1000),2))
        i=i+1
    i = -2000
    j=1
    while (i < 0):
        ulimit[i] = mround(round(Low + (vdelta * i / 1000), 2))
        i = i + 1
        j=j+1
    return ulimit

def fiblower(vdelta,Low):
    llimit={}
    i=1
    while(i<=2000):
        llimit[i]=mround(round(Low-(vdelta*i/1000),2))
        i=i+1
    return llimit


def getKey(mydict,ivalue):
    a1=list(mydict.values())
    #print("test1");
    try:
        b1=a1.index(ivalue)
    except ValueError:
        try:
            b1 = a1.index(round(ivalue-.05,2))
        except ValueError:
            try:
                b1 = a1.index(round(ivalue + .05,2))
            except ValueError:
                try:
                    b1 = a1.index(round(ivalue - .1,2))
                except ValueError:
                    try:
                        b1 = a1.index(round(ivalue + .1, 2))
                    except ValueError:
                        try:
                            b1 = a1.index(round(ivalue - .15, 2))
                        except ValueError:
                            try:
                                b1 = a1.index(round(ivalue + .15, 2))
                            except ValueError:
                                try:
                                    b1 = a1.index(round(ivalue - .2, 2))
                                except ValueError:
                                    try:
                                        b1 = a1.index(round(ivalue + .2, 2))
                                    except ValueError:
                                        try:
                                            b1 = a1.index(round(ivalue - .25, 2))
                                        except ValueError:
                                            try:
                                                b1 = a1.index(round(ivalue + .25, 2))
                                            except ValueError:
                                                try:
                                                    b1 = a1.index(round(ivalue - .3, 2))
                                                except ValueError:
                                                    try:
                                                        b1 = a1.index(round(ivalue + .3, 2))
                                                    except ValueError:
                                                        try:
                                                            b1 = a1.index(round(ivalue - .35, 2))
                                                        except ValueError:
                                                            try:
                                                                b1 = a1.index(round(ivalue + .35, 2))
                                                            except ValueError:
                                                                try:
                                                                    b1 = a1.index(round(ivalue - .4, 2))
                                                                except ValueError:
                                                                    try:
                                                                        b1 = a1.index(round(ivalue + .4, 2))
                                                                    except ValueError:
                                                                        try:
                                                                            b1 = a1.index(round(ivalue - .45, 2))
                                                                        except ValueError:
                                                                            b1 = a1.index(round(ivalue + .45, 2))


    except :
        print("Error")
    a = b1
    #print(a)
    return list(mydict.keys())[a]
# Simple Moving Average
def SMA(data,field, ndays):
 SMA = pd.Series(pd.rolling_mean(data[field], ndays), name = 'SMA'+ str(ndays))
 data = data.join(SMA)
 return data

# Exponentially-weighted Moving Average
def EWMA(data,field, ndays):
 EMA = pd.Series(pd.ewma(data[field], span = ndays, min_periods = ndays - 1), name = 'EMA' + str(ndays))
 data = data.join(EMA)
 return data

def process(symbol):
    day=21
    month=2
    year=2018
    do = datetime.datetime(year,month,day,9,14)
    do1 = datetime.datetime(year,month,day,15,30)
    i=1
    lastrcount=0
    PrevStartDate =do-datetime.timedelta(days=1)
    PrevEndDate = do1-datetime.timedelta(days=1)
    strStartDate=PrevStartDate.strftime("%m-%d-%Y %H:%M")
    strEndDate = PrevEndDate.strftime("%m-%d-%Y %H:%M")
    StockName=symbol#"CADILAHC%"
    PSQL="select max(chigh) as High,min(clow) as Low from Stocks15V3 where symbol like '"+StockName+"' and cdate>='"+strStartDate+"' and cdate <='" + strEndDate + "'"
    print(PSQL)
    fibmax=fibpd.read_sql_query(PSQL,connection)
    #print(fibmax)
    vHigh=fibmax.iloc[len(fibmax)-1]['high']
    vLow=fibmax.iloc[len(fibmax)-1]['low']
    #print(vHigh)
    #print(vLow)
    fUpper=fibupper(vHigh-vLow,vLow)
    fLower=fiblower(vHigh-vLow,vLow)
    while(i<700):

        ndate = do + datetime.timedelta(minutes=1)
        #print(ndate.strftime("%m-%d-%Y %H:%M"))
        strdate=ndate.strftime("%m-%d-%Y %H:%M")

        SQL="select symbol,cdate,copen,chigh,clow,cclose,cvolume from Stocks15V3 where symbol like '"+StockName+"' and cdate>='19-Feb-2018' and cdate <='" + strdate + "'"
        #print(SQL)
        estimated_data=pd.read_sql_query(SQL,connection)
        NewData=estimated_data

        col1 = estimated_data[:]['cdate'] # First column data
        col2 = estimated_data[:]['copen'] # Second column data
        i=i+1
        index5 = peakutils.indexes(col2, thres=.7, min_dist=200)
        do = ndate
        #print(str(ndate) + " - " + str(index5))
        if(len(index5)>0):
            lreccount=index5[len(index5)-1]
            if lastrcount!=lreccount:
                d1=estimated_data.iloc[lastrcount][2]
                d2 = estimated_data.iloc[lreccount][2]
                #print(str(getKey(fUpper,d1)) + " - " + str(getKey(fUpper,d2)))
                if (lreccount + 5 > len(estimated_data)):
                    data=estimated_data.iloc[len(estimated_data)-1]
                    if(data[2]>data[5]):
                        sellprice=data[2]
                    else:
                        sellprice = data[5]
                    sellTarget=round(sellprice*(1-0.01),2)
                    StopLoss=round(sellprice*(1+0.01),2)
                    NewData = SMA(NewData, "chigh", 50)
                    NewData = EWMA(NewData, "chigh", 50)
                    NewData = EWMA(NewData, "chigh", 25)
                    NewData = SMA(NewData, "chigh", 25)
					#sma1=SMA(estimated_data, 'chigh', 50)
                    SMA1=round(NewData.iloc[lreccount]["SMA50"],2)
                    EMA1 = round(NewData.iloc[lreccount]["EMA50"],2)
                    SMA2 = round(NewData.iloc[lreccount]["SMA25"], 2)
                    EMA2 = round(NewData.iloc[lreccount]["EMA25"], 2)
                    l=getKey(fUpper, d2)
                    #l=getKey(fUpper,sellprice)
                    threshold=25
                    Hit="No"
                    if ((l>(1000-threshold) and l<(1000+threshold)) or (l>(786-threshold) and l<(786+threshold)) or (l>(1382-threshold) and l<(1382+threshold))):
                        Hit="Filtered"
                    if(SMA2 > EMA2) and (SMA1 > EMA2) and (SMA1>EMA1) or True:
                    #print("Sell : " +estimated_data.iloc[lreccount][0] + " - " +str(estimated_data.iloc[len(estimated_data)-1][1]) + " - " + str(sellprice) + " - "+str(sellTarget) + " - "+ str(StopLoss) +" - "+SMA1+" - "+EMA1)
                        print("Sell : " + estimated_data.iloc[lreccount][0] + " - " + str(estimated_data.iloc[len(estimated_data) - 1][1]) + " - " + str(sellprice) + " - " + str(sellTarget) + " - " + str(StopLoss) + " - " + str(SMA1) + " - " + str(EMA1) + " - " + str((SMA1>EMA1)) + " = " +str(round(EMA1-SMA1,2)) + " - " + str(SMA2) + " - " + str(EMA2) + " - " + str((SMA2 > EMA2)) + " = " + str(round(EMA2 - SMA2, 2))+ " - "+ str((SMA1 > EMA2)) + " - " +str(getKey(fUpper,sellprice)) + " --- " + Hit)
            lastrcount = lreccount
				#print()
        if do.hour >= 15 or (do.hour >= 15 and do.minute > 30):
            d1 = 1
            if (do.weekday() == 4):
                d1 = 3
            tdo = do + datetime.timedelta(days=d1)
            do = datetime.datetime(tdo.year, tdo.month, tdo.day, 9, 14)

def getindex(searchdates,data):
    listdates = list(data)
    listsearchdates=list(searchdates)
    i=0
    #dates = datetime.datetime(year, month, day, 9, 14)
    returnlist=[]
    while(i<len(listdates)):
        dates=listdates[i]
        y = dates.year
        m = dates.month
        d = dates.day
        h = dates.hour
        mi = dates.minute
        #print(str(y) + " - " + str(m) + " - " + str(d) + " - " + str(h) + " - " + str(mi))
        returnlist.append(listsearchdates.index(datetime.datetime(y,m,d,h,mi)))
        i=i+1
    return returnlist

def process1(symbol):
    day=27
    month=2
    year=2018
    do = datetime.datetime(year,month,day,9,14)

    do1 = datetime.datetime(year,month,day,15,30)
    i=1
    lastrcount=0
    PrevStartDate =do-datetime.timedelta(days=1)
    PrevEndDate = do1-datetime.timedelta(days=1)
    strStartDate=PrevStartDate.strftime("%m-%d-%Y %H:%M")
    strEndDate = PrevEndDate.strftime("%m-%d-%Y %H:%M")
    StockName=symbol#"CADILAHC%"
    #StockName = "CADILAHC%"
    PSQL="select max(chigh) as High,min(clow) as Low from Stocks15V3 where symbol like '"+StockName+"' and cdate>='"+strStartDate+"' and cdate <='" + strEndDate + "'"
    #print(PSQL)
    fibmax=fibpd.read_sql_query(PSQL,connection)
    #print(fibmax)
    vHigh=fibmax.iloc[len(fibmax)-1]['high']
    vLow=fibmax.iloc[len(fibmax)-1]['low']
    #print(vHigh)
    #print(vLow)
    fUpper=fibupper(vHigh-vLow,vLow)
    fLower=fibupper(vHigh-vLow,vLow)
    #fLower = fiblower(vHigh - vLow, vLow)
    while(i<350):


        ndate = do + datetime.timedelta(minutes=1)
        #print(ndate.strftime("%m-%d-%Y %H:%M"))
        strdate=ndate.strftime("%m-%d-%Y %H:%M")


        SQL="select symbol,cdate,copen,chigh,clow,cclose,cvolume from Stocks15V3 where symbol like '"+StockName+"' and cdate>='26-Feb-2018' and cdate <='" + strdate + "'"
        #SQLC="select symbol,cdate,copen,chigh,clow,cclose,cvolume from Stocks15V3 where symbol like '"+StockName+"' and cdate ='" + strdate + "'"
        alldata = pd.read_sql_query(SQL, connection)
        orido=alldata.iloc[len(alldata) - 30]['cdate']
        startdate = orido.strftime("%m-%d-%Y %H:%M")
        SQLLH = "select max(chigh) as high, min(clow) as low from Stocks15V3 where symbol like '" + StockName + "' and cdate>='" + startdate + "' and cdate <='" + strdate + "'"
        #print(SQLLH)
        #print(SQL)

        hldata = pd.read_sql_query(SQLLH, connection)
        #cdata = pd.read_sql_query(SQL, connection)
        #print(hldata)
        #NewData=alldataprint
        alldate = alldata[:]['cdate']
        alllow = alldata[:]['clow'] # First column data
        allhigh = alldata[:]['chigh'] # Second column data
        maxhigh=hldata.iloc[len(hldata)-1]['high']
        maxlow = hldata.iloc[len(hldata) - 1]['low']
        chigh= alldata.iloc[len(alldata) - 1]['chigh']
        clow = alldata.iloc[len(alldata) - 1]['clow']
        data = alldata.iloc[len(alldata) - 1]
        SQLALLHigh = "Select cdate,copen,chigh,clow,cclose,cvolume from Stocks15V3 where symbol like '" + StockName + "' and cdate>='" + startdate + "' and cdate <='" + strdate + "' and chigh="+ str(maxhigh)
        SQLALLLow = "Select cdate,copen,chigh,clow,cclose,cvolume from Stocks15V3 where symbol like '" + StockName + "' and cdate>='" + startdate + "' and cdate <='" + strdate + "' and clow=" + str(maxlow)
        #print(SQLALLHigh)
        #print(SQLALLLow)
        #print(alldata)
        allhighdata = pd.read_sql_query(SQLALLHigh, connection)
        alllowdata = pd.read_sql_query(SQLALLLow, connection)
        #print(allhighdata)
        #print(alllowdata)
        HighIndexes=getindex(alldate,allhighdata[:]['cdate'])
        LowIndexes = getindex(alldate, alllowdata[:]['cdate'])
        lasthigh=allhighdata.iloc[len(allhighdata)-1]['chigh']
        lastlow = alllowdata.iloc[len(alllowdata) - 1]['clow']
        lasthighindex=HighIndexes[len(HighIndexes)-1]
        lastlowindex = LowIndexes[len(LowIndexes) - 1]
        currentindex=len(alldata)-1
        lreccount=currentindex

        threshold = 35
        threshold1=2


        Hit = "No"
        lasthighfib = getKey(fUpper, lasthigh)
        currhighfib=getKey(fUpper, chigh)
        #print("High: " + strdate + " - " + str(chigh) + " - " + str(lasthigh) + " - " + str(lasthighindex)  + " - " + str(currentindex) + " - " + str(lasthighfib) + " - " + str(currhighfib))
        if (data[2] > data[5]):
            sellprice = data[2]
        else:
            sellprice = data[5]
        sellTarget = round(sellprice * (1 - 0.01), 2)
        StopLoss = round(sellprice * (1 + 0.01), 2)
        if ((lasthighfib > (382 - threshold) and lasthighfib < (382 + threshold)) or
                (lasthighfib > (618 - threshold) and lasthighfib < (618 + threshold)) or
                (lasthighfib > (500 - threshold) and lasthighfib < (500 + threshold)) or
                (lasthighfib > (1000 - threshold) and lasthighfib < (1000 + threshold)) or (
                lasthighfib > (786 - threshold) and lasthighfib < (786 + threshold)) or (
                lasthighfib > (1382 - threshold) and lasthighfib < (1382 + threshold))) and (lasthighfib-currhighfib)>30 and (lasthighfib-currhighfib)<60: # Changing from 60-some low
            Hit = "Filtered"
            print("Sell - " + alldata.iloc[lreccount]['symbol'] + " - " + str(
                alldata.iloc[lreccount]['cdate']) + " - " + str(sellprice) + " - " + str(
                sellTarget) + " - " + str(StopLoss) + " - " + str(getKey(fUpper, sellprice)) + " - " + Hit)
        #i=i+1



        Hit = "No"
        lastlowfib = getKey(fLower, lastlow)
        currlowfib=getKey(fLower, clow)
        #print("Low: " + strdate + " - " + str(clow) + " - " + str(lastlow) + " - " + str(lastlowindex)  + " - " + str(currentindex) + " - " + str(lastlowfib) + " - " + str(currlowfib))
        if (data[2] > data[5]):
            sellprice = data[2]
        else:
            sellprice = data[5]
        sellTarget = round(sellprice * (1 - 0.01), 2)
        StopLoss = round(sellprice * (1 + 0.01), 2)
        '''if ((lastlowfib > (382 - threshold) and lastlowfib < (382 + threshold)) or
            (lastlowfib > (618 - threshold) and lastlowfib < (618 + threshold)) or
            (lastlowfib > (500 - threshold) and lastlowfib < (500 + threshold)) or
            (lastlowfib > (1000 - threshold) and lastlowfib < (1000 + threshold)) or (
                    lastlowfib > (786 - threshold) and lastlowfib < (786 + threshold)) or (
                    lastlowfib > (1382 - threshold) and lastlowfib < (1382 + threshold))) and (
                currlowfib - lastlowfib) > 30 and (currlowfib - lastlowfib) < 60:  # Changing from 60-some low'''
        if ((currlowfib > (0 + round(threshold/2)) and (currlowfib < (0 - round(threshold/2)) and lastlowfib < (0 + threshold1))) or #Changing the condition from (currlowfib > (0 + threshold)
                (currlowfib > (382 + threshold) and lastlowfib < (382 + threshold1)) or
                (currlowfib > (618 + threshold) and lastlowfib < (618 + threshold1)) or
                (currlowfib > (500 + threshold) and lastlowfib < (500 + threshold1)) or
                (currlowfib > (1000 + threshold) and lastlowfib < (1000 + threshold1)) or (
                    currlowfib > (786 + threshold) and lastlowfib < (786 + threshold1)) or (
                    currlowfib > (1382 + threshold) and lastlowfib < (1382 + threshold1))) and (currlowfib-lastlowfib)>30 and (currlowfib-lastlowfib)<60: # Changing from 60-some low

            Hit = "Filtered"
            print("BUY - " + alldata.iloc[lreccount]['symbol'] + " - " + str(
                alldata.iloc[lreccount]['cdate']) + " - " + str(sellprice) + " - " + str(
                sellTarget) + " - " + str(StopLoss) + " - " + str(getKey(fUpper, sellprice)) + " - " + Hit)
        i=i+1
        '''
        i=i+1
        index5 = peakutils.indexes(col2, thres=.7, min_dist=200)
        do = ndate
        #print(str(ndate) + " - " + str(index5))
        if(len(index5)>0):
            lreccount=index5[len(index5)-1]
            if lastrcount!=lreccount:
                d1=estimated_data.iloc[lastrcount][2]
                d2 = estimated_data.iloc[lreccount][2]
                #print(str(getKey(fUpper,d1)) + " - " + str(getKey(fUpper,d2)))
                if (lreccount + 5 > len(estimated_data)):
                    data=estimated_data.iloc[len(estimated_data)-1]
                    if(data[2]>data[5]):
                        sellprice=data[2]
                    else:
                        sellprice = data[5]
                    sellTarget=round(sellprice*(1-0.01),2)
                    StopLoss=round(sellprice*(1+0.01),2)
                    NewData = SMA(NewData, "chigh", 50)
                    NewData = EWMA(NewData, "chigh", 50)
                    NewData = EWMA(NewData, "chigh", 25)
                    NewData = SMA(NewData, "chigh", 25)
					#sma1=SMA(estimated_data, 'chigh', 50)
                    SMA1=round(NewData.iloc[lreccount]["SMA50"],2)
                    EMA1 = round(NewData.iloc[lreccount]["EMA50"],2)
                    SMA2 = round(NewData.iloc[lreccount]["SMA25"], 2)
                    EMA2 = round(NewData.iloc[lreccount]["EMA25"], 2)
                    l=getKey(fUpper, d2)
                    #l=getKey(fUpper,sellprice)
                    threshold=25
                    Hit="No"
                    if ((l>(1000-threshold) and l<(1000+threshold)) or (l>(786-threshold) and l<(786+threshold)) or (l>(1382-threshold) and l<(1382+threshold))):
                        Hit="Filtered"
                    if(SMA2 > EMA2) and (SMA1 > EMA2) and (SMA1>EMA1) or True:
                    #print("Sell : " +estimated_data.iloc[lreccount][0] + " - " +str(estimated_data.iloc[len(estimated_data)-1][1]) + " - " + str(sellprice) + " - "+str(sellTarget) + " - "+ str(StopLoss) +" - "+SMA1+" - "+EMA1)
                        print("Sell : " + estimated_data.iloc[lreccount][0] + " - " + str(estimated_data.iloc[len(estimated_data) - 1][1]) + " - " + str(sellprice) + " - " + str(sellTarget) + " - " + str(StopLoss) + " - " + str(SMA1) + " - " + str(EMA1) + " - " + str((SMA1>EMA1)) + " = " +str(round(EMA1-SMA1,2)) + " - " + str(SMA2) + " - " + str(EMA2) + " - " + str((SMA2 > EMA2)) + " = " + str(round(EMA2 - SMA2, 2))+ " - "+ str((SMA1 > EMA2)) + " - " +str(getKey(fUpper,sellprice)) + " --- " + Hit)
            lastrcount = lreccount
				#print()
				'''
        do = ndate
        if do.hour >= 15 or (do.hour >= 15 and do.minute > 30):
            d1 = 1
            if (do.weekday() == 4):
                d1 = 3
            tdo = do + datetime.timedelta(days=d1)
            do = datetime.datetime(tdo.year, tdo.month, tdo.day, 9, 14)


process1("CADILAHC")
#CADILAHC #RELIANCE
#estimated_data.
#index2 = peakutils.indexes(col2, thres=0.2, min_dist=250)
#index3 = peakutils.indexes(col2, thres=0.3, min_dist=250)
#index4 = peakutils.indexes(col2, thres=0.4, min_dist=250)

#index6 = peakutils.indexes(col2, thres=0.6, min_dist=250)
#index7 = peakutils.indexes(col2, thres=0.7, min_dist=250)
#index8 = peakutils.indexes(col2, thres=0.8, min_dist=250)
#index9 = peakutils.indexes(col2, thres=0.9, min_dist=250)
#index10 = peakutils.indexes(col2, thres=1, min_dist=250)

#index2 = peakutils.indexes(col2, thres=-0.4, max_dist=250)
#print(index1)

#for r in index1:
#    print("Index1,"+str(estimated_data.iloc[r][0]))
#for r in index2:
#    print("Index2,"+str(estimated_data.iloc[r][0]))
#for r in index3:
#    print("Index3,"+str(estimated_data.iloc[r][0]))
#for r in index4:
#    print("Index4,"+str(estimated_data.iloc[r][0]))
#for r in index5:
#    print("Index5,"+str(estimated_data.iloc[r][1]))
#for r in index6:
#    print("Index6,"+str(estimated_data.iloc[r][0]))
#for r in index7:
#    print("Index7,"+str(estimated_data.iloc[r][0]))
#print(estimated_data.iloc[index5[len(index5)-1]])
#for r in index8:
#    print("Index8,"+str(estimated_data.iloc[r][0]))
#for r in index9:
#    print("Index9,"+str(estimated_data.iloc[r][0]))
#for r in index10:
#    print("Index10,"+str(estimated_data.iloc[r][0]))


#plt.plot(col2,lw=0.4, alpha=0.4 )
#plt.plot(col1,col2, lw=0.4, alpha=0.4 )
#plt.plot(col2[index10], marker="o", ls="", ms=4 )
#plt.plot(col2[index8], marker="1", ls="", ms=4 )
#plt.plot(col2[index5], marker="2", ls="", ms=4 )
#plt.plot(col2[index1], marker="o", ls="", ms=6 )
#plt.plot(col2[index2], marker="o", ls="", ms=3 )

print("Finished")
#plt.show()