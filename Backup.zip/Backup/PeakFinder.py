import pandas as pd
import peakutils
import matplotlib.pyplot as plt
import pypyodbc
import json
import time
import datetime
connection = pypyodbc.connect('Driver={SQL Server};Server=localhost;Database=Stock;uid=sa;pwd=admin4$bmo')
#cursor = connection.cursor()
strdate=datetime.datetime.today().strftime("%m-%d-%Y %H:%M")
SQL="select symbol,cdate,copen,chigh,clow,cclose,cvolume from Stocks15V3 where symbol like 'NIIT%' and cdate>'08-Feb-2018'"
#cursor.execute(SQL)
estimated_data=pd.read_sql_query(SQL,connection)
#a.__delitem__(0)
#estimated_data = pd.read_csv("C:/Temp/DataSets/Fortis.csv",skiprows=1,header=None) #col1 = estimated_data[:][1]
col1 = estimated_data[:]['cdate'] # First column data
col2 = estimated_data[:]['copen'] # Second column data
#estimated_data.iloc[index]
#peakutils
#index1 = peakutils.indexes(col2, thres=-0.1, min_dist=250)
#index2 = peakutils.indexes(col2, thres=-0.2, min_dist=250)
#index3 = peakutils.indexes(col2, thres=-0.3, min_dist=250)
#index4 = peakutils.indexes(col2, thres=-0.4, min_dist=250)
#index5 = peakutils.indexes(col2, thres=-0.5, min_dist=250)
#index6 = peakutils.indexes(col2, thres=-0.6, min_dist=250)
#index7 = peakutils.indexes(col2, thres=-0.7, min_dist=250)
#index8 = peakutils.indexes(col2, thres=-0.8, min_dist=250)
#index9 = peakutils.indexes(col2, thres=-0.9, min_dist=250)
#index10 = peakutils.indexes(col2, thres=1, min_dist=250)

#index1 = peakutils.indexes(col2, thres=0.1, min_dist=250)
index2 = peakutils.indexes(col2, thres=0.2, min_dist=250)
index3 = peakutils.indexes(col2, thres=0.3, min_dist=250)
index4 = peakutils.indexes(col2, thres=0.4, min_dist=250)
index5 = peakutils.indexes(col2, thres=0.5, min_dist=250)
index6 = peakutils.indexes(col2, thres=0.6, min_dist=250)
index7 = peakutils.indexes(col2, thres=0.7, min_dist=250)
index8 = peakutils.indexes(col2, thres=0.8, min_dist=250)
index9 = peakutils.indexes(col2, thres=0.9, min_dist=250)
index10 = peakutils.indexes(col2, thres=1, min_dist=250)

#index2 = peakutils.indexes(col2, thres=-0.4, max_dist=250)
#print(index1)

#for r in index1:
#    print("Index1,"+str(estimated_data.iloc[r][0]))
#for r in index2:
#    print("Index2,"+str(estimated_data.iloc[r][0]))
#for r in index3:
#    print("Index3,"+str(estimated_data.iloc[r][0]))
#for r in index4:
#    print("Index4,"+str(estimated_data.iloc[r][0]))
for r in index5:
    print("Index5,"+str(estimated_data.iloc[r][1]))
#for r in index6:
#    print("Index6,"+str(estimated_data.iloc[r][0]))
#for r in index7:
#    print("Index7,"+str(estimated_data.iloc[r][0]))
#for r in index8:
#    print("Index8,"+str(estimated_data.iloc[r][0]))
#for r in index9:
#    print("Index9,"+str(estimated_data.iloc[r][0]))
#for r in index10:
#    print("Index10,"+str(estimated_data.iloc[r][0]))


plt.plot(col2,lw=0.4, alpha=0.4 )
#plt.plot(col1,col2, lw=0.4, alpha=0.4 )
#plt.plot(col2[index10], marker="o", ls="", ms=4 )
#plt.plot(col2[index8], marker="1", ls="", ms=4 )
plt.plot(col2[index5], marker="2", ls="", ms=4 )
#plt.plot(col2[index1], marker="o", ls="", ms=6 )
#plt.plot(col2[index2], marker="o", ls="", ms=3 )


plt.show()