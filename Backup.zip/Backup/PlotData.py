import matplotlib as mpl
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.cbook as cbook

def read_datafile(file_name):

    data = np.loadtxt(file_name, delimiter=',')
    return data

data = read_datafile('C:/Temp/DataSets/Fortis.csv')


fig = plt.figure()

ax1 = fig.add_subplot(111)

ax1.set_title("Data")    
ax1.set_xlabel('t')
ax1.set_ylabel('s')

ax1.plot(x,y, c='r', label='My data')

leg = ax1.legend()

plt.show()