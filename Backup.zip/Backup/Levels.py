
import pandas as pd
import numpy as np
import datetime
import math
import re
import matplotlib
from dateutil.parser import parse

import matplotlib.pyplot as plt
#from matplotlib.finance import quotes_historical_yahoo_ohlc
from matplotlib.lines import Line2D


def fibupper(vdelta,Low):
    ulimit={}
    i=1
    while(i<=4000):
        ulimit[i]=mround(round(Low+(vdelta*i/1000),2))
        i=i+1
    i = -4000
    j=1
    while (i < 0):
        ulimit[i] = mround(round(Low + (vdelta * i / 1000), 2))
        i = i + 1
        j=j+1
    return ulimit

def fiblower(vdelta,Low):
    llimit={}
    i=1
    while(i<=2000):
        llimit[i]=mround(round(Low-(vdelta*i/1000),2))
        i=i+1
    return llimit

def getKey(mydict,ivalue):
    a1=list(mydict.values())
    #print("test1");
    try:
        b1=a1.index(ivalue)
    except ValueError:
        try:
            b1 = a1.index(round(ivalue-.05,2))
        except ValueError:
            try:
                b1 = a1.index(round(ivalue + .05,2))
            except ValueError:
                try:
                    b1 = a1.index(round(ivalue - .1,2))
                except ValueError:
                    try:
                        b1 = a1.index(round(ivalue + .1, 2))
                    except ValueError:
                        try:
                            b1 = a1.index(round(ivalue - .15, 2))
                        except ValueError:
                            try:
                                b1 = a1.index(round(ivalue + .15, 2))
                            except ValueError:
                                try:
                                    b1 = a1.index(round(ivalue - .2, 2))
                                except ValueError:
                                    try:
                                        b1 = a1.index(round(ivalue + .2, 2))
                                    except ValueError:
                                        try:
                                            b1 = a1.index(round(ivalue - .25, 2))
                                        except ValueError:
                                            try:
                                                b1 = a1.index(round(ivalue + .25, 2))
                                            except ValueError:
                                                try:
                                                    b1 = a1.index(round(ivalue - .3, 2))
                                                except ValueError:
                                                    try:
                                                        b1 = a1.index(round(ivalue + .3, 2))
                                                    except ValueError:
                                                        try:
                                                            b1 = a1.index(round(ivalue - .35, 2))
                                                        except ValueError:
                                                            try:
                                                                b1 = a1.index(round(ivalue + .35, 2))
                                                            except ValueError:
                                                                try:
                                                                    b1 = a1.index(round(ivalue - .4, 2))
                                                                except ValueError:
                                                                    try:
                                                                        b1 = a1.index(round(ivalue + .4, 2))
                                                                    except ValueError:
                                                                        try:
                                                                            b1 = a1.index(round(ivalue - .45, 2))
                                                                        except ValueError:
                                                                            b1 = a1.index(round(ivalue + .45, 2))
    except:
        print("Error")
    a = b1
    #print(a)
    return list(mydict.keys())[a]

def tgetKey(mydict,ivalue):
    a1=list(mydict.values()).index(round(ivalue,2))
    return a1

def mround(m):
    a=m*100
    b=a%10
    c=0
    if(b>=5 and b<=7):
        c=-1
        d=.05
    elif(b>=7):
        c=0
        d = 0
    else:
        c=0
        d=0
    return round((round(a/10)+c)/10+d,2)


def getFibLevels(vHigh,vLow):
    
    #vHigh=3282
    #vLow=3186
    fUpper=fibupper(vHigh-vLow,vLow)
    #fLower=fiblower(stg100['High'][i]-stg100['Low'][i],stg100['Low'][i])
    
    fUpper[318]
    FibSeries=[-1786,-1618,-1500,-1382,-1236,-1000,-786,-618,-500,-382,-236,1,236,382,500,618,786,1000,1236,1382,1500,1618,1786,2000,2236,2382,2500,2786,3000]
    FibLevels=[]
    j=0
    while(j<len(FibSeries)):    
        print(str(FibSeries[j])+"\t:"+str(round(fUpper[FibSeries[j]])))
        FibLevels.append(round(fUpper[FibSeries[j]]))
        j=j+1
    return True
	
getFibLevels(31760,31565)
	