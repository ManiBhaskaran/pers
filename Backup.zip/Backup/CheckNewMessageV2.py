import selenium.webdriver
from selenium import webdriver 
from selenium.webdriver.support.ui import WebDriverWait 
from selenium.webdriver.support import expected_conditions as EC 
from selenium.webdriver.common.keys import Keys 
from selenium.webdriver.common.by import By 
from selenium.common.exceptions import TimeoutException
import socket
import time 
import pandas as pd
import numpy as np
import winsound
import pyglet
import datetime
from time import sleep
  
# Replace below path with the absolute path 
# to chromedriver in your computer 

def element_presence(by,xpath,time):
    element_present = EC.presence_of_element_located((By.XPATH, xpath))
    WebDriverWait(driver, time).until(element_present)
 
def is_connected():
    try:
        # connect to the host -- tells us if the host is actually
        # reachable
        socket.create_connection(("www.google.com", 80))
        return True
    except :
        is_connected()
#text="ddd" 
def send_whatsapp_msg(phone_no,text):
    #driver1.get("https://web.whatsapp.com/send?phone={}&source=&data=#".format(phone_no))
    #try:
    #    driver1.switch_to_alert().accept()
    #except Exception as e:
    #    pass
 
    #try:#
    #element_presence(By.XPATH,'//*[@id="main"]/footer/div[1]/div[2]/div/div[2]',30)
    #time.sleep(10)
    txt_box=driver1.find_element(By.XPATH , '//*[@id="main"]/footer/div[1]/div[2]/div/div[2]')
    #txt_box.value
    #txt_box.text="dddd"
    
    #//*[@id="main"]/footer/div[1]/div[2]/div/div[2]
    #txt_box.send_keys('te')
    global no_of_message
    for x in range(no_of_message):
        txt_box.send_keys(text)        
        txt_box.send_keys('\n')
 
    #except Exception as e:
    #    print("invailid phone no :"+str(phone_no))
        
        
driver = webdriver.Chrome('C:\\Users\\lalitha\\chromedriver') 
Timer=0
FirstTime=True

no_of_message=1 # no. of time you want the message to be send
moblie_no_list=[919940133201] # list of phone number can be of any length

driver1 = webdriver.Chrome(executable_path="C:\\Users\\lalitha\\chromedriver.exe")
driver1.get("http://web.whatsapp.com")
sleep(50) #wait time to scan the code in second
driver1.get("https://web.whatsapp.com/send?phone={}&source=&data=#".format(phone_no))

while(Timer<1):    
    driver.get("http://mcx.freetips.tips/") 
    wait = WebDriverWait(driver, 800) 
    
    
    
    classname='"post-news"'
    x_arg1 = '//div[contains(@class,' + classname + ')]'
    #postdesc='"post-desc"'
    #postdescarg = '//p[contains(@class,' + postdesc + ')]'
    #datestr='"date"'
    #datearg = '//span[contains(@class,' + datestr + ')]'
    #category='"meta-cat"'
    #categoryarg = '//span[contains(@class,' + category + ')]'
    #user='"meta-user"'
    #userarg = '//span[contains(@class,' + user + ')]'
    
    
    message1 = wait.until(EC.presence_of_element_located(( 
        By.XPATH, x_arg1))) 
    messages1=driver.find_elements_by_xpath(x_arg1)
    #messages_postdesc=driver.find_elements_by_xpath(postdescarg)
    #messages_date=driver.find_elements_by_xpath(datearg)
    #messages_category=driver.find_elements_by_xpath(categoryarg)
    #messages_user=driver.find_elements_by_xpath(userarg)
    
    lDescription=[]
    lDate=[]
    lCategory=[]
    lUser=[]
    lTipsID=[]
    
    
    i=0
    index=9999
    for message in messages1:
        msgAr=message.text.split('\n')
        #print("\n"+messages_postdesc[i].text + "\n" +messages_date[i].text + "\n"+messages_category[i].text+ "\n"+messages_user[i].text)
        lDescription.insert(index,msgAr[0])
        lDate.insert(index,msgAr[3].split(' : ')[1].replace(' at','').strip())
        lTipsID.insert(index,msgAr[4].split(' : ')[1].strip())
        lCategory.insert(index,msgAr[5].split(' : ')[1].strip())
        lUser.insert(index,msgAr[6].split(' : ')[1].strip())
        i=i+1
        #break
        
    Data={'Message':lDescription,'Date':lDate,'Category':lCategory,'User':lUser,'TipsID':lTipsID}
    df1 = pd.DataFrame(Data)
    #df1.iloc[1:5]
    df1.index=df1['TipsID']
    
    
    #df1.iloc[1]
    
    if(FirstTime):
        GlobalData=df1
        NewData=GlobalData
        FirstTime=False
        #print('True');
    else:
        #print('False.......')
        MergeResult=pd.merge(GlobalData, df1, how='outer', indicator='Exist')
        NewData=MergeResult.loc[np.where(MergeResult['Exist']=='right_only')]
         GlobalData=pd.concat([GlobalData,df1]).drop_duplicates(keep='first')
    
    l=0
    #print('\n\n**********   ' + str(datetime.datetime.now()) + "  ---  " + str(Timer)  + '    *******\n\n')
    firstSound=True
    while(l<len(NewData)):
        Messagez='\n\n**********       *******\n\n'                
        #print('\n\n**********       *******\n\n')
        Messagez=Messagez+NewData.iloc[l]['User']+'\n'+NewData.iloc[l]['Date']+'\n'+NewData.iloc[l]['Message']
        #Messagehtml='<BR>**********       *******<BR>'                
        #print('\n\n**********       *******\n\n')
        #Messagehtml=Messagehtml+NewData.iloc[l]['User']+'<BR>'+NewData.iloc[l]['Date']+'<BR>'+NewData.iloc[l]['Message']
        print(Messagez)
        #Messagez="Test Message"
        for moblie_no in moblie_no_list:
            try:
                
                send_whatsapp_msg(moblie_no,Messagez)
            except Exception as e:
                #sleep(10)
                is_connected()
        l=l+1
        if(firstSound):
            winsound.PlaySound('sound.wav', winsound.SND_FILENAME)
            firstSound=False
    time.sleep(30)
    Timer=Timer+1