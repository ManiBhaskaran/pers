import urllib.request
import json
import time
import datetime
import smtplib
mylist=['a']
delay=30*3000
close_time=time.time()+delay


gmail_user = 'manikandantrade@gmail.com'  
gmail_password = 'mcseccna'
sent_from = gmail_user  
to = ['maniitil@gmail.com','rich4trade@gmail.com']  
subject = 'Alert From Money'  
#proxy_support = urllib.request.ProxyHandler({'http' : 'http://web-proxy.houston.hpecorp.net:8080', 
#                                             'https': 'http://web-proxy.houston.hpecorp.net:8080'})
#opener = urllib.request.build_opener(proxy_support)
#urllib.request.install_opener(opener)
i=0;
t_end = time.time() + 60 * 15
while i < 10000000:

	subject = 'Alert From Money :'  + str(datetime.datetime.time(datetime.datetime.now()))
#while True:
      ##bla bla
      ###bla bla
	
 #   if time.time()>close_time :
#		break
	Message=""
	i=i+1
	x = urllib.request.urlopen('http://mmb.moneycontrol.com/index.php?q=boarder/ajax_call&section=get_messages&is_boarder_page=1&offset=&lmid=&isp=0&gmt=my_post&uid=neha0103&pgno=1')
	#x = urllib.request.urlopen('http://mmb.moneycontrol.com/index.php?q=boarder/ajax_call&section=get_messages&is_boarder_page=1&offset=10&lmid=&isp=0&gmt=my_post&uid=neha0103&pgno=1')
	#http://mmb.moneycontrol.com/index.php?q=boarder/ajax_call&section=get_messages&is_boarder_page=1&offset=50&lmid=58017099&isp=1&gmt=my_post&uid=neha0103&pgno=3
	input_dict = json.loads(x.read())
	output_dict1 = [x for x in input_dict if x['repost_by_user'] == None]
	for res3 in output_dict1:  
		if any(res3['user_id']+'  ----  '+res3['message'] in s for s in mylist):
			t=23
		else:
			mylist.append(res3['user_id']+'  ----  '+res3['message'])
			#print(str(datetime.datetime.time(datetime.datetime.now())) + " - " + res3['user_id']+'  --  '+res3['topic']+'  --  '+res3['message'])
			Message=Message+"\n"+str(datetime.datetime.time(datetime.datetime.now())) + " - " + res3['user_id']+'  --  '+res3['topic']+'  --  '+res3['message']
#		print(res3['user_id']+'  --  '+res3['topic'] +'  --  '+ res3['message'])
	#output_dict = [x for x in input_dict if x['replyto_user'] == '']
	output_dict = input_dict 
	for res3 in output_dict:  
		#if mylist.index(res3['message']) <= 0:
		if any(res3['user_id']+'  --  '+res3['message'] in s for s in mylist):
			t=23
		else:
			mylist.append(res3['user_id']+'  --  '+res3['message'])
			#print(str(datetime.datetime.time(datetime.datetime.now())) + " - " + res3['user_id']+'  --  '+res3['topic']+'  --  '+res3['message'])
			Message=Message+"\n"+str(datetime.datetime.time(datetime.datetime.now())) + " - " + res3['user_id']+'  --  '+res3['topic']+'  --  '+res3['message']
	print(Message)
	BODY = '\r\n'.join(['To: %s' % to,
                    'From: %s' % sent_from,
                    'Subject: %s' % subject ,
                    '', Message])
	if Message!="" and 5==5:
		try:  
			server = smtplib.SMTP_SSL('smtp.gmail.com', 465)
			server.ehlo()
			server.login(gmail_user, gmail_password)
			server.sendmail(sent_from, to, BODY)
			server.close()
			print('Mail Sent')
		except:  
			print('Something went wrong..')
	time.sleep (30)
	