# -*- coding: utf-8 -*-
"""
Created on Fri Apr 26 08:44:58 2019

@author: lalitha
"""
def getDf(Date,Transaction,GC2,GC1,GC,SC,SC1,SC2,Profit,GP,SP,Doji,GP1,GP2,GF1,SP1,SP2,SF1):
    Test={}
    Test["Date"]=Date
    Test["Transaction"]=Transaction
    Test["GC2"]=GC2
    Test["GC1"]=GC1
    Test["GC"]=GC
    Test["SC"]=SC
    Test["SC1"]=SC1
    Test["SC2"]=SC2
    Test["Profit"]=Profit
    Test["GP"]=GP
    Test["SP"]=SP
    Test["Doji"]=Doji
    Test["GP1"]=GP1
    Test["GP2"]=GP2
    Test["GF1"]=GF1
    Test["SP1"]=SP1
    Test["SP2"]=SP2
    Test["SF1"]=SF1
    return Test
    
    
pp=0
TProfit=0
DataIndex=0
Messages=[]
AMessages=[]
BMessages=[]
SResult1=False;SResult2=False;SResult3=False
GResult1=False;GResult2=False;GResult3=False
while(pp<=15):

#    Symbol="SILVER"
#    SilverCandle15Min=candlestick.getLiveDataFromZerodha(Symbol,"15minute")
#    #SilverCandle1Min=candlestick.getLiveDataFromZerodha(Symbol,"minute")
#    #SilverCandle3Min=candlestick.getLiveDataFromZerodha(Symbol,"3minute")
##    SilverCandle5Min=candlestick.getLiveDataFromZerodha(Symbol,"5minute")
#    SilverCandle30Min=candlestick.getLiveDataFromZerodha(Symbol,"30minute")
#    ChartWithBreakOut(SilverHistory,DataIndex,SilverCandle15Min,SilverCandle30Min,Symbol+"V1")
#    ChartWithBreakOut(SilverHistoryV2,DataIndex,SilverCandle15Min,SilverCandle30Min,Symbol+"V2")
#    
#    Symbol="GOLD"
#    #GoldHistoryV3=candlestick.GetEODDataFromMCX(Symbol,"C",3,GoldExpiry)
#    #GoldHistoryV4=candlestick.GetEODDataFromMCX(Symbol,"C",4,GoldExpiry)
#    GoldCandle15Min=candlestick.getLiveDataFromZerodha(Symbol,"15minute")
#    #GoldCandle1Min=candlestick.getLiveDataFromZerodha(Symbol,"minute")
#    #GoldCandle3Min=candlestick.getLiveDataFromZerodha(Symbol,"3minute")
##    GoldCandle5Min=candlestick.getLiveDataFromZerodha(Symbol,"5minute")
#    GoldCandle30Min=candlestick.getLiveDataFromZerodha(Symbol,"30minute")
#    ChartWithBreakOut(GoldHistoryV1,DataIndex,GoldCandle15Min,GoldCandle30Min,Symbol+"V1")
#    ChartWithBreakOut(GoldHistoryV2,DataIndex,GoldCandle15Min,GoldCandle30Min,Symbol+"V2")

    AtSilverPivot=False
    AtGoldPivot=False
    TProfit=0
    DataIndex=pp
    pp=pp+1
    
#    Symbol="GOLD"
#    GoldCandle5Min=candlestick.getLiveDataFromZerodha(Symbol,"5minute")
#    Symbol="SILVER"
#    SilverCandle5Min=candlestick.getLiveDataFromZerodha(Symbol,"5minute")

#    Symbol="GOLD"
#    GoldCandle5Min=candlestick.getLiveDataFromZerodha(Symbol,"15minute")
#    Symbol="SILVER"
#    SilverCandle5Min=candlestick.getLiveDataFromZerodha(Symbol,"15minute")

#    Symbol="GOLD"
#    GoldCandleXMin=candlestick.getLiveDataFromZerodha(Symbol,"5minute")
#    Symbol="SILVER"
#    SilverCandleXMin=candlestick.getLiveDataFromZerodha(Symbol,"5minute")
    GoldCandle5Min=GoldCandleXMin
    SilverCandle5Min=SilverCandleXMin
    SilverHistory.iloc[DataIndex]['Date']
    fibMS={}
    AllList=[]
    test(SilverHistory,DataIndex,0)
    SF1=AllList    
    AllList=[]
    test(SilverHistoryV2,DataIndex,0)
    SF2=AllList
    SF3=fibMS
    
    fibMS={}
    AllList=[]
    test(GoldHistoryV1,DataIndex,0)
    GF1=AllList
    AllList=[]
    test(GoldHistoryV2,DataIndex,0)
    GF2=AllList
    GF3=fibMS
    AllList=[]
    
    GP1=GoldHistoryV1.iloc[DataIndex]['IPivot']
    GP2=GoldHistoryV2.iloc[DataIndex]['IPivot']
    SP1=SilverHistory.iloc[DataIndex]['IPivot']
    SP2=SilverHistoryV2.iloc[DataIndex]['IPivot']
    
    GoldData=getSpecificData(GoldHistoryV1,GoldCandle5Min,DataIndex)
    SilverData=getSpecificData(SilverHistoryV2,SilverCandle5Min,DataIndex)
    
    SearchData=GoldCandleXMin
    SilverSearchData=SilverCandleXMin
    #SilverData.iloc[36]['Date'][']
    #GoldData=getSpecificData1(GoldHistoryV1,GoldCandle5Min,DataIndex,4)
    #SilverData=getSpecificData1(SilverHistoryV2,SilverCandle5Min,DataIndex,4)

    GoldData['high'][:3]
    isAnyOrder=False
    LastTransaction=""
    LastDateIndex=0
    i=1
    LastFoundIndex=-1
    LastFoundSignal=""
    fPH=SilverHistoryV2.iloc[DataIndex]['High']
    fPL=SilverHistoryV2.iloc[DataIndex]['Low']
    #DataIndex=7
    SilverHistoryV2.iloc[DataIndex]['Date']
    #SilverHistory.iloc[DataIndex]
    #GoldHistoryV1.iloc[DataIndex]
    #GoldHistoryV2.iloc[DataIndex]
    SRange=fPH-fPL    
    Stolerance=round(SRange*.01,0)
    SMargin=round(SRange*.25,0)
    SStoploss=round(SRange*.3,0)
    
    fPH=GoldHistoryV1.iloc[DataIndex]['High']
    fPL=GoldHistoryV1.iloc[DataIndex]['Low']
    GRange=fPH-fPL    
    Gtolerance=round(GRange*.01,0)
    GMargin=round(GRange*.25,0)
    GStoploss=round(GRange*.3,0)
    if(GMargin>100):
        GMargin=100
        GStoploss=110
        
    while(i<len(GoldData)):
        if(i>10):
            j=i-10
        else:
            j=i
        #i=25
        SLL=SilverData['low'][j:i+1].min()
        SHH=SilverData['high'][j:i+1].max()
        SL=SilverData.iloc[i]['low']
        SH=SilverData.iloc[i]['high']
        SO=SilverData.iloc[i]['open']
        SC=SilverData.iloc[i]['close']
        
        GLL=GoldData['low'][j:i+1].min()
        GHH=GoldData['high'][j:i+1].max()
        GL=GoldData.iloc[i]['low']
        GH=GoldData.iloc[i]['high']
        GO=GoldData.iloc[i]['open']
        GC=GoldData.iloc[i]['close']
        
        
        Transaction=""
        Reliability=False
        Data=GoldData    
        
        DateIndex=i
        #Margin=0.002
        #Stoploss=0.002            
       
        
        #SilverData.iloc[9]['Date']
        #i=11
        #isAnyOrder=True
        
        #i=i+1
        if (isAnyOrder) :
            #Result=candlestick.Check(Data,LastTransaction,LastDateIndex,GMargin,GStoploss,SearchData[:i])                                
            #print(str(SilverData.iloc[i]['Date']) +"\t" +str(Result['Profit']))
            #if(Result['Profit']==GMargin or abs(Result['Profit'])==GStoploss):
            #    isAnyOrder=False                    
                    #print(str(SilverData.iloc[i]['Date']) +" Sell  \t" + str(GO>GC) + "\t"+str(SO>SC) + " - " + str(Result['Profit']))
            CurrentDate=SilverData.iloc[i]['Date'].strftime("%m/%d/%Y %I:%M %p")
            if(LastResult['Hit']=="Hit"):
                if (CurrentDate==LastResult['TargetTime']):            
                    isAnyOrder=False
            elif(LastResult['Hit']=="StopLoss"):
                if (CurrentDate==LastResult['StopLossTime']):            
                    isAnyOrder=False
            elif ((LastResult['Hit']=="LastPriceHit-Loss") or (LastResult['Hit']=="LastPrice-Profit")):
                i=len(GoldData)
                isAnyOrder=False
                    #BMessages.append(str(SilverData.iloc[LastDateIndex]['Date']) +"\t" + LastTransaction +"\t" + str(GPO1>GPC1) + " < " + str(GPO>GPC) +" < " +str(GO>GC) + "\t==\t"+str(SO>SC)+" > "+str(SPO>SPC)+" > "+str(SPO1>SPC1) + " -\t " + str(Result['Profit']) + " - " + str(GO==GC) + " SP=" + str(AtSilverPivot) +  " GP=" + str(AtGoldPivot) + "\t"+str(SilverData.iloc[LastDateIndex]['Date']))
            
        if((LastFoundIndex!=-1) and (isAnyOrder==False)):        
            SPL=SilverData.iloc[LastFoundIndex]['low']
            SPH=SilverData.iloc[LastFoundIndex]['high']
            SPO=SilverData.iloc[LastFoundIndex]['open']
            SPC=SilverData.iloc[LastFoundIndex]['close']
            GPO=GoldData.iloc[LastFoundIndex]['open']
            GPC=GoldData.iloc[LastFoundIndex]['close']
            GPL=GoldData.iloc[LastFoundIndex]['low']
            GPH=GoldData.iloc[LastFoundIndex]['high']
            SPO1=SilverData.iloc[LastFoundIndex-1]['open']
            SPC1=SilverData.iloc[LastFoundIndex-1]['close']
            GPO1=GoldData.iloc[LastFoundIndex-1]['open']
            GPC1=GoldData.iloc[LastFoundIndex-1]['close']
            
            
#            if((SL==SP1) or (SL==SP2)):
#                print("At Pivot")
            
            
            if((SL>SPL) and (GL>GPL)):
                Result={}
                Result['Profit']=0    
                Transaction="Buy"
                if((AtSilverPivot or AtGoldPivot) and False):
                    Result=candlestick.Check(Data,Transaction,DateIndex,GMargin,GStoploss,SearchData)
                    Messages.append(str(SilverData.iloc[i]['Date']) +"\t"+Transaction+"2   \t" + str(GPO1>GPC1) + " < " + str(GPO>GPC) +" < " +str(GO>GC) + "\t==\t"+str(SO>SC)+" > "+str(SPO>SPC)+" > "+str(SPO1>SPC1) + " -\t " + str(Result['Profit']) + " - " + " SP=" + str(AtSilverPivot) +  " GP=" + str(AtGoldPivot)+ "\tS="+str(AtSilverPivotS) + "\tG="+str(AtGoldPivotS))
                Reliability= (((GO>GC)==False) and ((SO>SC)==False) and ((GPO1>GPC1)==True) and ((SPO1>SPC1)==True))
                Reliability= (Reliability or 
                              (
                                      ((GO>GC)==False) and ((SO>SC)==False) and 
                                      ((GPO1>GPC1)==False) and ((SPO1>SPC1)==False) and 
                                      ((GPO>GPC)==False) and ((SPO>SPC)==False)
                                      )
                              )
                if ((Transaction!="") and Reliability):
                    if(GO==GC):
                        Transaction="Sell"
                    
                    Result=candlestick.Check(Data,Transaction,DateIndex,GMargin,GStoploss,SearchData)
                    LastResult=Result
                    isAnyOrder=True
                    LastTransaction=Transaction
                    LastDateIndex=i
#                    if(Result['Profit']==GMargin or abs(Result['Profit'])==GStoploss):
#                        isAnyOrder=False                    
                    #print(str(SilverData.iloc[i]['Date']) + "\t "+Transaction+"1   \t" + str(GO>GC) + "\t"+str(SO>SC) + " - " + str(Result['Profit']))
                    BMessages.append(getDf(SilverData.iloc[i]['Date'],Transaction,
                                           (GPO1>GPC1),(GPO>GPC),(GO>GC),
                                           (SO>SC),(SPO>SPC),(SPO1>SPC1),
                                           Result['Profit'],AtSilverPivot,AtGoldPivot,(GO==GC),
                                           GResult1,GResult2,GResult3,
                                           SResult1,SResult2,SResult3))
                             
                    
                    TProfit=Result['Profit']+TProfit
            if((SH<SPH) and (GH<GPH)):
                Result={}
                Result['Profit']=0    
                #print(str(SilverData.iloc[i]['Date']) +" Sell \t" + str(GO>GC) + "\t"+str(SO>SC))
                Transaction="Sell"
                
                if((AtSilverPivot or AtGoldPivot) and False):
                    Result=candlestick.Check(Data,Transaction,DateIndex,GMargin,GStoploss,SearchData)
                    Messages.append(str(SilverData.iloc[i]['Date']) +" Sell2  \t" + str(GPO1>GPC1) + " < " + str(GPO>GPC) +" < " +str(GO>GC) + "\t==\t"+str(SO>SC)+" > "+str(SPO>SPC)+" > "+str(SPO1>SPC1) + " -\t " + str(Result['Profit']) + " - " + str(GO==GC) + " SP=" + str(AtSilverPivot) +  " GP=" + str(AtGoldPivot)+ "\tS="+str(AtSilverPivotS) + "\tG="+str(AtGoldPivotS))
                    
                Reliability= (((GO>GC)==True) and ((SO>SC)==True) and ((GPO1>GPC1)==False) and ((SPO1>SPC1)==False))
                Reliability= (Reliability or 
                              (
                                      ((GO>GC)==True) and ((SO>SC)==True) and 
                                      ((GPO1>GPC1)==True) and ((SPO1>SPC1)==True) and 
                                      ((GPO>GPC)==True) and ((SPO>SPC)==True)
                                      )
                              )
                if ((Transaction!="") and Reliability):
                    Result={}
                    Result['Profit']=0
                    if(GO==GC):
                        Transaction="Buy"
                    Result=candlestick.Check(Data,Transaction,DateIndex,GMargin,GStoploss,SearchData)
                    LastResult=Result
                    isAnyOrder=True
                    LastTransaction=Transaction
                    LastDateIndex=i
#                    if(Result['Profit']==GMargin or abs(Result['Profit'])==GStoploss):
#                        isAnyOrder=False                    
                    #print(str(SilverData.iloc[i]['Date']) +" Sell  \t" + str(GO>GC) + "\t"+str(SO>SC) + " - " + str(Result['Profit']))
                    #BMessages.append(str(SilverData.iloc[i]['Date']) +" Sell  \t" + str(GPO1>GPC1) + " < " + str(GPO>GPC) +" < " +str(GO>GC) + "\t==\t"+str(SO>SC)+" > "+str(SPO>SPC)+" > "+str(SPO1>SPC1) + " -\t " + str(Result['Profit']) + " - " + str(GO==GC) + " SP=" + str(AtSilverPivot) +  " GP=" + str(AtGoldPivot))
                    BMessages.append(getDf(SilverData.iloc[i]['Date'],Transaction,
                                           (GPO1>GPC1),(GPO>GPC),(GO>GC),
                                           (SO>SC),(SPO>SPC),(SPO1>SPC1),
                                           Result['Profit'],AtSilverPivot,AtGoldPivot,(GO==GC),
                                           GResult1,GResult2,GResult3,
                                           SResult1,SResult2,SResult3))
                    
                    TProfit=Result['Profit']+TProfit
            if(LastFoundSignal=="Buy" and ( (SPL-Stolerance <= SL <= SPL+Stolerance) or (GPL-Gtolerance <= GL <= GPL+Gtolerance))):
                Reliability= (((GO>GC)==False) and ((SO>SC)==False) and ((GPO1>GPC1)==True) and ((SPO1>SPC1)==True))
                if(Reliability):
                    Result={}
                    Result['Profit']=0
#                    Result=candlestick.Check(Data,"Buy",DateIndex,GMargin,GStoploss,SearchData)
#                    BMessages.append(str(SilverData.iloc[i]['Date']) +" Buy  \t" + str(GPO1>GPC1) + " < " + str(GPO>GPC) +" < " +str(GO>GC) + "\t==\t"+str(SO>SC)+" > "+str(SPO>SPC)+" > "+str(SPO1>SPC1) + " -\t " + str(Result['Profit']) + " - " + str(GO==GC) + " SP=" + str(AtSilverPivot) +  " GP=" + str(AtGoldPivot))
                    if(AtGoldPivot ):
                        
#                        Result=candlestick.Check(Data,"Buy",DateIndex,GMargin,GStoploss,SearchData)
                        print(str(i)+  "\t-" +str(SilverData.iloc[i]['Date']) +"\tBUYY \t" + str(GO>GC) + "\t"+str(SO>SC) + "\tS="+str(AtSilverPivotS) + "\tG="+str(AtGoldPivotS)+" - " + str(Result['Profit']))            
                        AMessages.append(str(SilverData.iloc[i]['Date']) +"\tBUYY GOLD\t" + str(GO>GC) + "\t"+str(SO>SC) + "\tS="+str(AtSilverPivotS) + "\tG="+str(AtGoldPivotS)+" - " + str(Result['Profit']))
                    if(AtSilverPivot ):
#                        Result=candlestick.Check(SilverData,"Buy",DateIndex,SMargin,SStoploss,SilverSearchData)
                        print(str(i)+  "\t-" +str(SilverData.iloc[i]['Date']) +"\tBUYY \t" + str(GO>GC) + "\t"+str(SO>SC) + "\tS="+str(AtSilverPivotS) + "\tG="+str(AtGoldPivotS)+" - " + str(Result['Profit']))            
                        AMessages.append(str(SilverData.iloc[i]['Date']) +"\tBUYY SILVER\t" + str(GO>GC) + "\t"+str(SO>SC) + "\tS="+str(AtSilverPivotS) + "\tG="+str(AtGoldPivotS)+" - " + str(Result['Profit']))
                    
            if(LastFoundSignal=="Sell" and ( (SH-Stolerance <= SPH <= SH+Stolerance) or (GH-Gtolerance <= GPH <= GH+Gtolerance))):
                Reliability= (((GO>GC)==True) and ((SO>SC)==True) and ((GPO1>GPC1)==False) and ((SPO1>SPC1)==False))
                if(Reliability):
                    Result={}
                    Result['Profit']=0
#                    Result=candlestick.Check(Data,"Sell",DateIndex,GMargin,GStoploss,SearchData)
#                    BMessages.append(str(SilverData.iloc[i]['Date']) +" Sell  \t" + str(GPO1>GPC1) + " < " + str(GPO>GPC) +" < " +str(GO>GC) + "\t==\t"+str(SO>SC)+" > "+str(SPO>SPC)+" > "+str(SPO1>SPC1) + " -\t " + str(Result['Profit']) + " - " + str(GO==GC) + " SP=" + str(AtSilverPivot) +  " GP=" + str(AtGoldPivot))
                    if(AtGoldPivot):
                        #print(str(i)+  "\t- " +str(SilverData.iloc[i]['Date']) +"\tSELLK \t" + str(GO>GC) + "\t"+str(SO>SC))
                        Result=candlestick.Check(Data,"Sell",DateIndex,GMargin,GStoploss,SearchData)
                        print(str(i)+  "\t-" +str(SilverData.iloc[i]['Date']) +"\tSELLK \t" + str(GO>GC) + "\t"+str(SO>SC) + "\tS="+str(AtSilverPivotS) + "\tG="+str(AtGoldPivotS)+" - " + str(Result['Profit']))            
                        AMessages.append(str(SilverData.iloc[i]['Date']) +"\tSELLK GOLD\t" + str(GO>GC) + "\t"+str(SO>SC) + "\tS="+str(AtSilverPivotS) + "\tG="+str(AtGoldPivotS)+" - " + str(Result['Profit']))
                    if(AtSilverPivot ):
                        Result=candlestick.Check(SilverData,"Sell",DateIndex,SMargin,SStoploss,SilverSearchData)
                        print(str(i)+  "\t-" +str(SilverData.iloc[i]['Date']) +"\tSELLK \t" + str(GO>GC) + "\t"+str(SO>SC) + "\tS="+str(AtSilverPivotS) + "\tG="+str(AtGoldPivotS)+" - " + str(Result['Profit']))            
                        AMessages.append(str(SilverData.iloc[i]['Date']) +"\tSELLK SILVER\t" + str(GO>GC) + "\t"+str(SO>SC) + "\tS="+str(AtSilverPivotS) + "\tG="+str(AtGoldPivotS)+" - " + str(Result['Profit']))
            
            
                
            LastFoundIndex=-1
            LastFoundSignal=""
        SResult1=False;SResult2=False;SResult3=False
        GResult1=False;GResult2=False;GResult3=False
        if(SL==SLL):
            SResult1=isInRange(SilverHistoryV2,DataIndex,SL,SF1,0,0.03)        
            SResult2=isInRange(SilverHistoryV2,DataIndex,SL,SF2,0,0.03)
            SResult3=isInRange(SilverHistoryV2,DataIndex,SL,list(SF3.values()),0,0.03)
            LastFoundSignal="Buy"
        else:
            if(SH==SHH):
                SResult1=isInRange(SilverHistoryV2,DataIndex,SH,SF1,0,0.03)        
                SResult2=isInRange(SilverHistoryV2,DataIndex,SH,SF2,0,0.03)
                SResult3=isInRange(SilverHistoryV2,DataIndex,SH,list(SF3.values()),0,0.03)       
                LastFoundSignal="Sell"
        
        if(GL==GLL):
            GResult1=isInRange(GoldHistoryV1,DataIndex,GL,GF1,0,0.03)        
            GResult2=isInRange(GoldHistoryV1,DataIndex,GL,GF2,0,0.03)        
            GResult3=isInRange(GoldHistoryV1,DataIndex,GL,list(GF3.values()),0,0.03)        
            LastFoundSignal="Buy"
        else:
            if(GH==GHH):
                GResult1=isInRange(GoldHistoryV1,DataIndex,GH,GF1,0,0.03)        
                GResult2=isInRange(GoldHistoryV1,DataIndex,GH,GF2,0,0.03)        
                GResult3=isInRange(GoldHistoryV1,DataIndex,GH,list(GF3.values()),0,0.03)
                LastFoundSignal="Sell"
        
        #if ( (GResult3==True) or SResult3==True):
        #   Messages.append(SilverData.iloc[i]['Date']) 
        if(((SResult1==True)| (SResult2==True)| (SResult3==True)) and ((GResult1==True)| (GResult2==True)| (GResult3==True))):
            #print(SilverData.iloc[i]['Date'])
            LastFoundIndex=i
        TS=round(SRange*.02,0)
        TG=round(GRange*.02,0)
        AtGoldPivot=False
        AtSilverPivot=False
        AtSilverPivotS=""
        AtGoldPivotS=""
        
        if((SL-TS <= SP1 <= SL+TS)):
            AtSilverPivot=True
            AtSilverPivotS="SP1"
        if((SL-TS <= SP2 <= SL+TS)):
            AtSilverPivot=True
            AtSilverPivotS="SP2"
            #print("Silver At Pivot")
        if((GL-TG <= GP1 <= GL+TG)):
            AtGoldPivot=True
            AtGoldPivotS="GP1"
        if ((GL-TG <= GP2 <= GL+TG)):
            #print("Gold At Pivot")
            AtGoldPivot=True
            AtGoldPivotS="GP2"
        #print(str(i)+" - " + str(LastFoundIndex))
        i=i+1
    Msg=""
    print("Last Run Time :"+LastRunTime)
    for Message in Messages:
        print(Message)
    
    for Message in AMessages:
        print(Message)
    
    pf=0
    for Message in BMessages:
        if( (Message.find("True < True < True")<0) and (Message.find("False < False < True")<0)):
            
            print(Message)
            za=Message.find("-\t")
            zb=Message.find("- ")        
            pf=pf+float(Message[za+3:zb-1])
    print(pf)
    LastRunTime=str(datetime.now())
    print("Waiting.... Check the Profit Manually")
    Columns=["Date","Transaction","GC2","GC1","GC","SC","SC1","SC2","Profit","GP","SP","Doji","GP1","GP2","GF1","SP1","SP2","SF1"]
    TDF=pd.DataFrame(BMessages)
    TDF=TDF.reindex(columns=Columns)
    TDF.iloc[0]
    TDF[['GC1','GC2','GC']]
    TDF.to_csv("html\Output.csv",index=False,sep="\t")
    TDF['Profit'].sum()
    TDF[(TDF['GC2']==True) &
        (TDF['GC1']==True) &
        (TDF['GC']==True) ]['Profit'].sum()
    
    TDF[(TDF['GC2']==False) &
        (TDF['GC1']==False) &
        (TDF['GC']==False) ]['Profit'].sum()
    
    TDF=DF
    TDF['Profit'].sum()
    TDF['Profit'].count()

    G1A=TDF[((((TDF['GC2']==True) & (TDF['GC1']==True) & (TDF['GC']==True))==False) &
        (((TDF['GC2']==False) & (TDF['GC1']==False) & (TDF['GC']==False))==False) 
        )
#        & ((TDF["SF1"]==True))
        #& (TDF["GP1"]==True))
        
#            | ((TDF["SF1"]==True) & (TDF["SP1"]==True)))
        #]['Profit'].count()
        ]['Profit'].sum()
    
def Con(d):
    return d*-1    

    G1B=TDF[((((TDF['GC2']==True) & (TDF['GC1']==True) & (TDF['GC']==True))==True) |
        (((TDF['GC2']==False) & (TDF['GC1']==False) & (TDF['GC']==False))==True) )
        & ( True
        #(TDF["GP1"]==True)
        #& (TDF["GP1"]==True) 
        #))
        #& (TDF["SP1"]==True)
        )
            #| ((TDF["SF1"]==True) & (TDF["SP1"]==True)))
#        ][['Date','Profit','Transaction','GF1','GP1','GP2']]
    #    ][['Profit','Transaction','AtGoldPivotS','AtSilverPivotS']]
    #]['Profit'].count() 
 #   ]['Profit'].apply(Con).sum()
    ]['Profit'].sum()

#    TDF.columns
    G1D=TDF[((((TDF['GC2']==True) & (TDF['GC1']==True) & (TDF['GC']==True))==True) |
        (((TDF['GC2']==False) & (TDF['GC1']==False) & (TDF['GC']==False))==True) )
        & ((TDF["GP1"]==True)
        #& (TDF["GF1"]==True) 
        #))
        #& (TDF["SP1"]==True)
        )
            #| ((TDF["SF1"]==True) & (TDF["SP1"]==True)))
#        ][['Date','Profit','Transaction','GF1','GP1','GP2']]
    #    ][['Profit','Transaction','AtGoldPivotS','AtSilverPivotS']]
#    ]['Profit'].count()
    ]['Profit'].sum()
    ]['Profit'].apply(Con).sum()
    
    
    G1C=TDF[((((TDF['GC2']==True) & (TDF['GC1']==True) & (TDF['GC']==True))==True) |
        (((TDF['GC2']==False) & (TDF['GC1']==False) & (TDF['GC']==False))==True) )
        & ((TDF["GP1"]==False)
        & (TDF["GP2"]==False) 
        #))
        #& (TDF["SP1"]==True)
        )
            #| ((TDF["SF1"]==True) & (TDF["SP1"]==True)))
        ][['Date','Profit','Transaction','GF1','SP1','SP2','SF1']]
#        ][['Profit','Transaction','AtGoldPivotS','AtSilverPivotS']]
#    ]['Profit'].count()
    ]['Profit'].sum()

    TDF[(((TDF['GC2']==True) & (TDF['GC1']==True) & (TDF['GC']==True))==True) |
        (((TDF['GC2']==False) & (TDF['GC1']==False) & (TDF['GC']==False))==True) 
        & (((TDF["GF1"]==False) & (TDF["GP1"]==False))
            | ((TDF["SF1"]==False) & (TDF["SP1"]==False)))
        ]['Profit'].sum()
    

    TDF[(TDF['GC2']==False) &
        (TDF['GC1']==False) &
        (TDF['GC']==False) ]['Profit'].sum()
    
    TDF[(TDF['GC2']==True) &
        (TDF['GC1']==True) &
        (TDF['GC']==True) ][['Profit','GP1','GP2','GF1','SP1','SP2','SF1']]
    
    TDF[(TDF["GP1"]==True) & TDF["GF1"]==True ]['Profit'].sum()
    TDF[(TDF["GP2"]==True) & TDF["GF1"]==True ]['Profit'].sum()
    TDF[(TDF["SP1"]==True) & (TDF["SF1"]==True) ]['Profit'].sum()
    TDF[(TDF["SP2"]==True) & TDF["SF1"]==True ]['Profit'].sum()
    
    TDF[(TDF["GP1"]==True) & (TDF["GF1"]==True )
    & (TDF["SP1"]==True)   ][['Date','Profit','Transaction']]
    
    TDF[(TDF["GP1"]==True) & (TDF["GF1"]==True )
    & (TDF["SP2"]==True)   ][['Date','Profit','Transaction']]
    
    TDF[(TDF["SP1"]==True) & (TDF["SF1"]==True )
    & (TDF["GP1"]==True)   ][['Date','Profit','Transaction']]
    
    
    TDF[(TDF["SP1"]==True) & (TDF["SF1"]==True )
    & (TDF["GP2"]==True)   ][['Date','Profit','Transaction']]
    
    & (TDF["SF1"]==True)
    
    
    & (TDF["SP1"]==True)
    ['Profit'].sum()
    
    
    BDF.columns
    BDF[(BDF["SP1"]==True) & (BDF["SF1"]==True )
    & (BDF["GP2"]==True)   ][['Date','Profit','Transaction']]
    BDF[['Date','Profit','GP1','GP2','GF1','SP1','SP2','SF1']]
    
    #time.sleep(120)
#        za=Message.find("-\t")
#        zb=Message.find("- ")        
#        pf=pf+float(Message[za+3:zb-1])
        
#    for Message in Messages:
#        print(Message)
    T1['Symbol']