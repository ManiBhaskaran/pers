# -*- coding: utf-8 -*-
"""
Created on Sat Nov  9 09:59:06 2019

@author: lalitha
"""

#DateIndex=1
p=48
print(StockList.iloc[p]['Symbol'])
Symbol=StockList.iloc[p]['Symbol']


Data=DataFrameCollection[StockList.iloc[p]['Symbol']].fillna(0)

if(False):
    UpdateDataFrameCollection(StockList.iloc[p]['Symbol'],2)
    NiftyData=DataFrameCollection['NIFTY'].fillna(0)
    Data=Data.astype({'LowP': 'float','LowS': 'float','HighP': 'float','HighS': 'float','CloseP': 'float','CloseS': 'float'})
    Data['BaseLine1']=0.9
    Data['BaseLine2']=0.8
    Data['BaseLine3']=0.01
    Data['BaseLine4']=-0.9
    Data['BaseLine5']=-0.8
    
    Data['AvgP']=  Data.apply(lambda row: (float(row.LowP) + float(row.HighP) + float(row.CloseP))/3, axis=1)
    Data['AvgS']=  Data.apply(lambda row: (float(row.LowS) + float(row.HighS) + float(row.CloseS))/3, axis=1)
    
    Data['AvgPStd']=  Data[['LowP','HighP','CloseP']].std(axis=1)
    Data['AvgSStd']=  Data[['LowS','HighS','CloseS']].std(axis=1)
    #Data['AvgSStd']=  Data.apply(lambda row: pd.Series([row.LowS, row.HighS,row.CloseS]))
    #Data['AvgPStd']=  Data.apply(lambda row: pd.Series([float(row.LowP) , float(row.HighP) , float(row.CloseP)]))
    
    Datesar=list(Data['Date'])
    LowP=list(Data['LowP'])
    LowS=list(Data['LowS'])
    HighS=list(Data['HighS'])
    HighP=list(Data['HighP'])
    CloseS=list(Data['HLCS'])
    CloseP=list(Data['HLCP'])
    #pd.rolling_corr(Data['High'],NiftyData['High'],15)
    MAHigh=list(Data['High'].rolling(window=15).corr(NiftyData['High']).fillna(0))
    MALow=list(Data['Low'].rolling(window=15).corr(NiftyData['Low']).fillna(0))
    fig = go.Figure()
    
    fig.add_trace(go.Scatter(x=Datesar, y=list(Data['BaseLine1']), name='BaseLine1',
                             line=dict(color='green', width=2,dash='dash')))
    fig.add_trace(go.Scatter(x=Datesar, y=list(Data['BaseLine2']), name='BaseLine2',
                             line=dict(color='red', width=2,dash='dot')))
    fig.add_trace(go.Scatter(x=Datesar, y=list(Data['BaseLine3']), name='BaseLine3',
                             line=dict(color='red', width=2,dash='dot')))
    fig.add_trace(go.Scatter(x=Datesar, y=list(Data['BaseLine4']), name='BaseLine4',
                             line=dict(color='green', width=2,dash='dash')))
    fig.add_trace(go.Scatter(x=Datesar, y=list(Data['BaseLine5']), name='BaseLine5',
                             line=dict(color='red', width=4,dash='dot')))
    
    Xar=[]
    Xar.append(Datesar[int(len(Datesar)/2)])
    Yar=[]
    Yar.append(1.5)
    textAr=[]
    textAr.append(StockList.iloc[p]['Symbol'])
    fig.add_trace(go.Scatter(x=Xar,y=Yar,text=textAr, mode='text'))
    
    fig.add_trace(go.Scatter(x=Datesar, y=list(Data['AvgPStd']), name='AvgPStd',
                             line=dict(color='yellow', width=4,dash='dot')))
    
    fig.add_trace(go.Scatter(x=Datesar, y=list(Data['AvgSStd']), name='AvgSStd',
                             line=dict(color='green', width=4,dash='dot')))
    
    fig.add_trace(go.Scatter(x=Datesar, y=list(Data['RLowP']), name='RLowP',
                             line=dict(color='firebrick', width=1,dash='dash')))
    
    
    fig.add_trace(go.Scatter(x=Datesar, y=list(Data['RHighP']), name='RHighP',
                             line=dict(color='magenta', width=1,dash='dot')))
    
    fig.add_trace(go.Scatter(x=Datesar, y=LowP, name='LowP',
                                 line=dict(color='firebrick', width=1)))   
    fig.add_trace(go.Scatter(x=Datesar, y=LowS, name = 'LowS',
                                 line=dict(color='royalblue', width=1)))
    
    if(False):
        fig.add_trace(go.Scatter(x=Datesar, y=HighS, name='HighS',
                                 line = dict(color='crimson', width=1)))
        fig.add_trace(go.Scatter(x=Datesar, y=HighP, name='HighP',
                             line = dict(color='greenyellow', width=1)))
        fig.add_trace(go.Scatter(x=Datesar, y=CloseS, name='CloseS',
                             line=dict(color='mediumpurple', width=1)))
        fig.add_trace(go.Scatter(x=Datesar, y=CloseP, name='CloseP',
                             line=dict(color='royalblue', width=1)))
    plot(fig,filename="12Chart4.html")


dispChart(Data,"Test123Mani20",StockList.iloc[p]['Symbol'])

LastPivot=pd.read_csv(r"C:\ReadMoneycontrol\Mani 2.0\Data3\\"+Symbol+"-Pivot.csv",encoding='utf-8')
PivotD=LastPivot.iloc[DateIndex*-1]
i=0
Percentage=0.0002
T=round(Data.iloc[0]['Open']*Percentage,2)
HighList=[]
LowList=[]
ResultAr=[]

while(i<len(Data)):
    ResultSt={}
    H=Data.iloc[i]['High']
    L=Data.iloc[i]['Low']
    #H=Data['High'].max()
    #L=Data['Low'].max()
#PivotD
    RangeList=getChartRangeList(H,L,PivotD)
        
    
    for R in RangeList:
        #R="A1000"
        if( H==PivotD[R]):
            #print(R+" High Same" + Data.iloc[i]['Date'])
            HighList.append(i)
        elif( H+T>=PivotD[R]>=H-T):
            #print(str(i)+ "==> "+ R+" High Approx " + Data.iloc[i]['Date'] +" - "+ str(H+T) + " = " + str(PivotD[R]) + " = "+ str(H-T))
            HighList.append(i)
        if( L==PivotD[R]):
            #print(R+" Low Same" + Data.iloc[i]['Date'])
            LowList.append(i)
        elif( L+T>=PivotD[R]>=L-T):
            #print(str(i)+ "==> "+ R+" Low Approx " + Data.iloc[i]['Date'] +" - "+ str(L+T) + " = " + str(PivotD[R]) + " = "+ str(L-T))
            LowList.append(i)    
    offset=5
    if(str(HighList).find(str(i-offset)+"")>0):
        a=isPeak(Data['High'][:i], len(Data['High'][:i]), Data.iloc[i-offset]['High'], i-10, i)
        if(a):
            Diff=round(Data.iloc[i-offset]['High']-Data.iloc[i]['High'],2)
            DiffP=round(Diff/Data.iloc[i]['High']*100,2)
            print(str(i)+ " - " + Data.iloc[i]['Date'] + " HIGH - " +Data.iloc[i-offset]['Date'] + " - " + str(a) + " - " + str(Diff) + " ~ " + str(DiffP));    
            ResultSt['Stock']=Symbol
            ResultSt['Index']=i
            ResultSt['CurrentDate']=Data.iloc[i]['Date']
            ResultSt['Type']='High'
            ResultSt['SingleDate']=Data.iloc[i-offset]['Date']
            ResultSt['Diff']=Diff
            ResultSt['DiffP']=DiffP
            ResultAr.append(ResultSt)
    if(str(LowList).find(str(i-offset)+"")>0):
        Trough=isTrough(Data['Low'][:i], len(Data['Low'][:i]), Data.iloc[i-offset]['Low'], i-10, i-1)
        if(Trough):
            Diff=round(Data.iloc[i-offset]['Low']-Data.iloc[i]['Low'],2)
            DiffP=round(Diff/Data.iloc[i]['Low']*100,2)
            print(str(i)+ " - "+Data.iloc[i]['Date'] + " Low - " +Data.iloc[i-offset]['Date'] + " - " + str(Trough)+ " - " + str(Diff) + " ~ " + str(DiffP));    
            ResultSt['Stock']=Symbol
            ResultSt['Index']=i
            ResultSt['CurrentDate']=Data.iloc[i]['Date']
            ResultSt['Type']='Low'
            ResultSt['SingleDate']=Data.iloc[i-offset]['Date']
            ResultSt['Diff']=Diff
            ResultSt['DiffP']=DiffP
            ResultAr.append(ResultSt)


    i=i+1

pd.DataFrame(ResultAr)


def dispChart(Data1,filename,Symbol):
    #Data=Data1
    LastPivot=pd.read_csv(r"C:\ReadMoneycontrol\Mani 2.0\Data3\\"+Symbol+"-Pivot.csv",encoding='utf-8')
    #ListData=['IPivot','H1','L1','L2','H2','A0','A236','A382','A500','A786']#,'Z236','Z382','Z500','Z786']
    #ListData=['IPivot','H1','H2','H3','A0','A236','A382','A500','A618','A786','A1000','A1236','A1382','A1500','A1618','A2000']
    PivotD=LastPivot.iloc[DateIndex*-1]
    ListData=getChartRangeList(Data1['High'].max(),Data1['Low'].min(),PivotD)
    #ListData=getChartRangeList(Data['High'].max(),Data['Low'].min(),PivotD)
    #ListData=['IPivot','L1','A0','A236','A382','A500','A786']#,'Z236','Z382','Z500','Z786']
    
    date1=parse(parse(PivotD['Date']).strftime("%Y-%m-%d 09:00"))
    date2=parse(parse(PivotD['Date']).strftime("%Y-%m-%d 15:30"))
    
    Lines=[]
    AxisText=[]
    AxisValue=[]
    AxisX=[]
    
    for la in ListData:
        Position=date2
        Symbol1="+"
        value=PivotD[la]
        color='rgb(100, 100, 100)'
        linestyle=3
        if(la.find("A")>=0):
            color='rgb(0, 255, 0)'
            linestyle=2
        if(la.find("Z")>=0):
            color='rgb(255, 0, 0)'
            linestyle=2
        if(la.find("H")>=0):
            color='rgb(0, 0, 255)'
            linestyle=1
            Position=date1
            Symbol1="-"
        if(la.find("L")>=0):
            color='rgb(255,0 , 255)'
            linestyle=1
            Position=date1
            Symbol1="-"
        
        
        Lines.append(candlestick.CreateLinesV1(date1,date2,value,color,linestyle))
        AxisText.append(la)
        AxisValue.append(value)            
        AxisX.append(candlestick.CurrentDate(candlestick.N1(Position,"10M",Symbol1)))
    
    AxisText.append(Symbol)
    AxisValue.append(max(AxisValue))            
    AxisX.append(candlestick.CurrentDate(candlestick.N1(date1,"4H","+")))
    Datesar=list(Data1['Date'])
    Xar=[]
    Xar.append(Datesar[int(len(Datesar)/2)])
    Yar=[]
    Yar.append(Data1['High'].max()*1.001)
    textAr=[]
    textAr.append(Symbol)
    
    trace0 = go.Scatter(x=AxisX,y=AxisValue,text=AxisText, mode='text')
    
    trace=go.Candlestick(x=Datesar,
                               open=Data1['Open'],
                               high=Data1['High'],
                               low=Data1['Low'],
                               close=Data1['Close'])
    data=[trace,trace0]
    #AxisText=[]
    #AxisValue=[]
    #AxisX=[]
    #data=[trace,trace0]
    Layout={}
    Layout["shapes"]=Lines
    #Layout["annotations"]=AnnotationsAr
       
    #annotations
    
    fig2 = {'data': data,'layout': Layout}

    
#
#    fig1 = go.Figure()
#    
#    List_ = list(Data1['Date'])
#    fig1.add_trace( go.Candlestick(x=List_,
#                               open=Data1['Open'],
#                               high=Data1['High'],
#                               low=Data1['Low'],
#                               close=Data1['Close']))
#    fig1.add_trace(go.Scatter(x=Xar,y=Yar,text=textAr, mode='text'))
#    
    plot(fig2,filename=filename+".html")
    


#dispChart(Data,"NIFTY20",StockList.iloc[p]['Symbol'])





#dispChart(NiftyData,"Test123Mani20-Nifty","NIFTY")

#NiftyData['High'].max()