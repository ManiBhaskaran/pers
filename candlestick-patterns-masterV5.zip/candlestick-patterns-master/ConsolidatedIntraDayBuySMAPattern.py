# -*- coding: utf-8 -*-
"""
Created on Mon Jan  6 18:08:34 2020

@author: lalitha
"""
import itertools
import jhtalib as ta
import requests
from dateutil.parser import parse
import plotly.graph_objs as go
from plotly import __version__
from plotly.offline import download_plotlyjs, init_notebook_mode, plot, iplot
import numpy as np
import plotly.io as pio
import os


from sklearn.model_selection import train_test_split    
from sklearn.tree import DecisionTreeRegressor
from sklearn.tree import DecisionTreeClassifier
from sklearn import metrics


#import datetime
import threading

from candlestick import candlestick
#import datetime
import pandas as pd
import json
import time
from dateutil.parser import parse
#import datetime
from datetime import datetime, timedelta


DIRNIFTYStockList="C:\ReadMoneycontrol\Mani 2.0\StockList.txt"
DIRFOStockList="C:\ReadMoneycontrol\Mani 2.0\StockList-New.txt"
DIRNIFTYStockListID="C:\ReadMoneycontrol\Mani 2.0\StockListIDOriginal.txt"
DIRFOStockListID="C:\ReadMoneycontrol\Mani 2.0\StockListID-NEW.csv"
StockListAll="C:\ReadMoneycontrol\Mani 2.0\StockListAll.txt"


DIRNIFTY="C:\ReadMoneycontrol\Mani 2.0"
DIRFO="C:\ReadMoneycontrol\Mani 2.0\\2"

DataDir=DIRNIFTY


#DataDir=DIRNIFTY
#StockListFile=DIRFOStockList
#RealTime=DIRFOStockListID
#DataDir=DIRNIFTY
#StockListFile=DIRNIFTYStockList
StockListFile=StockListAll
RealTime=DIRNIFTYStockListID


StockListFile=r"C:\ReadMoneycontrol\Mani 2.0\StockListID-NEWList.csv"
DataDir=r"C:\ReadMoneycontrol\Mani 2.0\NEWDataIncr1"

StockList=pd.read_csv(StockListFile)

def default(o):
    if isinstance(o, (datetime.date, datetime.datetime)):
        return o.isoformat()


def ApplyDF(Start,End):
    global IndexList,ResultList
    IndexList=IndexList+list(DayS.iloc[Start:End].index)
    #print("\n"+str(Start)+" = " +str(End) + " - " +str((datetime.now()-Date1).seconds))
    ResultList.append(DayS.iloc[Start:End].apply(lambda x: getFirstBuy(x,25,List,Group.get_group(x['CDATE'])),axis=1))

SellPos=-1
BuyPos=-1
Cdate=""
SearchDate=""
def getFirstBuy(X,Y,List,SearchDate):
#    global SellPos,Cdate,SearchDate
    global Cdate
    global BuyPos    
    targetdict={}
    targetar=[]
    targetar1=[]
#    if(Cdate!=X['CDATE']):
#        SearchDate=DayS[ ( DayS['CDATE']==X['CDATE'] )]
    Cdate=X['CDATE']
    Y=SearchDate.Indx.max()-1
    for a in List:    
        targetar.append(SearchFilter(SearchDate,X,Y,a) )
        
    
#    targetar.append(targetdict)
    return X['Date'],targetar


def SearchFilter(SearchDate,X,Y,Field):    
    ResultStr=SearchDate[ 
          (SearchDate['Indx']>X['Indx']) & 
          ( SearchDate['Indx']<Y) & 
          (SearchDate[Field]==True)
          ]
    if(len(ResultStr)>0):
        return ResultStr.Indx.iloc[0]
    else:
        return -1



ITSTOCKS=["TCS","JUSTDIAL","INFY","TATAELXSI","NIITTECH","MINDTREE","WIPRO","HCLTECH","TECHM","HEXAWARE"]
#'TCS',''  => 9:15 & 3:15
#'SBIN',Axisbank','BPCL' : 10-11
#NOTWORKING :- ONGC, MINDTREE,WIPRO,TECHM--
def PrStock(Stock):
    #Stock='GAIL'
    SBIN5Min=candlestick.LoadCSVData(DataDir,Stock,"15minute")
    SBIN5Min['CDATE']=pd.to_datetime(SBIN5Min['Date']).dt.strftime("%Y-%b-%d")
    SBINDay=candlestick.LoadCSVData(DataDir,Stock,"day")
    SBINDay['CDATE']=pd.to_datetime(SBINDay['Date']).dt.strftime("%Y-%b-%d")    
    SBIN5Min.drop_duplicates(subset =["Date"], keep = "first", inplace = True) 
    SBIN5Min['Indx']=((SBIN5Min['Date']-pd.to_datetime(pd.to_datetime(SBIN5Min['CDATE']).dt.strftime("%Y-%m-%d 09:15"))).dt.seconds/60/15).astype(int)
    SBIN5Min=SBIN5Min[SBIN5Min['Indx']<=24]
    SBINDay['HL']=SBINDay['High'].shift(1)-SBINDay['Low'].shift(1)
    SBINDay['PDayLow']=SBINDay['Low'].shift(1)
    SBINDay['PDayHigh']=SBINDay['High'].shift(1)
    SBINDay['PDayClose']=SBINDay['Close'].shift(1)
    SBINDay['PDayOpen']=SBINDay['Open'].shift(1)
    SBINDay['PDayVolume']=SBINDay['V'].shift(1)
    SBINDay['PDayVolumeSMA5']=SBINDay['V'].shift(1).rolling(5).mean()
    SBINDay['PDayVolumeSMA10']=SBINDay['V'].shift(1).rolling(10).mean()
    SBINDay['PDayVolumeSMA15']=SBINDay['V'].shift(1).rolling(15).mean()
    SBINDay['PDayVolumeSMA20']=SBINDay['V'].shift(1).rolling(20).mean()
    SBINDay['DayRSI14']=ta.RSI(SBINDay,14)
    SBINDay['DaySMA50']=SBINDay['Close'].shift(1).rolling(50).mean()
    SBINDay["IPivot"]=candlestick.MaRound((SBINDay['Close'].shift(1)+SBINDay['High'].shift(1)+SBINDay['Low'].shift(1))/3)
    SBINDay["H4"]=candlestick.MaRound(SBINDay["IPivot"]+((SBINDay['High'].shift(1)-SBINDay['Low'].shift(1))*3))   
    SBINDay["H3A"]=candlestick.MaRound(SBINDay["IPivot"]+((SBINDay['High'].shift(1)-SBINDay['Low'].shift(1))*2.5))   
    SBINDay["H3"]=candlestick.MaRound(SBINDay["IPivot"]+((SBINDay['High'].shift(1)-SBINDay['Low'].shift(1))*2))   
    SBINDay["H2A"]=candlestick.MaRound(SBINDay["IPivot"]+((SBINDay['High'].shift(1)-SBINDay['Low'].shift(1))*1.5))   
    SBINDay["H2"]=candlestick.MaRound(SBINDay["IPivot"]+((SBINDay['High'].shift(1)-SBINDay['Low'].shift(1))))      
    SBINDay["H1"]=candlestick.MaRound(2*SBINDay["IPivot"]-SBINDay["Low"].shift(1))    
    SBINDay["IPivot-H"]=round((SBINDay["IPivot"]+SBINDay["H1"])/2,2)
    SBINDay["L4"]=candlestick.MaRound(SBINDay["IPivot"]-((SBINDay['High'].shift(1)-SBINDay['Low'].shift(1))*3))
    SBINDay["L3A"]=candlestick.MaRound(SBINDay["IPivot"]-((SBINDay['High'].shift(1)-SBINDay['Low'].shift(1))*2.5))
    SBINDay["L3"]=candlestick.MaRound(SBINDay["IPivot"]-((SBINDay['High'].shift(1)-SBINDay['Low'].shift(1))*2))
    SBINDay["L2A"]=candlestick.MaRound(SBINDay["IPivot"]-((SBINDay['High'].shift(1)-SBINDay['Low'].shift(1))*1.5))   
    SBINDay["L2"]=candlestick.MaRound(SBINDay["IPivot"]-((SBINDay['High'].shift(1)-SBINDay['Low'].shift(1))))      
    SBINDay["L1"]=candlestick.MaRound(2*SBINDay["IPivot"]-SBINDay["High"].shift(1))        
    SBINDay["IPivot-L"]=round((SBINDay["IPivot"]+SBINDay["L1"])/2,2)
    
    merged = SBIN5Min.merge(SBINDay, on=['CDATE'], how='left')
    CustomMerge=merged[['Date_x','HL','PDayLow','PDayHigh','PDayClose','PDayOpen','PDayVolume','PDayVolumeSMA5','PDayVolumeSMA10','PDayVolumeSMA15','PDayVolumeSMA20', 'DayRSI14', 'DaySMA50',
                        'H1','H2','H2A','H3','H3A','H4','IPivot-H',"IPivot",
                        "L1","L2",'L2A',"L3",'L3A',"L4",'IPivot-L']]
    CustomMerge.columns=['Date', 'HL', 'PDayLow','PDayHigh','PDayClose','PDayOpen','PDayVolume','PDayVolumeSMA5','PDayVolumeSMA10','PDayVolumeSMA15','PDayVolumeSMA20', 'DayRSI14', 'DaySMA50',
                         'H1','H2','H2A','H3','H3A','H4','IPivot-H',"IPivot",
                        "L1","L2",'L2A',"L3",'L3A',"L4",'IPivot-L']
    SBIN5Min=SBIN5Min.merge(CustomMerge, on=['Date'], how='left')
    #SBIN5Min['HL']=merged['HL']
    #SBIN5Min['PLow']=merged['PLow']       
    SBIN5Min['HighFib']=round((SBIN5Min['High']-SBIN5Min['PDayLow'])*1000/SBIN5Min['HL'])
    SBIN5Min['LowFib']=round((SBIN5Min['Low']-SBIN5Min['PDayLow'])*1000/SBIN5Min['HL'])
    SBIN5Min['OpenFib']=round((SBIN5Min['Open']-SBIN5Min['PDayLow'])*1000/SBIN5Min['HL'])
    SBIN5Min['CloseFib']=round((SBIN5Min['Close']-SBIN5Min['PDayLow'])*1000/SBIN5Min['HL'])
    
    SBIN5Min.drop(SBIN5Min[SBIN5Min['Indx'] > 24].index, inplace = True) 
    #SBIN5Min.drop(SBIN5Min[SBIN5Min['Indx'] > 74].index, inplace = True) 
    offset=4
    SBIN5Min['SMA-C-21-1']=SBIN5Min['Close'].shift(1).rolling(21).mean()#For 5, its is 63
    SBIN5Min['SMA-C-150-1']=SBIN5Min['Close'].shift(1).rolling(150).mean()#For 5, its is 63
    SBIN5Min['SMA-O-150-1']=SBIN5Min['Open'].shift(1).rolling(150).mean()#For 5, its is 63
    SBIN5Min['SMA-O-150']=SBIN5Min['Open'].rolling(150).mean()#For 5, its is 63
    SBIN5Min['SMA-C-10-1']=SBIN5Min['Close'].shift(1).rolling(10).mean()#For 10 its 30
    SBIN5Min['SMA-C-21']=SBIN5Min['Close'].rolling(21).mean()#For 5, its is 63
    SBIN5Min['SMA-C-10']=SBIN5Min['Close'].rolling(10).mean()#For 10 its 30
    SBIN5Min['SMA-C-150']=SBIN5Min['Close'].rolling(150).mean()#For 5, its is 63
    SBIN5Min['SMA-V-20']=SBIN5Min['V'].shift(1).rolling(20).mean()#For 10 its 30
    SBIN5Min['SMA-V-20-1']=SBIN5Min['V'].shift(1).rolling(20).mean()#For 10 its 30
    SBIN5Min['SMA-V-20']=SBIN5Min['V'].rolling(20).mean()#For 10 its 30
    SBIN5Min['EMA-C-50']=SBIN5Min['Close'].ewm(span=50, adjust=False).mean()
    SBIN5Min['RSI14']=ta.RSI(SBIN5Min,14)
    SBIN5Min=SBIN5Min.sort_values('Date',ascending=False)    
    SBIN5Min['MaxP']=SBIN5Min['High'].shift(1).rolling(10).max()
    SBIN5Min['MinP']=SBIN5Min['Low'].shift(1).rolling(10).min()    
    SBIN5Min['Open5']=SBIN5Min['Open'].shift(5)
    SBIN5Min['MaxP1']=SBIN5Min['High'].shift(1).rolling(20).max()
    SBIN5Min['MinP1']=SBIN5Min['Low'].shift(1).rolling(20).min()
    SBIN5Min['Open15']=SBIN5Min['Open'].shift(15)
    SBIN5Min['MaxP2']=SBIN5Min['High'].shift(1).rolling(30).max()
    SBIN5Min['MinP2']=SBIN5Min['Low'].shift(1).rolling(30).min()
    SBIN5Min['Open20']=SBIN5Min['Open'].shift(20)    
    SBIN5Min['Max10']=SBIN5Min['High'].shift(9)
    SBIN5Min['Min10']=SBIN5Min['Low'].shift(9)
    SBIN5Min['Open10']=SBIN5Min['Open'].shift(10)    
    SBIN5Min=SBIN5Min.sort_values('Date',ascending=True)
    
    SBIN5Min['CV']=SBIN5Min.groupby(['CDATE'])['V'].apply(lambda x: x.cumsum())
    SBIN5Min['CDayHigh']=SBIN5Min.groupby(['CDATE'])['High'].apply(lambda x: x.cummax())
    SBIN5Min['CDayLow']=SBIN5Min.groupby(['CDATE'])['Low'].apply(lambda x: x.cummin())
    #SBIN5Min['COpen']=
    FirstOpen=pd.DataFrame(SBIN5Min.groupby(['CDATE']).apply(lambda x: x['Open'].iloc[0]))
    FirstOpen.columns=['DayOpen']
    FirstOpen['CDATE']=FirstOpen.index
    SBIN5Min=SBIN5Min.merge(FirstOpen,on=['CDATE'])
    #SBIN5Min.groupby(['CDATE'])['Low'].count()
    SBIN5Min['SMAV20']=SBIN5Min['V'].shift(1).rolling(20).mean()
#    SBIN5Min=candlestick.HA(SBIN5Min)
    #SBIN5Min=candlestick.heikenashi(SBIN5Min)
    #Dt=SBIN5Min[['Date','Open','High','Low','Close','DayOpen','HA_Close', 'HA_Open',
    #       'HA_High', 'HA_Low','CDayHigh','CDayLow']]
    #SBIN5Min['SMAV20'].head(30)
    
    Sdf=candlestick.Newmacd(SBIN5Min,"Close")
    SBIN5Min['MACD']=Sdf['MACD']
    #SCandle['RSI']=SRSIValue
    #Candle['Close']=Candle['Close']
    SBIN5Min['Signal']=Sdf['Signal']
    SBIN5Min['Crossover']=Sdf['Crossover']
#    Sdf=candlestick.Ichimoku(SBIN5Min,9,26,52,-26)
#    SBIN5Min.merge(Sdf)




    DayS=SBIN5Min
    DayS["RH1"]=(DayS['High']>DayS['H1']) & (DayS['Low']<DayS['H1'])
    DayS["RIPivot"]=(DayS['High']>DayS['IPivot']) & (DayS['Low']<DayS['IPivot'])
    DayS["RH2"]=(DayS['High']>DayS['H2']) & (DayS['Low']<DayS['H2'])    
    DayS["RH2A"]=(DayS['High']>DayS['H2A']) & (DayS['Low']<DayS['H2A'])
    DayS["RH3"]=(DayS['High']>DayS['H3']) & (DayS['Low']<DayS['H3'])
    DayS["RH3A"]=(DayS['High']>DayS['H3A']) & (DayS['Low']<DayS['H3A'])    
    DayS["RH4"]=(DayS['High']>DayS['H4']) & (DayS['Low']<DayS['H4'])
    DayS["RIP-H"]=(DayS['High']>DayS['IPivot-H']) & (DayS['Low']<DayS['IPivot-H'])
    DayS["RIP-L"]=(DayS['High']>DayS['IPivot-L']) & (DayS['Low']<DayS['IPivot-L'])
    DayS["RL1"]=(DayS['High']>DayS['L1']) & (DayS['Low']<DayS['L1'])
    DayS["RL2"]=(DayS['High']>DayS['L2']) & (DayS['Low']<DayS['L2'])    
    DayS["RL2A"]=(DayS['High']>DayS['L2A']) & (DayS['Low']<DayS['L2A'])
    DayS["RL3"]=(DayS['High']>DayS['L3']) & (DayS['Low']<DayS['L3'])
    DayS["RL3A"]=(DayS['High']>DayS['L3A']) & (DayS['Low']<DayS['L3A'])    
    DayS["RL4"]=(DayS['High']>DayS['L4']) & (DayS['Low']<DayS['L4'])
#    DayS["SH2SL"]=(DayS['High']>DayS['H2A']) & (DayS['Low']<DayS['H2A'])
#    DayS["SH2TA"]=(DayS['High']>DayS['H1']) & (DayS['Low']<DayS['H1'])
#    DayS["SH2ASL"]=(DayS['High']>DayS['H2A']) & (DayS['Low']<DayS['H2A'])
#    DayS["SH2ATA"]=(DayS['High']>DayS['H2']) & (DayS['Low']<DayS['H2'])
    
    #I = np.array([row[[x for x in range(A.shape[1]) if x != i-1]] for row in A if row[i-1] == i])
    #print I
    #len(DayS[(DayS["SH2ATA"]==True)])
    #Tz['Label']=np.select([(Tz['SellProfitP']>0) & (Tz['BuyProfitP']<0),(Tz['SellProfitP']<0) & (Tz['BuyProfitP']>0),(Tz['SellProfitP']<0) & (Tz['BuyProfitP']<0)],[-1,1,-100],Tz['Label'] )
    
    
    
    List=['RH1', 'RIPivot', 'RH2', 'RH2A',
           'RH3', 'RH3A', 'RH4', 'RIP-H','RIP-L','RL1','RL2','RL3','RL4','RL2A','RL3A']
    
    Group=DayS.groupby('CDATE')
    
    IndexList=[]
    ResultList=[]
    #itertools
    print("Starting")
    Date1=datetime.now()
    #i=0
    #j=0
    #Runthread=[]
    #Increment=50
    #while(i<len(DayS)):
    #    Runthread.append(threading.Thread(target=ApplyDF,args=(i,i+Increment)))
    #    Runthread[-1].start()
    #    if((j%10==0) & (j!=0)):
    #        for thread in Runthread:
    #            thread.join()
    #        Runthread=[]
    #    i=i+Increment
    #    j=j+1
    #for thread in Runthread:
    #    thread.join()    
    if(False):
        Result1=DayS.apply(lambda x: getFirstBuy(x,25,List,Group.get_group(x['CDATE'])),axis=1)
        print("StockNameStockName : " + str((datetime.now()-Date1).seconds))
        len(Result1.iloc[0])
        Result1
        
        TempAr=[]
        i=0
        while(i<len(Result1)):
            TempDict={}
            TempDict['Date']=Result1.iloc[i][0]
            j=0
            while(j<len(List)):
                TempDict[List[j]+"_R"]=Result1.iloc[i][1][j]
                j=j+1
            i=i+1
            TempAr.append(TempDict)
        CheckDfResultdf=pd.DataFrame(TempAr)
        len(CheckDfResultdf)
        merged = CheckDfResultdf.merge(DayS, on=['Date'], how='left')    
        SBIN5Min=merged

    SBIN5Min['Buy']=(
        (
        (SBIN5Min['Close']<SBIN5Min['H1']) & (SBIN5Min['High']<SBIN5Min['H1'])
        & (SBIN5Min['High'].shift(1)<SBIN5Min['H1'])
        & (SBIN5Min['High'].shift(2)<SBIN5Min['H1'])
        )
        |
        (
        (SBIN5Min['Close']<SBIN5Min['H2']) & (SBIN5Min['High']<SBIN5Min['H2'])
        & (SBIN5Min['Close']>SBIN5Min['H1'])
        )
        |
        (
        (SBIN5Min['DayOpen']<SBIN5Min['H2']) & (SBIN5Min['DayOpen']>SBIN5Min['H1'])
        & (SBIN5Min['Low']>SBIN5Min['IPivot'])
        )
        )




    IntraDayBuy=SBIN5Min[
            (
                    #( (SBIN5Min['Close']>SBIN5Min['SMA-C-21']) & (SBIN5Min['Open']<SBIN5Min['SMA-C-21'])) &
                (
                    (
                        (SBIN5Min['Close']>SBIN5Min['SMA-C-21']) &
                        (SBIN5Min['SMA-C-10']>SBIN5Min['SMA-C-21']) &
                        (SBIN5Min['Close']>SBIN5Min['SMA-C-150']) 
    #                    & ( (SBIN5Min['Close']>SBIN5Min['SMA-C-21']) & 
    #                     (
    #                             (SBIN5Min['Low']<SBIN5Min['SMA-C-10']) |
    #                             (SBIN5Min['SMA-C-21'].shift(1)<SBIN5Min['SMA-C-10'].shift(1)) |
    #                             (SBIN5Min['SMA-C-21'].shift(2)<SBIN5Min['SMA-C-10'].shift(2)) |
    #                             (SBIN5Min['SMA-C-21'].shift(3)<SBIN5Min['SMA-C-10'].shift(3))
    #                             
    #                     )
    #                )
                    )
    #            |
    #                (
    #                    (SBIN5Min['Close'].shift(1)>SBIN5Min['SMA-C-21'].shift(1)) &
    #                    (SBIN5Min['SMA-C-10'].shift(1)>SBIN5Min['SMA-C-21'].shift(1)) &
    #                    ( (SBIN5Min['Close'].shift(1)>SBIN5Min['SMA-C-21'].shift(1)) 
    #                    & (SBIN5Min['Low'].shift(1)<SBIN5Min['SMA-C-10'].shift(1))) 
    #                )
                ) &
    
    
    (
     (
        (SBIN5Min['SMA-C-10'].shift(1)>SBIN5Min['SMA-C-21'].shift(1)) &
        (SBIN5Min['SMA-C-10'].shift(2)>SBIN5Min['SMA-C-21'].shift(2)) &
        (SBIN5Min['SMA-C-10'].shift(3)>SBIN5Min['SMA-C-21'].shift(3)) &
        (SBIN5Min['SMA-C-10'].shift(4)>SBIN5Min['SMA-C-21'].shift(4)) &
        (SBIN5Min['SMA-C-10'].shift(5)>SBIN5Min['SMA-C-21'].shift(5)) &
        (SBIN5Min['SMA-C-10'].shift(6)>SBIN5Min['SMA-C-21'].shift(6)) &
        (SBIN5Min['SMA-C-10'].shift(7)>SBIN5Min['SMA-C-21'].shift(7)) &
        (SBIN5Min['SMA-C-10'].shift(8)>SBIN5Min['SMA-C-21'].shift(8)) &
        (SBIN5Min['SMA-C-10'].shift(9)>SBIN5Min['SMA-C-21'].shift(9)) &
        (SBIN5Min['SMA-C-10'].shift(10)>SBIN5Min['SMA-C-21'].shift(10)) &
        (SBIN5Min['SMA-C-10'].shift(11)>SBIN5Min['SMA-C-21'].shift(11)) &
        (SBIN5Min['SMA-C-10'].shift(12)>SBIN5Min['SMA-C-21'].shift(12)) 
    #    &(SBIN5Min['SMA-C-10'].shift(13)>SBIN5Min['SMA-C-21'].shift(13)) &
    #    (SBIN5Min['SMA-C-10'].shift(14)>SBIN5Min['SMA-C-21'].shift(14)) &
    #    (SBIN5Min['SMA-C-10'].shift(15)>SBIN5Min['SMA-C-21'].shift(15)) &
    #    (SBIN5Min['SMA-C-10'].shift(16)>SBIN5Min['SMA-C-21'].shift(16)) &
    #    (SBIN5Min['SMA-C-10'].shift(17)>SBIN5Min['SMA-C-21'].shift(17)) &
    #    (SBIN5Min['SMA-C-10'].shift(18)>SBIN5Min['SMA-C-21'].shift(18)) &
    #    (SBIN5Min['SMA-C-10'].shift(19)>SBIN5Min['SMA-C-21'].shift(19)) &
    #    (SBIN5Min['SMA-C-10'].shift(20)>SBIN5Min['SMA-C-21'].shift(20)) &
    #    (SBIN5Min['SMA-C-10'].shift(21)>SBIN5Min['SMA-C-21'].shift(21)) &
    #    (SBIN5Min['SMA-C-10'].shift(22)>SBIN5Min['SMA-C-21'].shift(22)) &
    #    (SBIN5Min['SMA-C-10'].shift(23)>SBIN5Min['SMA-C-21'].shift(23)) &
    #    (SBIN5Min['SMA-C-10'].shift(24)>SBIN5Min['SMA-C-21'].shift(24)) &
    #    (SBIN5Min['SMA-C-10'].shift(25)>SBIN5Min['SMA-C-21'].shift(25)) &
    #    (SBIN5Min['SMA-C-10'].shift(26)>SBIN5Min['SMA-C-21'].shift(26))  &
    #    (SBIN5Min['SMA-C-150'].shift(20)<SBIN5Min['SMA-C-21'].shift(20)) &
    #    (SBIN5Min['SMA-C-150'].shift(21)<SBIN5Min['SMA-C-21'].shift(21)) &
    #    (SBIN5Min['SMA-C-150'].shift(22)<SBIN5Min['SMA-C-21'].shift(22)) &
    #    (SBIN5Min['SMA-C-150'].shift(23)<SBIN5Min['SMA-C-21'].shift(23)) &
    #    (SBIN5Min['SMA-C-150'].shift(24)<SBIN5Min['SMA-C-21'].shift(24)) &
    #    (SBIN5Min['SMA-C-150'].shift(25)<SBIN5Min['SMA-C-21'].shift(25)) &
    #    (SBIN5Min['SMA-C-150'].shift(26)<SBIN5Min['SMA-C-21'].shift(26)) 
    
     )
    # |
    # (
    #    (SBIN5Min['SMA-C-10'].shift(1)<SBIN5Min['SMA-C-21'].shift(1)) &
    #    (SBIN5Min['SMA-C-10'].shift(2)<SBIN5Min['SMA-C-21'].shift(2)) &
    #    (SBIN5Min['SMA-C-10'].shift(3)<SBIN5Min['SMA-C-21'].shift(3)) &
    #    (SBIN5Min['SMA-C-10'].shift(4)<SBIN5Min['SMA-C-21'].shift(4)) &
    #    (SBIN5Min['SMA-C-10'].shift(5)<SBIN5Min['SMA-C-21'].shift(5)) &
    #    (SBIN5Min['SMA-C-10'].shift(6)<SBIN5Min['SMA-C-21'].shift(6)) &
    #    (SBIN5Min['SMA-C-10'].shift(7)<SBIN5Min['SMA-C-21'].shift(7)) &
    #    (SBIN5Min['SMA-C-10'].shift(8)<SBIN5Min['SMA-C-21'].shift(8)) &
    #    (SBIN5Min['SMA-C-10'].shift(9)<SBIN5Min['SMA-C-21'].shift(9)) &
    #    (SBIN5Min['SMA-C-10'].shift(10)<SBIN5Min['SMA-C-21'].shift(10)) &
    #    (SBIN5Min['SMA-C-10'].shift(11)<SBIN5Min['SMA-C-21'].shift(11)) &
    #    (SBIN5Min['SMA-C-10'].shift(12)<SBIN5Min['SMA-C-21'].shift(12)) &
    #    (SBIN5Min['SMA-C-10'].shift(13)<SBIN5Min['SMA-C-21'].shift(13)) &
    #    (SBIN5Min['SMA-C-10'].shift(14)<SBIN5Min['SMA-C-21'].shift(14)) &
    #    (SBIN5Min['SMA-C-10'].shift(15)<SBIN5Min['SMA-C-21'].shift(15)) &
    #    (SBIN5Min['SMA-C-10'].shift(16)<SBIN5Min['SMA-C-21'].shift(16)) &
    #    (SBIN5Min['SMA-C-10'].shift(17)<SBIN5Min['SMA-C-21'].shift(17)) &
    #    (SBIN5Min['SMA-C-10'].shift(18)<SBIN5Min['SMA-C-21'].shift(18)) &
    #    (SBIN5Min['SMA-C-10'].shift(19)<SBIN5Min['SMA-C-21'].shift(19)) &
    #    (SBIN5Min['SMA-C-10'].shift(20)<SBIN5Min['SMA-C-21'].shift(20)) &
    #    (SBIN5Min['SMA-C-10'].shift(21)<SBIN5Min['SMA-C-21'].shift(21)) &
    #    (SBIN5Min['SMA-C-10'].shift(22)<SBIN5Min['SMA-C-21'].shift(22)) &
    #    (SBIN5Min['SMA-C-10'].shift(23)<SBIN5Min['SMA-C-21'].shift(23)) &
    #    (SBIN5Min['SMA-C-10'].shift(24)<SBIN5Min['SMA-C-21'].shift(24)) &
    #    (SBIN5Min['SMA-C-10'].shift(25)<SBIN5Min['SMA-C-21'].shift(25)) &
    #    (SBIN5Min['SMA-C-10'].shift(26)<SBIN5Min['SMA-C-21'].shift(26)) 
    # )
    ) &
     
                   (SBIN5Min['SMA-C-10']>SBIN5Min['SMA-C-21']) &
                   (SBIN5Min['RSI14']>=67) & 
                   (SBIN5Min['RSI14'].shift(1)<SBIN5Min['RSI14']) & 
                   #(SBIN5Min['RSI14'].shift(2)<SBIN5Min['RSI14'].shift(1)) &
    #              (SBIN5Min['SMA-C-10'].shift(1)>SBIN5Min['SMA-C-21'].shift(1)) &
                    (SBIN5Min['Indx']<=24) 
                    )
            ]
    #[['Date','Open','High','Low','Close','DayOpen','HA_Close', 'HA_Open','RSI14',
    #       'HA_High', 'HA_Low','CDayHigh','CDayLow','SMA-C-21','SMA-C-10','SMA-C-21-1','SMA-C-10-1','PDayClose', 'PDayOpen']]
    IntraDayBuy['PPER']=round((IntraDayBuy['PDayClose']-IntraDayBuy['PDayOpen']+0.00001)/IntraDayBuy['PDayOpen']*100,2)
    IntraDayBuy['SMADIFF']=round((IntraDayBuy['SMA-C-10']-IntraDayBuy['SMA-C-21']+0.00001)/IntraDayBuy['SMA-C-21']*10000)
    IntraDayBuy['Stock']=Stock
    SBIN5Min['Stock']=Stock
    return SBIN5Min,IntraDayBuy



a=round(len(StockList)/3)*1
q1=000
First=True
while(q1<len(StockList)):#len(ITSTOCKS)-1):
    #ZQ=PrStock(ITSTOCKS[q1])
    if(os.path.exists("C:\ReadMoneycontrol\Mani 2.0\GapUp-Temp\\"+StockList.StockName[q1]+'AllStock.csv')==False):
        print(StockList.StockName[q1])
        AllStock,FilteredStock=PrStock(StockList.StockName[q1])    
    
#    if(First):
#        ConsolidatedFilteredStock=FilteredStock
#        ConsolidatedAllStock=AllStock
#        First=False
#    else:
#        ConsolidatedFilteredStock=ConsolidatedFilteredStock.append(FilteredStock)
#        ConsolidatedAllStock=ConsolidatedAllStock.append(AllStock)        
        FilteredStock.to_csv("C:\ReadMoneycontrol\Mani 2.0\GapUp-Temp\\"+StockList.StockName[q1]+"Filtered.csv",sep=',',encoding='utf-8',index=False)
        AllStock.to_csv("C:\ReadMoneycontrol\Mani 2.0\GapUp-Temp\\"+StockList.StockName[q1]+"AllStock.csv",sep=',',encoding='utf-8',index=False)
    q1=q1+1    
#Result=ConsolidatedZ[['Date','CDATE','Stock','Open','High','Low','Close','DayOpen','RSI14',
#           'CDayHigh','CDayLow','SMA-C-21','SMA-C-10','SMA-C-21-1','SMA-C-10-1','PDayClose', 'PDayOpen']]
#
#Result['CDATE']=pd.to_datetime(Result['CDATE'])
#

#list(map(int,DayS["HitIndex"].iloc[0]))
if(False):
    
    IntraDayBuy1=ConsolidatedFilteredStock[['Date','CDATE','Stock','Open','High','Low','Close','DayOpen','RSI14',
           'H1','H2','H3','H4','IPivot','HighFib','LowFib','PDayClose', 'PDayOpen','Buy']]

    DayS=ConsolidatedAllStock[ConsolidatedAllStock['CDATE']=="2019-Dec-13"][['Date','CDATE','Open','High','Low','Close','DayOpen','RSI14',
               'H1','H2','H3','H4','IPivot','HighFib','LowFib','PDayClose', 'PDayOpen','Buy']]
    
    DayS=ConsolidatedAllStock[ConsolidatedAllStock['CDATE']=="2019-Nov-29"][['Date','Indx','CDATE','Open','High','Low','Close','DayOpen','RSI14',
               'H1','H2','H2A','H3','H4','IPivot','HighFib','LowFib','PDayClose', 'PDayOpen','Buy']]

    DayS=ConsolidatedAllStock
    DayS["BH1TA"]=(DayS['High']>DayS['H1']) & (DayS['Low']<DayS['H1'])
    DayS["BH1SL"]=(DayS['High']>DayS['IPivot']) & (DayS['Low']<DayS['IPivot'])
    DayS["BH2TA"]=(DayS['High']>DayS['H2']) & (DayS['Low']<DayS['H2'])
    DayS["BH2SL"]=(DayS['High']>DayS['H1']) & (DayS['Low']<DayS['H1'])
    DayS["BH2ATA"]=(DayS['High']>DayS['H2A']) & (DayS['Low']<DayS['H2A'])
    DayS["BH2ASL"]=(DayS['High']>DayS['H2']) & (DayS['Low']<DayS['H2'])
    
    DayS["SH1TA"]=(DayS['High']>DayS['IPivot']) & (DayS['Low']<DayS['IPivot'])
    DayS["SH1SL"]=(DayS['High']>DayS['H2']) & (DayS['Low']<DayS['H2'])
    
    DayS["SH2SL"]=(DayS['High']>DayS['H2A']) & (DayS['Low']<DayS['H2A'])
    DayS["SH2TA"]=(DayS['High']>DayS['H1']) & (DayS['Low']<DayS['H1'])
    DayS["SH2ASL"]=(DayS['High']>DayS['H2A']) & (DayS['Low']<DayS['H2A'])
    DayS["SH2ATA"]=(DayS['High']>DayS['H2']) & (DayS['Low']<DayS['H2'])
    
    #I = np.array([row[[x for x in range(A.shape[1]) if x != i-1]] for row in A if row[i-1] == i])
    #print I
    #len(DayS[(DayS["SH2ATA"]==True)])
    #Tz['Label']=np.select([(Tz['SellProfitP']>0) & (Tz['BuyProfitP']<0),(Tz['SellProfitP']<0) & (Tz['BuyProfitP']>0),(Tz['SellProfitP']<0) & (Tz['BuyProfitP']<0)],[-1,1,-100],Tz['Label'] )
    
    
    
    List=['BH1TA', 'BH1SL', 'BH2TA', 'BH2SL',
           'BH2ATA', 'BH2ASL', 'SH1TA', 'SH1SL', 'SH2SL', 'SH2TA', 'SH2ASL',
           'SH2ATA']
    
    Group=DayS.groupby('CDATE')
    
    IndexList=[]
    ResultList=[]
    #itertools
    print("Starting")
    Date1=datetime.now()
    #i=0
    #j=0
    #Runthread=[]
    #Increment=50
    #while(i<len(DayS)):
    #    Runthread.append(threading.Thread(target=ApplyDF,args=(i,i+Increment)))
    #    Runthread[-1].start()
    #    if((j%10==0) & (j!=0)):
    #        for thread in Runthread:
    #            thread.join()
    #        Runthread=[]
    #    i=i+Increment
    #    j=j+1
    #for thread in Runthread:
    #    thread.join()    
    Result1=DayS.apply(lambda x: getFirstBuy(x,25,List,Group.get_group(x['CDATE'])),axis=1)
    print("StockNameStockName : " + str((datetime.now()-Date1).seconds))
    len(Result1.iloc[0])
    Result1
    
    TempAr=[]
    i=0
    while(i<len(Result1)):
        TempDict={}
        TempDict['Date']=Result1.iloc[i][0]
        j=0
        while(j<len(List)):
            TempDict[List[j]+"_R"]=Result1.iloc[i][1][j]
            j=j+1
        i=i+1
        TempAr.append(TempDict)
    CheckDfResultdf=pd.DataFrame(TempAr)
    len(CheckDfResultdf)
    merged = CheckDfResultdf.merge(DayS, on=['Date'], how='left')    
    #SBIN5Min=merged
    IntraDayBuy1=ConsolidatedFilteredStock
    IntraDayBuy1=ConsolidatedFilteredStock[['Date','CDATE','Indx','Stock','Buy','BH1TA_R', 'BH1SL_R', 'BH2TA_R', 'BH2SL_R', 'BH2ATA_R',
       'BH2ASL_R', 'SH1TA_R', 'SH1SL_R', 'SH2SL_R', 'SH2TA_R', 'SH2ASL_R', 'Open','High','Low','Close','DayOpen','CDayHigh','CDayLow','RSI14',
           'H1','H2','H2A','H3','H4','IPivot','HighFib','LowFib','PDayClose', 'PDayOpen']]

    ConsolidatedAllStock[ConsolidatedAllStock['CDATE']=="2019-Nov-20"][['Date','Indx','CDATE','Open','High','Low','Close']]
    #Tz['Label']=np.select([(Tz['SellProfitP']>0) & (Tz['BuyProfitP']<0),(Tz['SellProfitP']<0) & (Tz['BuyProfitP']>0),(Tz['SellProfitP']<0) & (Tz['BuyProfitP']<0)],[-1,1,-100],Tz['Label'] )
    IntraDayBuy1['Signal']=np.select(
            [
            ( (IntraDayBuy1['Open']<IntraDayBuy1['H1']) & (IntraDayBuy1['CDayHigh']<IntraDayBuy1['H1']) & (IntraDayBuy1['High']<IntraDayBuy1['H1']) & (IntraDayBuy1['Low']>IntraDayBuy1['IPivot']) & (IntraDayBuy1['CDayLow']>IntraDayBuy1['IPivot'])),
            ( (IntraDayBuy1['Open']<IntraDayBuy1['H1']) & (IntraDayBuy1['CDayHigh']>IntraDayBuy1['H1']) & (IntraDayBuy1['High']<IntraDayBuy1['H1']) & (IntraDayBuy1['Low']>IntraDayBuy1['IPivot']) & (IntraDayBuy1['CDayLow']>IntraDayBuy1['IPivot'])),
            ( (IntraDayBuy1['Open']<IntraDayBuy1['H1']) & (IntraDayBuy1['CDayHigh']<IntraDayBuy1['H1']) & (IntraDayBuy1['High']<IntraDayBuy1['H1']) & (IntraDayBuy1['Low']>IntraDayBuy1['IPivot']) & (IntraDayBuy1['CDayLow']<IntraDayBuy1['IPivot'])),
            ( (IntraDayBuy1['Open']<IntraDayBuy1['H1']) & (IntraDayBuy1['CDayHigh']<IntraDayBuy1['H1']) & (IntraDayBuy1['High']>IntraDayBuy1['H1']) & (IntraDayBuy1['Low']>IntraDayBuy1['IPivot']) & (IntraDayBuy1['CDayLow']>IntraDayBuy1['IPivot'])),
            ( (IntraDayBuy1['Open']<IntraDayBuy1['H1']) & (IntraDayBuy1['CDayHigh']<IntraDayBuy1['H1']) & (IntraDayBuy1['High']<IntraDayBuy1['H1']) & (IntraDayBuy1['Low']<IntraDayBuy1['IPivot']) & (IntraDayBuy1['CDayLow']>IntraDayBuy1['IPivot'])),
            ( (IntraDayBuy1['Open']<IntraDayBuy1['H1']) & (IntraDayBuy1['CDayHigh']<IntraDayBuy1['H1']) & (IntraDayBuy1['High']<IntraDayBuy1['H1']) & (IntraDayBuy1['Low']<IntraDayBuy1['IPivot']) & (IntraDayBuy1['CDayLow']<IntraDayBuy1['IPivot'])),         
            
            ( (IntraDayBuy1['Open']<IntraDayBuy1['H2']) & (IntraDayBuy1['CDayHigh']<IntraDayBuy1['H2']) & (IntraDayBuy1['High']<IntraDayBuy1['H2']) & (IntraDayBuy1['Low']>IntraDayBuy1['H1']) & (IntraDayBuy1['CDayLow']>IntraDayBuy1['H1'])),
            ( (IntraDayBuy1['Open']<IntraDayBuy1['H2']) & (IntraDayBuy1['CDayHigh']>IntraDayBuy1['H2']) & (IntraDayBuy1['High']<IntraDayBuy1['H2']) & (IntraDayBuy1['Low']>IntraDayBuy1['H1']) & (IntraDayBuy1['CDayLow']>IntraDayBuy1['H1'])),
            ( (IntraDayBuy1['Open']<IntraDayBuy1['H2']) & (IntraDayBuy1['CDayHigh']<IntraDayBuy1['H2']) & (IntraDayBuy1['High']<IntraDayBuy1['H2']) & (IntraDayBuy1['Low']>IntraDayBuy1['H1']) & (IntraDayBuy1['CDayLow']<IntraDayBuy1['H1'])),
            ( (IntraDayBuy1['Open']<IntraDayBuy1['H2']) & (IntraDayBuy1['CDayHigh']<IntraDayBuy1['H2']) & (IntraDayBuy1['High']>IntraDayBuy1['H2']) & (IntraDayBuy1['Low']>IntraDayBuy1['H1']) & (IntraDayBuy1['CDayLow']>IntraDayBuy1['H1'])),
            ( (IntraDayBuy1['Open']<IntraDayBuy1['H2']) & (IntraDayBuy1['CDayHigh']<IntraDayBuy1['H2']) & (IntraDayBuy1['High']<IntraDayBuy1['H2']) & (IntraDayBuy1['Low']<IntraDayBuy1['H1']) & (IntraDayBuy1['CDayLow']>IntraDayBuy1['H1'])),
            ( (IntraDayBuy1['Open']<IntraDayBuy1['H2']) & (IntraDayBuy1['CDayHigh']<IntraDayBuy1['H2']) & (IntraDayBuy1['High']<IntraDayBuy1['H2']) & (IntraDayBuy1['Low']<IntraDayBuy1['H1']) & (IntraDayBuy1['CDayLow']<IntraDayBuy1['H1'])),         
            ( (IntraDayBuy1['Open']<IntraDayBuy1['H2']) & (IntraDayBuy1['CDayHigh']<IntraDayBuy1['H2']) & (IntraDayBuy1['High']<IntraDayBuy1['H2']) & (IntraDayBuy1['Low']<IntraDayBuy1['H1']) & (IntraDayBuy1['CDayLow']<IntraDayBuy1['IPivot'])),         
            
            ( (IntraDayBuy1['Open']<IntraDayBuy1['H2A']) & (IntraDayBuy1['CDayHigh']<IntraDayBuy1['H2A']) & (IntraDayBuy1['High']<IntraDayBuy1['H2A']) & (IntraDayBuy1['Low']>IntraDayBuy1['H2']) & (IntraDayBuy1['CDayLow']>IntraDayBuy1['H2'])),
            ( (IntraDayBuy1['Open']<IntraDayBuy1['H2A']) & (IntraDayBuy1['CDayHigh']>IntraDayBuy1['H2A']) & (IntraDayBuy1['High']<IntraDayBuy1['H2A']) & (IntraDayBuy1['Low']>IntraDayBuy1['H2']) & (IntraDayBuy1['CDayLow']>IntraDayBuy1['H2'])),
            ( (IntraDayBuy1['Open']<IntraDayBuy1['H2A']) & (IntraDayBuy1['CDayHigh']<IntraDayBuy1['H2A']) & (IntraDayBuy1['High']<IntraDayBuy1['H2A']) & (IntraDayBuy1['Low']>IntraDayBuy1['H2']) & (IntraDayBuy1['CDayLow']<IntraDayBuy1['H2'])),
            ( (IntraDayBuy1['Open']<IntraDayBuy1['H2A']) & (IntraDayBuy1['CDayHigh']<IntraDayBuy1['H2A']) & (IntraDayBuy1['High']>IntraDayBuy1['H2A']) & (IntraDayBuy1['Low']>IntraDayBuy1['H2']) & (IntraDayBuy1['CDayLow']>IntraDayBuy1['H2'])),
            ( (IntraDayBuy1['Open']<IntraDayBuy1['H2A']) & (IntraDayBuy1['CDayHigh']<IntraDayBuy1['H2A']) & (IntraDayBuy1['High']<IntraDayBuy1['H2A']) & (IntraDayBuy1['Low']<IntraDayBuy1['H2']) & (IntraDayBuy1['CDayLow']>IntraDayBuy1['H2'])),
            ( (IntraDayBuy1['Open']<IntraDayBuy1['H2A']) & (IntraDayBuy1['CDayHigh']<IntraDayBuy1['H2A']) & (IntraDayBuy1['High']<IntraDayBuy1['H2A']) & (IntraDayBuy1['Low']<IntraDayBuy1['H2']) & (IntraDayBuy1['CDayLow']<IntraDayBuy1['H2'])),         
            ( (IntraDayBuy1['Open']<IntraDayBuy1['H2A']) & (IntraDayBuy1['CDayHigh']<IntraDayBuy1['H2A']) & (IntraDayBuy1['High']<IntraDayBuy1['H2A']) & (IntraDayBuy1['Low']<IntraDayBuy1['H2']) & (IntraDayBuy1['CDayLow']<IntraDayBuy1['H1'])),         
			( (IntraDayBuy1['Open']<IntraDayBuy1['H2A']) & (IntraDayBuy1['CDayHigh']<IntraDayBuy1['H2A']) & (IntraDayBuy1['High']<IntraDayBuy1['H2A']) & (IntraDayBuy1['Low']<IntraDayBuy1['H2']) & (IntraDayBuy1['CDayLow']<IntraDayBuy1['IPivot'])),   
            
            
            ( (IntraDayBuy1['Open']<IntraDayBuy1['H3']) & (IntraDayBuy1['CDayHigh']<IntraDayBuy1['H3']) & (IntraDayBuy1['High']<IntraDayBuy1['H3']) & (IntraDayBuy1['Low']>IntraDayBuy1['H2A']) & (IntraDayBuy1['CDayLow']>IntraDayBuy1['H2A'])),
            ( (IntraDayBuy1['Open']<IntraDayBuy1['H3']) & (IntraDayBuy1['CDayHigh']>IntraDayBuy1['H3']) & (IntraDayBuy1['High']<IntraDayBuy1['H3']) & (IntraDayBuy1['Low']>IntraDayBuy1['H2A']) & (IntraDayBuy1['CDayLow']>IntraDayBuy1['H2A'])),
            ( (IntraDayBuy1['Open']<IntraDayBuy1['H3']) & (IntraDayBuy1['CDayHigh']<IntraDayBuy1['H3']) & (IntraDayBuy1['High']<IntraDayBuy1['H3']) & (IntraDayBuy1['Low']>IntraDayBuy1['H2A']) & (IntraDayBuy1['CDayLow']<IntraDayBuy1['H2A'])),
            ( (IntraDayBuy1['Open']<IntraDayBuy1['H3']) & (IntraDayBuy1['CDayHigh']<IntraDayBuy1['H3']) & (IntraDayBuy1['High']>IntraDayBuy1['H3']) & (IntraDayBuy1['Low']>IntraDayBuy1['H2A']) & (IntraDayBuy1['CDayLow']>IntraDayBuy1['H2A'])),
            ( (IntraDayBuy1['Open']<IntraDayBuy1['H3']) & (IntraDayBuy1['CDayHigh']<IntraDayBuy1['H3']) & (IntraDayBuy1['High']<IntraDayBuy1['H3']) & (IntraDayBuy1['Low']<IntraDayBuy1['H2A']) & (IntraDayBuy1['CDayLow']>IntraDayBuy1['H2A'])),
            ( (IntraDayBuy1['Open']<IntraDayBuy1['H3']) & (IntraDayBuy1['CDayHigh']<IntraDayBuy1['H3']) & (IntraDayBuy1['High']<IntraDayBuy1['H3']) & (IntraDayBuy1['Low']<IntraDayBuy1['H2A']) & (IntraDayBuy1['CDayLow']<IntraDayBuy1['H2A'])),        
			( (IntraDayBuy1['Open']<IntraDayBuy1['H3']) & (IntraDayBuy1['CDayHigh']<IntraDayBuy1['H3']) & (IntraDayBuy1['High']<IntraDayBuy1['H3']) & (IntraDayBuy1['Low']<IntraDayBuy1['H2A']) & (IntraDayBuy1['CDayLow']<IntraDayBuy1['H2'])),         			
            ( (IntraDayBuy1['Open']<IntraDayBuy1['H3']) & (IntraDayBuy1['CDayHigh']<IntraDayBuy1['H3']) & (IntraDayBuy1['High']<IntraDayBuy1['H3']) & (IntraDayBuy1['Low']<IntraDayBuy1['H2A']) & (IntraDayBuy1['CDayLow']<IntraDayBuy1['H1'])),         
			( (IntraDayBuy1['Open']<IntraDayBuy1['H3']) & (IntraDayBuy1['CDayHigh']<IntraDayBuy1['H3']) & (IntraDayBuy1['High']<IntraDayBuy1['H3']) & (IntraDayBuy1['Low']<IntraDayBuy1['H2A']) & (IntraDayBuy1['CDayLow']<IntraDayBuy1['IPivot']))
#            ( (IntraDayBuy1['Open']<IntraDayBuy1['H2']) & (IntraDayBuy1['CDayHigh']<IntraDayBuy1['H2']) & (IntraDayBuy1['High']<IntraDayBuy1['H2']) & (IntraDayBuy1['Low']>IntraDayBuy1['H1']) & (IntraDayBuy1['CDayLow']>IntraDayBuy1['H1'])),
#            ( (IntraDayBuy1['Open']<IntraDayBuy1['H2']) & (IntraDayBuy1['CDayHigh']>IntraDayBuy1['H2']) & (IntraDayBuy1['High']<IntraDayBuy1['H2']) & (IntraDayBuy1['Low']<IntraDayBuy1['H1']) & (IntraDayBuy1['CDayLow']>IntraDayBuy1['H1'])),
#            ( (IntraDayBuy1['Open']<IntraDayBuy1['H1']) & (IntraDayBuy1['CDayHigh']<IntraDayBuy1['H1']) & (IntraDayBuy1['High']<IntraDayBuy1['H1']) & (IntraDayBuy1['Low']>IntraDayBuy1['IPivot']) & (IntraDayBuy1['CDayLow']<IntraDayBuy1['H1'])),
#            ( (IntraDayBuy1['Open']<IntraDayBuy1['H2']) & (IntraDayBuy1['CDayHigh']<IntraDayBuy1['H2']) & (IntraDayBuy1['High']<IntraDayBuy1['H2']) & (IntraDayBuy1['Low']<IntraDayBuy1['H1']) & (IntraDayBuy1['CDayLow']<IntraDayBuy1['H1'])),
#            ( (IntraDayBuy1['Open']<IntraDayBuy1['H2']) & (IntraDayBuy1['CDayHigh']>IntraDayBuy1['H2']) & (IntraDayBuy1['High']<IntraDayBuy1['H2']) & (IntraDayBuy1['Low']<IntraDayBuy1['H1']) & (IntraDayBuy1['CDayLow']<IntraDayBuy1['H1']))            
            ],
            ["H1","H1+CHTH1",'H1-CLTP','H1-HTH1',"H1-LTP","H1-BLTP",
             "H2","H2+CHTH2",'H2-CLTH1','H2-HTH2',"H2-LTH1","H2-BLTH1","H2-LTH1-CLTP",
             "H2A","H2A+CHTH2A",'H2A-CLTH2','H2A-HTH2A',"H2A-LTH2","H2A-BLTH2","H2A-LTH2-CLTH1","H2A-LTH2-CLTP",
             "H3","H3+CHTH3",'H3-CLTH2A','H3-HTH3',"H3-LTH2A","H3-BLTH2A","H3-LTH2A-CLTH2","H2A-LTH2-CLTH1","H3-LTH2A-CLTP"   
             ],"None1")
    IntraDayBuy1['H1H2P']=round((IntraDayBuy1['H2']-IntraDayBuy1['H1'])/IntraDayBuy1['H1']*100,2)
    IntraDayBuy1['H2H3P']=round((IntraDayBuy1['H3']-IntraDayBuy1['H2'])/IntraDayBuy1['H2']*100,2)
    IntraDayBuy1['P31']=round((IntraDayBuy1['H2H3P']-IntraDayBuy1['H1H2P'])/IntraDayBuy1['H1H2P']*100,2)
    
    C=IntraDayBuy1[['Date','Signal','Indx','CDATE','Stock','Buy', 'Open','High','Low','Close','DayOpen','CDayHigh','CDayLow','RSI14',
           'H1','H2','H2A','H3','H4','IPivot','HighFib','LowFib','PDayClose', 'PDayOpen',
    
    'BH1TA_R', 'BH1SL_R', 'BH2TA_R', 'BH2SL_R', 'BH2ATA_R',
       'BH2ASL_R', 'SH1TA_R', 'SH1SL_R', 'SH2SL_R', 'SH2TA_R', 'SH2ASL_R','H1H2P','H2H3P','P31']]
    
    D=C[ (C['Signal']=='H1') &
       (C['Indx']==0)]
    D['PL']=np.select(
            [
            (D['H1H2P']<2) & (D['H2H3P']>4) & ((D['BH1TA_R']<D['BH1SL_R']) | ((D['BH1SL_R']!=-1) & (D['BH1TA_R']==-1))) ,
            (D['BH1TA_R']<D['BH1SL_R']),
            (D['BH2TA_R']<D['BH1SL_R']),
            (D['BH2ATA_R']<D['BH1SL_R']),
            (D['BH1TA_R']>D['BH1SL_R']) | ((D['BH1SL_R']==-1) & (D['BH1TA_R']!=-1)),
            (D['BH2TA_R']>D['BH1SL_R']) | ((D['BH1SL_R']==-1) & (D['BH2TA_R']!=-1)),
            (D['BH2ATA_R']>D['BH1SL_R']) | ((D['BH1SL_R']==-1) & (D['BH2ATA_R']!=-1))
            
            ],
            [
            'S-IPivot','H1SL','H2SL','H2ASL','BH1','BH2','BH2A'
            ]
            ,"None"
            )
    D1=D[['Date','Signal','PL','CDATE','Stock','Buy','H1H2P','H2H3P','P31', 'Open','High','Low','Close','DayOpen','CDayHigh','CDayLow','RSI14',
           'H1','H2','H2A','H3','H4','IPivot','HighFib','LowFib','PDayClose', 'PDayOpen',    
    'BH1TA_R', 'BH1SL_R', 'BH2TA_R', 'BH2SL_R', 'BH2ATA_R',
       'BH2ASL_R', 'SH1TA_R', 'SH1SL_R', 'SH2SL_R', 'SH2TA_R', 'SH2ASL_R']]
    
    
    
    
    
    
    
    
    
    C=IntraDayBuy1[['Date','Signal','Indx','CDATE','Stock','Buy', 'Open','High','Low','Close','DayOpen','CDayHigh','CDayLow','RSI14',
           'H1','H2','H2A','H3','H4','IPivot','HighFib','LowFib','PDayClose', 'PDayOpen',
    
    'RH1_R', 'RH2A_R', 'RH2_R', 'RH3A_R', 'RH3_R', 'RH4_R',
       'RIP-H_R', 'RIP-L_R', 'RIPivot_R','H1H2P','H2H3P','P31']]
    
    D=C[ (C['Signal']=='H1') &
       (C['Indx']==0)]
    D['C-H1']=round((D['H1']-D['Close'])/D['Close']*1000,2)
    D['L-H1']=round((D['H1']-D['Low'])/D['Low']*1000,2)
    D['CHL']=round((D['High']-D['Low'])/D['Low']*1000,2)
    D['O-H1']=round((D['H1']-D['Open'])/D['Open']*1000,2)
    D['PL']=np.select(
            [
            (D['H1H2P']<2) & (D['H2H3P']>4) & ((D['RH1_R']<D['RIPivot_R']) | ((D['RIPivot_R']!=-1) & (D['RH1_R']==-1))) ,
            (D['RH1_R']<D['RIPivot_R']),
            (D['RH2_R']<D['RIPivot_R']),
            (D['RH2A_R']<D['RIPivot_R']),
            (D['RH2A_R']>D['RIPivot_R']) | ((D['RIPivot_R']==-1) & (D['RH2A_R']!=-1)),
            (D['RH2_R']>D['RIPivot_R']) | ((D['RIPivot_R']==-1) & (D['RH2_R']!=-1)),
            (D['RH1_R']>D['RIPivot_R']) | ((D['RIPivot_R']==-1) & (D['RH1_R']!=-1))
            
            
            
            ],
            [
            'S-IPivot','H1SL','H2SL','H2ASL','BH2A','BH2','BH1'
            ]
            ,"None"
            )
    D1=D[['Date','Signal','PL','C-H1','L-H1','CHL','O-H1','CDATE','Stock','Buy','H1H2P','H2H3P','P31', 'Open','High','Low','Close','DayOpen','CDayHigh','CDayLow','RSI14',
           'H1','H2','H2A','H3','H4','IPivot','HighFib','LowFib','PDayClose', 'PDayOpen',    
    'RH1_R', 'RH2A_R', 'RH2_R', 'RH3A_R', 'RH3_R', 'RH4_R',
       'RIP-H_R', 'RIP-L_R', 'RIPivot_R']]
    
    
    
    
    
#
#IntraDayBuy1[
#        (
#        (IntraDayBuy1['Close']<IntraDayBuy1['H1']) & (IntraDayBuy1['High']<IntraDayBuy1['H1'])
#        )
#        ]
        
#ConsolidatedAllStock=pd.read_csv("C:\ReadMoneycontrol\Mani 2.0\Temp3\ADANIENTFiltered.csv")
#ConsolidatedFilteredStock=pd.read_csv("C:\ReadMoneycontrol\Mani 2.0\Temp3\MFSLFiltered.csv")
#ConsolidatedFilteredStock.to_csv("C:\ReadMoneycontrol\Mani 2.0\Temp3\PNBFiltered.csv",sep=',',encoding='utf-8',index=False)
#ConsolidatedAllStock.to_csv("C:\ReadMoneycontrol\Mani 2.0\Temp3\APNBllStock.csv",sep=',',encoding='utf-8',index=False)
