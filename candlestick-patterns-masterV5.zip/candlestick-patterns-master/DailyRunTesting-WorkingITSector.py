# -*- coding: utf-8 -*-
"""
Created on Thu Jan  2 22:01:24 2020

@author: lalitha
"""
ITSTOCKS=["TCS","JUSTDIAL","INFY","TATAELXSI","NIITTECH","MINDTREE","WIPRO","HCLTECH","TECHM","HEXAWARE"]
#'TCS',''  => 9:15 & 3:15
#'SBIN',Axisbank','BPCL' : 10-11
#NOTWORKING :- ONGC, MINDTREE,WIPRO,TECHM--
def PrStock(Stock):
    #Stock='GAIL'
    SBIN5Min=LoadCSVData(Stock,"15minute")
    SBIN5Min['CDATE']=pd.to_datetime(SBIN5Min['Date']).dt.strftime("%Y-%b-%d")
    SBINDay=LoadCSVData(Stock,"day")
    SBINDay['CDATE']=pd.to_datetime(SBINDay['Date']).dt.strftime("%Y-%b-%d")    
    SBIN5Min.drop_duplicates(subset =["Date"], keep = "first", inplace = True) 
    SBIN5Min['Indx']=((SBIN5Min['Date']-pd.to_datetime(pd.to_datetime(SBIN5Min['CDATE']).dt.strftime("%Y-%m-%d 09:15"))).dt.seconds/60/15).astype(int)
    SBIN5Min=SBIN5Min[SBIN5Min['Indx']<=24]
    SBINDay['HL']=SBINDay['High'].shift(1)-SBINDay['Low'].shift(1)
    SBINDay['PDayLow']=SBINDay['Low'].shift(1)
    SBINDay['PDayHigh']=SBINDay['High'].shift(1)
    SBINDay['PDayClose']=SBINDay['Close'].shift(1)
    SBINDay['PDayOpen']=SBINDay['Open'].shift(1)
    SBINDay['PDayVolume']=SBINDay['V'].shift(1)
    SBINDay['PDayVolumeSMA5']=SBINDay['V'].shift(1).rolling(5).mean()
    SBINDay['PDayVolumeSMA10']=SBINDay['V'].shift(1).rolling(10).mean()
    SBINDay['PDayVolumeSMA15']=SBINDay['V'].shift(1).rolling(15).mean()
    SBINDay['PDayVolumeSMA20']=SBINDay['V'].shift(1).rolling(20).mean()
    SBINDay['DayRSI14']=ta.RSI(SBINDay,14)
    SBINDay['DaySMA50']=SBINDay['Close'].shift(1).rolling(50).mean()
    SBINDay["IPivot"]=candlestick.MaRound((SBINDay['Close'].shift(1)+SBINDay['High'].shift(1)+SBINDay['Low'].shift(1))/3)
    SBINDay["H4"]=candlestick.MaRound(SBINDay["IPivot"]+((SBINDay['High'].shift(1)-SBINDay['Low'].shift(1))*3))   
    SBINDay["H3"]=candlestick.MaRound(SBINDay["IPivot"]+((SBINDay['High'].shift(1)-SBINDay['Low'].shift(1))*2))   
    SBINDay["H2"]=candlestick.MaRound(SBINDay["IPivot"]+((SBINDay['High'].shift(1)-SBINDay['Low'].shift(1))))      
    SBINDay["H1"]=candlestick.MaRound(2*SBINDay["IPivot"]-SBINDay["Low"].shift(1))    
    SBINDay["L4"]=candlestick.MaRound(SBINDay["IPivot"]-((SBINDay['High'].shift(1)-SBINDay['Low'].shift(1))*3))   
    SBINDay["L3"]=candlestick.MaRound(SBINDay["IPivot"]-((SBINDay['High'].shift(1)-SBINDay['Low'].shift(1))*2))   
    SBINDay["L2"]=candlestick.MaRound(SBINDay["IPivot"]-((SBINDay['High'].shift(1)-SBINDay['Low'].shift(1))))      
    SBINDay["L1"]=candlestick.MaRound(2*SBINDay["IPivot"]-SBINDay["High"].shift(1))        
    
    merged = SBIN5Min.merge(SBINDay, on=['CDATE'], how='left')
    CustomMerge=merged[['Date_x','HL','PDayLow','PDayHigh','PDayClose','PDayOpen','PDayVolume','PDayVolumeSMA5','PDayVolumeSMA10','PDayVolumeSMA15','PDayVolumeSMA20', 'DayRSI14', 'DaySMA50','H1','H2','H3','H4',"IPivot","L1","L2","L3","L4"]]
    CustomMerge.columns=['Date', 'HL', 'PDayLow','PDayHigh','PDayClose','PDayOpen','PDayVolume','PDayVolumeSMA5','PDayVolumeSMA10','PDayVolumeSMA15','PDayVolumeSMA20', 'DayRSI14', 'DaySMA50','H1','H2','H3','H4',"IPivot","L1","L2","L3","L4"]
    SBIN5Min=SBIN5Min.merge(CustomMerge, on=['Date'], how='left')
    #SBIN5Min['HL']=merged['HL']
    #SBIN5Min['PLow']=merged['PLow']       
    SBIN5Min['HighFib']=round((SBIN5Min['High']-SBIN5Min['PDayLow'])*1000/SBIN5Min['HL'])
    SBIN5Min['LowFib']=round((SBIN5Min['Low']-SBIN5Min['PDayLow'])*1000/SBIN5Min['HL'])
    SBIN5Min['OpenFib']=round((SBIN5Min['Open']-SBIN5Min['PDayLow'])*1000/SBIN5Min['HL'])
    SBIN5Min['CloseFib']=round((SBIN5Min['Close']-SBIN5Min['PDayLow'])*1000/SBIN5Min['HL'])
    
    SBIN5Min.drop(SBIN5Min[SBIN5Min['Indx'] > 24].index, inplace = True) 
    #SBIN5Min.drop(SBIN5Min[SBIN5Min['Indx'] > 74].index, inplace = True) 
    offset=4
    SBIN5Min['SMA-C-21-1']=SBIN5Min['Close'].shift(1).rolling(21).mean()#For 5, its is 63
    SBIN5Min['SMA-C-150-1']=SBIN5Min['Close'].shift(1).rolling(150).mean()#For 5, its is 63
    SBIN5Min['SMA-C-10-1']=SBIN5Min['Close'].shift(1).rolling(10).mean()#For 10 its 30
    SBIN5Min['SMA-C-21']=SBIN5Min['Close'].rolling(21).mean()#For 5, its is 63
    SBIN5Min['SMA-C-10']=SBIN5Min['Close'].rolling(10).mean()#For 10 its 30
    SBIN5Min['SMA-C-150']=SBIN5Min['Close'].rolling(150).mean()#For 5, its is 63
    SBIN5Min['SMA-V-20']=SBIN5Min['V'].shift(1).rolling(20).mean()#For 10 its 30
    SBIN5Min['SMA-V-20-1']=SBIN5Min['V'].shift(1).rolling(20).mean()#For 10 its 30
    SBIN5Min['SMA-V-20']=SBIN5Min['V'].rolling(20).mean()#For 10 its 30
    SBIN5Min['EMA-C-50']=SBIN5Min['Close'].ewm(span=50, adjust=False).mean()
    SBIN5Min['RSI14']=ta.RSI(SBIN5Min,14)
    SBIN5Min=SBIN5Min.sort_values('Date',ascending=False)    
    SBIN5Min['MaxP']=SBIN5Min['High'].shift(1).rolling(10).max()
    SBIN5Min['MinP']=SBIN5Min['Low'].shift(1).rolling(10).min()    
    SBIN5Min['Open5']=SBIN5Min['Open'].shift(5)
    SBIN5Min['MaxP1']=SBIN5Min['High'].shift(1).rolling(20).max()
    SBIN5Min['MinP1']=SBIN5Min['Low'].shift(1).rolling(20).min()
    SBIN5Min['Open15']=SBIN5Min['Open'].shift(15)
    SBIN5Min['MaxP2']=SBIN5Min['High'].shift(1).rolling(30).max()
    SBIN5Min['MinP2']=SBIN5Min['Low'].shift(1).rolling(30).min()
    SBIN5Min['Open20']=SBIN5Min['Open'].shift(20)    
    SBIN5Min['Max10']=SBIN5Min['High'].shift(9)
    SBIN5Min['Min10']=SBIN5Min['Low'].shift(9)
    SBIN5Min['Open10']=SBIN5Min['Open'].shift(10)
    
    SBIN5Min=SBIN5Min.sort_values('Date',ascending=True)
    
    Z=SBIN5Min[(SBIN5Min['Open']<=SBIN5Min['High'])
    & ((SBIN5Min['PClose']-SBIN5Min['Open'])/SBIN5Min['Open']*100>-1)#<
    & ((SBIN5Min['High']-SBIN5Min['Open'])/SBIN5Min['Open']*100<1) #<
    & (SBIN5Min['V']>=SBIN5Min['V'].shift(1).rolling(74*3).mean())
    & (
       ((SBIN5Min['PClose']-SBIN5Min['POpen'])/SBIN5Min['POpen']*100<-2) #<
    | ((SBIN5Min['PClose']-SBIN5Min['POpen'])/SBIN5Min['POpen']*100>2)) #<)
    & (SBIN5Min['Indx']==0)]
    Z['LowP1']=round((Z['Close']-Z['MinP'])/Z['MinP']*100,2)
    Z['LowP2']=round((Z['Close']-Z['MinP1'])/Z['MinP1']*100,2)
    Z['LowP3']=round((Z['Close']-Z['MinP2'])/Z['MinP2']*100,2)
    Z['LowP10']=round((Z['Close']-Z['Min10'])/Z['Min10']*100,2)
    Z['AVGP10']=round((Z['Close']-Z['Open10'])/Z['Open10']*100,2)
    Z['AVGP5']=round((Z['Close']-Z['Open5'])/Z['Open5']*100,2)
    Z['AVGP15']=round((Z['Close']-Z['Open15'])/Z['Open15']*100,2)
    Z['AVGP20']=round((Z['Close']-Z['Open20'])/Z['Open20']*100,2)
    Z['HighP1']=round((Z['Close']-Z['MaxP'])/Z['MaxP']*100,2)
    Z['HighP2']=round((Z['Close']-Z['MaxP1'])/Z['MaxP1']*100,2)
    Z['HighP3']=round((Z['Close']-Z['MaxP2'])/Z['MaxP2']*100,2)
    Z['HighP10']=round((Z['Close']-Z['Max10'])/Z['Max10']*100,2)
    Z['Stock']=Stock
    return Z
q1=0
First=True
while(q1<len(ITSTOCKS)-1):
    ZQ=PrStock(ITSTOCKS[q1])
    q1=q1+1
    if(First):
        ConsolidatedZ=ZQ
        First=False
    else:
        ConsolidatedZ=ConsolidatedZ.append(ZQ)
        
#Z1=Z[['Date','V','LowP1','LowP2','LowP3','LowP10','HighP1','HighP2','HighP3','HighP10']]
Z2=ConsolidatedZ[['Date', 'Open', 'High', 'Low', 'Close','Open10','AVGP10', 'V',  'MaxP', 'MinP', 'MaxP1', 'MinP1', 'MaxP2', 'MinP2', 'Max10',
       'Min10', 'LowP1', 'LowP2', 'LowP3', 'LowP10', 'HighP1', 'HighP2',
       'HighP3', 'HighP10']]

ConsolidatedZ[(ConsolidatedZ['AVGP10']>-2)
           # & (ConsolidatedZ['LowP10']<3) 
           ][
        ['LowP10','HighP10','AVGP10','AVGP5','AVGP15','AVGP20']].sum()
ConsolidatedZ[['LowP10','HighP10','AVGP10','AVGP5','AVGP15','AVGP20']].sum()
#ConsolidatedZ.to_csv("C:\\ReadMoneycontrol\\Mani 2.0\\Report\\ITSectorDownTrend.csv",sep=',',encoding='utf-8',index=False)

#SBIN5Min['High'].shift(1).rolling(10).max().index


    StockList=ConsolidatedZ['Stock'].unique()
    CheckDFAll=ConsolidatedZ
    ki=0
    Sum=0
    CheckDfResult=[]
    while(ki<1):#len(StockList)-1):
        StockName=StockList[ki]
        ki=ki+1
        CheckDF=CheckDFAll[CheckDFAll['Stock']==StockName]
        #Sum+=CheckDF[CheckDF['Stock']==StockName].shape[0]
        #print(StockName + "= " +str(CheckDF[CheckDF['Stock']==StockName].shape[0]))
        SData5Min=LoadCSVData(StockName,"15minute")
        SData5Min=SData5Min.rename(columns = {'Open':'open','High':'high','Low':'low','Close':'close'})
        SData3Min=LoadCSVData(StockName,"minute")
        SData3Min=SData3Min.rename(columns = {'Open':'open','High':'high','Low':'low','Close':'close'})
        SDataDay=LoadCSVData(StockName,"day")

        indx=-1
        
        First=True
        while(indx<len(CheckDF)-1): #len(CheckDF)-1
            indx+=1
            
            #indx=1
            ClosePrices=CheckDF.iloc[indx]['Close']
            MV=1.5
            SV=2
            Margin=round(ClosePrices*MV/100,2)
            Stoploss=round(ClosePrices*SV/100,2)
            SearchDate=CheckDF.iloc[indx]['Date'].strftime("%Y-%b-%d")
            candlestick.Tollerance=0.05
            StockName=CheckDF.iloc[indx]['Stock']
            if(SearchDate!='2019-Oct-27'):
                candlestick.Tollerance=0.05
                #StockName=CheckDF.iloc[indx]['Stock']
                
                Data5Min1,DateIndex=FilterData(parse(SearchDate),SData5Min,SDataDay)
                Data3Min1,DateIndex=FilterData(parse(SearchDate),SData3Min,SDataDay)
       
            #Margin=round(ClosePrices*(1-CheckDF.iloc[indx]['CFD']/100),2)
            #Stoploss=round(ClosePrices*(1+CheckDF.iloc[indx]['CFD']*1.5/100),2)
            T=.4
            Tollerance=round(ClosePrices*T/100,2)
            #SellP=ClosePrices
        #    SellT=ClosePrices-Margin
        #    #SellT=SellP*(1-Margin)    
        #    SellSL=ClosePrices+Stoploss
        #    #SellSL=SellP*(1+Stoploss)
        #    
        #    SellPT=Data3Min[(Data3Min['high']>=SellP-Tollerance) & (Data3Min['low']<=SellP+Tollerance)]
        #    SellTT=Data3Min[(Data3Min['high']>=SellT-Tollerance) & (Data3Min['low']<=SellT+Tollerance)]
        #    SellSLT=Data3Min[(Data3Min['high']>=SellSL-Tollerance) & (Data3Min['low']<=SellSL+Tollerance)]
        #    Data3Min[(Data3Min['high']<=SellT+Tollerance)]
        #    
            #if(CheckDF.iloc[indx]['Index']==4) :
            
            CheckStatus={}
            CheckStatus['Stock']=CheckDF.iloc[indx]['Stock']
            CheckStatus['CurrentDate']=CheckDF.iloc[indx]['Date']
            
            ResultSearch=candlestick.Check(Data5Min1,"Sell",0,Margin,Stoploss,Data3Min1)        
            CheckStatus['SellPrice']=ResultSearch['Price']
            CheckStatus['SellTarget']=ResultSearch['Target']
            CheckStatus['SellStopLoss']=ResultSearch['StopLoss']
            CheckStatus['SellHit']=ResultSearch['Hit']
            CheckStatus['SellProfitPrice']=round(ResultSearch['Profit'],2)
            CheckStatus['SellProfitP']=round(ResultSearch['Profit']/ClosePrices*100,2)
            
            ResultSearch=candlestick.Check(Data5Min1,"Buy",0,Margin,Stoploss,Data3Min1)        
            #CheckStatus={}        Data5Min1
            CheckStatus['BuyHit']=ResultSearch['Hit']
            CheckStatus['BuyPrice']=ResultSearch['Price']
            CheckStatus['BuyTarget']=ResultSearch['Target']
            CheckStatus['BuyStopLoss']=ResultSearch['StopLoss']
            CheckStatus['BuyProfitPrice']=round(ResultSearch['Profit'],2)
            CheckStatus['BuyProfitP']=round(ResultSearch['Profit']/ClosePrices*100,2)
        #    if((ResultSearch['Hit']=="Hit") or (ResultSearch['Hit'].find("Profit")>0)):
        #        CheckStatus['SellProfit']=True
            #tdaily=Data5Min
            #Signal="Buy"
            #DateIndex=CheckDF.iloc[indx]['Index']        
            #SearchData=Data3Min
            #list(tdaily[DateIndex+1:][:1]['Date'])[0]
            
            CheckDfResult.append(CheckStatus)
        #    if((ResultSearch['Hit']=="Hit") or (ResultSearch['Hit'].find("Profit")>0)):
        #        CheckStatus['BuyProfit']=True
            PStockName=StockName
            PCDATE=CheckDF.iloc[indx]['CDATE']
            First=False
                
    CheckDfResultdf=pd.read_json(json.dumps(CheckDfResult))  
    CheckDfResultdf=pd.read_json(json.dumps(CheckDfResult,sort_keys=True,indent=1,default=default))
    FinalCheckResults=CheckDF.merge(CheckDfResultdf)
    #FinalCheckResults['CDATE']=pd.to_datetime(FinalCheckResults['CurrentDate']).dt.strftime("%Y-%b-%d")
    #FinalCheckResults.to_csv("C:\\ReadMoneycontrol\\Mani 2.0\\Temp\\NewResultsH1L1.csv",sep=',',encoding='utf-8',index=False)
    
CheckDfResultdf.groupby('Stock')[['BuyProfitP','SellProfitP']].sum()

def default(o):
    if isinstance(o, (datetime.date, datetime.datetime)):
        return o.isoformat()
json.dumps(
  CheckDfResult,
  sort_keys=True,
  indent=1,
  default=default
)