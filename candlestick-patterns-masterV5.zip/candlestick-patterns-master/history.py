    Msg=""

Columns=["Date","Symbol","Transaction","GC2","GC1","GC","SC","SC1","SC2","Profit","GP","SP","Doji","GP1","GP2","GF1","SP1","SP2","SF1","AtGoldPivotS","AtSilverPivotS"]
BDF=pd.DataFrame(BMessages)
BDF=BDF.reindex(columns=Columns)
ADF=pd.DataFrame(AMessages)
ADF=ADF.reindex(columns=Columns)
DF=pd.DataFrame(Messages)
DF=DF.reindex(columns=Columns)
#     DF['Profit'].count()
##DF[['Date','Profit','Transaction','GF1','GP1','GP2','SF1']]
DF['Profit'].sum()
ADF[ADF['Symbol']=="GoldD"]['Profit'].sum()
ADF[ADF['Symbol']=="Gold"]['Profit'].sum()
ADF['Profit'].sum()/ADF['Profit'].count()

##ADF[['Date','Profit','Transaction','GF1','GP1','GP2','SF1']]
BDF['Profit'].sum()
    ##BDF[['Date','Profit','Transaction','GF1','GP1','GP2','SF1']]
    #BDF['Profit']

#    for Message in BMessages:
#        print(Message)
#        #za=Message.find("-\t")
#        #zb=Message.find("- ")        
#        #pf=pf+float(Message[za+3:zb-1])
#        
#    for Message in Messages:
#        print(Message)
#        Msg=Msg+"\n"+Message.replace("\t","        ") 
#    if(Msg!=""):
###        send_whatsapp_msg(919962899983,Msg)
###        send_whatsapp_msg(918946071473,Msg)
#        send_whatsapp_msg(919176642890,Msg)
print("Waiting.... Check the Profit Manually")

ADF[ (ADF['GC2']==False) & (ADF['Symbol']=='Gold')][['Date','Profit','Transaction']]
ADF[ (ADF['GC2']==False) & (ADF['Symbol']=='Gold')]['Profit'].sum()
ADF[ (ADF['GC2']==False) & (ADF['Symbol']=='Gold')]['Profit'].count()
ADF[ (ADF['GC2']==False) & (ADF['Symbol']=='Gold')]['Profit'].sum()
ADF[ (ADF['GC2']==False) & (ADF['Symbol']=='GoldD')]['Profit'].sum()
ADF[ (ADF['GC1']==False) & (ADF['Symbol']=='GoldD')]['Profit'].sum()
ADF[ (ADF['GC2']==True) & (ADF['Symbol']=='GoldD')]['Profit'].sum()
ADF[ (ADF['GC2']==True) & (ADF['Symbol']=='Gold')]['Profit'].sum()
ADF[ (ADF['GC2']==True) & (ADF['Symbol']=='GoldD')]['Profit'].sum()
ADF[ (ADF['GC2']==True) & (ADF['Symbol']=='Gold')]['Profit'].sum()
ADF[ (ADF['GC2']==True) & (ADF['Symbol']=='GoldD')]['Profit'].sum()
ADF[ (ADF['GC2']==True) & (ADF['Symbol']=='GoldD')]['Profit'].count()
660/24
ADF[ (ADF['GC1']==True) & (ADF['Symbol']=='GoldD')]['Profit'].count()
ADF[ (ADF['GC']==True) & (ADF['Symbol']=='GoldD')]['Profit'].sum()
ADF[ (ADF['GC1']==True) & (ADF['Symbol']=='GoldD')]['Profit'].sum()
ADF[ (ADF['GC2']==True) & (ADF['Symbol']=='GoldD')]['Profit'].sum()
ADF[ (ADF['GC']==True) & (ADF['Symbol']=='GoldD')]['Profit'].sum()
ADF[ (ADF['GC1']==True) & (ADF['Symbol']=='GoldD')]['Profit'].sum()
ADF[ (ADF['GC1']==False) & (ADF['Symbol']=='GoldD')]['Profit'].sum()
ADF[ (ADF['GC']==False) & (ADF['Symbol']=='GoldD')]['Profit'].sum()
ADF[ (ADF['GC']==False) & (ADF['Symbol']=='GoldD')]['Profit'].sum()
ADF[ (ADF['GC']==False) & (ADF['Symbol']=='Gold')]['Profit'].sum()
ADF[ (ADF['GC']==False) & (ADF['Symbol']=='Gold')]['Profit'].sum()
ADF[ (ADF['GC']==False) & (ADF['Symbol']=='Gold') & (ADF['Transaction']=='Buy')]['Profit'].sum()
ADF[ (ADF['GC2']==False) & (ADF['Symbol']=='Gold') & (ADF['Transaction']=='Buy')]['Profit'].sum()
ADF[ (ADF['GC2']==False) & (ADF['Symbol']=='Gold')]['Profit'].sum()
ADF[ (ADF['GC2']==False) & (ADF['Symbol']=='Gold') & (ADF['Transaction']=='Sell')]['Profit'].sum()
ADF[ (ADF['GC2']==False) & (ADF['Symbol']=='Gold') & (ADF['Transaction']=='Sell')]['Profit'].sum()
ADF[ (ADF['GC2']==False) & (ADF['Symbol']=='Gold') & (ADF['Transaction']=='Buy')]['Profit'].sum()
ADF[ (ADF['GC2']==True) & (ADF['Symbol']=='Gold') & (ADF['Transaction']=='Sell')]['Profit'].sum()
ADF[ (ADF['GC2']==False) & (ADF['Symbol']=='Gold') ]['Profit'].sum()
ADF[ (ADF['GC1']==False) & (ADF['Symbol']=='Gold') ]['Profit'].sum()
ADF[ (ADF['GC1']==False) & (ADF['Symbol']=='GoldD') ]['Profit'].sum()
ADF[ (ADF['GC1']==False) & (ADF['Symbol']=='Gold') & (ADF['GC1']==True)]['Profit'].sum()
ADF[ (ADF['GC1']==False) & (ADF['Symbol']=='Gold') & (ADF['GC2']==True)]['Profit'].sum()
ADF[ (ADF['GC1']==False) & (ADF['Symbol']=='Gold') & (ADF['GC2']==True)]['Profit'].count()
ADF[ (ADF['GC1']==False) & (ADF['Symbol']=='Gold') & (ADF['GC2']==True)]['Profit'].sum()
ADF[ (ADF['GC1']==False) & (ADF['Symbol']=='GoldD') & (ADF['GC2']==True)]['Profit'].count()
ADF[ (ADF['GC1']==False) & (ADF['Symbol']=='GoldD') & (ADF['GC2']==True)]['Profit']
ADF[ (ADF['GC1']==False) & (ADF['Symbol']=='GoldD') & (ADF['GC2']==True)]['Profit'].sum()
ADF[ (ADF['GC1']==True) & (ADF['Symbol']=='GoldD') & (ADF['GC2']==True)]['Profit'].sum()
ADF[ (ADF['GC1']==True) & (ADF['Symbol']=='GoldD') & (ADF['GC2']==True)]['Profit'].sum()
ADF[ (ADF['GC1']==False) & (ADF['Symbol']=='GoldD') & (ADF['GC2']==True) &  (ADF['GC']==True)]['Profit'].sum()
ADF[ (ADF['GC1']==False) & (ADF['Symbol']=='GoldD') & (ADF['GC2']==True) &  (ADF['GC']==True)]['Profit'].sum()
ADF[ (ADF['GC1']==False) & (ADF['Symbol']=='GoldD') & (ADF['GC2']==True) &  (ADF['GC']==False)]['Profit'].sum()
ADF[ (ADF['GC1']==False) & (ADF['Symbol']=='GoldD') & (ADF['GC2']==True) &  (ADF['GC']==False)]['Profit'].sum()
ADF[ (ADF['GC1']==False) & (ADF['Symbol']=='Gold') & (ADF['GC2']==True) &  (ADF['GC']==False)]['Profit'].sum()
ADF[ (ADF['GC1']==False) & (ADF['Symbol']=='Gold') & (ADF['GC2']==True) &  (ADF['GC']==False)]['Profit'].sum()
ADF[ (ADF['GC2']==False) & (ADF['Symbol']=='Gold')]['Profit'].sum()
ADF[ (ADF['GC2']==False) & (ADF['Symbol']=='Gold')]['Profit'].sum()
ADF[ (ADF['GC2']==False) & (ADF['Symbol']=='Gold')]['Profit'].sum()/ADF[ (ADF['GC2']==False) & (ADF['Symbol']=='Gold')]['Profit'].count()
ADF[ (ADF['GC2']==False) & (ADF['Symbol']=='Gold')]['Profit'].sum()/ADF[ (ADF['GC2']==False) & (ADF['Symbol']=='Gold')]['Profit'].count()
ZSum=ADF[ (ADF['GC2']==False) & (ADF['Symbol']=='Gold')]['Profit'].sum()
ZCount=ADF[ (ADF['GC2']==False) & (ADF['Symbol']=='Gold')]['Profit'].count()
print((ZSum/ZCount-15)*ZCount)
ZSum=ADF[ (ADF['GC2']==False) & (ADF['Symbol']=='Gold')]['Profit'].sum()
ZCount=ADF[ (ADF['GC2']==False) & (ADF['Symbol']=='Gold')]['Profit'].count()
print((ZSum/ZCount-15)*ZCount)
ZSum=ADF[ (ADF['GC2']==False) & (ADF['Symbol']=='Gold')]['Profit'].sum()
ZCount=ADF[ (ADF['GC2']==False) & (ADF['Symbol']=='Gold')]['Profit'].count()
print((ZSum/ZCount-5)*ZCount)
ZSum=ADF[ (ADF['GC2']==False) & (ADF['Symbol']=='Gold')]['Profit'].sum()
ZCount=ADF[ (ADF['GC2']==False) & (ADF['Symbol']=='Gold')]['Profit'].count()
print((ZSum/ZCount-5)*ZCount)

## ---(Sun Apr 28 14:46:11 2019)---
runfile('C:/ReadMoneycontrol/Crude/candlestick-patterns-master/candlestick-patterns-master/NewStrategyV4.py', wdir='C:/ReadMoneycontrol/Crude/candlestick-patterns-master/candlestick-patterns-master')
runfile('C:/ReadMoneycontrol/Crude/candlestick-patterns-master/candlestick-patterns-master/ParsingOldData.py', wdir='C:/ReadMoneycontrol/Crude/candlestick-patterns-master/candlestick-patterns-master')
runfile('C:/ReadMoneycontrol/Crude/candlestick-patterns-master/candlestick-patterns-master/NewStrategyV4.2.py', wdir='C:/ReadMoneycontrol/Crude/candlestick-patterns-master/candlestick-patterns-master')
SilverHistoryDataV1
HResult=GetHData(SilverDF);
S5MinData=HResult[1]
HResult=GetHData(GoldDF)
G5MinData=HResult[1]
GoldExpiry="05DEC2018"
SilverExpiry="05DEC2018"
Symbol="GOLD"
GoldHistoryV1=candlestick.GetEODDataFromMCX(Symbol,PivotType,OHLC,GoldExpiry)
GoldHistoryV2=candlestick.GetEODDataFromMCX(Symbol,PivotType,3,GoldExpiry)
#ChartWithBreakOut(GoldHistoryV1,DataIndex,GoldCandle15Min,GoldCandle30Min,Symbol+"V1")
#ChartWithBreakOut(GoldHistoryV2,DataIndex,GoldCandle15Min,GoldCandle30Min,Symbol+"V2")
Symbol="SILVER"
PivotType="D"
OHLC=4
SilverHistory=candlestick.GetEODDataFromMCX(Symbol,PivotType,OHLC,SilverExpiry)
SilverHistoryV2=candlestick.GetEODDataFromMCX(Symbol,PivotType,3,SilverExpiry)

GoldHistoryDataV2
GoldHistoryV1
G5MinData
S5MinData
GoldCandle5Min=G5MinData
SilverCandle5Min=S5MinData
DataIndex=0
pp=28
TProfit=0
Messages=[]
AMessages=[]
BMessages=[]
while(pp<=50):
    AtSilverPivot=False
    AtGoldPivot=False
    TProfit=0
    DataIndex=pp
    pp=pp+1


#    Symbol="GOLD"
#    GoldCandle5Min=candlestick.getLiveDataFromZerodha(Symbol,"5minute")
#    Symbol="SILVER"
#    SilverCandle5Min=candlestick.getLiveDataFromZerodha(Symbol,"5minute")
    #SilverHistory.iloc[4]['Date']
    #GoldHistoryV1.iloc[32]['Date']
    fibMS={}
    AllList=[]
    test(SilverHistory,DataIndex,0)
    SF1=AllList    
    AllList=[]
    test(SilverHistoryV2,DataIndex,0)
    SF2=AllList
    SF3=fibMS
    
    fibMS={}
    AllList=[]
    test(GoldHistoryV1,DataIndex,0)
    GF1=AllList
    AllList=[]
    test(GoldHistoryV2,DataIndex,0)
    GF2=AllList
    GF3=fibMS
    AllList=[]
    
    
    GP1=GoldHistoryV1.iloc[DataIndex]['IPivot']
    GP2=GoldHistoryV2.iloc[DataIndex]['IPivot']
    SP1=SilverHistory.iloc[DataIndex]['IPivot']
    SP2=SilverHistoryV2.iloc[DataIndex]['IPivot']
    
    
    GoldData=getSpecificData(GoldHistoryV1,GoldCandle15Min,DataIndex)
    SilverData=getSpecificData(SilverHistoryV2,SilverCandle15Min,DataIndex)
    #SilverData.iloc[10]['Date'][']
    #GoldData=getSpecificData1(GoldHistoryV1,GoldCandle5Min,DataIndex,4)
    #SilverData=getSpecificData1(SilverHistoryV2,SilverCandle5Min,DataIndex,4)
    
    GoldData['high'][:3]
    
    #SilverData.iloc[i]['Date']
    #SilverData.iloc[i]['low']
    
    fPH=SilverHistoryV2.iloc[DataIndex]['High']
    fPL=SilverHistoryV2.iloc[DataIndex]['Low']
    SRange=fPH-fPL    
    Stolerance=round(SRange*.01,0)
    SMargin=round(SRange*.25,0)
    SStoploss=round(SRange*.3,0)
    
    ##########################
    
    LastFoundIndex=-1
    LastFoundSignal=""
    LastFoundIndex1=-1
    LastFoundSignal1=""    
    
    ########################
    
    fPH=GoldHistoryV1.iloc[DataIndex]['High']
    fPL=GoldHistoryV1.iloc[DataIndex]['Low']
    GRange=fPH-fPL    
    Gtolerance=round(GRange*.01,0)
    GMargin=round(GRange*.25,0)
    GMargin1=round(GRange*.35,0)
    GStoploss=round(GRange*.3,0)
    GStoploss1=round(GRange*.5,0)
    if(GMargin>100):
        GMargin=100
        GStoploss=110
    #i=36
    #SilverData.iloc[36]['Date']        
    #SilverData.iloc[i-1]['Date'] 
    i=1
    while(i<len(GoldData)-10):
        if(i>10):
            j=i-10
        else:
            j=i
        SLL=SilverData['low'][j:i+1].min()
        SHH=SilverData['high'][j:i+1].max()
        SL=SilverData.iloc[i]['low']
        SH=SilverData.iloc[i]['high']
        SO=SilverData.iloc[i]['open']
        SC=SilverData.iloc[i]['close']
        
        GLL=GoldData['low'][j:i+1].min()
        GHH=GoldData['high'][j:i+1].max()
        GL=GoldData.iloc[i]['low']
        GH=GoldData.iloc[i]['high']
        GO=GoldData.iloc[i]['open']
        GC=GoldData.iloc[i]['close']
        if(LastFoundIndex!=-1):        
            SPL=SilverData.iloc[LastFoundIndex]['low']
            SPH=SilverData.iloc[LastFoundIndex]['high']
            SPO=SilverData.iloc[LastFoundIndex]['open']
            SPC=SilverData.iloc[LastFoundIndex]['close']
            GPO=GoldData.iloc[LastFoundIndex]['open']
            GPC=GoldData.iloc[LastFoundIndex]['close']
            GPL=GoldData.iloc[LastFoundIndex]['low']
            GPH=GoldData.iloc[LastFoundIndex]['high']
            SPO1=SilverData.iloc[LastFoundIndex-1]['open']
            SPC1=SilverData.iloc[LastFoundIndex-1]['close']
            GPO1=GoldData.iloc[LastFoundIndex-1]['open']
            GPC1=GoldData.iloc[LastFoundIndex-1]['close']
            
            Transaction=""
            Reliability=False
            Data=GoldData    
            
            #DateIndex=i
            #Margin=0.002
            #Stoploss=0.002            
            SearchData=GoldCandle5Min
            SilverSearchData=SilverCandle5Min

#            if((SL==SP1) or (SL==SP2)):
#                print("At Pivot")
            if(False and AtGoldPivot):
                if(AtGoldPivotS=="GP1"):
                    
                    BuyPrice=GoldHistoryV1.iloc[DataIndex]["H0M1"]
                    BuyTarget=GoldHistoryV1.iloc[DataIndex]["H1"]
                    BuyStopLoss=GoldHistoryV1.iloc[DataIndex]["L0M0"]
                    
                    SellPrice=GoldHistoryV1.iloc[DataIndex]["L0M1"]
                    SellTarget=GoldHistoryV1.iloc[DataIndex]["L1"]
                    SellStopLoss=GoldHistoryV1.iloc[DataIndex]["H0M0"]
                
                
                elif(AtGoldPivotS=="GP2"):
                    BuyPrice=GoldHistoryV2.iloc[DataIndex]["H0M1"]
                    BuyTarget=GoldHistoryV2.iloc[DataIndex]["H1"]
                    BuyStopLoss=GoldHistoryV2.iloc[DataIndex]["L0M0"]
                    #DataIndex=10;GoldHistoryV2.iloc[DataIndex]['Date']
                    SellPrice=GoldHistoryV2.iloc[DataIndex]["L0M1"]
                    SellTarget=GoldHistoryV2.iloc[DataIndex]["L1"]
                    SellStopLoss=GoldHistoryV2.iloc[DataIndex]["H0M0"]
                
                if((BuyTarget-BuyPrice)<30):
                    BuyPrice=BuyPrice+(BuyTarget-BuyPrice)
                    BuyTarget=BuyTarget+(BuyTarget-BuyPrice)
                    BuyStopLoss=BuyStopLoss-(BuyTarget-BuyPrice)
                    SellPrice=SellPrice+(SellTarget-SellPrice)
                    SellTarget=SellTarget+(SellTarget-SellPrice)
                    SellStopLoss=SellStopLoss-(SellTarget-SellPrice)
                print(AtGoldPivotS+"\t"+str(GoldData.iloc[i]['Date'])+"\tBuy At \t"+str(round(BuyPrice))+"\t"+str(round(BuyTarget))+"\t"+str(round(BuyStopLoss)))
                print(AtGoldPivotS+"\t"+str(GoldData.iloc[i]['Date'])+"\tSell At\t"+str(round(SellPrice))+"\t"+str(round(SellTarget))+"\t"+str(round(SellStopLoss)))
            
            
            if(False and LastFoundIndex1!=-1):# and LastFoundSignal!=""):
                taH=GoldData.iloc[LastFoundIndex1]['high']
                taL=GoldData.iloc[LastFoundIndex1]['low']
                taO=GoldData.iloc[LastFoundIndex1]['open']
                taC=GoldData.iloc[LastFoundIndex1]['close']
                tbH=GoldData.iloc[LastFoundIndex]['high']
                tbL=GoldData.iloc[LastFoundIndex]['low']
                tbO=GoldData.iloc[LastFoundIndex]['open']
                tbC=GoldData.iloc[LastFoundIndex]['close']
                taOC=round((taC-taO)/GRange*100,2)
                tbOC=round((tbC-tbO)/GRange*100,2)
                taHL=round((taH-taL)/GRange*100,2)
                tbHL=round((tbH-tbL)/GRange*100,2)
                SameH=(taH-Gtolerance <= tbH <= taH+Gtolerance)
                SameL=(taL-Gtolerance <= tbL <= taL+Gtolerance)
                if ((SameH and SameL) and 
                    (
                            (
                            (round(tbHL-taHL,2)==0) or
                            (round(tbHL-taHL,2)==round(tbOC+taOC,2))
                            )
                    #and (-.8 <= (round(tbHL-taHL,2)==0) <= 0.8)
                    )        
                            ):
                    print(str(SilverData.iloc[i]['Date']) 
                + "\t" + str((taO>taC)) 
                + "\t" + str((tbO>tbC)) 
                + "\t" + str(SameH)
                + "\t" + str(SameL)
                + "\t" + str(Gtolerance)
                +"\t"+ str(taOC)
                +"\t"+ str(tbOC)
                +"\t"+ str(round(tbOC+taOC,2))
                +"\t"+ str(round(tbHL-taHL,2)))
                LastFoundSignal1="" 
                LastFoundSignal=""
                #LastFoundIndex=-1
                LastFoundIndex1=-1
            
            if(False):
                if((SL>SPL) and (GL>GPL)):
                    
                    Transaction="Buy"
                    Reliability= (((GO>GC)==False) and ((SO>SC)==False) and ((GPO1>GPC1)==True) and ((SPO1>SPC1)==True))
                    Reliability1= (
                                  (
                                          ((GO>GC)==False) and ((SO>SC)==False) and 
                                          ((GPO1>GPC1)==False) and ((SPO1>SPC1)==False) and 
                                          ((GPO>GPC)==False) and ((SPO>SPC)==False)
                                          )
                                  )
                    Reliability=(Reliability or Reliability1)            
                    ### Overriding default rule
                    Reliability=True               
                    if ((Transaction!="") and Reliability):
                        if((GO==GC)):
                            Transaction="Sell"
                        if ((Reliability1==True) and ((GPO>GPC)==True)):
                            Transaction="Sell"
                        Result={}
                        Result['Profit']=0    
                        Result=candlestick.Check(Data,Transaction,DateIndex,GMargin,GStoploss,SearchData)
                        #print(str(SilverData.iloc[i]['Date']) + "\t "+Transaction+"1   \t" + str(GO>GC) + "\t"+str(SO>SC) + " - " + str(Result['Profit']))
                        #Messages.append(str(SilverData.iloc[i]['Date']) +Transaction+"1   \t" + str(GPO1>GPC1) + " < " + str(GPO>GPC) +" < " +str(GO>GC) + "\t==\t"+str(SO>SC)+" > "+str(SPO>SPC)+" > "+str(SPO1>SPC1) + " -\t " + str(Result['Profit']) + " - " + " SP=" + str(AtSilverPivot) +  " GP=" + str(AtGoldPivot))
                        Messages.append(getDf(SilverData.iloc[i]['Date'],'Gold',Transaction,
                           (GPO1>GPC1),(GPO>GPC),(GO>GC),
                           (SO>SC),(SPO>SPC),(SPO1>SPC1),
                           Result['Profit'],AtSilverPivot,AtGoldPivot,(GO==GC),
                           GResult1,GResult2,GResult3,
                           SResult1,SResult2,SResult3,AtGoldPivotS,AtSilverPivotS))
                        
                        TProfit=Result['Profit']+TProfit
                if((SH<SPH) and (GH<GPH)):
                    #print(str(SilverData.iloc[i]['Date']) +" Sell \t" + str(GO>GC) + "\t"+str(SO>SC))
                    Transaction="Sell"
                    Reliability= (((GO>GC)==True) and ((SO>SC)==True) and ((GPO1>GPC1)==False) and ((SPO1>SPC1)==False))
                    Reliability1= (
                                  (
                                          ((GO>GC)==True) and ((SO>SC)==True) and 
                                          ((GPO1>GPC1)==True) and ((SPO1>SPC1)==True) and 
                                          ((GPO>GPC)==True) and ((SPO>SPC)==True)
                                          )
                                  )
                    Reliability=(Reliability or Reliability1)
                    ### Overriding default rule
                    Reliability=True
                    if ((Transaction!="") and Reliability):
                        if((GO==GC)):
                            Transaction="Buy"
                        if ((Reliability1==True) and ((GPO>GPC)==True)):
                            Transaction="Buy"
                        Result={}
                        Result['Profit']=0
                        Result=candlestick.Check(Data,Transaction,DateIndex,GMargin,GStoploss,SearchData)
                        #print(str(SilverData.iloc[i]['Date']) +" Sell  \t" + str(GO>GC) + "\t"+str(SO>SC) + " - " + str(Result['Profit']))
                        #Messages.append(str(SilverData.iloc[i]['Date']) +" Sell  \t" + str(GPO1>GPC1) + " < " + str(GPO>GPC) +" < " +str(GO>GC) + "\t==\t"+str(SO>SC)+" > "+str(SPO>SPC)+" > "+str(SPO1>SPC1) + " -\t " + str(Result['Profit']) + " - " + str(GO==GC) + " SP=" + str(AtSilverPivot) +  " GP=" + str(AtGoldPivot))
                        Messages.append(getDf(SilverData.iloc[i]['Date'],'Gold',Transaction,
                           (GPO1>GPC1),(GPO>GPC),(GO>GC),
                           (SO>SC),(SPO>SPC),(SPO1>SPC1),
                           Result['Profit'],AtSilverPivot,AtGoldPivot,(GO==GC),
                           GResult1,GResult2,GResult3,
                           SResult1,SResult2,SResult3,AtGoldPivotS,AtSilverPivotS))
                        TProfit=Result['Profit']+TProfit
            if(True):
                if(LastFoundSignal=="Buy" and ((GPL-Gtolerance <= GL <= GPL+Gtolerance))):
                #if(LastFoundSignal=="Buy" and ( (SPL-Stolerance <= SL <= SPL+Stolerance) or (GPL-Gtolerance <= GL <= GPL+Gtolerance))):
                    Reliability=True
                    Transaction="Buy"
                    #Reliability= (((GO>GC)==False) and ((SO>SC)==False) and ((GPO1>GPC1)==True) and ((SPO1>SPC1)==True))
                    if(Reliability):
                        Result=candlestick.Check(Data,"Buy",DateIndex,GMargin,GStoploss,SearchData)
                        AMessages.append(getDf(SilverData.iloc[i]['Date'],'Gold',Transaction,
                           (GPO1>GPC1),(GPO>GPC),(GO>GC),
                           (SO>SC),(SPO>SPC),(SPO1>SPC1),
                           Result['Profit'],AtSilverPivot,AtGoldPivot,(GO==GC),
                           GResult1,GResult2,GResult3,
                           SResult1,SResult2,SResult3,AtGoldPivotS,AtSilverPivotS))
                        Result=candlestick.Check(Data,"Buy",DateIndex,GMargin1,GStoploss1,SearchData)
                        AMessages.append(getDf(SilverData.iloc[i]['Date'],'GoldD',Transaction,
                           (GPO1>GPC1),(GPO>GPC),(GO>GC),
                           (SO>SC),(SPO>SPC),(SPO1>SPC1),
                           Result['Profit'],AtSilverPivot,AtGoldPivot,(GO==GC),
                           GResult1,GResult2,GResult3,
                           SResult1,SResult2,SResult3,AtGoldPivotS,AtSilverPivotS))
                        #AMessages.append(str(SilverData.iloc[i]['Date']) +" Buy GOLDD \t" + str(GPO1>GPC1) + " < " + str(GPO>GPC) +" < " +str(GO>GC) + "\t==\t"+str(SO>SC)+" > "+str(SPO>SPC)+" > "+str(SPO1>SPC1) + " -\t " + str(Result['Profit']) + " - " + str(GO==GC) + " SP=" + str(AtSilverPivot) +  " GP=" + str(AtGoldPivot))
                        if(False):
                            if(AtGoldPivot ):
                                Result=candlestick.Check(Data,"Buy",DateIndex,GMargin,GStoploss,SearchData)
                                print(str(i)+  "\t-" +str(SilverData.iloc[i]['Date']) +"\tBUYY \t" + str(GO>GC) + "\t"+str(SO>SC) + "\tS="+str(AtSilverPivotS) + "\tG="+str(AtGoldPivotS)+" - " + str(Result['Profit']))            
                                #AMessages.append(str(SilverData.iloc[i]['Date']) +"\tBUYY GOLD\t" + str(GO>GC) + "\t"+str(SO>SC) + "\tS="+str(AtSilverPivotS) + "\tG="+str(AtGoldPivotS)+" - " + str(Result['Profit']))
                                BMessages.append(getDf(SilverData.iloc[i]['Date'],'Gold',Transaction,
                               (GPO1>GPC1),(GPO>GPC),(GO>GC),
                               (SO>SC),(SPO>SPC),(SPO1>SPC1),
                               Result['Profit'],AtSilverPivot,AtGoldPivot,(GO==GC),
                               GResult1,GResult2,GResult3,
                               SResult1,SResult2,SResult3,AtGoldPivotS,AtSilverPivotS))
                            
                            if(AtSilverPivot ):
                                Result=candlestick.Check(SilverData,"Buy",DateIndex,SMargin,SStoploss,SilverSearchData)
                                print(str(i)+  "\t-" +str(SilverData.iloc[i]['Date']) +"\tBUYY \t" + str(GO>GC) + "\t"+str(SO>SC) + "\tS="+str(AtSilverPivotS) + "\tG="+str(AtGoldPivotS)+" - " + str(Result['Profit']))            
        #                        AMessages.append(str(SilverData.iloc[i]['Date']) +"\tBUYY SILVER\t" + str(GO>GC) + "\t"+str(SO>SC) + "\tS="+str(AtSilverPivotS) + "\tG="+str(AtGoldPivotS)+" - " + str(Result['Profit']))
                                BMessages.append(getDf(SilverData.iloc[i]['Date'],'Silver',Transaction,
                               (GPO1>GPC1),(GPO>GPC),(GO>GC),
                               (SO>SC),(SPO>SPC),(SPO1>SPC1),
                               Result['Profit'],AtSilverPivot,AtGoldPivot,(GO==GC),
                               GResult1,GResult2,GResult3,
                               SResult1,SResult2,SResult3,AtGoldPivotS,AtSilverPivotS))
                
                
                #if(LastFoundSignal=="Sell" and ( (SH-Stolerance <= SPH <= SH+Stolerance) or (GH-Gtolerance <= GPH <= GH+Gtolerance))):                    
                if(LastFoundSignal=="Sell" and ( (GH-Gtolerance <= GPH <= GH+Gtolerance))):
                    Reliability=True
                    #Reliability= (((GO>GC)==True) and ((SO>SC)==True) and ((GPO1>GPC1)==False) and ((SPO1>SPC1)==False))
                    Transaction="Sell"
                    if(Reliability):
                        Result=candlestick.Check(Data,"Sell",DateIndex,GMargin,GStoploss,SearchData)
                        #AMessages.append(str(SilverData.iloc[i]['Date']) +" Sell GOLDD  \t" + str(GPO1>GPC1) + " < " + str(GPO>GPC) +" < " +str(GO>GC) + "\t==\t"+str(SO>SC)+" > "+str(SPO>SPC)+" > "+str(SPO1>SPC1) + " -\t " + str(Result['Profit']) + " - " + str(GO==GC) + " SP=" + str(AtSilverPivot) +  " GP=" + str(AtGoldPivot))
                        AMessages.append(getDf(SilverData.iloc[i]['Date'],'Gold',Transaction,
                           (GPO1>GPC1),(GPO>GPC),(GO>GC),
                           (SO>SC),(SPO>SPC),(SPO1>SPC1),
                           Result['Profit'],AtSilverPivot,AtGoldPivot,(GO==GC),
                           GResult1,GResult2,GResult3,
                           SResult1,SResult2,SResult3,AtGoldPivotS,AtSilverPivotS))
                        Result=candlestick.Check(Data,"Buy",DateIndex,GMargin1,GStoploss1,SearchData)
                        AMessages.append(getDf(SilverData.iloc[i]['Date'],'GoldD',Transaction,
                           (GPO1>GPC1),(GPO>GPC),(GO>GC),
                           (SO>SC),(SPO>SPC),(SPO1>SPC1),
                           Result['Profit'],AtSilverPivot,AtGoldPivot,(GO==GC),
                           GResult1,GResult2,GResult3,
                           SResult1,SResult2,SResult3,AtGoldPivotS,AtSilverPivotS))
                        if(False):
                            if(AtGoldPivot):
                                #print(str(i)+  "\t- " +str(SilverData.iloc[i]['Date']) +"\tSELLK \t" + str(GO>GC) + "\t"+str(SO>SC))
                                Result=candlestick.Check(Data,"Sell",DateIndex,GMargin,GStoploss,SearchData)
                                print(str(i)+  "\t-" +str(SilverData.iloc[i]['Date']) +"\tSELLK \t" + str(GO>GC) + "\t"+str(SO>SC) + "\tS="+str(AtSilverPivotS) + "\tG="+str(AtGoldPivotS)+" - " + str(Result['Profit']))            
                                #AMessages.append(str(SilverData.iloc[i]['Date']) +"\tSELLK GOLD\t" + str(GO>GC) + "\t"+str(SO>SC) + "\tS="+str(AtSilverPivotS) + "\tG="+str(AtGoldPivotS)+" - " + str(Result['Profit']))
                                BMessages.append(getDf(SilverData.iloc[i]['Date'],'Gold',Transaction,
                               (GPO1>GPC1),(GPO>GPC),(GO>GC),
                               (SO>SC),(SPO>SPC),(SPO1>SPC1),
                               Result['Profit'],AtSilverPivot,AtGoldPivot,(GO==GC),
                               GResult1,GResult2,GResult3,
                               SResult1,SResult2,SResult3,AtGoldPivotS,AtSilverPivotS))
                            if(AtSilverPivot ):
                                Result=candlestick.Check(SilverData,"Sell",DateIndex,SMargin,SStoploss,SilverSearchData)
                                print(str(i)+  "\t-" +str(SilverData.iloc[i]['Date']) +"\tSELLK \t" + str(GO>GC) + "\t"+str(SO>SC) + "\tS="+str(AtSilverPivotS) + "\tG="+str(AtGoldPivotS)+" - " + str(Result['Profit']))            
                                #AMessages.append(str(SilverData.iloc[i]['Date']) +"\tSELLK SILVER\t" + 
                                #str(GO>GC) + "\t"+str(SO>SC) + "\tS="+str(AtSilverPivotS) 
                                #+ "\tG="+str(AtGoldPivotS)+" - " + str(Result['Profit']))
                                BMessages.append(getDf(SilverData.iloc[i]['Date'],'Silver',Transaction,
                               (GPO1>GPC1),(GPO>GPC),(GO>GC),
                               (SO>SC),(SPO>SPC),(SPO1>SPC1),
                               Result['Profit'],AtSilverPivot,AtGoldPivot,(GO==GC),
                               GResult1,GResult2,GResult3,
                               SResult1,SResult2,SResult3,AtGoldPivotS,AtSilverPivotS))
            
            
            
            
            LastFoundSignal=""
        SResult1=False;SResult2=False;SResult3=False
        GResult1=False;GResult2=False;GResult3=False;Threshold=0.03
        if(SL==SLL):
            SResult1=isInRange(SilverHistoryV2,DataIndex,SL,SF1,0,Threshold)        
            SResult2=isInRange(SilverHistoryV2,DataIndex,SL,SF2,0,Threshold)
            SResult3=isInRange(SilverHistoryV2,DataIndex,SL,list(SF3.values()),0,Threshold)
            LastFoundSignal="Buy"
        else:
            if(SH==SHH):
                SResult1=isInRange(SilverHistoryV2,DataIndex,SH,SF1,0,Threshold)        
                SResult2=isInRange(SilverHistoryV2,DataIndex,SH,SF2,0,Threshold)
                SResult3=isInRange(SilverHistoryV2,DataIndex,SH,list(SF3.values()),0,Threshold)       
                LastFoundSignal="Sell"
        
        if(GL==GLL):
            GResult1=isInRange(GoldHistoryV1,DataIndex,GL,GF1,0,Threshold)        
            GResult2=isInRange(GoldHistoryV1,DataIndex,GL,GF2,0,Threshold)        
            GResult3=isInRange(GoldHistoryV1,DataIndex,GL,list(GF3.values()),0,Threshold)        
            LastFoundSignal="Buy"
        else:
            if(GH==GHH):
                GResult1=isInRange(GoldHistoryV1,DataIndex,GH,GF1,0,Threshold)        
                GResult2=isInRange(GoldHistoryV1,DataIndex,GH,GF2,0,Threshold)        
                GResult3=isInRange(GoldHistoryV1,DataIndex,GH,list(GF3.values()),0,Threshold)
                LastFoundSignal="Sell"
        #((SResult1==True)| (SResult2==True)| (SResult3==True)) and
        if( ((GResult1==True)| (GResult2==True)| (GResult3==True))):
            #print(SilverData.iloc[i]['Date'])
            if(LastFoundIndex!=-1):
                LastFoundIndex1=LastFoundIndex
                LastFoundSignal1=PreviousSignal
            LastFoundIndex=i
            PreviousSignal=LastFoundSignal
        else:
            LastFoundIndex=-1
        
        
        TS=round(SRange*.015,0)
        TG=round(GRange*.015,0)
        AtGoldPivot=False
        AtSilverPivot=False
        AtSilverPivotS=""
        AtGoldPivotS=""
        
        if((SL-TS <= SP1 <= SL+TS)):
            AtSilverPivot=True
            AtSilverPivotS="SP1"
        if((SL-TS <= SP2 <= SL+TS)):
            AtSilverPivot=True
            AtSilverPivotS="SP2"
            #print("Silver At Pivot")
        if((GL-TG <= GP1 <= GL+TG) or (GH-TG <= GP1 <= GH+TG)):
            AtGoldPivot=True
            AtGoldPivotS="GP1"
        if ((GL-TG <= GP2 <= GL+TG) or (GH-TG <= GP1 <= GH+TG)):
            #print("Gold At Pivot")
            AtGoldPivot=True
            AtGoldPivotS="GP2"
        
        i=i+1
