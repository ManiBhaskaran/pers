# -*- coding: utf-8 -*-
"""
Created on Tue Dec 17 20:25:06 2019

@author: lalitha
"""

FinalCheckResults=pd.read_csv(r"C:\ReadMoneycontrol\Mani 2.0\Temp\MinuteV3.2-1-SecondRun.csv")

CDATES=list(FinalCheckResults['CDATE'].unique())
CDATES=list(FinalCheckResults[(FinalCheckResults['Type']=="High") & 
                  #(FinalCheckResults['HCFib']=='A1500')& 
                  (FinalCheckResults['HCLevel']=='H2') & 
                  (FinalCheckResults['PercHL']<0.3)
                  ]['CDATE'].unique())
FinalCheckResults[(FinalCheckResults['Type']=="High") & 
                  #(FinalCheckResults['HCFib']=='A1500')& 
                  (FinalCheckResults['HCLevel']=='H2') & 
                  (FinalCheckResults['PercHL']<0.3)
                  ].groupby([
            'Index'])['BuyProfitP','SellProfitP','BuyProfitP1','SellProfitP1'].sum()
                  ][['Stock','CurrentDate','BuyProfitP',
                  'SellProfitP','CFD','PercHL']]
#ResultDF05['CDATE']=pd.to_datetime(ResultDF05['CurrentDate']).dt.strftime("%Y-%b-%d")


minute="5minute"
ResultDF05=pd.read_csv(r"C:\ReadMoneycontrol\Mani 2.0\Report\\"+minute+'FO1-100.csv')
ResultDF05=pd.read_csv(r"C:\ReadMoneycontrol\Mani 2.0\FOTemp2\AUROPHARMAResultsH1.csv")
ResultDF05=ResultDF05[ResultDF05['CFD']>.3]
#ResultDF05.shape[0]
#ResultDF05[ResultDF05['Index']<60].shape[0]
ResultDF05=ResultDF05[ResultDF05['Index']<=60]

ResultDF05['CDATE']=pd.to_datetime(ResultDF05['CurrentDate']).dt.strftime("%Y-%b-%d")

CDATES=ResultDF05['CDATE'].unique()
#ResultDF05['Stock'].unique().shape
#SData=FinalCheckResults[FinalCheckResults['CDATE']==CDATES[11]]
#SData.shape

SData=ResultDF05[ResultDF05['CDATE']==CDATES[4]]
#SData=ResultDF05
#SData[SData.duplicated(['Stock','CurrentDate'],keep="first")][['Stock','CurrentDate']].sort_values(['CurrentDate','Stock'])
SData.drop_duplicates(subset =["Stock","CurrentDate","Type"], keep = "first", inplace = True) 


SData[(SData['LCLevel']=="L1") | (SData['LCLevel']=="L2")][['Stock','CurrentDate',
     'CGap','PercHL','LCFib','LCLevel','MaxHL','MaxHLClr','MaxHLIdx']]

SData[(SData['LCLevel']=="H1") | (SData['LCLevel']=="H2")][['Stock','CurrentDate',
     'CGap','PercHL','LCFib','LCLevel','MaxHL','MaxHLClr','MaxHLIdx']]

SData[(SData['HCLevel']=="H1") | (SData['HCLevel']=="H2")][['Stock','CurrentDate',
     'CGap','PercHL','HCFib','HCLevel','MaxHL','MaxHLClr','MaxHLIdx']]

Test1=SData[
#        (SData['PercHL']>-.2) & (SData['PercHL']<.2) &
   (SData['PercHL']>SData['CFD']*-1) & (SData['PercHL']<SData['CFD']) &
     #& (SData['TPercHO']<.3) 
     (SData['TPercOL']>=SData['CFD']*2.5) &
     (SData['CFD']>.5) &
#     (SData['TPercHL']>1) 
#     &
        (SData['Type']=="Low") 
#        & (((SData['LCFib']=="Z1500") | (SData['LCFib']=="Z2000") 
#        | (SData['LCFib']=="Z1786")
#        | (SData['LCFib']=="Z1000")
#        | (SData['LCFib']=="Z1236")
#        | (SData['LCFib']=="Z786")
#        | (SData['LCFib']=="Z1618")
#        | (SData['LCFib']=="Z2236")
#        | (SData['LCFib']=="Z2382")
#        | (SData['LCFib']=="Z2500")) 
#        | ((SData['LCLevel']=="L1") | (SData['LCLevel']=="L2") 
#        |  (SData['LCLevel']=="L3") | (SData['LCLevel']=="L4")))
#      
     ][['Index','CDATE','Stock','CurrentDate','TPercHO','TPercOL','DiffP','PDiffP','TPercHL','CFD','CPD',
     'CGap','PercHL','LCFib','LCLevel','MaxHL','MaxHLClr','MaxHLIdx','CC','BuyProfitP','SellProfitP','BuyProfitP1','SellProfitP1']].sort_values('Index',ascending=True)
Test1.drop_duplicates(subset =["Stock","CDATE"], keep = "first", inplace = True) 
Test1[['BuyProfitP','SellProfitP','BuyProfitP1','SellProfitP1']].sum()




THigh1=SData[
#        (SData['PercHL']>-.2) & (SData['PercHL']<.2) &
    (SData['PercHL']>SData['CFD']*-1) & (SData['PercHL']<SData['CFD']) &
     #& (SData['TPercHO']<.3) 
     (SData['TPercHO']>=SData['CFD']*2) &
     (SData['CFD']>.5) &
#     (SData['TPercHL']>1) 
#     &
        (SData['Type']=="High") 
#        & (((SData['LCFib']=="Z1500") | (SData['LCFib']=="Z2000") 
#        | (SData['LCFib']=="Z1786")
#        | (SData['LCFib']=="Z1000")
#        | (SData['LCFib']=="Z1236")
#        | (SData['LCFib']=="Z786")
#        | (SData['LCFib']=="Z1618")
#        | (SData['LCFib']=="Z2236")
#        | (SData['LCFib']=="Z2382")
#        | (SData['LCFib']=="Z2500")) 
#        | ((SData['LCLevel']=="L1") | (SData['LCLevel']=="L2") 
#        |  (SData['LCLevel']=="L3") | (SData['LCLevel']=="L4")))
#      
     ][['Index','CDATE','Stock','CurrentDate','TPercHO','TPercOL','DiffP','PDiffP','TPercHL','CFD','CPD',
     'CGap','PercHL','HCFib','HCLevel','MaxHL','MaxHLClr','MaxHLIdx','CC','BuyProfitP','SellProfitP','BuyProfitP1','SellProfitP1']].sort_values('Index',ascending=True)
THigh1.drop_duplicates(subset =["Stock","CDATE"], keep = "first", inplace = True) 
THigh1[['BuyProfitP','SellProfitP','BuyProfitP1','SellProfitP1']].sum()


SData[(SData['TPercOL']>=SData['CFD']*2) &
      (SData['TPercHL']>1) &
     (SData['LCFib']=='Z236')  &
#     &
        (SData['Type']=="Low")].groupby([
            'LCFib','CDATE'])['BuyProfitP','SellProfitP','BuyProfitP1','SellProfitP1'].count()
    
SData[(SData['TPercOL']>=SData['CFD']*2) &
      (SData['TPercHL']>1) &
     (SData['LCFib']=='Z236')  &
#     &
        (SData['Type']=="Low")].groupby([
            'LCFib','CDATE'])['BuyProfitP','SellProfitP','BuyProfitP1','SellProfitP1'].sum()
    


Test=SData[ (SData['Type']=="High") & (((SData['HCFib']=="A1500") | (SData['HCFib']=="A2000") 
        | (SData['HCFib']=="A1786")
        | (SData['HCFib']=="A1618")
        | (SData['HCFib']=="A2236")
        | (SData['HCFib']=="A1236")
        | (SData['HCFib']=="A2382")
        | (SData['HCFib']=="A1382")
        | (SData['HCFib']=="A2500")) | ((SData['HCLevel']=="H1") | (SData['HCLevel']=="H2")))
][['Index','Stock','CurrentDate',
     'CGap','PercHL','HCFib','HCLevel','MaxHL','MaxHLClr','MaxHLIdx','DiffP','PDiffP','TPercHL','CFD','CPD','CC']].sort_values('Index',ascending=True)
     
Test['FPrice']=round(Test['CC']*(1-Test['CFD']/100),2)
Test['FSL']=round(Test['CC']*(1+Test['CFD']/100*1.5),2)
Test['LPrice']=round(Test['CC']*(1-Test['CPD']/100),2)
Test['LSL']=round(Test['CC']*(1+Test['CPD']/100*1.5),2)
     
     
     
     ][['Index','Stock','CurrentDate',
     'CGap','PercHL','HCFib','HCLevel','MaxHL','MaxHLClr','MaxHLIdx','DiffP','PDiffP','TPercHL','CFD','CPD','CC']].sort_values('CurrentDate',ascending=False).head(6)

Test1=SData[(SData['Type']=="Low") & (((SData['LCFib']=="Z1500") | (SData['LCFib']=="Z2000") 
        | (SData['LCFib']=="Z1786")
        | (SData['LCFib']=="Z1000")
        | (SData['LCFib']=="Z1236")
        | (SData['LCFib']=="Z786")
        | (SData['LCFib']=="Z1618")
        | (SData['LCFib']=="Z2236")
        | (SData['LCFib']=="Z2382")
        | (SData['LCFib']=="Z2500")) | ((SData['LCLevel']=="L1") | (SData['LCLevel']=="L2")))
      
     ][['Index','Stock','CurrentDate',
     'CGap','PercHL','LCFib','LCLevel','MaxHL','MaxHLClr','MaxHLIdx','DiffP','PDiffP','TPercHL','CFD','CPD','CC']].sort_values('Index',ascending=True)
Test1['Price']=round(Test1['CC']*(1+Test1['CFD']/100),2)
Test1['SL']=round(Test1['CC']*(1-Test1['CFD']/100*1.5),2)
Test1['LPrice']=round(Test1['CC']*(1+Test1['CPD']/100),2)
Test1['LSL']=round(Test1['CC']*(1-Test1['CPD']/100*1.5),2)



.head(6)



SData[(SData['HCFib']=="A1500") | (SData['HCFib']=="A2000") 
        | (SData['HCFib']=="A1786")
        | (SData['HCFib']=="A1618")
        | (SData['HCFib']=="A2236")
        | (SData['HCFib']=="A2382")
        | (SData['HCFib']=="A2500")][['Stock','CurrentDate',
     'CGap','PercHL','HCFib','HCLevel','MaxHL','MaxHLClr','MaxHLIdx']]


SData[(SData['LCFib']=="Z1500") | (SData['LCFib']=="Z2000") 
        | (SData['LCFib']=="Z1786")
        | (SData['LCFib']=="Z1618")
        | (SData['LCFib']=="Z2236")
        | (SData['LCFib']=="Z2382")
        | (SData['LCFib']=="Z2500")][['Stock','CurrentDate',
     'CGap','PercHL','LCFib','LCLevel','MaxHL','MaxHLClr','MaxHLIdx']]

SData.groupby([
            'Index'])[['Stock']].count().sort_values(by="Stock",ascending=False).head(7)

t1=SData.groupby([
            'Index'])[['Stock']].count().sort_values(by="Stock",ascending=False).head(7).index
SData[SData.Index.isin(t1)].groupby(['Index','Type'])['Index'].count()

#SData[SData['Index']==6][['Stock','CurrentDate','Type','DiffP','PDiffP','CFD']]
tindex=13
SData[SData['Index']==tindex][['Stock','CurrentDate',
     'Type','DiffP','PDiffP','CFD']].groupby('Type')['DiffP','PDiffP'].count()

SData[(SData['Index']==tindex) & (SData['Type']=="High")][['Stock','CurrentDate',
     'CGap','PercHL','HCFib','HCLevel','MaxHL','MaxHLClr','MaxHLIdx','DiffP','PDiffP']]

SData[(SData['Index']==tindex) & (SData['Type']=="Low")][['Stock','CurrentDate',
     'CGap','PercHL','LCFib','LCLevel','MaxHL','MaxHLClr','MaxHLIdx','DiffP','PDiffP']]

SData.loc[524][['Stock','CurrentDate','CFD','DiffP','PDiffP']]
SData.loc[4643][['Stock','CurrentDate','BuyProfitP','SellProfitP','BuyProfitP1','SellProfitP1','CFD','DiffP','PDiffP']]


t[t['Index']==6][['Stock','CurrentDate','Type','DiffP','PDiffP','CFD']]

SData[['Stock','CurrentDate']]
z=FinalCheckResults[FinalCheckResults.duplicated(['Stock','CDATE'],keep="last")]
y= z[z['Seq']==True]

FinalCheckResults.drop_duplicates(subset =["Stock","CDATE","Seq"], keep = "first", inplace = True) 
a=FinalCheckResults[10:20]
b=FinalCheckResults[20:30]

y.groupby([
            'G'])['BuyProfitP','SellProfitP','BuyProfitP1','SellProfitP1'].sum()

y[y['Index']<40].groupby([
            'CDATE'])['BuyProfitP','SellProfitP','BuyProfitP1','SellProfitP1'].sum()

y[y['Index']>40].groupby([
            'G'])['BuyProfitP','SellProfitP','BuyProfitP1','SellProfitP1'].sum()


FinalCheckResults[ (FinalCheckResults['CFD']>0.2) 
                & (FinalCheckResults['CFD']<0.5)].groupby([
            'CDATE'])['BuyProfitP','SellProfitP','BuyProfitP1','SellProfitP1'].sum()


FinalCheckResults[ (FinalCheckResults['Type']=="High") &
        (FinalCheckResults['CFD']>0.6) 
                & (FinalCheckResults['CFD']<1.5)].groupby([
            'HCFib','CDATE'])['BuyProfitP','SellProfitP','BuyProfitP1','SellProfitP1'].sum()
                
FinalCheckResults[(FinalCheckResults['Seq']==True) & (FinalCheckResults['CFD']>0.2) & (FinalCheckResults['CFD']<0.5)].groupby([
            'G'])['BuyProfitP','SellProfitP','BuyProfitP1','SellProfitP1'].sum()


FinalCheckResults[(FinalCheckResults['CFD']>0.9) & (FinalCheckResults['CFD']<1)].groupby([
            'G'])['BuyProfitP','SellProfitP','BuyProfitP1','SellProfitP1'].sum()

a.groupby([
            'G'])['BuyProfitP','SellProfitP','BuyProfitP1','SellProfitP1'].sum()

a[a['Index']<30].groupby([
            'G'])['BuyProfitP','SellProfitP','BuyProfitP1','SellProfitP1'].sum()
a[a['Index']>30].groupby([
            'G'])['BuyProfitP','SellProfitP','BuyProfitP1','SellProfitP1'].sum()

b.groupby([
            'G'])['BuyProfitP','SellProfitP','BuyProfitP1','SellProfitP1'].sum()

b[ (b['CFD']>0.2) 
                & (b['CFD']<0.5)].groupby([
            'G'])['BuyProfitP','SellProfitP','BuyProfitP1','SellProfitP1'].sum()
a[ (a['CFD']>0.2) 
                & (a['CFD']<0.5)].groupby([
            'G'])['BuyProfitP','SellProfitP','BuyProfitP1','SellProfitP1'].sum()



b[b['Index']<40].groupby([
            'G'])['BuyProfitP','SellProfitP','BuyProfitP1','SellProfitP1'].sum()
   