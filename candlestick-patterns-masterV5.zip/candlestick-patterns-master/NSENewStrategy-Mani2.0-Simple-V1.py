# -*- coding: utf-8 -*-
"""
Created on Fri Nov 22 08:56:39 2019

@author: lalitha
"""
from candlestick import candlestick
import datetime
import pandas as pd
import json
import time
from dateutil.parser import parse
pd.set_option('display.max_columns', 500)
pd.set_option('display.max_rows', 1500)


def isPeak(arr, n, num, i, j): 

	# If num is smaller than the element 
	# on the left (if exists) 
	if (i >= 0 and arr[i] > num): 
		return False

	# If num is smaller than the element 
	# on the right (if exists) 
	if (j < n and arr[j] > num): 
		return False
	return True

# Function that returns true if num is 
# smaller than both arr[i] and arr[j] 
def isTrough(arr, n, num, i, j): 

	# If num is greater than the element 
	# on the left (if exists) 
	if (i >= 0 and arr[i] < num): 
		return False

	# If num is greater than the element 
	# on the right (if exists) 
	if (j < n and arr[j] < num): 
		return False
	return True

def printPeaksTroughs(arr, n): 

	print("Peaks : ", end = "") 

	# For every element 
	for i in range(n): 

		# If the current element is a peak 
		if (isPeak(arr, n, arr[i], i - 1, i + 1)): 
			print(arr[i], end = " ") 
	print() 

	print("Troughs : ", end = "") 

	# For every element 
	for i in range(n): 

		# If the current element is a trough 
		if (isTrough(arr, n, arr[i], i - 1, i + 1)): 
			print(arr[i], end = " ") 



def Process(iPercentage,ioffset):    
    ResultAr=[]
    p=-1
    while(p<len(StockList)-1):
        p=p+1
        #print(StockList.iloc[p]['Symbol'])
        Symbol=StockList.iloc[p]['Symbol']
        Data=DataFrameCollection[StockList.iloc[p]['Symbol']].fillna(0)
        LastPivot=pd.read_csv(r"C:\ReadMoneycontrol\Mani 2.0\Data3\\"+Symbol+"-Pivot.csv",encoding='utf-8')
        PivotD=LastPivot.iloc[DateIndex*-1]
        i=0
        Percentage=iPercentage
        offset=ioffset
        T=round(Data.iloc[0]['Open']*Percentage,2)
        HighList=[]
        LowList=[]
        
        
        while(i<len(Data)):
            ResultSt={}
            H=Data.iloc[i]['High']
            L=Data.iloc[i]['Low']
            #H=Data['High'].max()
            #L=Data['Low'].max()
        #PivotD
            RangeList=getChartRangeList(H,L,PivotD)
                
            
            for R in RangeList:
                #R="A1000"
                if( H==PivotD[R]):
                    #print(R+" High Same" + Data.iloc[i]['Date'])
                    HighList.append(i)
                elif( H+T>=PivotD[R]>=H-T):
                    #print(str(i)+ "==> "+ R+" High Approx " + Data.iloc[i]['Date'] +" - "+ str(H+T) + " = " + str(PivotD[R]) + " = "+ str(H-T))
                    HighList.append(i)
                if( L==PivotD[R]):
                    #print(R+" Low Same" + Data.iloc[i]['Date'])
                    LowList.append(i)
                elif( L+T>=PivotD[R]>=L-T):
                    #print(str(i)+ "==> "+ R+" Low Approx " + Data.iloc[i]['Date'] +" - "+ str(L+T) + " = " + str(PivotD[R]) + " = "+ str(L-T))
                    LowList.append(i)    
            
            if(str(HighList).find(str(i-offset)+"")>0):
                a=isPeak(Data['High'][:i], len(Data['High'][:i]), Data.iloc[i-offset]['High'], i-(offset*2), i)
                if(a):
                    Diff=round(Data.iloc[i-offset]['High']-Data.iloc[i]['High'],2)
                    DiffP=round(Diff/Data.iloc[i]['High']*100,2)
                    PDiff=round(Data.iloc[i-(offset*2)]['High']-Data.iloc[i-offset]['High'],2)
                    PDiffP=round(PDiff/Data.iloc[i-offset]['High']*100,2)
                    #print(str(i)+ " - " + Data.iloc[i]['Date'] + " HIGH - " +Data.iloc[i-offset]['Date'] + " - " + str(a) + " - " + str(Diff) + " ~ " + str(DiffP));                    
                    ResultSt['Stock']=Symbol
                    ResultSt['Index']=i
                    ResultSt['CurrentDate']=Data.iloc[i]['Date']
                    ResultSt['Type']='High'
                    ResultSt['SingleDate']=Data.iloc[i-offset]['Date']
                    ResultSt['Diff']=Diff
                    ResultSt['DiffP']=DiffP
                    ResultSt['PDiff']=PDiff
                    ResultSt['PDiffP']=PDiffP
                    
                    
                    ResultSt['PercHL']=round((Data.iloc[:i]['High'].max()-Data.iloc[i-offset]['High']+0.00001)/Data.iloc[i-offset]['High']*100,2)
                    H,L,C,O=list(Data.iloc[i-offset][['High',"Low","Close","Open"]])
                    ResultSt['HLC']=round((H-C)/C*100,2)
                    ResultSt['HL']=round((H-L)/L*100,2)
                    ResultSt['OC']=round((O-C)/C*100,2)
                    ResultSt['G']=O>C
                    ResultAr.append(ResultSt)
            if(str(LowList).find(str(i-offset)+"")>0):
                Trough=isTrough(Data['Low'][:i], len(Data['Low'][:i]), Data.iloc[i-offset]['Low'], i-(offset*2), i-1)
                if(Trough):
                    Diff=round(Data.iloc[i-offset]['Low']-Data.iloc[i]['Low'],2)
                    DiffP=round(Diff/Data.iloc[i]['Low']*100,2)
                    PDiff=round(Data.iloc[i-(offset*2)]['Low']-Data.iloc[i-offset]['Low'],2)
                    PDiffP=round(PDiff/Data.iloc[i-offset]['Low']*100,2)
                    #print(str(i)+ " - "+Data.iloc[i]['Date'] + " Low - " +Data.iloc[i-offset]['Date'] + " - " + str(Trough)+ " - " + str(Diff) + " ~ " + str(DiffP));    
                    ResultSt['Stock']=Symbol
                    ResultSt['Index']=i
                    ResultSt['CurrentDate']=Data.iloc[i]['Date']
                    ResultSt['Type']='Low'
                    ResultSt['SingleDate']=Data.iloc[i-offset]['Date']
                    ResultSt['Diff']=Diff
                    ResultSt['DiffP']=DiffP
                    ResultSt['PDiff']=PDiff
                    ResultSt['PDiffP']=PDiffP
                    ResultSt['PercHL']=round((Data.iloc[:i]['Low'].min()-Data.iloc[i-offset]['Low']+0.00001)/Data.iloc[i-offset]['Low']*100,2)
                    H,L,C,O=list(Data.iloc[i-offset][['High',"Low","Close","Open"]])
                    ResultSt['HLC']=round((L-C)/C*100,2)
                    ResultSt['HL']=round((H-L)/L*100,2)
                    ResultSt['OC']=round((O-C)/C*100,2)
                    ResultSt['G']=O>C
                    ResultAr.append(ResultSt)
            i=i+1
    
    ResultDF=pd.DataFrame(ResultAr)
    return ResultDF


def getHighDF(ResultDF):
    return ResultDF[(ResultDF['Type']=="High") & (ResultDF['DiffP']>0.1) & (ResultDF['PDiffP']<-0.1) & (ResultDF['PercHL']>-0.1) & (ResultDF['PercHL']<0.1) &(ResultDF['G']==False) ][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL']]

def getLowDF(ResultDF):
    return ResultDF[(ResultDF['Type']=="Low") & (ResultDF['DiffP']<-0.1) & (ResultDF['PDiffP']>0.1) & ((ResultDF['PercHL']>-0.1) & (ResultDF['PercHL']<0.1)) &(ResultDF['G']==True) ][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL']]


NiftyDay=pd.read_csv(r"C:\ReadMoneycontrol\Mani 2.0\Data\NIFTY50-day.csv")
DateIndex=4
StockList=pd.read_csv("C:\ReadMoneycontrol\Mani 2.0\StockList.txt")
DateIndex=5

minute="5minute"
DataFrameCollection={}
if(DateIndex<len(NiftyDay)-1):
#while(DateIndex<len(NiftyDay)-1):
    StartDate=NiftyDay.iloc[(DateIndex)*-1]['Date']
    if(DateIndex!=1):
        EndDate=NiftyDay.iloc[(DateIndex-1)*-1]['Date']
    else:
        EndDate=candlestick.N1(parse(StartDate),"1D","+").strftime("%Y-%m-%d")
    Nifty=pd.read_csv(r"C:\ReadMoneycontrol\Mani 2.0\Data\NIFTY50-"+minute+".csv")
    Nifty.columns=['Date', 'Open', 'High', 'Low', 'Close', 'V']
    NiftyD=Nifty[(Nifty['Date']>StartDate) & (Nifty['Date']<EndDate)]
    DataFrameCollection['NIFTY']=NiftyD
    DataFrameCollection['NIFTY'].sort_values('Date',inplace=True)
    DataFrameCollection['NIFTY'].drop_duplicates(subset ="Date", keep = "first", inplace = True) 
    DataFrameCollection['NIFTY'].reset_index(inplace=True,drop=True)
    #DataFrameCollection['NIFTY'][']
    DataFrameCollection['NIFTY']['HLC']=(DataFrameCollection['NIFTY']['High']+DataFrameCollection['NIFTY']['Low']+DataFrameCollection['NIFTY']['Close'])/3
    Comparison={}
    Comparison["NIFTY"]=list(NiftyD['Open'])
    ki=0
    while(ki<len(StockList)): #len(StockList)
        StockName=StockList.iloc[ki]['Symbol']
        ki=ki+1
        print(StockName)
        Stockdf=pd.read_csv(r"C:\ReadMoneycontrol\Mani 2.0\Data\\"+StockName+"-"+minute+".csv")
        Stockdf.columns=['Date', 'Open', 'High', 'Low', 'Close', 'V']
        StockD=Stockdf[(Stockdf['Date']>StartDate) & (Stockdf['Date']<EndDate)]
        DataFrameCollection[StockName]=StockD
        DataFrameCollection[StockName].sort_values('Date',inplace=True)
        DataFrameCollection[StockName].drop_duplicates(subset ="Date", keep = "first", inplace = True) 

        DataFrameCollection[StockName].reset_index(inplace=True,drop=True)
        DataFrameCollection[StockName]['HLC']=(DataFrameCollection[StockName]['High']+DataFrameCollection[StockName]['Low']+DataFrameCollection[StockName]['Close'])/3
        Comparison[StockName]=list(StockD['Open'])
        
        
        
#ids = df["ID"]
#df[ids.isin(ids[ids.duplicated()])].sort("ID")
ResultAr=[]
TInterval=['3minute','5minute','15minute']
PercentageAr=[0.0002,round(0.0002/3*5,4),round(0.0002/3*15,4)]
OffsetAr=[5,4,2]
iP=PercentageAr[TInterval.index(minute)]
iO=OffsetAr[TInterval.index(minute)]



ResultDF5=Process(iP,iO)
ResultDF3=Process(iP,3)
ResultDF7=Process(iP,7)
TR=ResultDF7[(ResultDF7['PDiffP']<-0.1) & (ResultDF7['PercHL']>-0.1)].reset_index()
TR=ResultDF7[(ResultDF7['DiffP']>-0.1) & (ResultDF7['PDiffP']<0.1)].reset_index()

TR=ResultDF7[(ResultDF7['DiffP']<0.1) & (ResultDF7['PDiffP']<-0.1) & (ResultDF7['HLC']!=ResultDF7['OC'])][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]
TR[TR.duplicated(['Stock','SingleDate'])][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]


TR=ResultDF5[(ResultDF5['DiffP']>-0.1) & (ResultDF5['PDiffP']<-0.4)][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]
TR[TR.duplicated(['Stock','SingleDate'])][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]


#Default No results1
TR=ResultDF5[(ResultDF5['DiffP']>-0.1) & (ResultDF5['PDiffP']<-0.1)][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]
TR[TR.duplicated(['Stock','SingleDate'])][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]

#Resul 2
TR=ResultDF5[(ResultDF5['DiffP']>-0.1) & (ResultDF5['PDiffP']>0.1)][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]
TR[TR.duplicated(['Stock','SingleDate'])][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]

#Resul 3
TR=ResultDF5[(ResultDF5['DiffP']>-0.1) & (ResultDF5['PDiffP']>-0.1) & (ResultDF5['PDiffP'] != ResultDF5['OC'])][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]
TR[TR.duplicated(['Stock','SingleDate'])][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]

#Resul 4
TR=ResultDF5[(ResultDF5['DiffP']>-0.1) & (ResultDF5['PDiffP']<0.1) & (ResultDF5['PDiffP'] != ResultDF5['OC'])][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]
TR[TR.duplicated(['Stock','SingleDate'])][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]



#Default No results1
TR=ResultDF5[(ResultDF5['DiffP']>0.1) & (ResultDF5['PDiffP']<-0.1)][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]
TR[TR.duplicated(['Stock','SingleDate'])][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]

#Resul 2
TR=ResultDF5[(ResultDF5['DiffP']>0.1) & (ResultDF5['PDiffP']>0.1)][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]
TR[TR.duplicated(['Stock','SingleDate'])][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]

#Resul 3
TR=ResultDF5[(ResultDF5['DiffP']>0.1) & (ResultDF5['PDiffP']>-0.1)][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]
TR[TR.duplicated(['Stock','SingleDate'])][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]

#Resul 4
TR=ResultDF5[(ResultDF5['DiffP']>0.1) & (ResultDF5['PDiffP']<0.1)][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]
TR[TR.duplicated(['Stock','SingleDate'])][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]




#Default No results1
TR=ResultDF5[(ResultDF5['DiffP']<0.1) & (ResultDF5['PDiffP']<-0.1)][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]
TR[TR.duplicated(['Stock','SingleDate'])][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]

#Resul 2
TR=ResultDF5[(ResultDF5['DiffP']<0.1) & (ResultDF5['PDiffP']>0.1)][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]
TR[TR.duplicated(['Stock','SingleDate'])][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]

#Resul 3
TR=ResultDF5[(ResultDF5['DiffP']<0.1) & (ResultDF5['PDiffP']>-0.1)][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]
TR[TR.duplicated(['Stock','SingleDate'])][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]

#Resul 4
TR=ResultDF5[(ResultDF5['DiffP']<0.1) & (ResultDF5['PDiffP']<0.1)][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]
TR[TR.duplicated(['Stock','SingleDate'])][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]




#Default No results1
TR=ResultDF5[(ResultDF5['DiffP']<-0.1) & (ResultDF5['PDiffP']<-0.1)][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]
TR[TR.duplicated(['Stock','SingleDate'])][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]

#Resul 2
TR=ResultDF5[(ResultDF5['DiffP']<-0.1) & (ResultDF5['PDiffP']>0.1)][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]
TR[TR.duplicated(['Stock','SingleDate'])][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]

#Resul 3
TR=ResultDF5[(ResultDF5['DiffP']<-0.1) & (ResultDF5['PDiffP']>-0.1)][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]
TR[TR.duplicated(['Stock','SingleDate'])][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]

#Resul 4
TR=ResultDF5[(ResultDF5['DiffP']<-0.1) & (ResultDF5['PDiffP']<0.1)][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]
TR[TR.duplicated(['Stock','SingleDate'])][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]


#Results Up Trend
TR=ResultDF5[(ResultDF5['HLC']!=ResultDF5['OC']) & (ResultDF5['DiffP']<-0.1) & (ResultDF5['PDiffP']>0.1)][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]
TR[TR.duplicated(['Stock','SingleDate'])][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]
TR[TR['Stock']=="ADANIPORTS"][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]
#Default -- end
#Down Trend
TR=ResultDF5[(ResultDF5['HLC']!=ResultDF5['OC']) & (ResultDF5['DiffP']<0.1) & (ResultDF5['PDiffP']<-0.1)][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]
TR[TR.duplicated(['Stock','SingleDate'])][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]
##Results ......... UP trend
TR=ResultDF5[(ResultDF5['HLC']!=ResultDF5['OC']) & (ResultDF5['DiffP']<0.1) & (ResultDF5['PDiffP']>-0.1)][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]
TR[TR.duplicated(['Stock','SingleDate'])][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]


#########################
####Results Up Trend
TR=ResultDF5[(ResultDF5['HLC']!=ResultDF5['OC']) & (ResultDF5['DiffP']<-0.1) & (ResultDF5['PDiffP']>-0.1)][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]
TR[TR.duplicated(['Stock','SingleDate'])][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]
#Default -- end
#Down Trend
TR=ResultDF5[(ResultDF5['HLC']!=ResultDF5['OC']) & (ResultDF5['DiffP']>0.1) & (ResultDF5['PDiffP']<-1)][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]
TR[TR.duplicated(['Stock','SingleDate'])][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]


##Results ......... Down trend
TR=ResultDF5[(ResultDF5['HLC']!=ResultDF5['OC']) & (ResultDF5['DiffP']<0.1) & (ResultDF5['PDiffP']<-1)][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]
TR[TR.duplicated(['Stock','SingleDate'])][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]
#################
###Up Trend
TR=ResultDF5[(ResultDF5['HLC']!=ResultDF5['OC']) & (ResultDF5['DiffP']>-0.1) & (ResultDF5['PDiffP']>1)][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]
TR[TR.duplicated(['Stock','SingleDate'])][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]
##Results ......... UP trend
TR=ResultDF5[(ResultDF5['HLC']!=ResultDF5['OC']) & (ResultDF5['DiffP']<-0.1) & (ResultDF5['PDiffP']>1)][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]
TR[TR.duplicated(['Stock','SingleDate'])][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]

#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


#Default High
TR=ResultDF3[(ResultDF7['HLC']!=ResultDF7['OC']) &(ResultDF3['DiffP']>0.1) & (ResultDF3['PDiffP']<-0.1)][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]
TR[TR.duplicated(['Stock','SingleDate'])][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]

#result Up trend
TR=ResultDF3[(ResultDF7['HLC']!=ResultDF7['OC']) & (ResultDF3['DiffP']<-0.1) & (ResultDF3['PDiffP']>0.1)][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]
TR[TR.duplicated(['Stock','SingleDate'])][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]

#result Down trend
TR=ResultDF3[ (ResultDF7['HLC']!=ResultDF7['OC']) & (ResultDF3['DiffP']<0.1) & (ResultDF3['PDiffP']<-0.1)][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]
TR[TR.duplicated(['Stock','SingleDate'])][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]




TR=ResultDF3[(ResultDF3['DiffP']<-0.1) & (ResultDF3['PDiffP']>0.1)].reset_index()
TR=ResultDF7[(ResultDF7['DiffP']<-0.1) & (ResultDF7['PDiffP']>0.1)].reset_index()

TR=ResultDF5
TR[TR.duplicated(['Stock','SingleDate'])][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]

ResultDF5H=getHighDF(ResultDF5)
ResultDF5L=getLowDF(ResultDF5)

ResultDF7H=getHighDF(ResultDF7)
ResultDF7L=getLowDF(ResultDF7)

ResultDF3H=getHighDF(ResultDF3)
ResultDF3L=getLowDF(ResultDF3)