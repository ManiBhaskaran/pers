# -*- coding: utf-8 -*-
"""
Created on Fri Jan 24 22:29:17 2020

@author: lalitha
"""

import os
import pandas as pd
import matplotlib.pyplot as plt
#import plotly.io as pio
import numpy as np

def MParseDate(Date):
    ts = (np.datetime64(pd.to_datetime(Date)) - np.datetime64('1970-01-01T00:00:00Z')) / np.timedelta64(1, 's')
    return N1(N1(datetime.utcfromtimestamp(ts),'5H',"+"),"30M","+")
seconds_per_unit = {"S": 1, "M": 60, "H": 3600, "D": 86400, "W": 604800}
def N1(date,s,Operation):
    if (Operation=="+"):
        return date+timedelta(seconds=int(s[:-1]) * seconds_per_unit[s[-1]])
    else:
        return date-timedelta(seconds=int(s[:-1]) * seconds_per_unit[s[-1]])

if(False):
    StrTimeIntervals=['minute','3minute','5minute','15minute','day']
    i=0
    while(i<len(StockList)):
        #StockName=StockList.iloc[i]['Symbol']
        StockName=StockList.iloc[i]['StockName']
        #StockName=StockList.iloc[i]['StockName']
#        StockDay=pd.read_csv(DataDir+r"\Data\\"+StockName+'-day.csv')
        #StockDay[StockDay['Date']==StockDay.iloc[len(StockDay)-1]['Date']].to_csv("C:\ReadMoneycontrol\Mani 2.0\Data\\"+StockName+'-LASTREADDAY.csv',index=False)
        for TimeInterval in StrTimeIntervals:    
            DeltaDay=pd.read_csv(r"C:\ReadMoneycontrol\Mani 2.0\NEWDataIncr1\Data\\"+StockName+'-'+TimeInterval+'.csv')        
            DeltaDay['Date']=pd.to_datetime(DeltaDay.Date)
            DeltaDay['Date']=N1(DeltaDay['Date'],"330M","+")
            #Delta=DeltaDay[DeltaDay['Date']>N1(parse(StockDay.iloc[len(StockDay)-1]['Date']),"1D","+").strftime("%Y-%m-%d")  ]
            if(TimeInterval=="day"):
                DeltaDay['Date']=pd.to_datetime(DeltaDay['Date']).dt.strftime("%Y-%m-%d")            
                #Delta=DeltaDay[DeltaDay['Date']>StockDay.iloc[len(StockDay)-1]['Date'] ]
            #DeltaDay['Date'].strftime("%Y-%m-%d")        
            #N1(parse(StockDay.iloc[len(StockDay)-1]['Date']),"1D","+").strftime("%Y-%m-%d")  
            
            DeltaDay.to_csv(r"C:\ReadMoneycontrol\Mani 2.0\NEWDataIncr1\Data\\"+StockName+'-'+TimeInterval+'.csv',header=True,index=False)
            #DeltaDay.to_csv(DataDir+r"\incr2\\"+StockName+'-'+TimeInterval+'.csv',mode='a',header=True,index=False)
        i=i+1
    

StockList=pd.read_csv("C:\ReadMoneycontrol\Mani 2.0\StockListID-NEWList.csv")
Day=15
First=True
i=0
while(i<len(StockList)):
    StockName=StockList.iloc[i]['StockName']
    FilePath=""
    #if(os.path.exists("C:\ReadMoneycontrol\Mani 2.0\Temp3\Corrected\\"+StockName+'AllStock.csv')==True):
    #    FilePath="C:\ReadMoneycontrol\Mani 2.0\Temp3\Corrected\\"+StockName+'AllStock.csv'
    if(os.path.exists("C:\ReadMoneycontrol\Mani 2.0\GapUp-ZTemp\\"+StockName+'AllStock.csv')==True):
        FilePath="C:\ReadMoneycontrol\Mani 2.0\GapUp-ZTemp\\"+StockName+'AllStock.csv'
    if(FilePath!=""):
        #print(StockName)
        Temp=pd.read_csv(FilePath)[-25*Day:][:26]   
        if(First):
            Data=Temp
        else:
            Data=Data.append(Temp)
    First=False
    i=i+1
        
Data['PDAYCLOSEDIFF']=round((Data['PDayClose']-Data['Close'].shift(1))/Data['Close'].shift(1)*100,2)
Data['GAPDIFF']=round((Data['Open']-Data['PDayClose'])/Data['PDayClose']*100,2)
        
i=0
StockUp=[]
StockDown=[]
while(i<len(StockList)):
    StockName=StockList.iloc[i]['StockName']
    SBIN5Min=Data[Data['Stock']==StockName]
    #SBIN5MinT=SBIN5Min[['Indx','SMA-C-10','SMA-C-21','Open','SMA-C-150']]
#    StockUPGapDown=SBIN5Min[     (
#            (SBIN5Min['Open']<SBIN5Min['SMA-C-150']) &
#            (SBIN5Min['Open'].shift(1)>SBIN5Min['SMA-C-150'].shift(1)) &
#            (SBIN5Min['Indx']==0) &
#            (SBIN5Min['PDayClose']>SBIN5Min['Open']) &
#            ((SBIN5Min['PDayClose']-SBIN5Min['Open'])/SBIN5Min['Open']*100>1)
#        )]
    
    StockUPGapDown1=SBIN5Min[     (
        (SBIN5Min['SMA-C-10'].shift(1)>SBIN5Min['SMA-C-21'].shift(1)) &
        (SBIN5Min['SMA-C-10'].shift(2)>SBIN5Min['SMA-C-21'].shift(2)) &
        (SBIN5Min['SMA-C-10'].shift(3)>SBIN5Min['SMA-C-21'].shift(3)) &
        (SBIN5Min['SMA-C-10'].shift(4)>SBIN5Min['SMA-C-21'].shift(4)) &
        (SBIN5Min['SMA-C-10'].shift(5)>SBIN5Min['SMA-C-21'].shift(5)) &
        (SBIN5Min['SMA-C-10'].shift(6)>SBIN5Min['SMA-C-21'].shift(6)) &
        (SBIN5Min['SMA-C-10'].shift(7)>SBIN5Min['SMA-C-21'].shift(7)) &
        (SBIN5Min['SMA-C-10'].shift(8)>SBIN5Min['SMA-C-21'].shift(8)) &
        (SBIN5Min['SMA-C-10'].shift(9)>SBIN5Min['SMA-C-21'].shift(9)) &
        (SBIN5Min['Indx']==24) 
        & (SBIN5Min['Open']>SBIN5Min['SMA-C-150']) 
        ) ]
    if(len(StockUPGapDown1)>0):
        StockUp.append(StockName)
    StockDownGapUP1=SBIN5Min[     ( 
    (SBIN5Min['SMA-C-10'].shift(1)<SBIN5Min['SMA-C-21'].shift(1)) &
        (SBIN5Min['SMA-C-10'].shift(2)<SBIN5Min['SMA-C-21'].shift(2)) &
        (SBIN5Min['SMA-C-10'].shift(3)<SBIN5Min['SMA-C-21'].shift(3)) &
        (SBIN5Min['SMA-C-10'].shift(4)<SBIN5Min['SMA-C-21'].shift(4)) &
        (SBIN5Min['SMA-C-10'].shift(5)<SBIN5Min['SMA-C-21'].shift(5)) &
        (SBIN5Min['SMA-C-10'].shift(6)<SBIN5Min['SMA-C-21'].shift(6)) &
        (SBIN5Min['SMA-C-10'].shift(7)<SBIN5Min['SMA-C-21'].shift(7)) &
        (SBIN5Min['SMA-C-10'].shift(8)<SBIN5Min['SMA-C-21'].shift(8)) &
        (SBIN5Min['SMA-C-10'].shift(9)<SBIN5Min['SMA-C-21'].shift(9)) &
        (SBIN5Min['Indx']==24) 
        & (SBIN5Min['Open']<SBIN5Min['SMA-C-150']) 
        ) ]
    
    if(len(StockDownGapUP1)>0):
        StockDown.append(StockName)
    i=i+1

i=0
First=True
while(i<len(StockUp)):
    
    SBIN5Min=Data[Data['Stock']==StockUp[i]][-2:]
    T2=(SBIN5Min['Open']>SBIN5Min['SMA-O-150'])[-1:].iloc[0]     
    T3=(SBIN5Min['High'].shift(1)<SBIN5Min['SMA-O-150'].shift(1))[-1:].iloc[0]
    T=round((SBIN5Min['Open']-SBIN5Min['PDayClose'])/SBIN5Min['PDayClose']*100,2)[-1:].iloc[0]
    PDAYCLOSEDIFF=SBIN5Min['PDAYCLOSEDIFF'][-1:].iloc[0]     
    if( (T<-.5) | (PDAYCLOSEDIFF>.5) | (PDAYCLOSEDIFF<-.5)):
        #print(StockUp[i])
        #print(SBIN5Min[['Stock','Indx','Open','Close','PDayClose','PDAYCLOSEDIFF','GAPDIFF']][-1:])
        if(First):
            SUP=SBIN5Min[-1:]
        else:
            SUP=SUP.append(SBIN5Min[-1:])
        First=False
    i=i+1
print(SBIN5Min['Date'])    
SUP[['Stock','Indx','Open','Close','PDayClose','PDAYCLOSEDIFF','GAPDIFF']].sort_values('PDAYCLOSEDIFF',ascending=False)
i=0
First=True
while(i<len(StockDown)):
    SBIN5Min=Data[Data['Stock']==StockDown[i]][-2:]
    #SBIN5Min=Data[Data['Stock']=="CEATLTD"][-2:]
    T2=(SBIN5Min['Open']<SBIN5Min['SMA-O-150'])[-1:].iloc[0]     
    T3=(SBIN5Min['High'].shift(1)>SBIN5Min['SMA-O-150'].shift(1))[-1:].iloc[0]
    PDAYCLOSEDIFF=SBIN5Min['PDAYCLOSEDIFF'][-1:].iloc[0]
    T=round((SBIN5Min['Open']-SBIN5Min['PDayClose'])/SBIN5Min['PDayClose']*100,2)[-1:].iloc[0]
    if((T>1)| (PDAYCLOSEDIFF>.5) | (PDAYCLOSEDIFF<-.5) ):#& T2 & T3
        #print(StockDown[i])
        if(First):
            SD=SBIN5Min[-1:]
        else:
            SD=SD.append(SBIN5Min[-1:])
        First=False
        
    i=i+1

SD[['Stock','Indx','Open','Close','PDayClose','PDAYCLOSEDIFF','GAPDIFF']].sort_values('PDAYCLOSEDIFF',ascending=False)
    #SBIN5MinT=SBIN5Min[['Indx','SMA-C-10','SMA-C-21','Open','SMA-C-150']]