# -*- coding: utf-8 -*-
"""
Created on Sun Nov 24 23:34:02 2019

@author: lalitha
"""

#ProcessY(iP,iO,Min5DF,pop,"TCS")  
iPercentage=iP
ioffset=iO
DataFrameCollection=Min5DF
Symbol="TCS"
def ProcessY(iPercentage,ioffset,DataFrameCollection,y,Symbol1):    
    global dd
    ResultAr=[]
    p=-1
    while(p<len(StockList)-1):
    #if(True):
        p=p+1
        #print(StockList.iloc[p]['Symbol'])
        Symbol=StockList.iloc[p]['Symbol']
        #Data1=DataFrameCollection[Symbol].fillna(0)
        Data1=DataFrameCollection[StockList.iloc[p]['Symbol']].fillna(0)
        dd=Data1
        LastPivot=pd.read_csv(r"C:\ReadMoneycontrol\Mani 2.0\Data3\\"+Symbol+"-Pivot.csv",encoding='utf-8')
        PivotD=LastPivot.iloc[DateIndex*-1]
        i=0
        Percentage=iPercentage
        offset=ioffset
        T=round(Data1.iloc[0]['Open']*Percentage,2)
        HighList=[]
        HighRList=[]
        LowList=[]
        LowRList=[]
        
        while(i<len(Data1)):
            Data=DataFrameCollection[Symbol].fillna(0)[:i+1]
            ResultSt={}
            #print
            H=Data.iloc[i]['High']
            L=Data.iloc[i]['Low']
            #H=Data['High'].max()
            #L=Data['Low'].max()
        #PivotD
            RangeList=getChartRangeList(H,L,PivotD)
                
            
            for R in RangeList:
                #R="A1000"
                if( H==PivotD[R]):
                    #print(R+" High Same" + Data.iloc[i]['Date'])
                    HighList.append(i)
                    HighRList.append(R)
                if( H+T>=PivotD[R]>=H-T):
                    #print(str(i)+ "==> "+ R+" High Approx " + Data.iloc[i]['Date'] +" - "+ str(H+T) + " = " + str(PivotD[R]) + " = "+ str(H-T))
                    HighList.append(i)
                    HighRList.append(R)
                if( L==PivotD[R]):
                    #print(R+" Low Same" + Data.iloc[i]['Date'])
                    LowList.append(i)
                    LowRList.append(R)
                if( L+T>=PivotD[R]>=L-T):
                    #print(str(i)+ "==> "+ R+" Low Approx " + Data.iloc[i]['Date'] +" - "+ str(L+T) + " = " + str(PivotD[R]) + " = "+ str(L-T))
                    LowList.append(i)    
                    LowRList.append(R)
            
            if(str(HighList).find(str(i-offset)+"")>0):
                a=isPeak(Data['High'][:i], len(Data['High'][:i]), Data.iloc[i-offset]['High'], i-(offset*2), i)
                if(a):
                    ResultSt={}
                    Diff=round(Data.iloc[i-offset]['High']-Data.iloc[i]['High'],2)
                    DiffP=round(Diff/Data.iloc[i]['High']*100,2)
                    PDiff=round(Data.iloc[i-(offset*2)]['High']-Data.iloc[i-offset]['High'],2)
                    PDiffP=round(PDiff/Data.iloc[i-offset]['High']*100,2)
                    #print(str(i)+ " - " + Data.iloc[i]['Date'] + " HIGH - " +Data.iloc[i-offset]['Date'] + " - " + str(a) + " - " + str(Diff) + " ~ " + str(DiffP));                    
                    ResultSt['Stock']=Symbol
                    ResultSt['Index']=i
                    ResultSt['CurrentDate']=Data.iloc[i]['Date']
                    ResultSt['Type']='High'
                    ResultSt['SingleDate']=Data.iloc[i-offset]['Date']
                    ResultSt['Diff']=Diff
                    ResultSt['DiffP']=DiffP
                    ResultSt['PDiff']=PDiff
                    ResultSt['PDiffP']=PDiffP
                    #ResultSt['Range']
                    
                    ResultSt['PercHL']=round((Data.iloc[:i]['High'].max()-Data.iloc[i-offset]['High']+0.00001)/Data.iloc[i-offset]['High']*100,2)
                    H,L,C,O=list(Data.iloc[i-offset][['High',"Low","Close","Open"]])
                    ResultSt['HLC']=round((H-C)/C*100,2)
                    ResultSt['HL']=round((H-L)/L*100,2)
                    ResultSt['OC']=round((O-C)/C*100,2)
                    ResultSt['G']=O>C
                    ResultAr.append(ResultSt)
            if(str(LowList).find(str(i-offset)+"")>0):
                Trough=isTrough(Data['Low'][:i], len(Data['Low'][:i]), Data.iloc[i-offset]['Low'], i-(offset*2), i-1)
                if(Trough):
                    ResultSt={}
                    #print(Symbol+"\ti="+str(i) + "\t"+str(i-offset)+"\t"+ str(i-(offset*2)))
                    Diff=round(Data.iloc[i-offset]['Low']-Data.iloc[i]['Low'],2)
                    DiffP=round(Diff/Data.iloc[i]['Low']*100,2)
                    PDiff=round(Data.iloc[i-(offset*2)]['Low']-Data.iloc[i-offset]['Low'],2)
                    PDiffP=round(PDiff/Data.iloc[i-offset]['Low']*100,2)
                    #print(str(i)+ " - "+Data.iloc[i]['Date'] + " Low - " +Data.iloc[i-offset]['Date'] + " - " + str(Trough)+ " - " + str(Diff) + " ~ " + str(DiffP));    
                    ResultSt['Stock']=Symbol
                    ResultSt['Index']=i
                    ResultSt['CurrentDate']=Data.iloc[i]['Date']
                    ResultSt['Type']='Low'
                    ResultSt['SingleDate']=Data.iloc[i-offset]['Date']
                    ResultSt['Diff']=Diff
                    ResultSt['DiffP']=DiffP
                    ResultSt['PDiff']=PDiff
                    ResultSt['PDiffP']=PDiffP
                    ResultSt['PercHL']=round((Data.iloc[:i]['Low'].min()-Data.iloc[i-offset]['Low']+0.00001)/Data.iloc[i-offset]['Low']*100,2)
                    H,L,C,O=list(Data.iloc[i-offset][['High',"Low","Close","Open"]])
                    ResultSt['HLC']=round((L-C)/C*100,2)
                    ResultSt['HL']=round((H-L)/L*100,2)
                    ResultSt['OC']=round((O-C)/C*100,2)
                    ResultSt['G']=O>C
                    ResultAr.append(ResultSt)
            i=i+1
    
    ResultDF=pd.DataFrame(ResultAr)
    return ResultDF

pop=5
while(pop<40):
    pop=pop+1
    print(pop)
    ResultDF05=ProcessY(iP,iO,Min5DF,pop,"TCS")  
    ResultDF5=ResultDF05
    TR=ResultDF5
    TR[TR.duplicated(['Stock','SingleDate'])][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]
    
    #Up Trend on duplicates
    TR=ResultDF5[(ResultDF5['HLC']!=ResultDF5['OC']) & (ResultDF5['DiffP']<-0.1) & (ResultDF5['PDiffP']>.5)]
    #[['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]
    print(TR[['Stock',
            'CurrentDate','SingleDate','PDiffP','DiffP','HL', 'HLC','OC', 'PercHL','Index','Type']])
    
    
    
    
    #Looks Up Trend
    TR=ResultDF5[(ResultDF5['HLC']!=ResultDF5['OC']) & (ResultDF5['DiffP']>-0.1) & (ResultDF5['PDiffP']>.5)]
    print(TR[['Stock',
            'CurrentDate','SingleDate','PDiffP','DiffP','HL', 'HLC','OC', 'PercHL','G','Type']])
    #TR[TR.duplicated(['Stock','SingleDate'])]
    
    #Down Trend when type is high
    print(ResultDF5[(ResultDF5['HLC']!=ResultDF5['OC']) & (ResultDF5['DiffP']>0.1) 
          & (ResultDF5['PDiffP']<-.5)][['Stock',
        'CurrentDate','SingleDate','PDiffP','DiffP','HL', 'HLC','OC', 'PercHL','G','Type']])
    
    TR=ResultDF5[(ResultDF5['HLC']!=ResultDF5['OC']) & (ResultDF5['DiffP']<0.1) & (ResultDF5['PDiffP']<-.5)]
    print(TR[['Stock',
        'CurrentDate','SingleDate','PDiffP','DiffP','HL', 'HLC','OC', 'PercHL','G','Type']])

    
    
Data=Min5DF['TCS'][:6]
i=5
isTrough(Data['Low'][:i], len(Data['Low'][:i]), Data.iloc[i-offset]['Low'], i-(offset*2), i-1)

LastPivot=pd.read_csv(r"C:\ReadMoneycontrol\Mani 2.0\Data3\\"+"TCS"+"-Pivot.csv",encoding='utf-8')
PivotD=LastPivot.iloc[DateIndex*-1]

def isTrough1(arr, n, num, i, j): 

	# If num is greater than the element 
	# on the left (if exists) 
    print(arr)
    print(n)
    print(num)
    print(i)
    print(j)
    #print(arr[i])
    #print(arr[j])
    if (i >= 0 and arr[i] < num): 
        print("FFF")
        return False

	# If num is greater than the element 
	# on the right (if exists) 
    if (j < n and arr[j] < num): 
        print("FFFdddd")
        return False
    return True

