# -*- coding: utf-8 -*-
"""
Created on Sat Jan 11 16:02:25 2020

@author: lalitha
"""
import os
import pandas as pd
import matplotlib.pyplot as plt
#import plotly.io as pio
import numpy as np
#i=0
#while(i<len(StockList)):
#    StockName=StockList.iloc[i]['StockName']
#    #StockDay=pd.read_csv("C:\ReadMoneycontrol\Mani 2.0\Data\\"+StockName+'-day.csv')   
#    if(os.path.exists("C:\ReadMoneycontrol\Mani 2.0\Temp3\Corrected\\"+StockName+'AllStock.csv')==True):
#        print(StockName)
#    i=i+1
BankStock=["FEDERALBNK","ICICIBANK","IDFCFIRSTB","SBIN","YESBANK","INDUSINDBK","HDFCBANK","AXISBANK","PNB","BANKBARODA","RBLBANK","KOTAKBANK"]    
AllStock=0
SBIN5Min=pd.read_csv("C:\ReadMoneycontrol\Mani 2.0\Temp3\SBINAllStock.csv")
Filter=SBIN5Min[     (
        (SBIN5Min['SMA-C-10'].shift(1)<SBIN5Min['SMA-C-21'].shift(1)) &
        (SBIN5Min['SMA-C-10'].shift(2)<SBIN5Min['SMA-C-21'].shift(2)) &
        (SBIN5Min['SMA-C-10'].shift(3)<SBIN5Min['SMA-C-21'].shift(3)) &
        (SBIN5Min['SMA-C-10'].shift(4)<SBIN5Min['SMA-C-21'].shift(4)) &
        (SBIN5Min['SMA-C-10'].shift(5)<SBIN5Min['SMA-C-21'].shift(5)) &
        (SBIN5Min['SMA-C-10'].shift(6)<SBIN5Min['SMA-C-21'].shift(6)) &
        (SBIN5Min['SMA-C-10'].shift(7)<SBIN5Min['SMA-C-21'].shift(7)) &
        (SBIN5Min['SMA-C-10'].shift(8)<SBIN5Min['SMA-C-21'].shift(8)) &
        (SBIN5Min['SMA-C-10'].shift(9)<SBIN5Min['SMA-C-21'].shift(9)) &
#        (SBIN5Min['Open']>SBIN5Min['SMA-C-150']) &
#        (SBIN5Min['Open'].shift(1)<SBIN5Min['SMA-C-150'].shift(1)) &
        
        (SBIN5Min['Indx']==0) &
        (SBIN5Min['PDayClose']<SBIN5Min['Open']) &
        ((SBIN5Min['Open']-SBIN5Min['PDayClose'])/SBIN5Min['PDayClose']*100>1)
    )][['Date','Stock','HighFib','Open','H4', 'H3A', 'H3', 'H2A', 'H2','H1', 'IPivot-H', 'IPivot', 'IPivot-L','L1', 'L2', 'L2A', 'L3', 'L3A', 'L4','RH1_R', 'RH2A_R', 'RH2_R', 'RH3A_R', 'RH3_R', 'RH4_R', 'RIP-H_R', 'RIP-L_R', 'RIPivot_R', 'RL1_R', 'RL2A_R', 'RL2_R', 'RL3A_R', 'RL3_R', 'RL4_R']]


Filterb=SBIN5Min[     (
        (SBIN5Min['SMA-C-10'].shift(1)>SBIN5Min['SMA-C-21'].shift(1)) &
        (SBIN5Min['SMA-C-10'].shift(2)>SBIN5Min['SMA-C-21'].shift(2)) &
        (SBIN5Min['SMA-C-10'].shift(3)>SBIN5Min['SMA-C-21'].shift(3)) &
        (SBIN5Min['SMA-C-10'].shift(4)>SBIN5Min['SMA-C-21'].shift(4)) &
        (SBIN5Min['SMA-C-10'].shift(5)>SBIN5Min['SMA-C-21'].shift(5)) &
        (SBIN5Min['SMA-C-10'].shift(6)>SBIN5Min['SMA-C-21'].shift(6)) &
        (SBIN5Min['SMA-C-10'].shift(7)>SBIN5Min['SMA-C-21'].shift(7)) &
        (SBIN5Min['SMA-C-10'].shift(8)>SBIN5Min['SMA-C-21'].shift(8)) &
        (SBIN5Min['SMA-C-10'].shift(9)>SBIN5Min['SMA-C-21'].shift(9)) &
        
        (SBIN5Min['Indx']==0) &
        (SBIN5Min['PDayClose']>SBIN5Min['Open']) &
        ((SBIN5Min['PDayClose']-SBIN5Min['Open'])/SBIN5Min['Open']*100>1)
    )][['Date','Stock','HighFib','Open','H4', 'H3A', 'H3', 'H2A', 'H2','H1', 'IPivot-H', 'IPivot', 'IPivot-L','L1', 'L2', 'L2A', 'L3', 'L3A', 'L4','RH1_R', 'RH2A_R', 'RH2_R', 'RH3A_R', 'RH3_R', 'RH4_R', 'RIP-H_R', 'RIP-L_R', 'RIPivot_R', 'RL1_R', 'RL2A_R', 'RL2_R', 'RL3A_R', 'RL3_R', 'RL4_R']]





First=True
i=0
while(i<len(StockList)):
    StockName=StockList.iloc[i]['StockName']
    FilePath=""
    #if(os.path.exists("C:\ReadMoneycontrol\Mani 2.0\Temp3\Corrected\\"+StockName+'AllStock.csv')==True):
    #    FilePath="C:\ReadMoneycontrol\Mani 2.0\Temp3\Corrected\\"+StockName+'AllStock.csv'
    if(os.path.exists("C:\ReadMoneycontrol\Mani 2.0\Temp3\\"+StockName+'AllStock.csv')==True):
        FilePath="C:\ReadMoneycontrol\Mani 2.0\Temp3\\"+StockName+'AllStock.csv'
        FilePath1="C:\ReadMoneycontrol\Mani 2.0\Temp3\\"+StockName+'Filtered.csv'
        FilteredStock=pd.read_csv(FilePath1)
    if(FilePath!=""):
        #print(StockName)
        SBIN5Min=pd.read_csv(FilePath)   
        FilteredStock=pd.read_csv(FilePath1)   
    
        StockDownGapUP=SBIN5Min[     (
            (SBIN5Min['Open']>SBIN5Min['SMA-C-150']) &
            (SBIN5Min['High'].shift(1)<SBIN5Min['SMA-C-150'].shift(1)) &
            #(SBIN5Min['Open'].shift(1)<SBIN5Min['SMA-C-150'].shift(1)) &
            #(SBIN5Min['Open'].shift(2)<SBIN5Min['SMA-C-150'].shift(2)) &
            
    #        (SBIN5Min['Indx']==0) &
            (SBIN5Min['PDayClose']<SBIN5Min['DayOpen']) &
            ((SBIN5Min['DayOpen']-SBIN5Min['PDayClose'])/SBIN5Min['PDayClose']*100>1)
        )]
    #[['Date','Stock','Indx','HighFib','Open','H4', 'H3A', 'H3', 'H2A', 'H2','H1', 'IPivot-H', 'IPivot', 'IPivot-L','L1', 'L2', 'L2A', 'L3', 'L3A', 'L4','RH1_R', 'RH2A_R', 'RH2_R', 'RH3A_R', 'RH3_R', 'RH4_R', 'RIP-H_R', 'RIP-L_R', 'RIPivot_R', 'RL1_R', 'RL2A_R', 'RL2_R', 'RL3A_R', 'RL3_R', 'RL4_R']]
    
    
        StockUPGapDown=SBIN5Min[     (
            (SBIN5Min['Open']<SBIN5Min['SMA-C-150']) &
            (SBIN5Min['Open'].shift(1)>SBIN5Min['SMA-C-150'].shift(1)) &
            (SBIN5Min['Indx']==0) &
            (SBIN5Min['PDayClose']>SBIN5Min['Open']) &
            ((SBIN5Min['PDayClose']-SBIN5Min['Open'])/SBIN5Min['Open']*100>1)
        )]
    
        StockDownGapUP1=SBIN5Min[     (
        (SBIN5Min['SMA-C-10'].shift(1)<SBIN5Min['SMA-C-21'].shift(1)) &
        (SBIN5Min['SMA-C-10'].shift(2)<SBIN5Min['SMA-C-21'].shift(2)) &
        (SBIN5Min['SMA-C-10'].shift(3)<SBIN5Min['SMA-C-21'].shift(3)) &
        (SBIN5Min['SMA-C-10'].shift(4)<SBIN5Min['SMA-C-21'].shift(4)) &
        (SBIN5Min['SMA-C-10'].shift(5)<SBIN5Min['SMA-C-21'].shift(5)) &
        (SBIN5Min['SMA-C-10'].shift(6)<SBIN5Min['SMA-C-21'].shift(6)) &
        (SBIN5Min['SMA-C-10'].shift(7)<SBIN5Min['SMA-C-21'].shift(7)) &
        (SBIN5Min['SMA-C-10'].shift(8)<SBIN5Min['SMA-C-21'].shift(8)) &
        (SBIN5Min['SMA-C-10'].shift(9)<SBIN5Min['SMA-C-21'].shift(9)) &
#        (SBIN5Min['Open']>SBIN5Min['SMA-C-150']) &
#        (SBIN5Min['Open'].shift(1)<SBIN5Min['SMA-C-150'].shift(1)) &
#        
        (SBIN5Min['Indx']==0) &
        (SBIN5Min['PDayClose']<SBIN5Min['Open']) &
        ((SBIN5Min['Open']-SBIN5Min['PDayClose'])/SBIN5Min['PDayClose']*100>1)
    )][['Date','Stock','HighFib','Open','H4', 'H3A', 'H3', 'H2A', 'H2','H1', 'IPivot-H', 'IPivot', 'IPivot-L','L1', 'L2', 'L2A', 'L3', 'L3A', 'L4','RH1_R', 'RH2A_R', 'RH2_R', 'RH3A_R', 'RH3_R', 'RH4_R', 'RIP-H_R', 'RIP-L_R', 'RIPivot_R', 'RL1_R', 'RL2A_R', 'RL2_R', 'RL3A_R', 'RL3_R', 'RL4_R']]


        StockUPGapDown1=SBIN5Min[     (
        (SBIN5Min['SMA-C-10'].shift(1)>SBIN5Min['SMA-C-21'].shift(1)) &
        (SBIN5Min['SMA-C-10'].shift(2)>SBIN5Min['SMA-C-21'].shift(2)) &
        (SBIN5Min['SMA-C-10'].shift(3)>SBIN5Min['SMA-C-21'].shift(3)) &
        (SBIN5Min['SMA-C-10'].shift(4)>SBIN5Min['SMA-C-21'].shift(4)) &
        (SBIN5Min['SMA-C-10'].shift(5)>SBIN5Min['SMA-C-21'].shift(5)) &
        (SBIN5Min['SMA-C-10'].shift(6)>SBIN5Min['SMA-C-21'].shift(6)) &
        (SBIN5Min['SMA-C-10'].shift(7)>SBIN5Min['SMA-C-21'].shift(7)) &
        (SBIN5Min['SMA-C-10'].shift(8)>SBIN5Min['SMA-C-21'].shift(8)) &
        (SBIN5Min['SMA-C-10'].shift(9)>SBIN5Min['SMA-C-21'].shift(9)) &
        
        (SBIN5Min['Indx']==0) &
        (SBIN5Min['PDayClose']>SBIN5Min['Open']) &
        ((SBIN5Min['PDayClose']-SBIN5Min['Open'])/SBIN5Min['Open']*100>1)
    )][['Date','Stock','HighFib','Open','H4', 'H3A', 'H3', 'H2A', 'H2','H1', 'IPivot-H', 'IPivot', 'IPivot-L','L1', 'L2', 'L2A', 'L3', 'L3A', 'L4','RH1_R', 'RH2A_R', 'RH2_R', 'RH3A_R', 'RH3_R', 'RH4_R', 'RIP-H_R', 'RIP-L_R', 'RIPivot_R', 'RL1_R', 'RL2A_R', 'RL2_R', 'RL3A_R', 'RL3_R', 'RL4_R']]


    
        if(First):
            ConsolidatedStockDownGapUP=StockDownGapUP
            ConsolidatedStockUPGapDown=StockUPGapDown
            ConsolidatedStockDownGapUP1=StockDownGapUP1
            ConsolidatedStockUPGapDown1=StockUPGapDown1
            FilteredStock.to_csv("C:\ReadMoneycontrol\Mani 2.0\Temp3\Report1\AllFilteredStock.csv",sep=',',encoding='utf-8',index=False)    
            First=False
        else:
            ConsolidatedStockDownGapUP=ConsolidatedStockDownGapUP.append(StockDownGapUP)
            ConsolidatedStockUPGapDown=ConsolidatedStockUPGapDown.append(StockUPGapDown)        
            ConsolidatedStockDownGapUP1=ConsolidatedStockDownGapUP.append(StockDownGapUP1)
            ConsolidatedStockUPGapDown1=ConsolidatedStockUPGapDown.append(StockUPGapDown1)        
            FilteredStock.to_csv("C:\ReadMoneycontrol\Mani 2.0\Temp3\Report1\AllFilteredStock.csv",sep=',',encoding='utf-8',index=False,mode='a',header=False)    
    #[['Date','Stock','HighFib','Open','H4', 'H3A', 'H3', 'H2A', 'H2','H1', 'IPivot-H', 'IPivot', 'IPivot-L','L1', 'L2', 'L2A', 'L3', 'L3A', 'L4','RH1_R', 'RH2A_R', 'RH2_R', 'RH3A_R', 'RH3_R', 'RH4_R', 'RIP-H_R', 'RIP-L_R', 'RIPivot_R', 'RL1_R', 'RL2A_R', 'RL2_R', 'RL3A_R', 'RL3_R', 'RL4_R']]
#    if(First):
#        FilteredStock.to_csv("C:\ReadMoneycontrol\Mani 2.0\Temp3\Report1\AllFilteredStock.csv",sep=',',encoding='utf-8',index=False)    
#        First=False
#    else:
#        FilteredStock.to_csv("C:\ReadMoneycontrol\Mani 2.0\Temp3\Report1\AllFilteredStock.csv",sep=',',encoding='utf-8',index=False,mode='a',header=False)    
#        
    i=i+1


#ConsolidatedStockDownGapUP.to_csv("C:\ReadMoneycontrol\Mani 2.0\Temp3\Report1\ConsolidatedStockDownGapUP.csv",sep=',',encoding='utf-8',index=False)
#ConsolidatedStockUPGapDown.to_csv("C:\ReadMoneycontrol\Mani 2.0\Temp3\Report1\ConsolidatedStockUPGapDown.csv",sep=',',encoding='utf-8',index=False)
#ConsolidatedStockDownGapUP1.to_csv("C:\ReadMoneycontrol\Mani 2.0\Temp3\Report1\ConsolidatedStockDownGapUP1.csv",sep=',',encoding='utf-8',index=False)
#ConsolidatedStockUPGapDown1.to_csv("C:\ReadMoneycontrol\Mani 2.0\Temp3\Report1\ConsolidatedStockUPGapDown1.csv",sep=',',encoding='utf-8',index=False)
#


AllFilteredStock=pd.read_csv("C:\ReadMoneycontrol\Mani 2.0\Temp3\Report1\AllFilteredStock.csv")

AllFilteredStock['Signal']=AllFilteredStock.apply(lambda x: CheckPrice(x,"Sell"),axis=1)
TTemp=AllFilteredStock[AllFilteredStock['Signal']!="H4"]
TTemp['SignalR']=TTemp.apply(lambda x: CheckPriceDepth1(x,"Sell"),axis=1)
TTemp.to_csv("C:\ReadMoneycontrol\Mani 2.0\Temp3\Report1\AllFilteredStock.csv",sep=',',encoding='utf-8',index=False)    
Temp=TTemp[['Date','Stock','Signal','SignalQ',
        'Open','High','Low','CDayHigh','CDayLow','H4', 'H3A', 'H3', 'H2A', 'H2','H1', 'IPivot-H', 'IPivot', 'IPivot-L','L1', 'L2', 'L2A', 'L3', 'L3A', 'L4','RH1_R', 'RH2A_R', 'RH2_R', 'RH3A_R', 'RH3_R', 'RH4_R', 'RIP-H_R', 'RIP-L_R', 'RIPivot_R', 'RL1_R', 'RL2A_R', 'RL2_R', 'RL3A_R', 'RL3_R', 'RL4_R']]
TTemp.groupby('Signal')['Signal'].count()
TTemp.groupby('SignalR')['SignalR'].count()
TTemp['SignalBuyPL']=TTemp.apply(lambda x: CheckSellPL(x,"Buy"),axis=1)
TTemp['SignalSellPL']=TTemp.apply(lambda x: CheckSellPL(x,"Sell"),axis=1)
Res=TTemp.groupby(['Signal','SignalBuyPL'])['Signal','SignalBuyPL'].count()
Temp2=TTemp.drop_duplicates(subset =["Stock","CDATE"], keep = "first", inplace = False) 

T=Temp2.groupby('SignalR')['SignalR'].count().reset_index(name='count').sort_values(['count'],ascending=False)
T['Count']
Temp2['SignalBuyPL']=Temp2.apply(lambda x: CheckSellPL(x,"Buy"),axis=1)
Temp2['SignalSellPL']=Temp2.apply(lambda x: CheckSellPL(x,"Sell"),axis=1)

Temp2[Temp2['SignalR']==T.SignalR.iloc[0]].groupby(['Signal','SignalBuyPL'])['Signal','SignalBuyPL'].count()

T1=Temp2[Temp2['SignalR']==T.SignalR.iloc[0]][['Date','CDATE','Stock','Signal','SignalQ','SignalBuyPL',
        'Open','High','Low','Close','CDayHigh','CDayLow','H4', 'H3A', 'H3', 'H2A', 'H2','H1', 'IPivot-H', 'IPivot', 'IPivot-L','L1', 'L2', 'L2A', 'L3', 'L3A', 'L4','RH1_R', 'RH2A_R', 'RH2_R', 'RH3A_R', 'RH3_R', 'RH4_R', 'RIP-H_R', 'RIP-L_R', 'RIPivot_R', 'RL1_R', 'RL2A_R', 'RL2_R', 'RL3A_R', 'RL3_R', 'RL4_R']]
T1['HP']=T1['Close']<T1['IPivot-H']
T2=T1[['Date','CDATE','Stock','Signal','SignalQ','HP','SignalBuyPL',
        'Open','High','Low','Close','CDayHigh','CDayLow','H4', 'H3A', 'H3', 'H2A', 'H2','H1', 'IPivot-H', 'IPivot', 'IPivot-L','L1', 'L2', 'L2A', 'L3', 'L3A', 'L4','RH1_R', 'RH2A_R', 'RH2_R', 'RH3A_R', 'RH3_R', 'RH4_R', 'RIP-H_R', 'RIP-L_R', 'RIPivot_R', 'RL1_R', 'RL2A_R', 'RL2_R', 'RL3A_R', 'RL3_R', 'RL4_R']]
T2.groupby(['HP','SignalBuyPL'])['HP','SignalBuyPL'].count()
Res.plot.bar()

def CheckPrice(Df,Field):
    if(Df['Open']>Df['IPivot']):
        if(Df['Open']<Df['IPivot-H']):
            return "IPivot"
        elif(Df['Open']<Df['H1']):
            return "IP-H"
        elif(Df['Open']<Df['H2']):
            return "H1"
        elif(Df['Open']<Df['H2A']):
            return "H2"
        elif(Df['Open']<Df['H3']):
            return "H2A"    
        elif(Df['Open']<Df['H3A']):
            return "H3"    
        elif(Df['Open']<Df['H4']):
            return "H3A"    
        else:
            return "H4"    
    else:
        if(Df['Open']>Df['IPivot-L']):
            return "IP-L"
        elif(Df['Open']>Df['L1']):
            return "L1"
        elif(Df['Open']>Df['L2']):
            return "L2"
        elif(Df['Open']>Df['L2A']):
            return "L2A"
        elif(Df['Open']>Df['L3']):
            return "L3"
        elif(Df['Open']>Df['L3A']):
            return "L3A"
        elif(Df['Open']>Df['L4']):
            return "L4"
        else:
            return "L4A"

R_List=['RH4_R','RH4_R','RH3A_R','RH3_R','RH2A_R','RH2_R','RH1_R','RIP-H_R', 'RIPivot_R',
         'RIP-L_R','RL1_R', 'RL2_R','RL2A_R', 'RL3_R','RL3A_R','RL4_R']
Signal="RL4A_R"

def CheckSellPL(Df,Trans):    
    
    Signal="R"+Df['Signal']+"_R"    
    
    #print(Signal)
    if(str(R_List).find(Signal)==-1):
        return -2000 #not in the list    
    if((R_List.index(Signal)!=len(R_List)-1)& (R_List.index(Signal)!=0) ):
        if(Trans=="Buy"):
            StopLoss=R_List[R_List.index(Signal)+1]
            Target=R_List[R_List.index(Signal)-1]
            UpList=R_List[:R_List.index(Signal)-1]
            DownList=R_List[R_List.index(Signal)+1:]
        else:
            Target=R_List[R_List.index(Signal)+1]
            TargetStr=Target.replace("R","").replace("_","")
            if(TargetStr=="IP-H"):
                TargetStr="IPivot-H"
            if(TargetStr=="IP-L"):
                TargetStr="IPivot-L"
            StopLoss=R_List[R_List.index(Signal)-1]
            StopLossStr=StopLoss.replace("R","").replace("_","")
            if(StopLossStr=="IP-H"):
                StopLossStr="IPivot-H"
            if(StopLossStr=="IP-L"):
                StopLossStr="IPivot-L"
            if((Df[StopLossStr]-Df['Open'])<(Df['Open']-Df[TargetStr])):
                StopLoss=R_List[R_List.index(Signal)-2
                                ]
            DownList=R_List[:R_List.index(Signal)-1]
            UpList=R_List[R_List.index(Signal)+1:]
        if(Df[StopLoss]==-1): 
            if(Df[Target]!=-1):
                return 100 #Profit
            else:
                Found=False
                for Levels in UpList:
                    if(Df[Levels]!=-1):
                        Found=True
                if(Found):
                    return 200#Skipped profit
                else:
                    Found=False
                    for Levels in DownList:
                        if(Df[Levels]!=-1):
                            Found=True                    
                    if(Found):
                        return -20#Skipped Loss
                    else:
                        return -100#No Pofit and loss
        else:           
            if(Df[Target]==-1):
                return -10   #Actual Loss           
            elif(Df[Target]<Df[StopLoss]):
                return 1   #Profit         
            else:
                return -1 # No Loss/Profit
    else:
        return -1000


ConsolidatedStockUPGapDown1=pd.read_csv("C:\ReadMoneycontrol\Mani 2.0\Temp3\Report\ConsolidatedStockUPGapDown1.csv")

ConsolidatedStockUPGapDown1['H-P']=round((ConsolidatedStockUPGapDown1['H1']-ConsolidatedStockUPGapDown1['IPivot']+0.00001)/ConsolidatedStockUPGapDown1['IPivot']*100,2)
ConsolidatedStockUPGapDown1['P-L']=round((ConsolidatedStockUPGapDown1['IPivot']-ConsolidatedStockUPGapDown1['L1']+0.00001)/ConsolidatedStockUPGapDown1['L1']*100,2)
ConsolidatedStockUPGapDown1['HPR']=ConsolidatedStockUPGapDown1['H-P']>ConsolidatedStockUPGapDown1['P-L']
ConsolidatedStockUPGapDown1['H2-H1']=round((ConsolidatedStockUPGapDown1['H2']-ConsolidatedStockUPGapDown1['H1']+0.00001)/ConsolidatedStockUPGapDown1['H1']*100,2)
ConsolidatedStockUPGapDown1['L1-L2']=round((ConsolidatedStockUPGapDown1['L1']-ConsolidatedStockUPGapDown1['L2']+0.00001)/ConsolidatedStockUPGapDown1['L2']*100,2)
ConsolidatedStockUPGapDown1['R2R']=ConsolidatedStockUPGapDown1['H2-H1']>ConsolidatedStockUPGapDown1['L1-L2']

ConsolidatedStockUPGapDown1['OpenFib']=round((ConsolidatedStockUPGapDown1['Open']-ConsolidatedStockUPGapDown1['PDayLow'])*1000/ConsolidatedStockUPGapDown1['HL'])
ConsolidatedStockUPGapDown1['Signal']=ConsolidatedStockUPGapDown1.apply(lambda x: CheckPrice(x,"Buy"),axis=1)   
ConsolidatedStockUPGapDown1['SignalPL']=ConsolidatedStockUPGapDown1.apply(lambda x: CheckSellPL(x,"Buy"),axis=1)
ConsolidatedStockUPGapDown1['SignalR']=np.select(
        [ConsolidatedStockUPGapDown1['SignalPL']>0,ConsolidatedStockUPGapDown1['SignalPL']<0],
        [1,-1],
        0)
ConsolidatedStockUPGapDown1.groupby(['Signal','HPR','SignalR']).size().unstack(fill_value=0).plot.bar()

StockUPGapDown1=ConsolidatedStockUPGapDown1[ConsolidatedStockUPGapDown1['Signal']!="LL2"][['Date','Stock','Signal','SignalR','SignalPL','HighFib','Open','H4', 'H3A', 'H3', 'H2A', 'H2','H1', 'IPivot-H', 'IPivot', 'IPivot-L','L1', 'L2', 'L2A', 'L3', 'L3A', 'L4','RH1_R', 'RH2A_R', 'RH2_R', 'RH3A_R', 'RH3_R', 'RH4_R', 'RIP-H_R', 'RIP-L_R', 'RIPivot_R', 'RL1_R', 'RL2A_R', 'RL2_R', 'RL3A_R', 'RL3_R', 'RL4_R']]
StockUPGapDown1.groupby('SignalPL')['SignalPL'].count()
StockUPGapDown1.groupby(['Date','SignalR']).size().unstack(fill_value=0).plot.bar()
ConsolidatedStockUPGapDown1.groupby('Signal')['Signal'].count()





ConsolidatedStockUPGapDown=pd.read_csv("C:\ReadMoneycontrol\Mani 2.0\Temp3\Report\ConsolidatedStockUPGapDown.csv")

ConsolidatedStockUPGapDown['H-P']=round((ConsolidatedStockUPGapDown['H1']-ConsolidatedStockUPGapDown['IPivot']+0.00001)/ConsolidatedStockUPGapDown['IPivot']*100,2)
ConsolidatedStockUPGapDown['P-L']=round((ConsolidatedStockUPGapDown['IPivot']-ConsolidatedStockUPGapDown['L1']+0.00001)/ConsolidatedStockUPGapDown['L1']*100,2)
ConsolidatedStockUPGapDown['HPR']=ConsolidatedStockUPGapDown['H-P']>ConsolidatedStockUPGapDown['P-L']
ConsolidatedStockUPGapDown['H2-H1']=round((ConsolidatedStockUPGapDown['H2']-ConsolidatedStockUPGapDown['H1']+0.00001)/ConsolidatedStockUPGapDown['H1']*100,2)
ConsolidatedStockUPGapDown['L1-L2']=round((ConsolidatedStockUPGapDown['L1']-ConsolidatedStockUPGapDown['L2']+0.00001)/ConsolidatedStockUPGapDown['L2']*100,2)
ConsolidatedStockUPGapDown['R2R']=ConsolidatedStockUPGapDown['H2-H1']>ConsolidatedStockUPGapDown['L1-L2']

ConsolidatedStockUPGapDown['OpenFib']=round((ConsolidatedStockUPGapDown['Open']-ConsolidatedStockUPGapDown['PDayLow'])*1000/ConsolidatedStockUPGapDown['HL'])
ConsolidatedStockUPGapDown['Signal']=ConsolidatedStockUPGapDown.apply(lambda x: CheckPrice(x,"Buy"),axis=1)   
ConsolidatedStockUPGapDown['SignalPL']=ConsolidatedStockUPGapDown.apply(lambda x: CheckSellPL(x,"Buy"),axis=1)
ConsolidatedStockUPGapDown['SignalR']=np.select(
        [ConsolidatedStockUPGapDown['SignalPL']>0,ConsolidatedStockUPGapDown['SignalPL']<0],
        [1,-1],
        0)
ConsolidatedStockUPGapDown.groupby(['Signal','HPR','SignalR']).size().unstack(fill_value=0).plot.bar()

StockUPGapDown=ConsolidatedStockUPGapDown[ConsolidatedStockUPGapDown['Signal']!="LL2"][['Date','Stock','Signal','SignalR','SignalPL','HighFib','Open','H4', 'H3A', 'H3', 'H2A', 'H2','H1', 'IPivot-H', 'IPivot', 'IPivot-L','L1', 'L2', 'L2A', 'L3', 'L3A', 'L4','RH1_R', 'RH2A_R', 'RH2_R', 'RH3A_R', 'RH3_R', 'RH4_R', 'RIP-H_R', 'RIP-L_R', 'RIPivot_R', 'RL1_R', 'RL2A_R', 'RL2_R', 'RL3A_R', 'RL3_R', 'RL4_R']]
StockUPGapDown.groupby('SignalPL')['SignalPL'].count()
StockUPGapDown.groupby(['Date','SignalR']).size().unstack(fill_value=0).plot.bar()
ConsolidatedStockUPGapDown.groupby('Signal')['Signal'].count()

ConsolidatedStockUPGapDown.append(ConsolidatedStockUPGapDown1)
#ConsolidatedStockUPGapDown.merge(ConsolidatedStockUPGapDown1,indicator=True)
T=pd.concat([ConsolidatedStockUPGapDown,ConsolidatedStockUPGapDown1]).drop_duplicates(keep=False)

ConsolidatedStockDownGapUP1=pd.read_csv("C:\ReadMoneycontrol\Mani 2.0\Temp3\Report\ConsolidatedStockDownGapUP1.csv")
ConsolidatedStockDownGapUP1['H-P']=round((ConsolidatedStockDownGapUP1['H1']-ConsolidatedStockDownGapUP1['IPivot']+0.00001)/ConsolidatedStockDownGapUP1['IPivot']*100,2)
ConsolidatedStockDownGapUP1['P-L']=round((ConsolidatedStockDownGapUP1['IPivot']-ConsolidatedStockDownGapUP1['L1']+0.00001)/ConsolidatedStockDownGapUP1['L1']*100,2)
ConsolidatedStockDownGapUP1['HPR']=ConsolidatedStockDownGapUP1['H-P']>ConsolidatedStockDownGapUP1['P-L']
ConsolidatedStockDownGapUP1['H2-H1']=round((ConsolidatedStockDownGapUP1['H2']-ConsolidatedStockDownGapUP1['H1']+0.00001)/ConsolidatedStockDownGapUP1['H1']*100,2)
ConsolidatedStockDownGapUP1['L1-L2']=round((ConsolidatedStockDownGapUP1['L1']-ConsolidatedStockDownGapUP1['L2']+0.00001)/ConsolidatedStockDownGapUP1['L2']*100,2)
ConsolidatedStockDownGapUP1['R2R']=ConsolidatedStockDownGapUP1['H2-H1']>ConsolidatedStockDownGapUP1['L1-L2']

ConsolidatedStockDownGapUP1['OpenFib']=round((ConsolidatedStockDownGapUP1['Open']-ConsolidatedStockDownGapUP1['PDayLow'])*1000/ConsolidatedStockDownGapUP1['HL'])
ConsolidatedStockDownGapUP1['Signal']=ConsolidatedStockDownGapUP1.apply(lambda x: CheckPrice(x,"Sell"),axis=1)
ConsolidatedStockDownGapUP1['SignalPL']=ConsolidatedStockDownGapUP1.apply(lambda x: CheckSellPL(x,"Sell"),axis=1)

ConsolidatedStockDownGapUP1['SignalR']=np.select(
        [ConsolidatedStockDownGapUP1['SignalPL']>0,ConsolidatedStockDownGapUP1['SignalPL']<0],
        [1,-1],
        0)
        
ConsolidatedStockDownGapUP1.groupby('Signal')['Signal'].count()
SignalStr="IP-H"
Value={}
Value['IP-H']=1000
Value['H1']=1500
Value['IPivot']=786
StockDownGapUP1_Buy=ConsolidatedStockDownGapUP1[
        (ConsolidatedStockDownGapUP1['Signal']==SignalStr) & 
        (ConsolidatedStockDownGapUP1['OpenFib']>Value[SignalStr]) ][['Date','Stock','SignalR','Signal','H-P','P-L','HPR',
        'H2-H1','L1-L2','R2R','SignalPL','OpenFib','HighFib','Open','H4', 'H3A', 'H3', 'H2A', 'H2','H1', 'IPivot-H', 'IPivot', 'IPivot-L','L1', 'L2', 'L2A', 'L3', 'L3A', 'L4','RH1_R', 'RH2A_R', 'RH2_R', 'RH3A_R', 'RH3_R', 'RH4_R', 'RIP-H_R', 'RIP-L_R', 'RIPivot_R', 'RL1_R', 'RL2A_R', 'RL2_R', 'RL3A_R', 'RL3_R', 'RL4_R']]
StockDownGapUP1_Buy.groupby('SignalPL')['SignalPL'].count()

StockDownGapUP1_Buy1=ConsolidatedStockDownGapUP1[
        (ConsolidatedStockDownGapUP1['Signal']==SignalStr) & 
        (ConsolidatedStockDownGapUP1['HPR']==True) & 
        (ConsolidatedStockDownGapUP1['OpenFib']<=Value[SignalStr]) ][['Date','Stock','SignalR','Signal','H-P','P-L','HPR',
        'H2-H1','L1-L2','R2R','SignalPL','OpenFib','HighFib','Open','H4', 'H3A', 'H3', 'H2A', 'H2','H1', 'IPivot-H', 'IPivot', 'IPivot-L','L1', 'L2', 'L2A', 'L3', 'L3A', 'L4','RH1_R', 'RH2A_R', 'RH2_R', 'RH3A_R', 'RH3_R', 'RH4_R', 'RIP-H_R', 'RIP-L_R', 'RIPivot_R', 'RL1_R', 'RL2A_R', 'RL2_R', 'RL3A_R', 'RL3_R', 'RL4_R']]
StockDownGapUP1_Buy1.groupby('SignalPL')['SignalPL'].count()

StockDownGapUP1_Sell=ConsolidatedStockDownGapUP1[
        (ConsolidatedStockDownGapUP1['Signal']==SignalStr) & 
        (ConsolidatedStockDownGapUP1['HPR']==False) & 
        (ConsolidatedStockDownGapUP1['OpenFib']<=Value[SignalStr]) ][['Date','Stock','SignalR','Signal','H-P','P-L','HPR',
        'H2-H1','L1-L2','R2R','SignalPL','OpenFib','HighFib','Open','H4', 'H3A', 'H3', 'H2A', 'H2','H1', 'IPivot-H', 'IPivot', 'IPivot-L','L1', 'L2', 'L2A', 'L3', 'L3A', 'L4','RH1_R', 'RH2A_R', 'RH2_R', 'RH3A_R', 'RH3_R', 'RH4_R', 'RIP-H_R', 'RIP-L_R', 'RIPivot_R', 'RL1_R', 'RL2A_R', 'RL2_R', 'RL3A_R', 'RL3_R', 'RL4_R']]
StockDownGapUP1_Sell.groupby('SignalPL')['SignalPL'].count()

StockDownGapUP2_Buy=ConsolidatedStockDownGapUP1[
        (ConsolidatedStockDownGapUP1['Signal']==SignalStr)  
        #& (ConsolidatedStockDownGapUP1['OpenFib']>1000) 
        ][['Date','Stock','Signal','H-P','P-L','HPR',
        'H2-H1','L1-L2','R2R','SignalPL','SignalR','OpenFib','HighFib','Open','H4', 'H3A', 'H3', 'H2A', 'H2','H1', 'IPivot-H', 'IPivot', 'IPivot-L','L1', 'L2', 'L2A', 'L3', 'L3A', 'L4','RH1_R', 'RH2A_R', 'RH2_R', 'RH3A_R', 'RH3_R', 'RH4_R', 'RIP-H_R', 'RIP-L_R', 'RIPivot_R', 'RL1_R', 'RL2A_R', 'RL2_R', 'RL3A_R', 'RL3_R', 'RL4_R']]
Res=StockDownGapUP2_Buy.groupby('SignalR')['SignalR'].count()
Res.plot.bar()
Res=StockDownGapUP2_Buy.groupby('SignalPL')['SignalPL'].count()
Res.plot.bar()

ConsolidatedStockDownGapUP1.groupby(['Signal','HPR','SignalR']).size().unstack(fill_value=0).plot.bar()

A=pd.read_csv("C:\ReadMoneycontrol\Mani 2.0\Temp3\Corrected\ACCAllStock.csv")

ConsolidatedStockDownGapUP1['Signal']=ConsolidatedStockDownGapUP1.apply(lambda x: CheckPrice(x,"Sell"),axis=1)
TTemp=ConsolidatedStockDownGapUP1[ConsolidatedStockDownGapUP1['Signal']!="H4"]
TTemp['Signal']=TTemp.apply(lambda x: CheckPriceDepth1(x,"Sell"),axis=1)
Temp=TTemp[['Date','Stock','Signal','SignalQ',
        'Open','High','Low','CDayHigh','CDayLow','H4', 'H3A', 'H3', 'H2A', 'H2','H1', 'IPivot-H', 'IPivot', 'IPivot-L','L1', 'L2', 'L2A', 'L3', 'L3A', 'L4','RH1_R', 'RH2A_R', 'RH2_R', 'RH3A_R', 'RH3_R', 'RH4_R', 'RIP-H_R', 'RIP-L_R', 'RIPivot_R', 'RL1_R', 'RL2A_R', 'RL2_R', 'RL3A_R', 'RL3_R', 'RL4_R']]


Temp1=ConsolidatedStockDownGapUP1[['Date','Stock','Signal',
        'Open','High','Low','CDayHigh','CDayLow','H4', 'H3A', 'H3', 'H2A', 'H2','H1', 'IPivot-H', 'IPivot', 'IPivot-L','L1', 'L2', 'L2A', 'L3', 'L3A', 'L4','RH1_R', 'RH2A_R', 'RH2_R', 'RH3A_R', 'RH3_R', 'RH4_R', 'RIP-H_R', 'RIP-L_R', 'RIPivot_R', 'RL1_R', 'RL2A_R', 'RL2_R', 'RL3A_R', 'RL3_R', 'RL4_R']]


def CheckPriceDepth1(Df,Field):
    if(Df['Open']>Df['IPivot']):
        if(Df['Open']<Df['IPivot-H']):
            return CHLCheck(Df,"IP-H")
        elif(Df['Open']<Df['H1']):
            return CHLCheck(Df,"H1")
        elif(Df['Open']<Df['H2']):
            return CHLCheck(Df,"H2")
        elif(Df['Open']<Df['H2A']):
            return CHLCheck(Df,"H2A")
        elif(Df['Open']<Df['H3']):
            return CHLCheck(Df,"H3")   
        elif(Df['Open']<Df['H3A']):
            return CHLCheck(Df,"H3A")    
        elif(Df['Open']<Df['H4']):
            return CHLCheck(Df,"H4")    
        else:
            return CHLCheck(Df,"H4A")    
    else:
        if(Df['Open']<Df['IPivot-L']):
            return CHLCheck(Df,"IPivot")
        elif(Df['Open']>Df['IPivot-L']):
            return CHLCheck(Df,"IP-L")
        elif(Df['Open']>Df['L1']):
            return CHLCheck(Df,"L2")
        elif(Df['Open']>Df['L2']):
            return CHLCheck(Df,"L2A")
        elif(Df['Open']>Df['L2A']):
            return CHLCheck(Df,"L3")
        elif(Df['Open']>Df['L3']):
            return CHLCheck(Df,"L3A")
        elif(Df['Open']>Df['L3A']):
            return CHLCheck(Df,"L4")
        else:
            return CHLCheck(Df,"L4A")
#        else:
#            return CHLCheck(Df,"L4A")
        
def CheckPriceDepth(Df,Field):
    if(Df['Open']>Df['IPivot']):
        if(Df['Open']<Df['IPivot-H']):
            return CHLCheck(Df,"IPivot")
        elif(Df['Open']<Df['H1']):
            return CHLCheck(Df,"IP-H")
        elif(Df['Open']<Df['H2']):
            return CHLCheck(Df,"H1")
        elif(Df['Open']<Df['H2A']):
            return CHLCheck(Df,"H2")
        elif(Df['Open']<Df['H3']):
            return CHLCheck(Df,"H2A")   
        elif(Df['Open']<Df['H3A']):
            return CHLCheck(Df,"H3")    
        elif(Df['Open']<Df['H4']):
            return CHLCheck(Df,"H3A")    
        else:
            return CHLCheck(Df,"H4")    
    else:
        if(Df['Open']>Df['IPivot-L']):
            return CHLCheck(Df,"IP-L")
        elif(Df['Open']>Df['L1']):
            return CHLCheck(Df,"L1")
        elif(Df['Open']>Df['L2']):
            return CHLCheck(Df,"L2")
        elif(Df['Open']>Df['L2A']):
            return CHLCheck(Df,"L2A")
        elif(Df['Open']>Df['L3']):
            return CHLCheck(Df,"L3")
        elif(Df['Open']>Df['L3A']):
            return CHLCheck(Df,"L3A")
        elif(Df['Open']>Df['L4']):
            return CHLCheck(Df,"L4")
        else:
            return CHLCheck(Df,"L4A")
        
def CHLCheck(Df,Signal):
    #Signal="H1"
    OSignal=Signal    
    Signals="R"+Signal+"_R"    
    if(Signal=="IP-H"):
        Signal="IPivot-H"
    if(Signal=="IP-L"):
        Signal="IPivot-L" 
    DownList=R_List[R_List.index(Signals)+1:]
    UpList=R_List[:R_List.index(Signals)]                        
    ResList=[]
    i=0

    for DownSignal in DownList:
        DownSignalStr=DownSignal.replace("R","").replace("_","")
        if(DownSignalStr=="IP-H"):
            DownSignalStr="IPivot-H"
        if(DownSignalStr=="IP-L"):
            DownSignalStr="IPivot-L"                
        if(i==0):
            FirstMatch=CLCheck(Df,DownSignalStr,"",DownSignalStr,OSignal)            
            ResList.append(FirstMatch)
        else:                    
            TempRes=CLCheck(Df,DownSignalStr,"~",DownSignalStr,"")
            if(TempRes!=""):
                ResList.append(TempRes)
        i=i+1                
#    if(FirstMatch==OSignal):
#        DownSignalString=FirstMatch
#    else:
    if(len(ResList)>0):
        DownSignalString=ResList[-1:][0]
    else:
        DownSignalString=""
        

    UResList=[]
    Ui=0
    UFirstMatch=""
    for UpSignal in UpList:
        UpSignalStr=UpSignal.replace("R","").replace("_","")
        if(UpSignalStr=="IP-H"):
            UpSignalStr="IPivot-H"
        if(UpSignalStr=="IP-L"):
            UpSignalStr="IPivot-L"                
        if(Ui==0):
            UFirstMatch=CHCheck(Df,UpSignalStr,"*",UpSignalStr,OSignal)
            UResList.append(UFirstMatch)            
        else:                    
            UTempRes=CHCheck(Df,UpSignalStr,"*",UpSignalStr,"")
            if(UTempRes!=""):
                UResList.append(UTempRes)
        Ui=Ui+1                
#    if(UFirstMatch==OSignal):
#        UpSignalString=UFirstMatch
#    else:
    if(len(UResList)>0):
        UpSignalString=UResList[-1:][0]
    else:
        UpSignalString=""

    
    if(Df['CDayHigh']<Df[Signal]):
        if(Df['High']<Df[Signal]):
            if(UpSignalString==DownSignalString):
                return OSignal
            elif((UpSignalString==OSignal) & (OSignal!=DownSignalString)):
            #    return OSignal+"__"+DownSignalString
                return OSignal+"_"+DownSignalString
            elif((UpSignalString!=OSignal) & (OSignal==DownSignalString)):
            #    return OSignal+"__"+UpSignalString
                return OSignal+"_"+UpSignalString
            else:
            #    return OSignal+"__"+UpSignalString+"_*_"+DownSignalString
                return OSignal+"_"+UpSignalString+"_"+DownSignalString
        else:
            if(UpSignalString==DownSignalString):
                return OSignal
            elif((UpSignalString==OSignal) & (OSignal!=DownSignalString)):
                #return OSignal+"__"+DownSignalString
                return OSignal+"_"+DownSignalString
            elif((UpSignalString!=OSignal) & (OSignal==DownSignalString)):
            #    return OSignal+"_*_"+UpSignalString
                return OSignal+"_"+UpSignalString
            else:
            #    return OSignal+"__"+UpSignalString+"_*_"+DownSignalString
                return OSignal+"_"+UpSignalString+"_"+DownSignalString

#            for UpSignal in UpList:
#                UpSignalStr=UpSignal.replace("R","").replace("_","")
#                if(UpSignalStr=="IP-H"):
#                    UpSignalStr="IPivot-H"
#                if(UpSignalStr=="IP-L"):
#                    UpSignalStr="IPivot-L"                
#                if(i==0):
#                    FirstMatch=CHCheck(Df,UpSignalStr,"*",UpSignalStr,OSignal)            
#                else:                    
#                    TempRes=CHCheck(Df,UpSignalStr,"*",UpSignalStr,"")
#                    if(TempRes!=""):
#                        ResList.append(TempRes)
#                i=i+1                
#            if(len(ResList)>0):
#                return FirstMatch+"_"+ResList[-1:][0]
#            else:
#                return FirstMatch

            
            #return CLCheck(Signal_1,"HT"+Signal,Suffix,Signal)
    else:
        if(UpSignalString==DownSignalString):
        #    return UpSignalString+"()"
            return UpSignalString+""
        elif((UpSignalString==OSignal) & (OSignal!=DownSignalString)):
        #    return OSignal+"_#_"+DownSignalString
            return OSignal+"_"+DownSignalString
        elif((UpSignalString!=OSignal) & (OSignal==DownSignalString)):
        #    return OSignal+"_#_"+UpSignalString
            return OSignal+"_"+UpSignalString
        else:
            #return OSignal+"__"+UpSignalString+"_#_"+DownSignalString
            return OSignal+"_"+UpSignalString+"_"+DownSignalString
     #   return CLCheck(Signal_1,"CHT"+Signal,Suffix,Signal)
#        for UpSignal in UpList:
#                UpSignalStr=UpSignal.replace("R","").replace("_","")
#                if(UpSignalStr=="IP-H"):
#                    UpSignalStr="IPivot-H"
#                if(UpSignalStr=="IP-L"):
#                    UpSignalStr="IPivot-L"                
#                if(i==0):
#                    FirstMatch=CHCheck(Df,UpSignalStr,".",UpSignalStr,OSignal)            
#                else:                    
#                    TempRes=CHCheck(Df,UpSignalStr,".",UpSignalStr,"")
#                    if(TempRes!=""):
#                        ResList.append(TempRes)
#                i=i+1                
#        if(len(ResList)>0):
#            return FirstMatch+"_"+ResList[-1:][0]
#        else:
#            return FirstMatch


    
def CLCheck(Df,Signal_1,Prefix,Suffix,DefaultReturn):
    if(Df['Low']<Df[Signal_1]):
        if(Df['CDayLow']<Df[Signal_1]):
            return Prefix+"BLT"+Suffix #both LowTPivot
        else:
            return Prefix+"LT"+Suffix
    else:
        if(Df['CDayLow']<Df[Signal_1]):
            return Prefix+'CLT'+Suffix
        else:
            return DefaultReturn #H1
    
            
def CHCheck(Df,Signal_1,Prefix,Suffix,DefaultReturn):
    if(Df['High']>Df[Signal_1]):
        if(Df['CDayHigh']>Df[Signal_1]):
            return Prefix+"BHT"+Suffix #both LowTPivot
        else:
            return Prefix+"HT"+Suffix
    else:
        if(Df['CDayHigh']>Df[Signal_1]):
            return Prefix+'CHT'+Suffix
        else:
            return DefaultReturn #H1
        
     
#ConsolidatedStockDownGapUP1.groupby('Signal')['Signal'].count()
#Res=ConsolidatedStockDownGapUP1.groupby(['Signal','SignalPL'])['Signal','SignalPL'].count().unstack()


#StockDownGapUP2_Buy.plot(kind="scatter", theme="white",x="HighFib",y="SignalPL",c="SignalPL")


#StockDownGapUP1=SBIN5Min[     (
#        (SBIN5Min['Close']>SBIN5Min['EMA-C-50']) &
#        (SBIN5Min['High'].shift(1)<SBIN5Min['EMA-C-50'].shift(1)) &
#        #(SBIN5Min['Open'].shift(1)<SBIN5Min['SMA-C-150'].shift(1)) &
#        #(SBIN5Min['Open'].shift(2)<SBIN5Min['SMA-C-150'].shift(2)) &
#        
##        (SBIN5Min['Indx']==0) &
#        (SBIN5Min['PDayClose']<SBIN5Min['DayOpen']) &
#        ((SBIN5Min['DayOpen']-SBIN5Min['PDayClose'])/SBIN5Min['PDayClose']*100>1)
#    )][['Date','Stock','Indx','HighFib','Open','H4', 'H3A', 'H3', 'H2A', 'H2','H1', 'IPivot-H', 'IPivot', 'IPivot-L','L1', 'L2', 'L2A', 'L3', 'L3A', 'L4','RH1_R', 'RH2A_R', 'RH2_R', 'RH3A_R', 'RH3_R', 'RH4_R', 'RIP-H_R', 'RIP-L_R', 'RIPivot_R', 'RL1_R', 'RL2A_R', 'RL2_R', 'RL3A_R', 'RL3_R', 'RL4_R']]
CD=ConsolidatedStockUPGapDown1['CDATE'].unique()
G=ConsolidatedStockUPGapDown1.groupby('CDATE')
G.get_group(CD[-9])


CD=ConsolidatedStockDownGapUP1[ConsolidatedStockDownGapUP1['Stock'].isin(BankStock)]['CDATE'].unique()
G=ConsolidatedStockDownGapUP1[ConsolidatedStockDownGapUP1['Stock'].isin(BankStock)].groupby('CDATE')
G.get_group(CD[-5])
ConsolidatedStockDownGapUP1.groupby('CDATE').count()