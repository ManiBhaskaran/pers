# -*- coding: utf-8 -*-
"""
Created on Wed Feb  5 22:16:26 2020

@author: lalitha
"""

import threading
import time
import requests
import datetime
import pandas as pd
import numpy as np
import json
from datetime import datetime, timedelta
import requests
from dateutil.parser import parse
import os
import itertools
import jhtalib as ta
from candlestick import candlestick
AllStockList="C:\ReadMoneycontrol\Mani 2.0\StockListAll.txt"
DIRNIFTY="C:\ReadMoneycontrol\Mani 2.0"

StockListFile=r"C:\ReadMoneycontrol\Mani 2.0\StockListID-NEWList.csv"
OtherStock=r"C:\ReadMoneycontrol\Mani 2.0\NEWDataIncr1"
#StockListFile=AllStockList
#DataDir=DIRNIFTY
DataDir=OtherStock
StockList1=pd.read_csv(StockListFile)
StockList1['Futures']="No"
StockList2=pd.read_csv(AllStockList)
StockList2['Futures']="Yes"
StockList=StockList2.append(StockList1)
def ProcessTransactions(StockDetails):
#    Cookie="_ga=GA1.2.2049447225.1545498156; __cfduid=d475c88a56e3eb88adf0ff0f32d7f14be1574230314; kf_session=mKSIWOPSPH25r1ZUb0W3UosgZ83w2yyy; user_id=RM5678; public_token=wiAGHwVOtJFJGaszeul59hWAyFYA6AJg; enctoken=8ZrRo7295CKBd6cnbbPX88U7X2t+5dL7ok4zXRA9hmpEGYuf1UBNQRGq15evouJx5AP3FqOsqcUA80SruKe1XbjXs/ug3Q=="
#    authorization="enctoken 8ZrRo7295CKBd6cnbbPX88U7X2t+5dL7ok4zXRA9hmpEGYuf1UBNQRGq15evouJx5AP3FqOsqcUA80SruKe1XbjXs/ug3Q=="
    Cookie="_ga=GA1.2.2049447225.1545498156; __cfduid=d475c88a56e3eb88adf0ff0f32d7f14be1574230314; kf_session=0CIygEttJnJ7Fs5T8Oo47dzwMnD420un; user_id=RM5678; public_token=JVBkpIuhxnKTm5qFwhc75tllz8teiKnI; enctoken=6+sdoKoPKGXn8aP/eRFPbt4V5R/rJgmOdRMhiEPcRVZi71WvQE7I+9kSDTTvZLH3HmXRNMCnqjSJ4QJHd9HcwXll2rcq+A=="
    authorization="enctoken 6+sdoKoPKGXn8aP/eRFPbt4V5R/rJgmOdRMhiEPcRVZi71WvQE7I+9kSDTTvZLH3HmXRNMCnqjSJ4QJHd9HcwXll2rcq+A=="
    headers = {'Content-type': 'application/x-www-form-urlencoded', 'Accept': 'application/json, text/plain, */*',
               'cookie':Cookie
               ,'authorization': authorization
               #,'x-csrftoken':'ydYuAU0A7nEJzXNJkAj58uiBc5pc9rWj'
               ,'referer':'https://kite.zerodha.com/chart/web/ciq/NSE/VEDL/784129'}
    i=0
    while(i<len(StockDetails)):    
        Symbol=StockDetails['symbol'].iloc[i]
        Transaction=StockDetails['Transaction'].iloc[i]
        Quantity=str(StockDetails['QTY'].iloc[i].astype(int))
        Price=str(StockDetails['TPrice'].iloc[i])
        Target=str(StockDetails['Target'].iloc[i])
        StopLoss=str(StockDetails['StopLoss'].iloc[i])
        TSL=str(StockDetails['TSL'].iloc[i])
        data="exchange=NSE&tradingsymbol="+ Symbol +"&transaction_type="+Transaction
        data=data+"&order_type=LIMIT&quantity="+Quantity+"&price="+Price+"&product=MIS&validity=DAY&disclosed_quantity=0&trigger_price=0"
        data=data+"&squareoff="+Target+"&stoploss="+StopLoss+"&trailing_stoploss="+TSL+"&variety=bo&user_id="
        #print(data)
        threading.Thread(target=startAction,args=(headers,data)).start()
        i=i+1
        

def startAction(headers,data):
    Response = requests.post('https://kite.zerodha.com/oms/orders/bo',
                                 headers=headers,data=data) #GOLD
    print(Response.text)


    
def DoIt():
    global ABuy_StockUpGapDown,ASell_StockDownGapUp,ABuy_StockUpGapDown1,ABuy_GAPDownStock
    global ASell_GAPUPStock_Fut,ABuy_GAPDownStock,ASell_GAPUPStock_Fut,ASell_GAPUPStock_NONFut,ABuy_GAPDownStock_NONFut
    global BuyST, SellST,T1,ABuy_GAPDownStock_Fut
    #Preopen=pd.read_csv(r"C:\ReadMoneycontrol\Mani 2.0\GapUpStrategy\01-Feb-2020\Data\PreOpen-2020-Feb-01.csv")
    #LastClose=pd.read_csv(r"C:\ReadMoneycontrol\Mani 2.0\GapUpStrategy\01-Feb-2020\cm31JAN2020bhav.csv")
    CStock=list(StockList.StockName)
    PreOpenLen=0
    while (PreOpenLen==0):
        time.sleep(5)
        PreOpen=getLatestPreOpenPrice()
        PreOpenLen=len(PreOpen[PreOpen['lastPrice']>50])        
#    #print("Hello")    
    PreOpen.to_csv(r"C:\ReadMoneycontrol\Mani 2.0\GapUpStrategy\Data\PreOpen-"+PreOpen['CDATE'].iloc[0]+".csv",sep=',',encoding='utf-8',index=False)
#    
   # PreOpen=pd.read_csv(r"C:\ReadMoneycontrol\Mani 2.0\GapUpStrategy\Data\PreOpen-2020-Feb-11.csv")
    LastClose=pd.read_csv(r"C:\ReadMoneycontrol\Mani 2.0\GapUpStrategy\cm19FEB2020bhav.csv")
    Exposure=pd.read_csv(r"C:\ReadMoneycontrol\Mani 2.0\StocExposure.csv")
    #Preopen=pd.read_csv(r"C:\ReadMoneycontrol\Mani 2.0\GapUpStrategy\Data\PreOpen-2020-Feb-05.csv")
    #LastClose=pd.read_csv(r"C:\ReadMoneycontrol\Mani 2.0\GapUpStrategy\cm04FEB2020bhav.csv")
    #LastClose.dtypes
    Leverage=Exposure[['Stock','mis_multiplier']]
    Leverage.columns=['StockName','Margin']
    PreO=PreOpen[['symbol','lastPrice','pChange','previousClose']]
    PreO['StockName']=PreO['symbol']
    LastC=LastClose[LastClose['SERIES']=='EQ'][['TIMESTAMP','SYMBOL','OPEN','LOW','CLOSE','LAST','TOTTRDQTY','TOTTRDVAL']]
    LastC.columns=['Date', 'symbol', 'Open','Low','Close', 'Last', 'V', 'Val']
    T1=PreO.merge(LastC,on=['symbol'],how="left")
    Stock=StockList[['StockName','Futures']]
    T2=T1.merge(Stock,on=['StockName'],how="right")
    T=T2.merge(Leverage,on=['StockName'],how="left")
    T=T.dropna()
#    T=LastC
    #T.dtypes
    T['AGap']=round((T['lastPrice']-T['Last']+0.00001)/T['Last']*100,2)
    T['CO']=round((T['Close']-T['Open']+0.000001)/T['Open']*100,2)
    T['LO']=round((T['Low']-T['Open']+0.000001)/T['Open']*100,2)
    T['CloseDiff']=round((T['Close']-T['Last'])/T['Last']*100,2)
    T['V']=round(T['V']/100000,2)
    T['Val']=round(T['Val']/10000000,2)
    T['Spike']=T['V']*T['Val']
    T1=T[(T['Close']>30) & T['symbol'].isin(CStock)]
    
    ABuy_StockUpGapDown=T1[(T1['AGap']<-1) & (T1['CloseDiff']<-1) & (T1['CO']>0) ]
    ASell_StockDownGapUp=T1[(T1['AGap']>1) & (T1['CloseDiff']>1) & (T1['CO']<0) ]
    ABuy_StockUpGapDown1=T1[(T1['AGap']<-.5) &  (T1['CO']>2) ]
    ASell_StockDownGapUp1=T1[(T1['AGap']>.5) & (T1['CO']<-2) & (T1['CloseDiff']>.1)]
    ASell_GAPUPStock=T1.sort_values(['AGap'],ascending=False).head().sort_values(['Spike'],ascending=False)
    ABuy_GAPDownStock=T1.sort_values(['AGap'],ascending=True).head().sort_values(['Spike'],ascending=False)
    
    ASell_GAPUPStock_Fut=T1[T1['Futures']=="Yes"].sort_values(['AGap'],ascending=False).head().sort_values(['Spike'],ascending=False)
    ABuy_GAPDownStock_Fut=T1[T1['Futures']=="Yes"].sort_values(['AGap'],ascending=True).head().sort_values(['Spike'],ascending=False)
    
    ASell_GAPUPStock_NONFut=T1[(T1['Futures']=="No") & (T1['Spike']>1)].sort_values(['AGap'],ascending=False).head().sort_values(['Spike'],ascending=False)
    ABuy_GAPDownStock_NONFut=T1[(T1['Futures']=="No") & (T1['Spike']>1)].sort_values(['AGap'],ascending=True).head().sort_values(['Spike'],ascending=False)
    #T=pd.merge([LastC,PreO],on=['symbol'])
#    BuyS=['IBULHSGFIN','DLF']
#    SellS=['APOLLOTYRE','SPECIALITY']
#
#    BuyST=T1[T1['symbol'].isin(BuyS)][['symbol','lastPrice','AGap']]
#    #BuyST.columns=['Symbol','Price']
#    Amount=180000/len(BuyS)
#    BuyST['Transaction']="BUY"
#    BuyST['QTY']=round(Amount/BuyST['lastPrice'],0)
#    BuyST['TPrice']=round(BuyST['lastPrice']*1.02,1)
#    BuyST['Target']=round(BuyST['lastPrice']*.012,1)
#    BuyST['StopLoss']=round(BuyST['lastPrice']*.03,1)
#    BuyST['TSL']=0
#    BuyST.to_csv(r"C:\ReadMoneycontrol\Mani 2.0\GapUpStrategy\Data\Buys.csv",sep=',',encoding='utf-8',index=False)
#    
#    SellST=T[T['symbol'].isin(BuyS)][['symbol','lastPrice','AGap']]
#    #BuyST.columns=['Symbol','Price']
#    Amount=180000/len(SellS)
#    SellST['Transaction']="SELL"
#    SellST['QTY']=round(Amount/BuyST['lastPrice'],0)
#    SellST['TPrice']=round(BuyST['lastPrice']*.97,1)
#    SellST['Target']=round(BuyST['lastPrice']*.012,1)
#    SellST['StopLoss']=round(BuyST['lastPrice']*.03,1)
#    SellST['TSL']=0
#    SellST.to_csv(r"C:\ReadMoneycontrol\Mani 2.0\GapUpStrategy\Data\Sells.csv",sep=',',encoding='utf-8',index=False)
#    

    
    # Schedule when you want the action to occur
    #time.strptime(datetime.now().strftime("%Y-%m-%d 09:15"))
def runit():
    
    end_time=parse(datetime.now().strftime("%Y-%m-%d 09:15"))
    while datetime.now() < end_time:
        time.sleep(1)
    print("Hello")
    SellSTdf=pd.read_csv(r"C:\ReadMoneycontrol\Mani 2.0\GapUpStrategy\Data\Sells1.csv")
    BuySTdf=pd.read_csv(r"C:\ReadMoneycontrol\Mani 2.0\GapUpStrategy\Data\Buys1.csv")
    BuyS=list(BuySTdf.Stock)
    SellS=list(SellSTdf.Stock)
    
    BuyST=T1[T1['symbol'].isin(BuyS)][['symbol','lastPrice','AGap','Margin']]
    #BuyST.columns=['Symbol','Price']
    Amount=1500/len(BuyS)
    BuyST['Transaction']="BUY"
    BuyST['QTY']=round(BuyST['Margin']*1.2*Amount/BuyST['lastPrice'],0)
    BuyST['TPrice']=round(BuyST['lastPrice']*1.02,1)    
    BuyST['Target']=BuyST.apply(lambda x:getTarget(x),axis=1)
    #BuyST['Target']=round(BuyST['lastPrice']*.012,1)
    BuyST['StopLoss']=round(BuyST['lastPrice']*.03,1)
    BuyST['TSL']=0
    BuyST.to_csv(r"C:\ReadMoneycontrol\Mani 2.0\GapUpStrategy\Data\Buys.csv",sep=',',encoding='utf-8',index=False)
    
    SellST=T1[T1['symbol'].isin(SellS)][['symbol','lastPrice','AGap','Margin']]
    #BuyST.columns=['Symbol','Price']
    Amount=1500/len(SellS)
    SellST['Transaction']="SELL"
    SellST['QTY']=round(SellST['Margin']*1.2*Amount/SellST['lastPrice'],0)
    SellST['TPrice']=round(SellST['lastPrice']*.97,1)
    SellST['Target']=SellST.apply(lambda x:getTarget(x),axis=1)
    #SellST['Target']=round(SellST['lastPrice']*.012,1)
    SellST['StopLoss']=round(SellST['lastPrice']*.03,1)
    SellST['TSL']=0
    SellST.to_csv(r"C:\ReadMoneycontrol\Mani 2.0\GapUpStrategy\Data\Sells.csv",sep=',',encoding='utf-8',index=False)
    
    ProcessTransactions(BuyST)
    ProcessTransactions(SellST)

#Result1=DayS.apply(lambda x: getFirstBuy(x,25,List,Group.get_group(x['CDATE'])),axis=1)
def getTarget(x):
    if((x['AGap']>3) | (x['AGap']<-4)):
        return round(x['lastPrice']*.03,1)
    else:
        return round(x['lastPrice']*.012,1)
    
        