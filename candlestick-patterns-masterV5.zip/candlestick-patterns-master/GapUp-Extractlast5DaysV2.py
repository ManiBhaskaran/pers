# -*- coding: utf-8 -*-
"""
Created on Sun Jan 26 21:32:51 2020

@author: lalitha
"""

import threading
import time
import requests
import datetime
import pandas as pd
import numpy as np
import json
from datetime import datetime, timedelta
import requests
from dateutil.parser import parse
import os
import itertools
import jhtalib as ta
from candlestick import candlestick
AllStockList="C:\ReadMoneycontrol\Mani 2.0\StockListAll.txt"
DIRNIFTY="C:\ReadMoneycontrol\Mani 2.0"
StockListFile=r"C:\ReadMoneycontrol\Mani 2.0\StockListID-NEWList.csv"
OtherStock=r"C:\ReadMoneycontrol\Mani 2.0\NEWDataIncr1"
#StockListFile=AllStockList
#DataDir=DIRNIFTY
DataDir=OtherStock

StrTimeIntervals=['minute','3minute','5minute','15minute','day']
FutureDir=r"C:\ReadMoneycontrol\Mani 2.0\GapUpStrategy\Data\\"
Non_FutureDir=r"C:\ReadMoneycontrol\Mani 2.0\GapUpStrategy\Data1\\"
LASTEODFILE=r"C:\ReadMoneycontrol\Mani 2.0\GapUpStrategy\cm20FEB2020bhav.csv"

def futuresf():
    DataDir=DIRNIFTY
    FStocks1=pd.read_csv(AllStockList)
    Phase1(FutureDir,FStocks1)
    TargetDir=FutureDir
    StockList=FStocks1
    Phase2(FutureDir)
    Phase3(FutureDir,FStocks1)


def Nonfuturesf():
    DataDir=OtherStock
    NFStocks1=pd.read_csv(StockListFile)
    TargetDir=Non_FutureDir
    Phase1(Non_FutureDir,NFStocks1)
    Phase2(Non_FutureDir)
    Phase3(Non_FutureDir,NFStocks1)
    
def MParseDate(Date):
    ts = (np.datetime64(pd.to_datetime(Date)) - np.datetime64('1970-01-01T00:00:00Z')) / np.timedelta64(1, 's')
    return N1(N1(datetime.utcfromtimestamp(ts),'5H',"+"),"30M","+")
seconds_per_unit = {"S": 1, "M": 60, "H": 3600, "D": 86400, "W": 604800}
def N1(date,s,Operation):
    if (Operation=="+"):
        return date+timedelta(seconds=int(s[:-1]) * seconds_per_unit[s[-1]])
    else:
        return date-timedelta(seconds=int(s[:-1]) * seconds_per_unit[s[-1]])


def Convert(DataDir,StockList):
    i=0
    while(i<len(StockList)):
        #StockName=StockList.iloc[i]['Symbol']
        StockName=StockList.iloc[i]['StockName']
        #StockName=StockList.iloc[i]['StockName']
       # StockDay=pd.read_csv(DataDir+r"\Data\\"+StockName+'-day.csv')
        #StockDay[StockDay['Date']==StockDay.iloc[len(StockDay)-1]['Date']].to_csv("C:\ReadMoneycontrol\Mani 2.0\Data\\"+StockName+'-LASTREADDAY.csv',index=False)
        #TimeInterval ="minute"
        for TimeInterval in StrTimeIntervals:    
            DeltaDay=pd.read_csv(DataDir+r"\Incr1\\"+StockName+'-'+TimeInterval+'.csv')        
            DeltaDay['Date']=pd.to_datetime(pd.to_datetime(DeltaDay.Date).dt.strftime("%Y-%m-%d %H:%M:%S"))
            #DeltaDay['Date']=N1(DeltaDay['Date'],"330M","+")
            #Delta=DeltaDay[DeltaDay['Date']>N1(parse(StockDay.iloc[len(StockDay)-1]['Date']),"1D","+").strftime("%Y-%m-%d")  ]
            if(TimeInterval=="day"):
                DeltaDay['Date']=pd.to_datetime(DeltaDay['Date']).dt.strftime("%Y-%m-%d")            
                #Delta=DeltaDay[DeltaDay['Date']>StockDay.iloc[len(StockDay)-1]['Date'] ]
            #DeltaDay['Date'].strftime("%Y-%m-%d")        
            #N1(parse(StockDay.iloc[len(StockDay)-1]['Date']),"1D","+").strftime("%Y-%m-%d")  
            
            DeltaDay.to_csv(DataDir+r"\Incr1\\"+StockName+'-'+TimeInterval+'.csv',index=False)
            #DeltaDay.to_csv(DataDir+r"\incr2\\"+StockName+'-'+TimeInterval+'.csv',mode='a',header=True,index=False)
        i=i+1
#Convert(DataDir)

def ExtractData(TargetDir,StockList):
    i=0
    First=True
    while(i<len(StockList)):
        StockName=StockList.iloc[i]['StockName']
        MinuteFile=""
        #if(os.path.exists("C:\ReadMoneycontrol\Mani 2.0\Temp3\Corrected\\"+StockName+'AllStock.csv')==True):
        #    FilePath="C:\ReadMoneycontrol\Mani 2.0\Temp3\Corrected\\"+StockName+'AllStock.csv'
        if(os.path.exists(DataDir+"\incr1\\"+StockName+'-15minute.csv')==True):
            MinuteFile=DataDir+"\incr1\\"+StockName+'-15minute.csv'
            DayFile=DataDir+"\incr1\\"+StockName+'-day.csv'        
        if(MinuteFile!=""):
    #        print(StockName)
            #FilePath="C:\ReadMoneycontrol\Mani 2.0\GapUp-ZTemp\\ASAHIINDIAAllStock.csv"
            MinDF=pd.read_csv(MinuteFile) 
            MinDFExt=MinDF
            #MinDFExt=MinDF.iloc[-300:]
            #MinDFExt=MinDF.iloc[:-25]
            MinDFExt['Stock']=StockName
            MinDF=""
            DayDF=pd.read_csv(DayFile)
            DayDFExt=DayDF
            ##DayDFExt=DayDF.iloc[-10:]
            #DayDFExt=DayDF.iloc[:-1]
            DayDFExt['Stock']=StockName
            DayDF=""
            if(First):
                CMinDF=MinDFExt                
                CDayDF=DayDFExt
            else:
                CMinDF=CMinDF.append(MinDFExt)
                CDayDF=CDayDF.append(DayDFExt)
            First=False
        i=i+1
    CMinDF.to_csv(TargetDir+"15Minute.csv",sep=',',encoding='utf-8',index=False)
    CDayDF.to_csv(TargetDir+"day.csv",sep=',',encoding='utf-8',index=False)

#ExtractData()    

def CheckPrice(Df,Field):
    if(Df['Open']>Df['IPivot']):
        if(Df['Open']<Df['IPivot-H']):
            return "IPivot"
        elif(Df['Open']<Df['H1']):
            return "IP-H"
        elif(Df['Open']<Df['H2']):
            return "H1"
        elif(Df['Open']<Df['H2A']):
            return "H2"
        elif(Df['Open']<Df['H3']):
            return "H2A"    
        elif(Df['Open']<Df['H3A']):
            return "H3"    
        elif(Df['Open']<Df['H4']):
            return "H3A"    
        else:
            return "H4"    
    else:
        if(Df['Open']>Df['IPivot-L']):
            return "IP-L"
        elif(Df['Open']>Df['L1']):
            return "L1"
        elif(Df['Open']>Df['L2']):
            return "L2"
        elif(Df['Open']>Df['L2A']):
            return "L2A"
        elif(Df['Open']>Df['L3']):
            return "L3"
        elif(Df['Open']>Df['L3A']):
            return "L3A"
        elif(Df['Open']>Df['L4']):
            return "L4"
        else:
            return "L4A"


def getLatestPreOpenPrice():
    headers = {'referer':'https://www.nseindia.com/market-data/pre-open-market-cm-and-emerge-market',
               'user-agent':"Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36"
               }
    PreOpenMarketURL="https://www.nseindia.com/api/market-data-pre-open?key=ALL"
    Response = requests.get(PreOpenMarketURL,
                                 headers=headers) #GOLD
    ResJson=Response.json()
    Data=pd.DataFrame(list(pd.DataFrame(ResJson['data'])['metadata']))
    
    CDATETIME=parse(parse(ResJson['timestamp']).strftime("%Y-%b-%d 09:15:00"))
    CDATE=parse(ResJson['timestamp']).strftime("%Y-%b-%d")
    Data['CDATE']=CDATE
    Data['Date']=CDATETIME
    return Data[['Date','symbol','lastPrice','pChange','previousClose','CDATE']]

    
def PrStock(Stock,MinuteData,DayData):
    #Stock='GAIL'
    #SBIN5Min=candlestick.LoadCSVData(DataDir,Stock,"15minute")
    #MinuteData=FilteredMin
    #DayData=FilteredDay
    SBIN5Min=MinuteData
    SBIN5Min.columns=['Date', 'Open', 'High', 'Low', 'Close', 'V','Stock']
    SBIN5Min['Date']=pd.to_datetime(SBIN5Min.Date)
    SBIN5Min['CDATE']=pd.to_datetime(SBIN5Min['Date']).dt.strftime("%Y-%b-%d")
    SBINDay=DayData
    SBINDay.columns=['Date', 'Open', 'High', 'Low', 'Close', 'V','Stock']
    SBINDay['Date']=pd.to_datetime(SBINDay.Date)
    #SBINDay=candlestick.LoadCSVData(DataDir,Stock,"day")
    SBINDay['CDATE']=pd.to_datetime(SBINDay['Date']).dt.strftime("%Y-%b-%d")    
    SBIN5Min.drop_duplicates(subset =["Date"], keep = "first", inplace = True) 
    SBIN5Min['Indx']=((SBIN5Min['Date']-pd.to_datetime(pd.to_datetime(SBIN5Min['CDATE']).dt.strftime("%Y-%m-%d 09:15"))).dt.seconds/60/15).astype(int)
    SBIN5Min=SBIN5Min[SBIN5Min['Indx']<=24]
    SBINDay['HL']=SBINDay['High'].shift(1)-SBINDay['Low'].shift(1)
    SBINDay['PDayLow']=SBINDay['Low'].shift(1)
    SBINDay['PDayHigh']=SBINDay['High'].shift(1)
    SBINDay['PDayClose']=SBINDay['Close'].shift(1)
    SBINDay['PDayOpen']=SBINDay['Open'].shift(1)
    SBINDay['PDayVolume']=SBINDay['V'].shift(1)
    SBINDay['PDayVolumeSMA5']=SBINDay['V'].shift(1).rolling(5).mean()
    SBINDay['PDayVolumeSMA10']=SBINDay['V'].shift(1).rolling(10).mean()
    SBINDay['PDayVolumeSMA15']=SBINDay['V'].shift(1).rolling(15).mean()
    SBINDay['PDayVolumeSMA20']=SBINDay['V'].shift(1).rolling(20).mean()
        #SBINDay['DayRSI14']=ta.RSI(SBINDay,14)
    SBINDay['DayRSI14']=0
    SBINDay['DaySMA50']=SBINDay['Close'].shift(1).rolling(50).mean()
    SBINDay["IPivot"]=candlestick.MaRound((SBINDay['Close'].shift(1)+SBINDay['High'].shift(1)+SBINDay['Low'].shift(1))/3)
    SBINDay["H4"]=candlestick.MaRound(SBINDay["IPivot"]+((SBINDay['High'].shift(1)-SBINDay['Low'].shift(1))*3))   
    SBINDay["H3A"]=candlestick.MaRound(SBINDay["IPivot"]+((SBINDay['High'].shift(1)-SBINDay['Low'].shift(1))*2.5))   
    SBINDay["H3"]=candlestick.MaRound(SBINDay["IPivot"]+((SBINDay['High'].shift(1)-SBINDay['Low'].shift(1))*2))   
    SBINDay["H2A"]=candlestick.MaRound(SBINDay["IPivot"]+((SBINDay['High'].shift(1)-SBINDay['Low'].shift(1))*1.5))   
    SBINDay["H2"]=candlestick.MaRound(SBINDay["IPivot"]+((SBINDay['High'].shift(1)-SBINDay['Low'].shift(1))))      
    SBINDay["H1"]=candlestick.MaRound(2*SBINDay["IPivot"]-SBINDay["Low"].shift(1))    
    SBINDay["IPivot-H"]=round((SBINDay["IPivot"]+SBINDay["H1"])/2,2)
    SBINDay["L4"]=candlestick.MaRound(SBINDay["IPivot"]-((SBINDay['High'].shift(1)-SBINDay['Low'].shift(1))*3))
    SBINDay["L3A"]=candlestick.MaRound(SBINDay["IPivot"]-((SBINDay['High'].shift(1)-SBINDay['Low'].shift(1))*2.5))
    SBINDay["L3"]=candlestick.MaRound(SBINDay["IPivot"]-((SBINDay['High'].shift(1)-SBINDay['Low'].shift(1))*2))
    SBINDay["L2A"]=candlestick.MaRound(SBINDay["IPivot"]-((SBINDay['High'].shift(1)-SBINDay['Low'].shift(1))*1.5))   
    SBINDay["L2"]=candlestick.MaRound(SBINDay["IPivot"]-((SBINDay['High'].shift(1)-SBINDay['Low'].shift(1))))      
    SBINDay["L1"]=candlestick.MaRound(2*SBINDay["IPivot"]-SBINDay["High"].shift(1))        
    SBINDay["IPivot-L"]=round((SBINDay["IPivot"]+SBINDay["L1"])/2,2)
    
    merged = SBIN5Min.merge(SBINDay, on=['CDATE'], how='left')
    CustomMerge=merged[['Date_x','HL','PDayLow','PDayHigh','PDayClose','PDayOpen','PDayVolume','PDayVolumeSMA5','PDayVolumeSMA10','PDayVolumeSMA15','PDayVolumeSMA20', 'DayRSI14', 'DaySMA50',
                        'H1','H2','H2A','H3','H3A','H4','IPivot-H',"IPivot",
                        "L1","L2",'L2A',"L3",'L3A',"L4",'IPivot-L']]
    CustomMerge.columns=['Date', 'HL', 'PDayLow','PDayHigh','PDayClose','PDayOpen','PDayVolume','PDayVolumeSMA5','PDayVolumeSMA10','PDayVolumeSMA15','PDayVolumeSMA20', 'DayRSI14', 'DaySMA50',
                         'H1','H2','H2A','H3','H3A','H4','IPivot-H',"IPivot",
                        "L1","L2",'L2A',"L3",'L3A',"L4",'IPivot-L']
    SBIN5Min=SBIN5Min.merge(CustomMerge, on=['Date'], how='left')
    #SBIN5Min['HL']=merged['HL']
    #SBIN5Min['PLow']=merged['PLow']       
    SBIN5Min['HighFib']=round((SBIN5Min['High']-SBIN5Min['PDayLow'])*1000/SBIN5Min['HL'])
    SBIN5Min['LowFib']=round((SBIN5Min['Low']-SBIN5Min['PDayLow'])*1000/SBIN5Min['HL'])
    SBIN5Min['OpenFib']=round((SBIN5Min['Open']-SBIN5Min['PDayLow'])*1000/SBIN5Min['HL'])
    SBIN5Min['CloseFib']=round((SBIN5Min['Close']-SBIN5Min['PDayLow'])*1000/SBIN5Min['HL'])
    
    SBIN5Min.drop(SBIN5Min[SBIN5Min['Indx'] > 24].index, inplace = True) 
    #SBIN5Min.drop(SBIN5Min[SBIN5Min['Indx'] > 74].index, inplace = True) 
    offset=4
    SBIN5Min['SMA-C-21-1']=SBIN5Min['Close'].shift(1).rolling(21).mean()#For 5, its is 63
    SBIN5Min['SMA-C-150-1']=SBIN5Min['Close'].shift(1).rolling(150).mean()#For 5, its is 63
    SBIN5Min['SMA-O-150-1']=SBIN5Min['Open'].shift(1).rolling(150).mean()#For 5, its is 63
    SBIN5Min['SMA-O-150']=SBIN5Min['Open'].rolling(150).mean()#For 5, its is 63
    SBIN5Min['SMA-C-10-1']=SBIN5Min['Close'].shift(1).rolling(10).mean()#For 10 its 30
    SBIN5Min['SMA-C-21']=SBIN5Min['Close'].rolling(21).mean()#For 5, its is 63
    SBIN5Min['SMA-C-10']=SBIN5Min['Close'].rolling(10).mean()#For 10 its 30
    SBIN5Min['SMA-C-150']=SBIN5Min['Close'].rolling(150).mean()#For 5, its is 63
    SBIN5Min['SMA-V-20']=SBIN5Min['V'].shift(1).rolling(20).mean()#For 10 its 30
    SBIN5Min['SMA-V-20-1']=SBIN5Min['V'].shift(1).rolling(20).mean()#For 10 its 30
    SBIN5Min['SMA-V-20']=SBIN5Min['V'].rolling(20).mean()#For 10 its 30
    SBIN5Min['EMA-C-50']=SBIN5Min['Close'].ewm(span=50, adjust=False).mean()
    SBIN5Min['RSI14']=ta.RSI(SBIN5Min,14)
    SBIN5Min=SBIN5Min.sort_values('Date',ascending=False)    
    SBIN5Min['MaxP']=SBIN5Min['High'].shift(1).rolling(10).max()
    SBIN5Min['MinP']=SBIN5Min['Low'].shift(1).rolling(10).min()    
    SBIN5Min['Open5']=SBIN5Min['Open'].shift(5)
    SBIN5Min['MaxP1']=SBIN5Min['High'].shift(1).rolling(20).max()
    SBIN5Min['MinP1']=SBIN5Min['Low'].shift(1).rolling(20).min()
    SBIN5Min['Open15']=SBIN5Min['Open'].shift(15)
    SBIN5Min['MaxP2']=SBIN5Min['High'].shift(1).rolling(30).max()
    SBIN5Min['MinP2']=SBIN5Min['Low'].shift(1).rolling(30).min()
    SBIN5Min['Open20']=SBIN5Min['Open'].shift(20)    
    SBIN5Min['Max10']=SBIN5Min['High'].shift(9)
    SBIN5Min['Min10']=SBIN5Min['Low'].shift(9)
    SBIN5Min['Open10']=SBIN5Min['Open'].shift(10)    
    SBIN5Min=SBIN5Min.sort_values('Date',ascending=True)
    
    SBIN5Min['CV']=SBIN5Min.groupby(['CDATE'])['V'].apply(lambda x: x.cumsum())
    SBIN5Min['CDayHigh']=SBIN5Min.groupby(['CDATE'])['High'].apply(lambda x: x.cummax())
    SBIN5Min['CDayLow']=SBIN5Min.groupby(['CDATE'])['Low'].apply(lambda x: x.cummin())
    #SBIN5Min['COpen']=
    #global FirstOpen
    FirstOpen=pd.DataFrame(SBIN5Min.groupby(['CDATE']).apply(lambda x: x['Open'].iloc[0]))
    FirstOpen.columns=['DayOpen']
    
    FirstOpen['CDATE']=FirstOpen.index
    FirstOpen.index.names = ['CD']
    #FirstOpen.reset_index(drop=True)
    SBIN5Min=SBIN5Min.merge(FirstOpen,on=['CDATE'])
    #SBIN5Min.groupby(['CDATE'])['Low'].count()
    SBIN5Min['SMAV20']=SBIN5Min['V'].shift(1).rolling(20).mean()
#    SBIN5Min=candlestick.HA(SBIN5Min)
    #SBIN5Min=candlestick.heikenashi(SBIN5Min)
    #Dt=SBIN5Min[['Date','Open','High','Low','Close','DayOpen','HA_Close', 'HA_Open',
    #       'HA_High', 'HA_Low','CDayHigh','CDayLow']]
    #SBIN5Min['SMAV20'].head(30)
    
    Sdf=candlestick.Newmacd(SBIN5Min,"Close")
    SBIN5Min['MACD']=Sdf['MACD']
    #SCandle['RSI']=SRSIValue
    #Candle['Close']=Candle['Close']
    SBIN5Min['Signal']=Sdf['Signal']
    SBIN5Min['Crossover']=Sdf['Crossover']
#    Sdf=candlestick.Ichimoku(SBIN5Min,9,26,52,-26)
#    SBIN5Min.merge(Sdf)




    DayS=SBIN5Min
    DayS["RH1"]=(DayS['High']>DayS['H1']) & (DayS['Low']<DayS['H1'])
    DayS["RIPivot"]=(DayS['High']>DayS['IPivot']) & (DayS['Low']<DayS['IPivot'])
    DayS["RH2"]=(DayS['High']>DayS['H2']) & (DayS['Low']<DayS['H2'])    
    DayS["RH2A"]=(DayS['High']>DayS['H2A']) & (DayS['Low']<DayS['H2A'])
    DayS["RH3"]=(DayS['High']>DayS['H3']) & (DayS['Low']<DayS['H3'])
    DayS["RH3A"]=(DayS['High']>DayS['H3A']) & (DayS['Low']<DayS['H3A'])    
    DayS["RH4"]=(DayS['High']>DayS['H4']) & (DayS['Low']<DayS['H4'])
    DayS["RIP-H"]=(DayS['High']>DayS['IPivot-H']) & (DayS['Low']<DayS['IPivot-H'])
    DayS["RIP-L"]=(DayS['High']>DayS['IPivot-L']) & (DayS['Low']<DayS['IPivot-L'])
    DayS["RL1"]=(DayS['High']>DayS['L1']) & (DayS['Low']<DayS['L1'])
    DayS["RL2"]=(DayS['High']>DayS['L2']) & (DayS['Low']<DayS['L2'])    
    DayS["RL2A"]=(DayS['High']>DayS['L2A']) & (DayS['Low']<DayS['L2A'])
    DayS["RL3"]=(DayS['High']>DayS['L3']) & (DayS['Low']<DayS['L3'])
    DayS["RL3A"]=(DayS['High']>DayS['L3A']) & (DayS['Low']<DayS['L3A'])    
    DayS["RL4"]=(DayS['High']>DayS['L4']) & (DayS['Low']<DayS['L4'])
#    DayS["SH2SL"]=(DayS['High']>DayS['H2A']) & (DayS['Low']<DayS['H2A'])
#    DayS["SH2TA"]=(DayS['High']>DayS['H1']) & (DayS['Low']<DayS['H1'])
#    DayS["SH2ASL"]=(DayS['High']>DayS['H2A']) & (DayS['Low']<DayS['H2A'])
#    DayS["SH2ATA"]=(DayS['High']>DayS['H2']) & (DayS['Low']<DayS['H2'])
    
    #I = np.array([row[[x for x in range(A.shape[1]) if x != i-1]] for row in A if row[i-1] == i])
    #print I
    #len(DayS[(DayS["SH2ATA"]==True)])
    #Tz['Label']=np.select([(Tz['SellProfitP']>0) & (Tz['BuyProfitP']<0),(Tz['SellProfitP']<0) & (Tz['BuyProfitP']>0),(Tz['SellProfitP']<0) & (Tz['BuyProfitP']<0)],[-1,1,-100],Tz['Label'] )
    
    
    
    List=['RH1', 'RIPivot', 'RH2', 'RH2A',
           'RH3', 'RH3A', 'RH4', 'RIP-H','RIP-L','RL1','RL2','RL3','RL4','RL2A','RL3A']
    
    #Group=DayS.groupby('CDATE')
    
    IndexList=[]
    ResultList=[]
    #itertools
    #print("Starting")
   # Date1=datetime.now()
    #i=0
    #j=0
    #Runthread=[]
    #Increment=50
    #while(i<len(DayS)):
    #    Runthread.append(threading.Thread(target=ApplyDF,args=(i,i+Increment)))
    #    Runthread[-1].start()
    #    if((j%10==0) & (j!=0)):
    #        for thread in Runthread:
    #            thread.join()
    #        Runthread=[]
    #    i=i+Increment
    #    j=j+1
    #for thread in Runthread:
    #    thread.join()    
    if(False):
        Result1=DayS.apply(lambda x: getFirstBuy(x,25,List,Group.get_group(x['CDATE'])),axis=1)
        print("StockNameStockName : " + str((datetime.now()-Date1).seconds))
        len(Result1.iloc[0])
        Result1
        
        TempAr=[]
        i=0
        while(i<len(Result1)):
            TempDict={}
            TempDict['Date']=Result1.iloc[i][0]
            j=0
            while(j<len(List)):
                TempDict[List[j]+"_R"]=Result1.iloc[i][1][j]
                j=j+1
            i=i+1
            TempAr.append(TempDict)
        CheckDfResultdf=pd.DataFrame(TempAr)
        len(CheckDfResultdf)
        merged = CheckDfResultdf.merge(DayS, on=['Date'], how='left')    
        SBIN5Min=merged

#    SBIN5Min['Buy']=(
#        (
#        (SBIN5Min['Close']<SBIN5Min['H1']) & (SBIN5Min['High']<SBIN5Min['H1'])
#        & (SBIN5Min['High'].shift(1)<SBIN5Min['H1'])
#        & (SBIN5Min['High'].shift(2)<SBIN5Min['H1'])
#        )
#        |
#        (
#        (SBIN5Min['Close']<SBIN5Min['H2']) & (SBIN5Min['High']<SBIN5Min['H2'])
#        & (SBIN5Min['Close']>SBIN5Min['H1'])
#        )
#        |
#        (
#        (SBIN5Min['DayOpen']<SBIN5Min['H2']) & (SBIN5Min['DayOpen']>SBIN5Min['H1'])
#        & (SBIN5Min['Low']>SBIN5Min['IPivot'])
#        )
#        )
#
#
#
#
#    IntraDayBuy=SBIN5Min[
#            (
#                    #( (SBIN5Min['Close']>SBIN5Min['SMA-C-21']) & (SBIN5Min['Open']<SBIN5Min['SMA-C-21'])) &
#                (
#                    (
#                        (SBIN5Min['Close']>SBIN5Min['SMA-C-21']) &
#                        (SBIN5Min['SMA-C-10']>SBIN5Min['SMA-C-21']) &
#                        (SBIN5Min['Close']>SBIN5Min['SMA-C-150']) 
#    #                    & ( (SBIN5Min['Close']>SBIN5Min['SMA-C-21']) & 
#    #                     (
#    #                             (SBIN5Min['Low']<SBIN5Min['SMA-C-10']) |
#    #                             (SBIN5Min['SMA-C-21'].shift(1)<SBIN5Min['SMA-C-10'].shift(1)) |
#    #                             (SBIN5Min['SMA-C-21'].shift(2)<SBIN5Min['SMA-C-10'].shift(2)) |
#    #                             (SBIN5Min['SMA-C-21'].shift(3)<SBIN5Min['SMA-C-10'].shift(3))
#    #                             
#    #                     )
#    #                )
#                    )
#    #            |
#    #                (
#    #                    (SBIN5Min['Close'].shift(1)>SBIN5Min['SMA-C-21'].shift(1)) &
#    #                    (SBIN5Min['SMA-C-10'].shift(1)>SBIN5Min['SMA-C-21'].shift(1)) &
#    #                    ( (SBIN5Min['Close'].shift(1)>SBIN5Min['SMA-C-21'].shift(1)) 
#    #                    & (SBIN5Min['Low'].shift(1)<SBIN5Min['SMA-C-10'].shift(1))) 
#    #                )
#                ) &
#    
#    
#    (
#     (
#        (SBIN5Min['SMA-C-10'].shift(1)>SBIN5Min['SMA-C-21'].shift(1)) &
#        (SBIN5Min['SMA-C-10'].shift(2)>SBIN5Min['SMA-C-21'].shift(2)) &
#        (SBIN5Min['SMA-C-10'].shift(3)>SBIN5Min['SMA-C-21'].shift(3)) &
#        (SBIN5Min['SMA-C-10'].shift(4)>SBIN5Min['SMA-C-21'].shift(4)) &
#        (SBIN5Min['SMA-C-10'].shift(5)>SBIN5Min['SMA-C-21'].shift(5)) &
#        (SBIN5Min['SMA-C-10'].shift(6)>SBIN5Min['SMA-C-21'].shift(6)) &
#        (SBIN5Min['SMA-C-10'].shift(7)>SBIN5Min['SMA-C-21'].shift(7)) &
#        (SBIN5Min['SMA-C-10'].shift(8)>SBIN5Min['SMA-C-21'].shift(8)) &
#        (SBIN5Min['SMA-C-10'].shift(9)>SBIN5Min['SMA-C-21'].shift(9)) &
#        (SBIN5Min['SMA-C-10'].shift(10)>SBIN5Min['SMA-C-21'].shift(10)) &
#        (SBIN5Min['SMA-C-10'].shift(11)>SBIN5Min['SMA-C-21'].shift(11)) &
#        (SBIN5Min['SMA-C-10'].shift(12)>SBIN5Min['SMA-C-21'].shift(12)) 
#    #    &(SBIN5Min['SMA-C-10'].shift(13)>SBIN5Min['SMA-C-21'].shift(13)) &
#    #    (SBIN5Min['SMA-C-10'].shift(14)>SBIN5Min['SMA-C-21'].shift(14)) &
#    #    (SBIN5Min['SMA-C-10'].shift(15)>SBIN5Min['SMA-C-21'].shift(15)) &
#    #    (SBIN5Min['SMA-C-10'].shift(16)>SBIN5Min['SMA-C-21'].shift(16)) &
#    #    (SBIN5Min['SMA-C-10'].shift(17)>SBIN5Min['SMA-C-21'].shift(17)) &
#    #    (SBIN5Min['SMA-C-10'].shift(18)>SBIN5Min['SMA-C-21'].shift(18)) &
#    #    (SBIN5Min['SMA-C-10'].shift(19)>SBIN5Min['SMA-C-21'].shift(19)) &
#    #    (SBIN5Min['SMA-C-10'].shift(20)>SBIN5Min['SMA-C-21'].shift(20)) &
#    #    (SBIN5Min['SMA-C-10'].shift(21)>SBIN5Min['SMA-C-21'].shift(21)) &
#    #    (SBIN5Min['SMA-C-10'].shift(22)>SBIN5Min['SMA-C-21'].shift(22)) &
#    #    (SBIN5Min['SMA-C-10'].shift(23)>SBIN5Min['SMA-C-21'].shift(23)) &
#    #    (SBIN5Min['SMA-C-10'].shift(24)>SBIN5Min['SMA-C-21'].shift(24)) &
#    #    (SBIN5Min['SMA-C-10'].shift(25)>SBIN5Min['SMA-C-21'].shift(25)) &
#    #    (SBIN5Min['SMA-C-10'].shift(26)>SBIN5Min['SMA-C-21'].shift(26))  &
#    #    (SBIN5Min['SMA-C-150'].shift(20)<SBIN5Min['SMA-C-21'].shift(20)) &
#    #    (SBIN5Min['SMA-C-150'].shift(21)<SBIN5Min['SMA-C-21'].shift(21)) &
#    #    (SBIN5Min['SMA-C-150'].shift(22)<SBIN5Min['SMA-C-21'].shift(22)) &
#    #    (SBIN5Min['SMA-C-150'].shift(23)<SBIN5Min['SMA-C-21'].shift(23)) &
#    #    (SBIN5Min['SMA-C-150'].shift(24)<SBIN5Min['SMA-C-21'].shift(24)) &
#    #    (SBIN5Min['SMA-C-150'].shift(25)<SBIN5Min['SMA-C-21'].shift(25)) &
#    #    (SBIN5Min['SMA-C-150'].shift(26)<SBIN5Min['SMA-C-21'].shift(26)) 
#    
#     )
#    # |
#    # (
#    #    (SBIN5Min['SMA-C-10'].shift(1)<SBIN5Min['SMA-C-21'].shift(1)) &
#    #    (SBIN5Min['SMA-C-10'].shift(2)<SBIN5Min['SMA-C-21'].shift(2)) &
#    #    (SBIN5Min['SMA-C-10'].shift(3)<SBIN5Min['SMA-C-21'].shift(3)) &
#    #    (SBIN5Min['SMA-C-10'].shift(4)<SBIN5Min['SMA-C-21'].shift(4)) &
#    #    (SBIN5Min['SMA-C-10'].shift(5)<SBIN5Min['SMA-C-21'].shift(5)) &
#    #    (SBIN5Min['SMA-C-10'].shift(6)<SBIN5Min['SMA-C-21'].shift(6)) &
#    #    (SBIN5Min['SMA-C-10'].shift(7)<SBIN5Min['SMA-C-21'].shift(7)) &
#    #    (SBIN5Min['SMA-C-10'].shift(8)<SBIN5Min['SMA-C-21'].shift(8)) &
#    #    (SBIN5Min['SMA-C-10'].shift(9)<SBIN5Min['SMA-C-21'].shift(9)) &
#    #    (SBIN5Min['SMA-C-10'].shift(10)<SBIN5Min['SMA-C-21'].shift(10)) &
#    #    (SBIN5Min['SMA-C-10'].shift(11)<SBIN5Min['SMA-C-21'].shift(11)) &
#    #    (SBIN5Min['SMA-C-10'].shift(12)<SBIN5Min['SMA-C-21'].shift(12)) &
#    #    (SBIN5Min['SMA-C-10'].shift(13)<SBIN5Min['SMA-C-21'].shift(13)) &
#    #    (SBIN5Min['SMA-C-10'].shift(14)<SBIN5Min['SMA-C-21'].shift(14)) &
#    #    (SBIN5Min['SMA-C-10'].shift(15)<SBIN5Min['SMA-C-21'].shift(15)) &
#    #    (SBIN5Min['SMA-C-10'].shift(16)<SBIN5Min['SMA-C-21'].shift(16)) &
#    #    (SBIN5Min['SMA-C-10'].shift(17)<SBIN5Min['SMA-C-21'].shift(17)) &
#    #    (SBIN5Min['SMA-C-10'].shift(18)<SBIN5Min['SMA-C-21'].shift(18)) &
#    #    (SBIN5Min['SMA-C-10'].shift(19)<SBIN5Min['SMA-C-21'].shift(19)) &
#    #    (SBIN5Min['SMA-C-10'].shift(20)<SBIN5Min['SMA-C-21'].shift(20)) &
#    #    (SBIN5Min['SMA-C-10'].shift(21)<SBIN5Min['SMA-C-21'].shift(21)) &
#    #    (SBIN5Min['SMA-C-10'].shift(22)<SBIN5Min['SMA-C-21'].shift(22)) &
#    #    (SBIN5Min['SMA-C-10'].shift(23)<SBIN5Min['SMA-C-21'].shift(23)) &
#    #    (SBIN5Min['SMA-C-10'].shift(24)<SBIN5Min['SMA-C-21'].shift(24)) &
#    #    (SBIN5Min['SMA-C-10'].shift(25)<SBIN5Min['SMA-C-21'].shift(25)) &
#    #    (SBIN5Min['SMA-C-10'].shift(26)<SBIN5Min['SMA-C-21'].shift(26)) 
#    # )
#    ) &
#     
#                   (SBIN5Min['SMA-C-10']>SBIN5Min['SMA-C-21']) &
#                   (SBIN5Min['RSI14']>=67) & 
#                   (SBIN5Min['RSI14'].shift(1)<SBIN5Min['RSI14']) & 
#                   #(SBIN5Min['RSI14'].shift(2)<SBIN5Min['RSI14'].shift(1)) &
#    #              (SBIN5Min['SMA-C-10'].shift(1)>SBIN5Min['SMA-C-21'].shift(1)) &
#                    (SBIN5Min['Indx']<=24) 
#                    )
#            ]
#    #[['Date','Open','High','Low','Close','DayOpen','HA_Close', 'HA_Open','RSI14',
#    #       'HA_High', 'HA_Low','CDayHigh','CDayLow','SMA-C-21','SMA-C-10','SMA-C-21-1','SMA-C-10-1','PDayClose', 'PDayOpen']]
#    IntraDayBuy['PPER']=round((IntraDayBuy['PDayClose']-IntraDayBuy['PDayOpen']+0.00001)/IntraDayBuy['PDayOpen']*100,2)
#    IntraDayBuy['SMADIFF']=round((IntraDayBuy['SMA-C-10']-IntraDayBuy['SMA-C-21']+0.00001)/IntraDayBuy['SMA-C-21']*10000)
#    IntraDayBuy['Stock']=Stock
    #SBIN5Min['Stock']=Stock
    SBIN5Min['PDAYCLOSEDIFF']=round((SBIN5Min['PDayClose']-SBIN5Min['Close'].shift(1))/SBIN5Min['Close'].shift(1)*100,2)
    SBIN5Min['GAPDIFF']=round((SBIN5Min['Open']-SBIN5Min['PDayClose'])/SBIN5Min['PDayClose']*100,2)
    return SBIN5Min

def Phase1(TargetDir,StockList):
    #print(len(StockList))
    Convert(DataDir,StockList)
    ExtractData(TargetDir,StockList)
    CDayDF=pd.read_csv(TargetDir+"day.csv")
    CMinDF=pd.read_csv(TargetDir+"15minute.csv")
    ### Extracting it from BhavCopy    
    CDayDF1=CDayDF[CDayDF['Date']!=CDayDF.iloc[-1]['Date']]
    CDayDF2=CDayDF[CDayDF['Date']==CDayDF.iloc[-1]['Date']]
    LastClose=pd.read_csv(LASTEODFILE)
    LastClose1=LastClose[LastClose['SERIES']=='EQ'][['SYMBOL','CLOSE','LAST']]
    LastClose1.columns=['Stock','Close1', 'Last']

    T=CDayDF2.merge(LastClose1,on=['Stock'],how="left")
    Null=T[T['Last'].isnull()]    
    NotNull=T[T['Last'].isnull()==False]
    NotNull['close']=NotNull['Close1']
    CDayDF2=NotNull.append(Null)
    CDayDF2.drop(['Close1','Last'],axis=1,inplace=True)
    #del CDayDF2['C]
    #CDayDF2=CDayDF2.drop(CDayDF2.ix[:, 'Close1':'Last'].columns, axis = 1)
    CDayDF=CDayDF1.append(CDayDF2)
    CDayDF.to_csv(TargetDir+"day.csv",sep=',',encoding='utf-8',index=False)
    DayStockNameGroup=CDayDF.groupby('Stock')
    MinStockNameGroup=CMinDF.groupby('Stock')
    i=0
    First=True
    while(i<len(StockList)):
    #if(True):
        Stock=StockList.iloc[i]['StockName']
        i=i+1
        #print("********** "+Stock+" *********")
        Temp=PrStock(Stock,MinStockNameGroup.get_group(Stock),DayStockNameGroup.get_group(Stock))
        if(First):
            DataWithMetrics=Temp                
            #CDayDF=DayDFExt
        else:
            DataWithMetrics=DataWithMetrics.append(Temp)
            #CDayDF=CDayDF.append(DayDFExt)
        First=False
    DataWithMetrics.to_csv(TargetDir+"DataWithMetrics.csv",sep=',',encoding='utf-8',index=False)

def Phase2(TargetDir):
    global CDayDF,CMinDF,DayStockNameGroup,MinStockNameGroup,DataWithMetrics
    CDayDF=pd.read_csv(TargetDir+"day.csv")
    CMinDF=pd.read_csv(TargetDir+"15minute.csv")
    DayStockNameGroup=CDayDF.groupby('Stock')
    MinStockNameGroup=CMinDF.groupby('Stock')
    DataWithMetrics=pd.read_csv(TargetDir+"DataWithMetrics.csv")

def Phase3(TargetDir,StockList):
    global Csud,Csdu,Csud2,Csdu2,TempA,ABuy_StockUGapDown,ASell_StockDGapUp
    global Csud0,Csdu0,Csud00,Csdu00,CStockDownGapUP00,CStockUPGapDown00
     
    CStock=list(StockList.StockName)
    StartTime=datetime.now()
    PreOpenLen=0
    while (PreOpenLen==0):
        time.sleep(5)
        PreOpen=getLatestPreOpenPrice()
        PreOpenLen=len(PreOpen[PreOpen['lastPrice']>50])        
    #print("Hello")    
    PreOpen.to_csv(r"C:\ReadMoneycontrol\Mani 2.0\GapUpStrategy\Data\PreOpen-"+PreOpen['CDATE'].iloc[0]+".csv",sep=',',encoding='utf-8',index=False)
    PreOpen=PreOpen[PreOpen['lastPrice']>50]
    PreOpenSymbol=list(PreOpen.symbol)
    FinalSymbolList=list(set(CStock)  & set(PreOpenSymbol))
    print("Download Completed: " + str((datetime.now()-StartTime).seconds))
    Date1=PreOpen['Date'].iloc[0]
    CDATE=PreOpen['CDATE'].iloc[0]
    i=0
    First=True
    while(i<len(FinalSymbolList)):
    #while(i<len(StockList)):
    #if(True):
        Stock=FinalSymbolList[i]
        #Stock=StockList.iloc[i]['StockName']
        i=i+1
        #print("********** "+Stock+" *********")
        #Open=DataWithMetrics[DataWithMetrics['Stock']==Stock][-25:][:1]['Open'].iloc[0]
        Open=PreOpen[PreOpen['symbol']==Stock]['lastPrice'].iloc[0]
        #Open=
        #Date=parse('24-01-2020 09:15:00')
        Date=Date1
        DfStruct={}
        DfStruct['Date']=Date
        DfStruct['open']=Open
        DfStruct['high']=Open
        DfStruct['low']=Open
        DfStruct['close']=Open
        DfStruct['V']=0
        DfStruct['Stock']=Stock
        DFar=[]      
        DFar.append(DfStruct)
        
        
        
        #FilteredMin=MinStockNameGroup.get_group(Stock)[-25:].append(pd.DataFrame(DFar)[['Date','open','high','low','close','V','Stock']])
        FilteredMin=MinStockNameGroup.get_group(Stock)[-25:].append(pd.DataFrame(DFar)[['Date','open','high','low','close','V','Stock']])
        #FilteredMin=MinStockNameGroup.get_group(Stock)[-25:].append(pd.DataFrame(DFar)[['Date','open','high','low','close','V','Stock']])
        FilteredMin['Date']=pd.to_datetime(FilteredMin['Date'])
        #FilteredMin[FilteredMin['Date']<=parse('27-Jan-2020 15:15')]
        FilteredMin[FilteredMin['Date']<=parse(DayStockNameGroup.get_group(Stock)['Date'].iloc[-1]+' 15:15')]
        #FilteredMin['CDATE']=pd.to_datetime(FilteredMin['Date']).dt.strftime("%Y-%b-%d")        
        #FilteredMin['Indx']=((FilteredMin['Date']-pd.to_datetime(pd.to_datetime(FilteredMin['CDATE']).dt.strftime("%Y-%m-%d 09:15"))).dt.seconds/60/15).astype(int)
        #FilteredMin=MinStockNameGroup.get_group(Stock)[:-25][-25:].append(pd.DataFrame(DFar)[['Date','open','high','low','close','V','Stock']])
        FilteredMin.reset_index(drop = True,inplace=True)
        #FilteredDay=DayStockNameGroup.get_group(Stock)[-50:-25].append(pd.DataFrame(DFar)[['Date','open','high','low','close','V','Stock']])
        FilteredDay=DayStockNameGroup.get_group(Stock).append(pd.DataFrame(DFar)[['Date','open','high','low','close','V','Stock']])
        Temp=PrStock(Stock,FilteredMin,FilteredDay)
    
    #    Temp=PrStock(Stock,MinStockNameGroup.get_group(Stock),DayStockNameGroup.get_group(Stock))
        if(First):
            DataWithMetrics1=Temp[-1:]                
            #CDayDF=DayDFExt
        else:
            DataWithMetrics1=DataWithMetrics1.append(Temp[-1:])
            #CDayDF=CDayDF.append(DayDFExt)
        First=False
    
    #DataWithMetrics.CDATE.unique()
    
    #Result=DataWithMetrics[DataWithMetrics['CDATE']!='2020-Jan-28'].append(DataWithMetrics1)
    Result=DataWithMetrics.append(DataWithMetrics1)
    Result['GAP']=Result['GAPDIFF']+Result['PDAYCLOSEDIFF']
    i=0
    First=True
    while(i<len(FinalSymbolList)):
    #if(True):
        Stock=FinalSymbolList[i]
        i=i+1
       # print("********** "+Stock+" *********")
        SBIN5Min=Result[Result['Stock']==Stock]
        StockDownGapUP1=SBIN5Min[     (
            (SBIN5Min['SMA-C-10'].shift(1)<SBIN5Min['SMA-C-21'].shift(1)) &
            (SBIN5Min['SMA-C-10'].shift(2)<SBIN5Min['SMA-C-21'].shift(2)) &
            (SBIN5Min['SMA-C-10'].shift(3)<SBIN5Min['SMA-C-21'].shift(3)) &
            (SBIN5Min['SMA-C-10'].shift(4)<SBIN5Min['SMA-C-21'].shift(4)) &
            (SBIN5Min['SMA-C-10'].shift(5)<SBIN5Min['SMA-C-21'].shift(5)) &
            (SBIN5Min['SMA-C-10'].shift(6)<SBIN5Min['SMA-C-21'].shift(6)) &
            (SBIN5Min['SMA-C-10'].shift(7)<SBIN5Min['SMA-C-21'].shift(7)) &
            (SBIN5Min['SMA-C-10'].shift(8)<SBIN5Min['SMA-C-21'].shift(8)) &
            (SBIN5Min['SMA-C-10'].shift(9)<SBIN5Min['SMA-C-21'].shift(9)) &
    #        (SBIN5Min['Open']>SBIN5Min['SMA-C-150']) &
    #        (SBIN5Min['Open'].shift(1)<SBIN5Min['SMA-C-150'].shift(1)) &
    #        
            (SBIN5Min['Indx']==0) &
            (SBIN5Min['PDayClose']<SBIN5Min['Open']) &
           # ((SBIN5Min['Open']-SBIN5Min['PDayClose'])/SBIN5Min['PDayClose']*100>1)
           ((SBIN5Min['GAPDIFF']>1) | (SBIN5Min['PDAYCLOSEDIFF']>.5) | (SBIN5Min['PDAYCLOSEDIFF']<-.5))
        )]
        
        StockDownGapUP0=SBIN5Min[     (
            (SBIN5Min['SMA-C-10'].shift(1)<SBIN5Min['SMA-C-21'].shift(1)) &
            (SBIN5Min['SMA-C-10'].shift(2)<SBIN5Min['SMA-C-21'].shift(2)) &
            (SBIN5Min['SMA-C-10'].shift(3)<SBIN5Min['SMA-C-21'].shift(3)) &
            (SBIN5Min['SMA-C-10'].shift(4)<SBIN5Min['SMA-C-21'].shift(4)) &
            (SBIN5Min['SMA-C-10'].shift(5)<SBIN5Min['SMA-C-21'].shift(5)) &
            (SBIN5Min['SMA-C-10'].shift(6)<SBIN5Min['SMA-C-21'].shift(6)) &
            (SBIN5Min['SMA-C-10'].shift(7)<SBIN5Min['SMA-C-21'].shift(7)) &
            (SBIN5Min['SMA-C-10'].shift(8)<SBIN5Min['SMA-C-21'].shift(8)) &
            (SBIN5Min['SMA-C-10'].shift(9)<SBIN5Min['SMA-C-21'].shift(9)) &
            (SBIN5Min['SMA-C-10'].shift(10)<SBIN5Min['SMA-C-21'].shift(10)) &
            (SBIN5Min['SMA-C-10'].shift(11)<SBIN5Min['SMA-C-21'].shift(11)) &
            (SBIN5Min['SMA-C-10'].shift(12)<SBIN5Min['SMA-C-21'].shift(12)) &
            (SBIN5Min['SMA-C-10'].shift(13)<SBIN5Min['SMA-C-21'].shift(13)) &
            (SBIN5Min['SMA-C-21'].shift(1)<SBIN5Min['EMA-C-50'].shift(1)) &
            (SBIN5Min['SMA-C-21'].shift(2)<SBIN5Min['EMA-C-50'].shift(2)) &
            (SBIN5Min['SMA-C-21'].shift(3)<SBIN5Min['EMA-C-50'].shift(3)) &
            (SBIN5Min['SMA-C-21'].shift(4)<SBIN5Min['EMA-C-50'].shift(4)) &
            (SBIN5Min['SMA-C-21'].shift(5)<SBIN5Min['EMA-C-50'].shift(5)) &
            (SBIN5Min['SMA-C-21'].shift(6)<SBIN5Min['EMA-C-50'].shift(6)) &
            (SBIN5Min['SMA-C-21'].shift(7)<SBIN5Min['EMA-C-50'].shift(7)) &
            (SBIN5Min['SMA-C-21'].shift(8)<SBIN5Min['EMA-C-50'].shift(8)) &
            (SBIN5Min['SMA-C-21'].shift(9)<SBIN5Min['EMA-C-50'].shift(9)) &
            (SBIN5Min['SMA-C-21'].shift(10)<SBIN5Min['EMA-C-50'].shift(10)) &
            (SBIN5Min['SMA-C-21'].shift(11)<SBIN5Min['EMA-C-50'].shift(11)) &
            (SBIN5Min['SMA-C-21'].shift(12)<SBIN5Min['EMA-C-50'].shift(12)) &
            (SBIN5Min['SMA-C-21'].shift(13)<SBIN5Min['EMA-C-50'].shift(13)) &
    #        (SBIN5Min['Open']>SBIN5Min['SMA-C-150']) &
    #        (SBIN5Min['Open'].shift(1)<SBIN5Min['SMA-C-150'].shift(1)) &
    #        
            (SBIN5Min['Indx']==0) 
            
        )]
        
        StockDownGapUP00=SBIN5Min[     (
                (SBIN5Min['SMA-C-10'].shift(1)<SBIN5Min['SMA-C-21'].shift(1)) &
                (SBIN5Min['SMA-C-21'].shift(1)<SBIN5Min['EMA-C-50'].shift(1)) &
                (SBIN5Min['SMA-C-10'].shift(2)<SBIN5Min['SMA-C-21'].shift(2)) &
                (SBIN5Min['SMA-C-21'].shift(2)<SBIN5Min['EMA-C-50'].shift(2)) &
                (SBIN5Min['SMA-C-10'].shift(3)<SBIN5Min['SMA-C-21'].shift(3)) &
                (SBIN5Min['SMA-C-21'].shift(3)<SBIN5Min['EMA-C-50'].shift(3)) &
                (SBIN5Min['SMA-C-10'].shift(4)<SBIN5Min['SMA-C-21'].shift(4)) &
                (SBIN5Min['SMA-C-21'].shift(4)<SBIN5Min['EMA-C-50'].shift(4)) &
                (SBIN5Min['SMA-C-10'].shift(5)<SBIN5Min['SMA-C-21'].shift(5)) &
                (SBIN5Min['SMA-C-21'].shift(5)<SBIN5Min['EMA-C-50'].shift(5)) &
                (SBIN5Min['SMA-C-10'].shift(6)<SBIN5Min['SMA-C-21'].shift(6)) &
                (SBIN5Min['SMA-C-21'].shift(6)<SBIN5Min['EMA-C-50'].shift(6)) &
                (SBIN5Min['SMA-C-10'].shift(7)<SBIN5Min['SMA-C-21'].shift(7)) &
                (SBIN5Min['SMA-C-21'].shift(7)<SBIN5Min['EMA-C-50'].shift(7)) &
                (SBIN5Min['SMA-C-10'].shift(8)<SBIN5Min['SMA-C-21'].shift(8)) &
                (SBIN5Min['SMA-C-21'].shift(8)<SBIN5Min['EMA-C-50'].shift(8)) &
                (SBIN5Min['SMA-C-10'].shift(9)<SBIN5Min['SMA-C-21'].shift(9)) &
                (SBIN5Min['SMA-C-21'].shift(9)<SBIN5Min['EMA-C-50'].shift(9)) &
                (SBIN5Min['SMA-C-10'].shift(10)<SBIN5Min['SMA-C-21'].shift(10)) &
                (SBIN5Min['SMA-C-21'].shift(10)<SBIN5Min['EMA-C-50'].shift(10)) &
                (SBIN5Min['SMA-C-10'].shift(11)<SBIN5Min['SMA-C-21'].shift(11)) &
                (SBIN5Min['SMA-C-21'].shift(11)<SBIN5Min['EMA-C-50'].shift(11)) &
                (SBIN5Min['SMA-C-10'].shift(12)<SBIN5Min['SMA-C-21'].shift(12)) &
                (SBIN5Min['SMA-C-21'].shift(12)<SBIN5Min['EMA-C-50'].shift(12)) &
                (SBIN5Min['SMA-C-10'].shift(13)<SBIN5Min['SMA-C-21'].shift(13)) &
                (SBIN5Min['SMA-C-21'].shift(13)<SBIN5Min['EMA-C-50'].shift(13)) &
                (SBIN5Min['SMA-C-10'].shift(14)<SBIN5Min['SMA-C-21'].shift(14)) &
                (SBIN5Min['SMA-C-21'].shift(14)<SBIN5Min['EMA-C-50'].shift(14)) &
                (SBIN5Min['SMA-C-10'].shift(15)<SBIN5Min['SMA-C-21'].shift(15)) &
                (SBIN5Min['SMA-C-21'].shift(15)<SBIN5Min['EMA-C-50'].shift(15)) &
                (SBIN5Min['SMA-C-10'].shift(16)<SBIN5Min['SMA-C-21'].shift(16)) &
                (SBIN5Min['SMA-C-21'].shift(16)<SBIN5Min['EMA-C-50'].shift(16)) &
                (SBIN5Min['SMA-C-10'].shift(17)<SBIN5Min['SMA-C-21'].shift(17)) &
                (SBIN5Min['SMA-C-21'].shift(17)<SBIN5Min['EMA-C-50'].shift(17)) &
                (SBIN5Min['SMA-C-10'].shift(18)<SBIN5Min['SMA-C-21'].shift(18)) &
                (SBIN5Min['SMA-C-21'].shift(18)<SBIN5Min['EMA-C-50'].shift(18)) &
                (SBIN5Min['SMA-C-10'].shift(19)<SBIN5Min['SMA-C-21'].shift(19)) &
                (SBIN5Min['SMA-C-21'].shift(19)<SBIN5Min['EMA-C-50'].shift(19)) &
                (SBIN5Min['SMA-C-10'].shift(20)<SBIN5Min['SMA-C-21'].shift(20)) &
                (SBIN5Min['SMA-C-21'].shift(20)<SBIN5Min['EMA-C-50'].shift(20)) &
                (SBIN5Min['SMA-C-10'].shift(21)<SBIN5Min['SMA-C-21'].shift(21)) &
                (SBIN5Min['SMA-C-21'].shift(21)<SBIN5Min['EMA-C-50'].shift(21)) &
                (SBIN5Min['SMA-C-10'].shift(22)<SBIN5Min['SMA-C-21'].shift(22)) &
                (SBIN5Min['SMA-C-21'].shift(22)<SBIN5Min['EMA-C-50'].shift(22)) &
                (SBIN5Min['SMA-C-10'].shift(23)<SBIN5Min['SMA-C-21'].shift(23)) &
                (SBIN5Min['SMA-C-21'].shift(23)<SBIN5Min['EMA-C-50'].shift(23)) &
                (SBIN5Min['SMA-C-10'].shift(24)<SBIN5Min['SMA-C-21'].shift(24)) &
                (SBIN5Min['SMA-C-21'].shift(24)<SBIN5Min['EMA-C-50'].shift(24)) &
                (SBIN5Min['SMA-C-10'].shift(25)<SBIN5Min['SMA-C-21'].shift(25)) &
                (SBIN5Min['SMA-C-21'].shift(25)<SBIN5Min['EMA-C-50'].shift(25)) &
                (SBIN5Min['SMA-C-10'].shift(26)<SBIN5Min['SMA-C-21'].shift(26)) &
                (SBIN5Min['SMA-C-21'].shift(26)<SBIN5Min['EMA-C-50'].shift(26)) &
                (SBIN5Min['SMA-C-10'].shift(27)<SBIN5Min['SMA-C-21'].shift(27)) &
                (SBIN5Min['SMA-C-21'].shift(27)<SBIN5Min['EMA-C-50'].shift(27)) &
                (SBIN5Min['SMA-C-10'].shift(28)<SBIN5Min['SMA-C-21'].shift(28)) &
                (SBIN5Min['SMA-C-21'].shift(28)<SBIN5Min['EMA-C-50'].shift(28)) &
                (SBIN5Min['SMA-C-10'].shift(29)<SBIN5Min['SMA-C-21'].shift(29)) &
                (SBIN5Min['SMA-C-21'].shift(29)<SBIN5Min['EMA-C-50'].shift(29)) &
                (SBIN5Min['SMA-C-10'].shift(30)<SBIN5Min['SMA-C-21'].shift(30)) &
                (SBIN5Min['SMA-C-21'].shift(30)<SBIN5Min['EMA-C-50'].shift(30)) &
                (SBIN5Min['Indx']==0) 
            )]
        #[['Date','Stock','PDAYCLOSEDIFF','GAPDIFF','HighFib','Open','H4', 'H3A', 'H3', 'H2A', 'H2','H1', 'IPivot-H', 'IPivot', 'IPivot-L','L1', 'L2', 'L2A', 'L3', 'L3A', 'L4','RH1_R', 'RH2A_R', 'RH2_R', 'RH3A_R', 'RH3_R', 'RH4_R', 'RIP-H_R', 'RIP-L_R', 'RIPivot_R', 'RL1_R', 'RL2A_R', 'RL2_R', 'RL3A_R', 'RL3_R', 'RL4_R']]
        StockDownGapUP2=SBIN5Min[     (
    #        (SBIN5Min['SMA-C-10'].shift(1)<SBIN5Min['SMA-C-21'].shift(1)) &
    #        (SBIN5Min['SMA-C-10'].shift(2)<SBIN5Min['SMA-C-21'].shift(2)) &
    #        (SBIN5Min['SMA-C-10'].shift(3)<SBIN5Min['SMA-C-21'].shift(3)) &
    #        (SBIN5Min['SMA-C-10'].shift(4)<SBIN5Min['SMA-C-21'].shift(4)) &
    #        (SBIN5Min['SMA-C-10'].shift(5)<SBIN5Min['SMA-C-21'].shift(5)) &
    #        (SBIN5Min['SMA-C-10'].shift(6)<SBIN5Min['SMA-C-21'].shift(6)) &
    #        (SBIN5Min['SMA-C-10'].shift(7)<SBIN5Min['SMA-C-21'].shift(7)) &
    #        (SBIN5Min['SMA-C-10'].shift(8)<SBIN5Min['SMA-C-21'].shift(8)) &
    #        (SBIN5Min['SMA-C-10'].shift(9)<SBIN5Min['SMA-C-21'].shift(9)) &
    ##        (SBIN5Min['Open']>SBIN5Min['SMA-C-150']) &
    ##        (SBIN5Min['Open'].shift(1)<SBIN5Min['SMA-C-150'].shift(1)) &
    ##        
            (SBIN5Min['Indx']==0) &
            (SBIN5Min['PDayClose']<SBIN5Min['Open']) &
           # ((SBIN5Min['Open']-SBIN5Min['PDayClose'])/SBIN5Min['PDayClose']*100>1)
           ((SBIN5Min['GAPDIFF']>1) | (SBIN5Min['PDAYCLOSEDIFF']>.5) | (SBIN5Min['PDAYCLOSEDIFF']<-.5))
        )]
    
        StockUPGapDown1=SBIN5Min[     (
            (SBIN5Min['SMA-C-10'].shift(1)>SBIN5Min['SMA-C-21'].shift(1)) &
            (SBIN5Min['SMA-C-10'].shift(2)>SBIN5Min['SMA-C-21'].shift(2)) &
            (SBIN5Min['SMA-C-10'].shift(3)>SBIN5Min['SMA-C-21'].shift(3)) &
            (SBIN5Min['SMA-C-10'].shift(4)>SBIN5Min['SMA-C-21'].shift(4)) &
            (SBIN5Min['SMA-C-10'].shift(5)>SBIN5Min['SMA-C-21'].shift(5)) &
            (SBIN5Min['SMA-C-10'].shift(6)>SBIN5Min['SMA-C-21'].shift(6)) &
            (SBIN5Min['SMA-C-10'].shift(7)>SBIN5Min['SMA-C-21'].shift(7)) &
            (SBIN5Min['SMA-C-10'].shift(8)>SBIN5Min['SMA-C-21'].shift(8)) &
            (SBIN5Min['SMA-C-10'].shift(9)>SBIN5Min['SMA-C-21'].shift(9)) &
            
            (SBIN5Min['Indx']==0) &
            (SBIN5Min['PDayClose']>SBIN5Min['Open']) &
           # ((SBIN5Min['PDayClose']-SBIN5Min['Open'])/SBIN5Min['Open']*100>1)
           ((SBIN5Min['GAPDIFF']<-1) | (SBIN5Min['PDAYCLOSEDIFF']>.5) | (SBIN5Min['PDAYCLOSEDIFF']<-.5))
        )]
        
        StockUPGapDown0=SBIN5Min[     (
            (SBIN5Min['SMA-C-10'].shift(1)>SBIN5Min['SMA-C-21'].shift(1)) &
            (SBIN5Min['SMA-C-10'].shift(2)>SBIN5Min['SMA-C-21'].shift(2)) &
            (SBIN5Min['SMA-C-10'].shift(3)>SBIN5Min['SMA-C-21'].shift(3)) &
            (SBIN5Min['SMA-C-10'].shift(4)>SBIN5Min['SMA-C-21'].shift(4)) &
            (SBIN5Min['SMA-C-10'].shift(5)>SBIN5Min['SMA-C-21'].shift(5)) &
            (SBIN5Min['SMA-C-10'].shift(6)>SBIN5Min['SMA-C-21'].shift(6)) &
            (SBIN5Min['SMA-C-10'].shift(7)>SBIN5Min['SMA-C-21'].shift(7)) &
            (SBIN5Min['SMA-C-10'].shift(8)>SBIN5Min['SMA-C-21'].shift(8)) &
            (SBIN5Min['SMA-C-10'].shift(9)>SBIN5Min['SMA-C-21'].shift(9)) &
            (SBIN5Min['SMA-C-10'].shift(10)>SBIN5Min['SMA-C-21'].shift(10)) &
            (SBIN5Min['SMA-C-10'].shift(11)>SBIN5Min['SMA-C-21'].shift(11)) &
            (SBIN5Min['SMA-C-10'].shift(12)>SBIN5Min['SMA-C-21'].shift(12)) &
            (SBIN5Min['SMA-C-10'].shift(13)>SBIN5Min['SMA-C-21'].shift(13)) &
            (SBIN5Min['SMA-C-21'].shift(1)>SBIN5Min['EMA-C-50'].shift(1)) &
            (SBIN5Min['SMA-C-21'].shift(2)>SBIN5Min['EMA-C-50'].shift(2)) &
            (SBIN5Min['SMA-C-21'].shift(3)>SBIN5Min['EMA-C-50'].shift(3)) &
            (SBIN5Min['SMA-C-21'].shift(4)>SBIN5Min['EMA-C-50'].shift(4)) &
            (SBIN5Min['SMA-C-21'].shift(5)>SBIN5Min['EMA-C-50'].shift(5)) &
            (SBIN5Min['SMA-C-21'].shift(6)>SBIN5Min['EMA-C-50'].shift(6)) &
            (SBIN5Min['SMA-C-21'].shift(7)>SBIN5Min['EMA-C-50'].shift(7)) &
            (SBIN5Min['SMA-C-21'].shift(8)>SBIN5Min['EMA-C-50'].shift(8)) &
            (SBIN5Min['SMA-C-21'].shift(9)>SBIN5Min['EMA-C-50'].shift(9)) &
            (SBIN5Min['SMA-C-21'].shift(10)>SBIN5Min['EMA-C-50'].shift(10)) &
            (SBIN5Min['SMA-C-21'].shift(11)>SBIN5Min['EMA-C-50'].shift(11)) &
            (SBIN5Min['SMA-C-21'].shift(12)>SBIN5Min['EMA-C-50'].shift(12)) &
            (SBIN5Min['SMA-C-21'].shift(13)>SBIN5Min['EMA-C-50'].shift(13)) &
            
            (SBIN5Min['Indx']==0) 
#            &
#            (SBIN5Min['PDayClose']>SBIN5Min['Open']) &
#           # ((SBIN5Min['PDayClose']-SBIN5Min['Open'])/SBIN5Min['Open']*100>1)
#           ((SBIN5Min['GAPDIFF']<-1) | (SBIN5Min['PDAYCLOSEDIFF']>.5) | (SBIN5Min['PDAYCLOSEDIFF']<-.5))
        )]
        
        StockUPGapDown00=SBIN5Min[     (
                (SBIN5Min['SMA-C-10'].shift(1)>SBIN5Min['SMA-C-21'].shift(1)) &
                (SBIN5Min['SMA-C-21'].shift(1)>SBIN5Min['EMA-C-50'].shift(1)) &
                (SBIN5Min['SMA-C-10'].shift(2)>SBIN5Min['SMA-C-21'].shift(2)) &
                (SBIN5Min['SMA-C-21'].shift(2)>SBIN5Min['EMA-C-50'].shift(2)) &
                (SBIN5Min['SMA-C-10'].shift(3)>SBIN5Min['SMA-C-21'].shift(3)) &
                (SBIN5Min['SMA-C-21'].shift(3)>SBIN5Min['EMA-C-50'].shift(3)) &
                (SBIN5Min['SMA-C-10'].shift(4)>SBIN5Min['SMA-C-21'].shift(4)) &
                (SBIN5Min['SMA-C-21'].shift(4)>SBIN5Min['EMA-C-50'].shift(4)) &
                (SBIN5Min['SMA-C-10'].shift(5)>SBIN5Min['SMA-C-21'].shift(5)) &
                (SBIN5Min['SMA-C-21'].shift(5)>SBIN5Min['EMA-C-50'].shift(5)) &
                (SBIN5Min['SMA-C-10'].shift(6)>SBIN5Min['SMA-C-21'].shift(6)) &
                (SBIN5Min['SMA-C-21'].shift(6)>SBIN5Min['EMA-C-50'].shift(6)) &
                (SBIN5Min['SMA-C-10'].shift(7)>SBIN5Min['SMA-C-21'].shift(7)) &
                (SBIN5Min['SMA-C-21'].shift(7)>SBIN5Min['EMA-C-50'].shift(7)) &
                (SBIN5Min['SMA-C-10'].shift(8)>SBIN5Min['SMA-C-21'].shift(8)) &
                (SBIN5Min['SMA-C-21'].shift(8)>SBIN5Min['EMA-C-50'].shift(8)) &
                (SBIN5Min['SMA-C-10'].shift(9)>SBIN5Min['SMA-C-21'].shift(9)) &
                (SBIN5Min['SMA-C-21'].shift(9)>SBIN5Min['EMA-C-50'].shift(9)) &
                (SBIN5Min['SMA-C-10'].shift(10)>SBIN5Min['SMA-C-21'].shift(10)) &
                (SBIN5Min['SMA-C-21'].shift(10)>SBIN5Min['EMA-C-50'].shift(10)) &
                (SBIN5Min['SMA-C-10'].shift(11)>SBIN5Min['SMA-C-21'].shift(11)) &
                (SBIN5Min['SMA-C-21'].shift(11)>SBIN5Min['EMA-C-50'].shift(11)) &
                (SBIN5Min['SMA-C-10'].shift(12)>SBIN5Min['SMA-C-21'].shift(12)) &
                (SBIN5Min['SMA-C-21'].shift(12)>SBIN5Min['EMA-C-50'].shift(12)) &
                (SBIN5Min['SMA-C-10'].shift(13)>SBIN5Min['SMA-C-21'].shift(13)) &
                (SBIN5Min['SMA-C-21'].shift(13)>SBIN5Min['EMA-C-50'].shift(13)) &
                (SBIN5Min['SMA-C-10'].shift(14)>SBIN5Min['SMA-C-21'].shift(14)) &
                (SBIN5Min['SMA-C-21'].shift(14)>SBIN5Min['EMA-C-50'].shift(14)) &
                (SBIN5Min['SMA-C-10'].shift(15)>SBIN5Min['SMA-C-21'].shift(15)) &
                (SBIN5Min['SMA-C-21'].shift(15)>SBIN5Min['EMA-C-50'].shift(15)) &
                (SBIN5Min['SMA-C-10'].shift(16)>SBIN5Min['SMA-C-21'].shift(16)) &
                (SBIN5Min['SMA-C-21'].shift(16)>SBIN5Min['EMA-C-50'].shift(16)) &
                (SBIN5Min['SMA-C-10'].shift(17)>SBIN5Min['SMA-C-21'].shift(17)) &
                (SBIN5Min['SMA-C-21'].shift(17)>SBIN5Min['EMA-C-50'].shift(17)) &
                (SBIN5Min['SMA-C-10'].shift(18)>SBIN5Min['SMA-C-21'].shift(18)) &
                (SBIN5Min['SMA-C-21'].shift(18)>SBIN5Min['EMA-C-50'].shift(18)) &
                (SBIN5Min['SMA-C-10'].shift(19)>SBIN5Min['SMA-C-21'].shift(19)) &
                (SBIN5Min['SMA-C-21'].shift(19)>SBIN5Min['EMA-C-50'].shift(19)) &
                (SBIN5Min['SMA-C-10'].shift(20)>SBIN5Min['SMA-C-21'].shift(20)) &
                (SBIN5Min['SMA-C-21'].shift(20)>SBIN5Min['EMA-C-50'].shift(20)) &
                (SBIN5Min['SMA-C-10'].shift(21)>SBIN5Min['SMA-C-21'].shift(21)) &
                (SBIN5Min['SMA-C-21'].shift(21)>SBIN5Min['EMA-C-50'].shift(21)) &
                (SBIN5Min['SMA-C-10'].shift(22)>SBIN5Min['SMA-C-21'].shift(22)) &
                (SBIN5Min['SMA-C-21'].shift(22)>SBIN5Min['EMA-C-50'].shift(22)) &
                (SBIN5Min['SMA-C-10'].shift(23)>SBIN5Min['SMA-C-21'].shift(23)) &
                (SBIN5Min['SMA-C-21'].shift(23)>SBIN5Min['EMA-C-50'].shift(23)) &
                (SBIN5Min['SMA-C-10'].shift(24)>SBIN5Min['SMA-C-21'].shift(24)) &
                (SBIN5Min['SMA-C-21'].shift(24)>SBIN5Min['EMA-C-50'].shift(24)) &
                (SBIN5Min['SMA-C-10'].shift(25)>SBIN5Min['SMA-C-21'].shift(25)) &
                (SBIN5Min['SMA-C-21'].shift(25)>SBIN5Min['EMA-C-50'].shift(25)) &
                (SBIN5Min['SMA-C-10'].shift(26)>SBIN5Min['SMA-C-21'].shift(26)) &
                (SBIN5Min['SMA-C-21'].shift(26)>SBIN5Min['EMA-C-50'].shift(26)) &
                (SBIN5Min['SMA-C-10'].shift(27)>SBIN5Min['SMA-C-21'].shift(27)) &
                (SBIN5Min['SMA-C-21'].shift(27)>SBIN5Min['EMA-C-50'].shift(27)) &
                (SBIN5Min['SMA-C-10'].shift(28)>SBIN5Min['SMA-C-21'].shift(28)) &
                (SBIN5Min['SMA-C-21'].shift(28)>SBIN5Min['EMA-C-50'].shift(28)) &
                (SBIN5Min['SMA-C-10'].shift(29)>SBIN5Min['SMA-C-21'].shift(29)) &
                (SBIN5Min['SMA-C-21'].shift(29)>SBIN5Min['EMA-C-50'].shift(29)) &
                (SBIN5Min['SMA-C-10'].shift(30)>SBIN5Min['SMA-C-21'].shift(30)) &
                (SBIN5Min['SMA-C-21'].shift(30)>SBIN5Min['EMA-C-50'].shift(30)) &
                (SBIN5Min['Indx']==0) 
                )]
            
        StockUPGapDown2=SBIN5Min[     (
    #        (SBIN5Min['SMA-C-10'].shift(1)>SBIN5Min['SMA-C-21'].shift(1)) &
    #        (SBIN5Min['SMA-C-10'].shift(2)>SBIN5Min['SMA-C-21'].shift(2)) &
    #        (SBIN5Min['SMA-C-10'].shift(3)>SBIN5Min['SMA-C-21'].shift(3)) &
    #        (SBIN5Min['SMA-C-10'].shift(4)>SBIN5Min['SMA-C-21'].shift(4)) &
    #        (SBIN5Min['SMA-C-10'].shift(5)>SBIN5Min['SMA-C-21'].shift(5)) &
    #        (SBIN5Min['SMA-C-10'].shift(6)>SBIN5Min['SMA-C-21'].shift(6)) &
    #        (SBIN5Min['SMA-C-10'].shift(7)>SBIN5Min['SMA-C-21'].shift(7)) &
    #        (SBIN5Min['SMA-C-10'].shift(8)>SBIN5Min['SMA-C-21'].shift(8)) &
    #        (SBIN5Min['SMA-C-10'].shift(9)>SBIN5Min['SMA-C-21'].shift(9)) &
    #        
            (SBIN5Min['Indx']==0) &
            (SBIN5Min['PDayClose']>SBIN5Min['Open']) &
           # ((SBIN5Min['PDayClose']-SBIN5Min['Open'])/SBIN5Min['Open']*100>1)
           ((SBIN5Min['GAPDIFF']<-1) | (SBIN5Min['PDAYCLOSEDIFF']>.5) | (SBIN5Min['PDAYCLOSEDIFF']<-.5))
        )]
        TempA=SBIN5Min[(SBIN5Min['Indx']==0)]
        if(First):
            CStockDownGapUP1=StockDownGapUP1
            CStockUPGapDown1=StockUPGapDown1
            CStockDownGapUP0=StockDownGapUP0
            CStockUPGapDown0=StockUPGapDown0
            CStockDownGapUP00=StockDownGapUP00
            CStockUPGapDown00=StockUPGapDown00
            CStockDownGapUP2=StockDownGapUP2
            CStockUPGapDown2=StockUPGapDown2
            CT=TempA
        else:
            CStockDownGapUP1=CStockDownGapUP1.append(StockDownGapUP1)
            CStockUPGapDown1=CStockUPGapDown1.append(StockUPGapDown1)
            CStockDownGapUP0=CStockDownGapUP0.append(StockDownGapUP0)
            CStockUPGapDown0=CStockUPGapDown0.append(StockUPGapDown0)
            CStockDownGapUP00=CStockDownGapUP00.append(StockDownGapUP00)
            CStockUPGapDown00=CStockUPGapDown00.append(StockUPGapDown00)
            CStockDownGapUP2=CStockDownGapUP2.append(StockDownGapUP2)
            CStockUPGapDown2=CStockUPGapDown2.append(StockUPGapDown2)
            CT=CT.append(TempA)
        First=False
        
    
    
    CStockUPGapDown1['Signal']=CStockUPGapDown1.apply(lambda x: CheckPrice(x,"Buy"),axis=1)   
    Csud=CStockUPGapDown1[CStockUPGapDown1['CDATE']==CDATE][['Date','Stock','Signal','GAP','PDayVolume','PDAYCLOSEDIFF','GAPDIFF','PDayClose','HighFib','Open','H4', 'H3A', 'H3', 'H2A', 'H2','H1', 'IPivot-H', 'IPivot', 'IPivot-L','L1', 'L2', 'L2A', 'L3', 'L3A', 'L4']]
    #print("Final : " + str((datetime.now()-StartTime).seconds))
    
    CStockDownGapUP1['Signal']=CStockDownGapUP1.apply(lambda x: CheckPrice(x,"Buy"),axis=1)   
    Csdu=CStockDownGapUP1[CStockDownGapUP1['CDATE']==CDATE][['Date','Stock','Signal','GAP','PDayVolume','PDAYCLOSEDIFF','GAPDIFF','PDayClose','HighFib','Open','H4', 'H3A', 'H3', 'H2A', 'H2','H1', 'IPivot-H', 'IPivot', 'IPivot-L','L1', 'L2', 'L2A', 'L3', 'L3A', 'L4']]
    #print("Final : " + str((datetime.now()-StartTime).seconds))
    
    CStockUPGapDown0['Signal']=CStockUPGapDown0.apply(lambda x: CheckPrice(x,"Buy"),axis=1)   
    Csud0=CStockUPGapDown0[CStockUPGapDown0['CDATE']==CDATE][['Date','Stock','Signal','GAP','PDayVolume','PDAYCLOSEDIFF','GAPDIFF','PDayClose','HighFib','Open','H4', 'H3A', 'H3', 'H2A', 'H2','H1', 'IPivot-H', 'IPivot', 'IPivot-L','L1', 'L2', 'L2A', 'L3', 'L3A', 'L4']]
    #print("Final : " + str((datetime.now()-StartTime).seconds))
    
    CStockDownGapUP0['Signal']=CStockDownGapUP0.apply(lambda x: CheckPrice(x,"Buy"),axis=1)   
    Csdu0=CStockDownGapUP0[CStockDownGapUP0['CDATE']==CDATE][['Date','Stock','Signal','GAP','PDayVolume','PDAYCLOSEDIFF','GAPDIFF','PDayClose','HighFib','Open','H4', 'H3A', 'H3', 'H2A', 'H2','H1', 'IPivot-H', 'IPivot', 'IPivot-L','L1', 'L2', 'L2A', 'L3', 'L3A', 'L4']]
    #print("Final : " + str((datetime.now()-StartTime).seconds))
   
    CStockUPGapDown00['Signal']=CStockUPGapDown00.apply(lambda x: CheckPrice(x,"Buy"),axis=1)   
    Csud00=CStockUPGapDown00[CStockUPGapDown00['CDATE']==CDATE][['Date','Stock','Signal','GAP','PDayVolume','PDAYCLOSEDIFF','GAPDIFF','PDayClose','HighFib','Open','H4', 'H3A', 'H3', 'H2A', 'H2','H1', 'IPivot-H', 'IPivot', 'IPivot-L','L1', 'L2', 'L2A', 'L3', 'L3A', 'L4']]
    #print("Final : " + str((datetime.now()-StartTime).seconds))
    
    CStockDownGapUP00['Signal']=CStockDownGapUP00.apply(lambda x: CheckPrice(x,"Buy"),axis=1)   
    Csdu00=CStockDownGapUP00[CStockDownGapUP00['CDATE']==CDATE][['Date','Stock','Signal','GAP','PDayVolume','PDAYCLOSEDIFF','GAPDIFF','PDayClose','HighFib','Open','H4', 'H3A', 'H3', 'H2A', 'H2','H1', 'IPivot-H', 'IPivot', 'IPivot-L','L1', 'L2', 'L2A', 'L3', 'L3A', 'L4']]
    #print("Final : " + str((datetime.now()-StartTime).seconds))
    
    CStockUPGapDown2['Signal']=CStockUPGapDown2.apply(lambda x: CheckPrice(x,"Buy"),axis=1)   
    Csud2=CStockUPGapDown2[CStockUPGapDown2['CDATE']==CDATE][['Date','Stock','Signal','GAP','PDayVolume','PDAYCLOSEDIFF','GAPDIFF','PDayClose','HighFib','Open','H4', 'H3A', 'H3', 'H2A', 'H2','H1', 'IPivot-H', 'IPivot', 'IPivot-L','L1', 'L2', 'L2A', 'L3', 'L3A', 'L4']]
    #print("Final : " + str((datetime.now()-StartTime).seconds))
    
    CStockDownGapUP2['Signal']=CStockDownGapUP2.apply(lambda x: CheckPrice(x,"Buy"),axis=1)   
    Csdu2=CStockDownGapUP2[CStockDownGapUP2['CDATE']==CDATE][['Date','Stock','Signal','GAP','PDayVolume','PDAYCLOSEDIFF','GAPDIFF','PDayClose','HighFib','Open','H4', 'H3A', 'H3', 'H2A', 'H2','H1', 'IPivot-H', 'IPivot', 'IPivot-L','L1', 'L2', 'L2A', 'L3', 'L3A', 'L4']]
    
    
    CT['Signal']=CT.apply(lambda x: CheckPrice(x,"Buy"),axis=1)   
    TempA=CT[CT['CDATE']==CDATE][['Date','Stock','Signal','GAP','PDayVolume','PDAYCLOSEDIFF','GAPDIFF','PDayClose','HighFib','Open','H4', 'H3A', 'H3', 'H2A', 'H2','H1', 'IPivot-H', 'IPivot', 'IPivot-L','L1', 'L2', 'L2A', 'L3', 'L3A', 'L4']]
    
    ABuy_StockUGapDown=Csud[(Csud['GAP']<-.5)]# & (Csud['PDAYCLOSEDIFF']<.5)]
    ASell_StockDGapUp=Csdu[(Csdu['GAP']>.5)]# & (Csud['PDAYCLOSEDIFF']<.5)]
    
if(False):
#    if(False):
#        Convert(DataDir)
#        ExtractData()
    CDayDF=pd.read_csv(r"C:\ReadMoneycontrol\Mani 2.0\GapUpStrategy\Data1\day.csv")
    CMinDF=pd.read_csv(r"C:\ReadMoneycontrol\Mani 2.0\GapUpStrategy\Data1\15minute.csv")
#    CDayDF=CDayDF[CDayDF['Date']!='2020-02-05']
#    CMinDF['Date']=pd.to_datetime(CMinDF.Date)
#    CMinDF=CMinDF[CMinDF['Date']<=parse('2020-Feb-05')]
    
### Extracting it from BhavCopy    
#    CDayDF1=CDayDF[CDayDF['Date']!=CDayDF.iloc[-1]['Date']]
#    CDayDF2=CDayDF[CDayDF['Date']==CDayDF.iloc[-1]['Date']]
#    T=CDayDF2.merge(LastClose1,on=['Stock'],how="left")
#    Null=T[T['Last'].isnull()]    
#    NotNull=T[T['Last'].isnull()==False]
#    NotNull['close']=NotNull['Close1']
#    CDayDF2=NotNull.append(Null)
#    CDayDF2=CDayDF2.drop(CDayDF2.ix[:, 'Close1':'Last'].columns, axis = 1)
#    CDayDF=CDayDF1.append(CDayDF2)
    
    
#    DayStockNameGroup=CDayDF.groupby('Stock')
#    MinStockNameGroup=CMinDF.groupby('Stock')
#    i=0
#    First=True
#    while(i<len(StockList)):
#    #if(True):
#        Stock=StockList.iloc[i]['StockName']
#        i=i+1
#        #print("********** "+Stock+" *********")
#        Temp=PrStock(Stock,MinStockNameGroup.get_group(Stock),DayStockNameGroup.get_group(Stock))
#        if(First):
#            DataWithMetrics=Temp                
#            #CDayDF=DayDFExt
#        else:
#            DataWithMetrics=DataWithMetrics.append(Temp)
#            #CDayDF=CDayDF.append(DayDFExt)
#        First=False
#    #DataWithMetrics.to_csv(r"C:\ReadMoneycontrol\Mani 2.0\GapUpStrategy\Data1\DataWithMetrics.csv",sep=',',encoding='utf-8',index=False)
    DataWithMetrics=pd.read_csv(r"C:\ReadMoneycontrol\Mani 2.0\GapUpStrategy\Data1\DataWithMetrics.csv")
    #DataWithMetrics=pd.read_csv(r"C:\ReadMoneycontrol\Mani 2.0\GapUpStrategy\01-Feb-2020\Data1\DataWithMetrics.csv")

    TZ=DataWithMetrics[DataWithMetrics['CDATE']!='2020-Feb-07']
    TZ['HLP']=round((TZ['High']-TZ['Low'])/TZ['Low']*100)
    TZ['OCP']=round((TZ['Open']-TZ['Close'])/TZ['Close']*100)
    TZ1=TZ[TZ['CDATE']=='2020-Feb-03']
    TZ1[(TZ1['HLP']>=4) & (TZ1['HLP']<5)][['Stock','Date','HLP','Open','OCP']]
#    C:\ReadMoneycontrol\Mani 2.0\GapUpStrategy\01-Feb-2020\Data
    #DataWithMetrics[DataWithMetrics['CDATE']!='2020-Feb-01'].to_csv(r"C:\ReadMoneycontrol\Mani 2.0\GapUpStrategy\01-Feb-2020\Data1\DataWithMetrics.csv",sep=',',encoding='utf-8',index=False)
    CStock=list(StockList.StockName)
    StartTime=datetime.now()
    PreOpenLen=0
    while (PreOpenLen==0):
        time.sleep(5)
        PreOpen=getLatestPreOpenPrice()
        PreOpenLen=len(PreOpen[PreOpen['lastPrice']>50])        
    #print("Hello")    
    PreOpen=PreOpen[PreOpen['lastPrice']>50]
    PreOpenSymbol=list(PreOpen.symbol)
    FinalSymbolList=list(set(CStock)  & set(PreOpenSymbol))
    print("Download Completed: " + str((datetime.now()-StartTime).seconds))
    Date1=PreOpen['Date'].iloc[0]
    CDATE=PreOpen['CDATE'].iloc[0]
    i=0
    First=True
    while(i<len(FinalSymbolList)):
    #while(i<len(StockList)):
    #if(True):
        Stock=FinalSymbolList[i]
        #Stock=StockList.iloc[i]['StockName']
        i=i+1
        #print("********** "+Stock+" *********")
        #Open=DataWithMetrics[DataWithMetrics['Stock']==Stock][-25:][:1]['Open'].iloc[0]
        Open=PreOpen[PreOpen['symbol']==Stock]['lastPrice'].iloc[0]
        #Open=
        #Date=parse('24-01-2020 09:15:00')
        Date=Date1
        DfStruct={}
        DfStruct['Date']=Date
        DfStruct['open']=Open
        DfStruct['high']=Open
        DfStruct['low']=Open
        DfStruct['close']=Open
        DfStruct['V']=0
        DfStruct['Stock']=Stock
        DFar=[]      
        DFar.append(DfStruct)
        
        
        
        #FilteredMin=MinStockNameGroup.get_group(Stock)[-25:].append(pd.DataFrame(DFar)[['Date','open','high','low','close','V','Stock']])
        FilteredMin=MinStockNameGroup.get_group(Stock)[-25:].append(pd.DataFrame(DFar)[['Date','open','high','low','close','V','Stock']])
        #FilteredMin=MinStockNameGroup.get_group(Stock)[-25:].append(pd.DataFrame(DFar)[['Date','open','high','low','close','V','Stock']])
        FilteredMin['Date']=pd.to_datetime(FilteredMin['Date'])
        #FilteredMin[FilteredMin['Date']<=parse('27-Jan-2020 15:15')]
        FilteredMin[FilteredMin['Date']<=parse(DayStockNameGroup.get_group(Stock)['Date'].iloc[-1]+' 15:15')]
        #FilteredMin['CDATE']=pd.to_datetime(FilteredMin['Date']).dt.strftime("%Y-%b-%d")        
        #FilteredMin['Indx']=((FilteredMin['Date']-pd.to_datetime(pd.to_datetime(FilteredMin['CDATE']).dt.strftime("%Y-%m-%d 09:15"))).dt.seconds/60/15).astype(int)
        #FilteredMin=MinStockNameGroup.get_group(Stock)[:-25][-25:].append(pd.DataFrame(DFar)[['Date','open','high','low','close','V','Stock']])
        FilteredMin.reset_index(drop = True,inplace=True)
        #FilteredDay=DayStockNameGroup.get_group(Stock)[-50:-25].append(pd.DataFrame(DFar)[['Date','open','high','low','close','V','Stock']])
        FilteredDay=DayStockNameGroup.get_group(Stock).append(pd.DataFrame(DFar)[['Date','open','high','low','close','V','Stock']])
        Temp=PrStock(Stock,FilteredMin,FilteredDay)
    
    #    Temp=PrStock(Stock,MinStockNameGroup.get_group(Stock),DayStockNameGroup.get_group(Stock))
        if(First):
            DataWithMetrics1=Temp[-1:]                
            #CDayDF=DayDFExt
        else:
            DataWithMetrics1=DataWithMetrics1.append(Temp[-1:])
            #CDayDF=CDayDF.append(DayDFExt)
        First=False
    
    #DataWithMetrics.CDATE.unique()
    
    #Result=DataWithMetrics[DataWithMetrics['CDATE']!='2020-Jan-28'].append(DataWithMetrics1)
    Result=DataWithMetrics.append(DataWithMetrics1)
    Result['GAP']=Result['GAPDIFF']+Result['PDAYCLOSEDIFF']
    i=0
    First=True
    while(i<len(FinalSymbolList)):
    #if(True):
        Stock=FinalSymbolList[i]
        i=i+1
       # print("********** "+Stock+" *********")
        SBIN5Min=Result[Result['Stock']==Stock]
        StockDownGapUP1=SBIN5Min[     (
            (SBIN5Min['SMA-C-10'].shift(1)<SBIN5Min['SMA-C-21'].shift(1)) &
            (SBIN5Min['SMA-C-10'].shift(2)<SBIN5Min['SMA-C-21'].shift(2)) &
            (SBIN5Min['SMA-C-10'].shift(3)<SBIN5Min['SMA-C-21'].shift(3)) &
            (SBIN5Min['SMA-C-10'].shift(4)<SBIN5Min['SMA-C-21'].shift(4)) &
            (SBIN5Min['SMA-C-10'].shift(5)<SBIN5Min['SMA-C-21'].shift(5)) &
            (SBIN5Min['SMA-C-10'].shift(6)<SBIN5Min['SMA-C-21'].shift(6)) &
            (SBIN5Min['SMA-C-10'].shift(7)<SBIN5Min['SMA-C-21'].shift(7)) &
            (SBIN5Min['SMA-C-10'].shift(8)<SBIN5Min['SMA-C-21'].shift(8)) &
            (SBIN5Min['SMA-C-10'].shift(9)<SBIN5Min['SMA-C-21'].shift(9)) &
    #        (SBIN5Min['Open']>SBIN5Min['SMA-C-150']) &
    #        (SBIN5Min['Open'].shift(1)<SBIN5Min['SMA-C-150'].shift(1)) &
    #        
            (SBIN5Min['Indx']==0) &
            (SBIN5Min['PDayClose']<SBIN5Min['Open']) &
           # ((SBIN5Min['Open']-SBIN5Min['PDayClose'])/SBIN5Min['PDayClose']*100>1)
           ((SBIN5Min['GAPDIFF']>1) | (SBIN5Min['PDAYCLOSEDIFF']>.5) | (SBIN5Min['PDAYCLOSEDIFF']<-.5))
        )]
        #[['Date','Stock','PDAYCLOSEDIFF','GAPDIFF','HighFib','Open','H4', 'H3A', 'H3', 'H2A', 'H2','H1', 'IPivot-H', 'IPivot', 'IPivot-L','L1', 'L2', 'L2A', 'L3', 'L3A', 'L4','RH1_R', 'RH2A_R', 'RH2_R', 'RH3A_R', 'RH3_R', 'RH4_R', 'RIP-H_R', 'RIP-L_R', 'RIPivot_R', 'RL1_R', 'RL2A_R', 'RL2_R', 'RL3A_R', 'RL3_R', 'RL4_R']]
        StockDownGapUP2=SBIN5Min[     (
    #        (SBIN5Min['SMA-C-10'].shift(1)<SBIN5Min['SMA-C-21'].shift(1)) &
    #        (SBIN5Min['SMA-C-10'].shift(2)<SBIN5Min['SMA-C-21'].shift(2)) &
    #        (SBIN5Min['SMA-C-10'].shift(3)<SBIN5Min['SMA-C-21'].shift(3)) &
    #        (SBIN5Min['SMA-C-10'].shift(4)<SBIN5Min['SMA-C-21'].shift(4)) &
    #        (SBIN5Min['SMA-C-10'].shift(5)<SBIN5Min['SMA-C-21'].shift(5)) &
    #        (SBIN5Min['SMA-C-10'].shift(6)<SBIN5Min['SMA-C-21'].shift(6)) &
    #        (SBIN5Min['SMA-C-10'].shift(7)<SBIN5Min['SMA-C-21'].shift(7)) &
    #        (SBIN5Min['SMA-C-10'].shift(8)<SBIN5Min['SMA-C-21'].shift(8)) &
    #        (SBIN5Min['SMA-C-10'].shift(9)<SBIN5Min['SMA-C-21'].shift(9)) &
    ##        (SBIN5Min['Open']>SBIN5Min['SMA-C-150']) &
    ##        (SBIN5Min['Open'].shift(1)<SBIN5Min['SMA-C-150'].shift(1)) &
    ##        
            (SBIN5Min['Indx']==0) &
            (SBIN5Min['PDayClose']<SBIN5Min['Open']) &
           # ((SBIN5Min['Open']-SBIN5Min['PDayClose'])/SBIN5Min['PDayClose']*100>1)
           ((SBIN5Min['GAPDIFF']>1) | (SBIN5Min['PDAYCLOSEDIFF']>.5) | (SBIN5Min['PDAYCLOSEDIFF']<-.5))
        )]
    
        StockUPGapDown1=SBIN5Min[     (
            (SBIN5Min['SMA-C-10'].shift(1)>SBIN5Min['SMA-C-21'].shift(1)) &
            (SBIN5Min['SMA-C-10'].shift(2)>SBIN5Min['SMA-C-21'].shift(2)) &
            (SBIN5Min['SMA-C-10'].shift(3)>SBIN5Min['SMA-C-21'].shift(3)) &
            (SBIN5Min['SMA-C-10'].shift(4)>SBIN5Min['SMA-C-21'].shift(4)) &
            (SBIN5Min['SMA-C-10'].shift(5)>SBIN5Min['SMA-C-21'].shift(5)) &
            (SBIN5Min['SMA-C-10'].shift(6)>SBIN5Min['SMA-C-21'].shift(6)) &
            (SBIN5Min['SMA-C-10'].shift(7)>SBIN5Min['SMA-C-21'].shift(7)) &
            (SBIN5Min['SMA-C-10'].shift(8)>SBIN5Min['SMA-C-21'].shift(8)) &
            (SBIN5Min['SMA-C-10'].shift(9)>SBIN5Min['SMA-C-21'].shift(9)) &
            
            (SBIN5Min['Indx']==0) &
            (SBIN5Min['PDayClose']>SBIN5Min['Open']) &
           # ((SBIN5Min['PDayClose']-SBIN5Min['Open'])/SBIN5Min['Open']*100>1)
           ((SBIN5Min['GAPDIFF']<-1) | (SBIN5Min['PDAYCLOSEDIFF']>.5) | (SBIN5Min['PDAYCLOSEDIFF']<-.5))
        )]
        
        
            
        StockUPGapDown2=SBIN5Min[     (
    #        (SBIN5Min['SMA-C-10'].shift(1)>SBIN5Min['SMA-C-21'].shift(1)) &
    #        (SBIN5Min['SMA-C-10'].shift(2)>SBIN5Min['SMA-C-21'].shift(2)) &
    #        (SBIN5Min['SMA-C-10'].shift(3)>SBIN5Min['SMA-C-21'].shift(3)) &
    #        (SBIN5Min['SMA-C-10'].shift(4)>SBIN5Min['SMA-C-21'].shift(4)) &
    #        (SBIN5Min['SMA-C-10'].shift(5)>SBIN5Min['SMA-C-21'].shift(5)) &
    #        (SBIN5Min['SMA-C-10'].shift(6)>SBIN5Min['SMA-C-21'].shift(6)) &
    #        (SBIN5Min['SMA-C-10'].shift(7)>SBIN5Min['SMA-C-21'].shift(7)) &
    #        (SBIN5Min['SMA-C-10'].shift(8)>SBIN5Min['SMA-C-21'].shift(8)) &
    #        (SBIN5Min['SMA-C-10'].shift(9)>SBIN5Min['SMA-C-21'].shift(9)) &
    #        
            (SBIN5Min['Indx']==0) &
            (SBIN5Min['PDayClose']>SBIN5Min['Open']) &
           # ((SBIN5Min['PDayClose']-SBIN5Min['Open'])/SBIN5Min['Open']*100>1)
           ((SBIN5Min['GAPDIFF']<-1) | (SBIN5Min['PDAYCLOSEDIFF']>.5) | (SBIN5Min['PDAYCLOSEDIFF']<-.5))
        )]
        TempA=SBIN5Min[(SBIN5Min['Indx']==0)]
        if(First):
            CStockDownGapUP1=StockDownGapUP1
            CStockUPGapDown1=StockUPGapDown1
            CStockDownGapUP2=StockDownGapUP2
            CStockUPGapDown2=StockUPGapDown2
            CT=TempA
        else:
            CStockDownGapUP1=CStockDownGapUP1.append(StockDownGapUP1)
            CStockUPGapDown1=CStockUPGapDown1.append(StockUPGapDown1)
            CStockDownGapUP2=CStockDownGapUP2.append(StockDownGapUP2)
            CStockUPGapDown2=CStockUPGapDown2.append(StockUPGapDown2)
            CT=CT.append(TempA)
        First=False
        
    
    
    CStockUPGapDown1['Signal']=CStockUPGapDown1.apply(lambda x: CheckPrice(x,"Buy"),axis=1)   
    Csud=CStockUPGapDown1[CStockUPGapDown1['CDATE']==CDATE][['Date','Stock','Signal','GAP','PDayVolume','PDAYCLOSEDIFF','GAPDIFF','PDayClose','HighFib','Open','H4', 'H3A', 'H3', 'H2A', 'H2','H1', 'IPivot-H', 'IPivot', 'IPivot-L','L1', 'L2', 'L2A', 'L3', 'L3A', 'L4']]
    #print("Final : " + str((datetime.now()-StartTime).seconds))
    
    CStockDownGapUP1['Signal']=CStockDownGapUP1.apply(lambda x: CheckPrice(x,"Buy"),axis=1)   
    Csdu=CStockDownGapUP1[CStockDownGapUP1['CDATE']==CDATE][['Date','Stock','Signal','GAP','PDayVolume','PDAYCLOSEDIFF','GAPDIFF','PDayClose','HighFib','Open','H4', 'H3A', 'H3', 'H2A', 'H2','H1', 'IPivot-H', 'IPivot', 'IPivot-L','L1', 'L2', 'L2A', 'L3', 'L3A', 'L4']]
    #print("Final : " + str((datetime.now()-StartTime).seconds))
    
    CStockUPGapDown2['Signal']=CStockUPGapDown2.apply(lambda x: CheckPrice(x,"Buy"),axis=1)   
    Csud2=CStockUPGapDown2[CStockUPGapDown2['CDATE']==CDATE][['Date','Stock','Signal','GAP','PDayVolume','PDAYCLOSEDIFF','GAPDIFF','PDayClose','HighFib','Open','H4', 'H3A', 'H3', 'H2A', 'H2','H1', 'IPivot-H', 'IPivot', 'IPivot-L','L1', 'L2', 'L2A', 'L3', 'L3A', 'L4']]
    #print("Final : " + str((datetime.now()-StartTime).seconds))
    
    CStockDownGapUP2['Signal']=CStockDownGapUP2.apply(lambda x: CheckPrice(x,"Buy"),axis=1)   
    Csdu2=CStockDownGapUP2[CStockDownGapUP2['CDATE']==CDATE][['Date','Stock','Signal','GAP','PDayVolume','PDAYCLOSEDIFF','GAPDIFF','PDayClose','HighFib','Open','H4', 'H3A', 'H3', 'H2A', 'H2','H1', 'IPivot-H', 'IPivot', 'IPivot-L','L1', 'L2', 'L2A', 'L3', 'L3A', 'L4']]
    
    
    CT['Signal']=CT.apply(lambda x: CheckPrice(x,"Buy"),axis=1)   
    TempA=CT[CT['CDATE']==CDATE][['Date','Stock','Signal','GAP','PDayVolume','PDAYCLOSEDIFF','GAPDIFF','PDayClose','HighFib','Open','H4', 'H3A', 'H3', 'H2A', 'H2','H1', 'IPivot-H', 'IPivot', 'IPivot-L','L1', 'L2', 'L2A', 'L3', 'L3A', 'L4']]
    
    ABuy_StockUGapDown=Csud[(Csud['GAP']<-.5)]# & (Csud['PDAYCLOSEDIFF']<.5)]
    ASell_StockDGapUp=Csdu[(Csdu['GAP']>.5)]# & (Csud['PDAYCLOSEDIFF']<.5)]
    
#Csud1=Csud[(Csud['PDAYCLOSEDIFF']<-.5)]# & (Csud['PDAYCLOSEDIFF']<.5)]
#Csud1=Csud[(Csud['PDAYCLOSEDIFF']>.5)]# & (Csud['PDAYCLOSEDIFF']<.5)]
#Csud1=Csud[(Csud['PDAYCLOSEDIFF']>-.5) & (Csud['PDAYCLOSEDIFF']<.5)]


#    CDayDF[CDayDF['Date']!='2020-02-01'].to_csv(r"C:\ReadMoneycontrol\Mani 2.0\GapUpStrategy\01-Feb-2020\Data1\day.csv",sep=',',encoding='utf-8',index=False)
#    CMinDF[CMinDF['Date']<'2020-02-01'].to_csv(r"C:\ReadMoneycontrol\Mani 2.0\GapUpStrategy\01-Feb-2020\Data1\15Minute.csv",sep=',',encoding='utf-8',index=False)
    
if(False):
    #Preopen=pd.read_csv(r"C:\ReadMoneycontrol\Mani 2.0\GapUpStrategy\01-Feb-2020\Data\PreOpen-2020-Feb-01.csv")
    #LastClose=pd.read_csv(r"C:\ReadMoneycontrol\Mani 2.0\GapUpStrategy\01-Feb-2020\cm31JAN2020bhav.csv")
    CStock=list(StockList.StockName)
    Preopen=pd.read_csv(r"C:\ReadMoneycontrol\Mani 2.0\GapUpStrategy\Data\PreOpen-2020-Feb-06.csv")
    LastClose=pd.read_csv(r"C:\ReadMoneycontrol\Mani 2.0\GapUpStrategy\cm05FEB2020bhav.csv")
    #LastClose.dtypes
    PreO=Preopen[['symbol','lastPrice','pChange','previousClose']]
    LastC=LastClose[LastClose['SERIES']=='EQ'][['TIMESTAMP','SYMBOL','OPEN','LOW','CLOSE','LAST','TOTTRDQTY','TOTTRDVAL']]
    LastC.columns=['Date', 'symbol', 'Open','Low','Close', 'Last', 'V', 'Val']
    T=PreO.merge(LastC,on=['symbol'],how="left")
    
    
    LastClose1=LastClose[LastClose['SERIES']=='EQ'][['SYMBOL','CLOSE','LAST']]
    LastClose1.columns=['Stock','Close1', 'Last']
    
    #T.dtypes
    T['CO']=round((T['Close']-T['Open']+0.000001)/T['Open']*100,2)
    T['LO']=round((T['Low']-T['Open']+0.000001)/T['Open']*100,2)
    T['CloseDiff']=round((T['Close']-T['Last'])/T['Last']*100,2)
    T['AGap']=round((T['lastPrice']-T['Last']+0.00001)/T['Last']*100,2)
    T['V']=round(T['V']/100000,2)
    T['Val']=round(T['Val']/10000000,2)
    T1=T[(T['Close']>30) & T['symbol'].isin(CStock)]
    ABuy_StockUpGapDown=T1[(T1['AGap']<-1) & (T1['CloseDiff']<-1) & (T1['CO']>0) ]
    ASell_StockDownGapUp=T1[(T1['AGap']>1) & (T1['CloseDiff']>1) & (T1['CO']<0) ]
    ABuy_StockUpGapDown1=T1[(T1['AGap']<-.5) &  (T1['CO']>2) ]
    ASell_StockDownGapUp1=T1[(T1['AGap']>.5) & (T1['CO']<-2) & (T1['CloseDiff']>.1)]
    
    SStockDownGapUp2=T1[(T1['AGap']>1) & (T1['CO']<-2) & (T1['CloseDiff']>1)]
    BStockUpGapDown2=T1[(T1['AGap']<-1) &  (T1['CO']>2) & (T1['CloseDiff']<-1)]
