# -*- coding: utf-8 -*-
"""
Created on Wed Nov  6 06:38:02 2019

@author: lalitha
"""
import threading
import time
import requests
import datetime
import pandas as pd
import numpy as np
import json
#from datetime import timedelta  
from datetime import datetime, timedelta
import requests
from dateutil.parser import parse

def MParseDate(Date):
    ts = (np.datetime64(pd.to_datetime(Date)) - np.datetime64('1970-01-01T00:00:00Z')) / np.timedelta64(1, 's')
    return N1(N1(datetime.utcfromtimestamp(ts),'5H',"+"),"30M","+")
seconds_per_unit = {"S": 1, "M": 60, "H": 3600, "D": 86400, "W": 604800}
def N1(date,s,Operation):
    if (Operation=="+"):
        return date+timedelta(seconds=int(s[:-1]) * seconds_per_unit[s[-1]])
    else:
        return date-timedelta(seconds=int(s[:-1]) * seconds_per_unit[s[-1]])




DIRNIFTY="C:\ReadMoneycontrol\Mani 2.0"
DIRFO="C:\ReadMoneycontrol\Mani 2.0\\2"
DIRNIFTYStockList="C:\ReadMoneycontrol\Mani 2.0\StockList.txt"
DIRFOStockList="C:\ReadMoneycontrol\Mani 2.0\StockList-New.txt"
AllStockList="C:\ReadMoneycontrol\Mani 2.0\StockListAll.txt"
#DataDir=DIRNIFTY
StockListFile=AllStockList

#StockListFile=DIRNIFTYStockList
a=1
if(a==1):
    StockList=pd.read_csv(StockListFile)    
    DataDir=DIRNIFTY
else:
    StockList=pd.read_csv("C:\ReadMoneycontrol\Mani 2.0\StockListID-NEWList.csv")
    DataDir=r"C:\ReadMoneycontrol\Mani 2.0\NEWDataIncr1\\"
#    StockList=pd.read_csv(AllStockList)    
#    DataDir=DIRNIFTY
#StockList=pd.read_csv("C:\ReadMoneycontrol\Mani 2.0\StockListIDOriginal.txt")

#StrTimeIntervals=['60minute','2hour','3hour']
StrTimeIntervals=['minute','3minute','5minute','15minute','30minute','60minute','2hour','3hour','day']
#StrTimeIntervals=['day']
#StockMinute=pd.read_csv(DataDir+r"\Data\\"+StockName+'-30minute.csv')
#StockMinute['Date']
i=0
while(i<len(StockList)):
    #StockName=StockList.iloc[i]['Symbol']
    StockName=StockList.iloc[i]['StockName']
    #StockName=StockList.iloc[i]['StockName']
    StockDay=pd.read_csv(DataDir+r"\Data\\"+StockName+'-day.csv')
    
    #StockDay[StockDay['Date']==StockDay.iloc[len(StockDay)-1]['Date']].to_csv("C:\ReadMoneycontrol\Mani 2.0\Data\\"+StockName+'-LASTREADDAY.csv',index=False)
    for TimeInterval in StrTimeIntervals:    
        DeltaDay=pd.read_csv(DataDir+r"\Incr1\\"+StockName+'-'+TimeInterval+'.csv')        
        if(TimeInterval=="day"):
            DeltaDay['Date']=pd.to_datetime(DeltaDay['Date']).dt.strftime("%Y-%m-%d")            
            Delta=DeltaDay[DeltaDay['Date']>StockDay.iloc[len(StockDay)-1]['Date'] ]
        else:
            DeltaDay['Date']=pd.to_datetime(pd.to_datetime(DeltaDay.Date).dt.strftime("%Y-%m-%d %H:%M:%S"))
            Delta=DeltaDay[DeltaDay['Date']>N1(parse(StockDay.iloc[len(StockDay)-1]['Date']),"1D","+").strftime("%Y-%m-%d")  ]
            #Delta=DeltaDay[DeltaDay['Date']>parse('28-Jan-2020')  ]
        #DeltaDay['Date']=N1(DeltaDay['Date'],"330M","+")
        #
        
        #DeltaDay['Date'].strftime("%Y-%m-%d")        
        #N1(parse(StockDay.iloc[len(StockDay)-1]['Date']),"1D","+").strftime("%Y-%m-%d")  
        
        Delta.to_csv(DataDir+r"\Data\\"+StockName+'-'+TimeInterval+'.csv',mode='a',header=False,index=False)
        #DeltaDay.to_csv(DataDir+r"\incr2\\"+StockName+'-'+TimeInterval+'.csv',mode='a',header=True,index=False)
    i=i+1
   
    
#((SBIN5Min['Date']-pd.to_datetime(pd.to_datetime(SBIN5Min['CDATE']).dt.strftime("%Y-%m-%d 09:15"))).dt.seconds/60/15).astype(int)
#StockList=pd.read_csv("C:\ReadMoneycontrol\Mani 2.0\StockList.txt")
#ki=0
#while(ki<len(StockList)):
#    StockName=StockList.iloc[ki]['Symbol']
#    ki=ki+1
#    print(StockName)
#    Stock=pd.read_csv(r"C:\ReadMoneycontrol\Mani 2.0\Data\\"+StockName+"-day.csv",encoding='utf-8')
##    LastPivot=pd.read_csv(r"C:\ReadMoneycontrol\Mani 2.0\Data2\\"+StockName+"-Pivot.csv",encoding='utf-8')
#    Stock.columns=['Date', 'Open', 'High', 'Low', 'Close', 'V']
#    #DateIndex=10
#    
##    LastPivot[LastPivot['Date']==LastPivot.iloc[len(LastPivot)-2]['Date']]
##    Stock1=candlestick.AppendPivot(Stock[Stock['Date']>=LastPivot.iloc[len(LastPivot)-2]['Date']])   
#    Stock1=candlestick.AppendPivot(Stock)
#    
#    #NIFTY1.iloc[-1]
#    #NIFTY1.iloc[0]['High']
#    Stock1.to_csv(r"C:\ReadMoneycontrol\Mani 2.0\Data3\\"+StockName+"-Pivot.csv",sep=',',encoding='utf-8',index=False,mode='a',header=False)
