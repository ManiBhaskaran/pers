# -*- coding: utf-8 -*-
"""
Created on Sun Mar  1 13:31:23 2020

@author: lalitha
"""


from bs4 import BeautifulSoup
import requests
import csv
import pandas as pd
import json
import datetime, calendar
import os.path
import time
Header1={}

#http_proxy  = "http://X119285:Password20.3@proxy-sgt.si.socgen:8080"
#https_proxy = "http://X119285:Password20.3@proxy-sgt.si.socgen:8080"
#ftp_proxy   = "ftp://10.10.1.10:3128"
#
#proxyDict = { 
#              "http"  : http_proxy, 
#              "https" : https_proxy, 
#              "ftp"   : ftp_proxy
#            }

Header1["Referer"]="https://www1.nseindia.com/products/content/derivatives/equities/historical_fo.htm"
Header1["User-Agent"]="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.87 Safari/537.36"
Header1["X-Requested-With"]= "XMLHttpRequest"
url = 'https://www1.nseindia.com/products/dynaContent/common/productsSymbolMapping.jsp?instrumentType=OPTSTK&symbol=AXISBANK&expiryDate=27-02-2020&optionType=CE&strikePrice=&dateRange=day&fromDate=&toDate=&segmentLink=9&symbolCount='
url="https://www1.nseindia.com/products/dynaContent/common/productsSymbolMapping.jsp?instrumentType=OPTSTK&symbol=ACC&expiryDate=27-02-2020&optionType=CE&strikePrice=&dateRange=&fromDate=02-Jan-2020&toDate=04-Feb-2020&segmentLink=9&symbolCount="


def getThursday(year):
    global Dates
#    year=2020
    month=1
    dt = datetime.date(year, month, 1)
    offset = 4 - dt.isoweekday()
    if offset < 0: offset += 7                          # Back up one week if necessary
    dt += datetime.timedelta(offset)                    # dt is now date of last Th in month
    while(dt.year==year):
        Dates.append(dt)
        dt += datetime.timedelta(7)                    # dt is now date of last Th in month
    return Dates


def LastThInMonth(year, month):
    
    # Create a datetime.date for the last day of the given month
    daysInMonth = calendar.monthrange(year, month)[1]   # Returns (month, numberOfDaysInMonth)
    dt = datetime.date(year, month, daysInMonth)

    # Back up to the most recent Thursday
    offset = 4 - dt.isoweekday()
    if offset > 0: offset -= 7                          # Back up one week if necessary
    dt += datetime.timedelta(offset)                    # dt is now date of last Th in month

    # Throw an exception if dt is in the current month and occurred before today
    now = datetime.date.today()                         # Get current date (local time, not utc)
#    if dt.year == now.year and dt.month == now.month and dt <= now:
#        raise Exception('Oops - missed the last Thursday of this month')

    return dt
Dates=[]
for year in range(2017,2021):
    getThursday(year)
#    for month in range(1, 13): 
#        Dates.append(LastThInMonth(year, month))

i=0
D2=[]
while i<len(Dates)-1:
    DateStr={}
    i=i+1
    D=Dates[i-1]
    D1=Dates[i]
    Start=D-datetime.timedelta(2)
    WorkingDays=""
    while(Start<=D1):        
        End=Start#+datetime.timedelta(1)
        
        
        Estr=End.strftime("%d-%b-%Y")
        Sstr=Start.strftime("%d-%b-%Y")
        
        Start=End+datetime.timedelta(1)
        if(End.isoweekday()==7):
            Start=Start+datetime.timedelta(1)
            #End=End+datetime.timedelta(2)
        if(Start.isoweekday()==6):
            Start=Start+datetime.timedelta(2)
            
        if(WorkingDays!=""):
            WorkingDays+=","
        WorkingDays+=Sstr+"^"+Estr
        
        #print(Sstr+" - " + Estr + " - "+ str(End.isoweekday()))
        
    DateStr[D1.strftime("%d-%m-%Y")]=WorkingDays
    D2.append(DateStr)

now = datetime.date.today().strftime("%d-%b-%Y")
now="09-Apr-2020"
URL="https://www1.nseindia.com/products/dynaContent/common/productsSymbolMapping.jsp?instrumentType=OPTIDX&symbol=NIFTY&expiryDate="+now+"&optionType=CE&strikePrice=&dateRange=day&fromDate=&toDate=&segmentLink=9&symbolCount="

Cookie="_ga=GA1.2.2049447225.1545498156; __cfduid=d475c88a56e3eb88adf0ff0f32d7f14be1574230314; kf_session=ZOOysGEp8uKzcNzWjGzBdj20SMxMBHSm; public_token=YjE82iwGOnVCChH1BX64knMUu0o1PNoN; user_id=RM5678; enctoken=dcIAdJEAGJBFMCxCd/n7KiE/6d7f+F1+xbXKoJ2EI5k03gJ2axFkkChscJSEQk+6eagNr13QOjJlg+ILDgGcQlsV5mZrpg=="
authorization="enctoken dcIAdJEAGJBFMCxCd/n7KiE/6d7f+F1+xbXKoJ2EI5k03gJ2axFkkChscJSEQk+6eagNr13QOjJlg+ILDgGcQlsV5mZrpg=="
headers = {
        #'Content-type': 'application/x-www-form-urlencoded',
#                ":authority": "kite.zerodha.com",
#                ":method": "GET",
#                ":path": "/oms/instruments/historical/7712001/15minute?user_id=RM5678&oi=1&from=2020-02-04&to=2020-02-18&ciqrandom=1582039082895",
#                ":scheme": "https",
           #'Accept': 'application/json, text/plain, */*',
           #"accept":"*/*",
           #"accept-encoding":"gzip, deflate, br",
           #"accept-language":"en-US,en;q=0.9",
           'authorization': authorization,
           'cookie':Cookie
           
           #,'x-csrftoken':'ydYuAU0A7nEJzXNJkAj58uiBc5pc9rWj'
           ,'referer':'https://kite.zerodha.com/static/build/chart.html?v=2.4.0'
           #,"sec-fetch-dest": "empty"
           #,"sec-fetch-mode": "cors"
           #,"sec-fetch-site": "same-origin"
           ,"user-agent": "Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.106 Safari/537.36"
           }


#StockList=pd.read_csv("C:\ReadMoneycontrol\Mani 2.0\StockListAll.txt")
ii=-1
#while(ii<len(StockList)-1):
if(True):
#while(ii<141):    
#    ii=ii+1
#    i=1
#    Stock="NIFTY"
#    print(Stock)
#    StartStock=False
#    if(os.path.exists(r"C:\ReadMoneycontrol\Mani 2.0\OptionsData\\"+Stock+".csv")==False):
#        StartStock=True
#    urls=[]
#    #while((i<len(D2)) & StartStock):
#    while(i<165):
#        #print(D2[i])
#        for d in D2[i]:
#            ttt=1
#        for SDates in D2[i][d].split(","):
#            SpDates=SDates.split("^")
#            StartDate=SpDates[0]
#            EndDate=SpDates[1]
#            for Type in list(['CE','PE']):
#                url = "https://www1.nseindia.com/products/dynaContent/common/productsSymbolMapping.jsp?instrumentType=OPTIDX&symbol="+Stock+"&expiryDate="+d+"&optionType="+Type+"&strikePrice=&dateRange=&fromDate="+StartDate+"&toDate="+EndDate+"&segmentLink=9&symbolCount="
#                urls.append(url)
#                #print(url)
#        i=i+1
#    
    columns1=[]
#    i=len(urls)-1
    First=True
#    responsecode=False
#    while(i>0):
#        url=urls[i]
    response = requests.get(URL, headers=Header1)
    #    response = requests.get(url, headers=Header1, verify=False,proxies=proxyDict)
    if(response.status_code==200):
        
        html=response.text
        soup = BeautifulSoup(html)
        table = soup.find_all('table')[0] 
        a1=str(table)
        if(a1.find("No Records")<0):
            responsecode=True
            df = pd.read_html(str(table))
            if(First):        
                for col in df[0].columns:
                    columns1.append(col[1])
            Aa1=df[0][2:]
            Aa1.columns=columns1
            
            if(First):
                Final=Aa1
            else:
                Final=Final.append(Aa1)
            First=False
        else:
            qi=0
#        i=i-1
    now = "BANKNIFTY2"+datetime.date.today().strftime("%m%d")
    #now = "BANKNIFTY20319"
    #now = "NIFTY20MAR"
    now = "NIFTY20409"
    F=now+Final['Strike Price'].astype(int).astype(str)+"CE"
    S=now+Final['Strike Price'].astype(int).astype(str)+"PE"
    Consolidated=list(F.append(S))
     
    StockIDData=getStockID(Consolidated)       
    StockIDData.to_csv("C:\ReadMoneycontrol\Mani 2.0\\"+now+"_STOCKID.csv",sep=',',encoding='utf-8',index=False)
def getStockID(StockList):
    #StockList=Consolidated
#    StockList=pd.read_csv("C:\ReadMoneycontrol\Mani 2.0\StockList-New.txt")
    headers = {'Content-type': 'application/x-www-form-urlencoded', 'Accept': 'application/json, text/plain, */*',
               'cookie':'_ga=GA1.2.2049447225.1545498156; __cfduid=d475c88a56e3eb88adf0ff0f32d7f14be1574230314; kf_session=ZOOysGEp8uKzcNzWjGzBdj20SMxMBHSm; public_token=YjE82iwGOnVCChH1BX64knMUu0o1PNoN; user_id=RM5678; enctoken=dcIAdJEAGJBFMCxCd/n7KiE/6d7f+F1+xbXKoJ2EI5k03gJ2axFkkChscJSEQk+6eagNr13QOjJlg+ILDgGcQlsV5mZrpg=='
               ,'x-csrftoken':'YjE82iwGOnVCChH1BX64knMUu0o1PNoN'
               ,'referer':'https://kite.zerodha.com/chart/web/ciq/NSE/VEDL/784129'
               ,'x-kite-version': '2.4.0'}
    
    i=0
    DatasAr=[]
    
    while(i<len(StockList)):
        Datas={}
        
        StockName=StockList[i]
        Datas['StockName']=StockName
        i=i+1
        data="segment=NSE&tradingsymbol="+StockName.replace("&","%26")+"&watch_id=1970823&weight=1"
        data="segment=NFO-OPT&tradingsymbol="+StockName.replace("&","%26")+"&watch_id=1970823&weight=11"
        Response = requests.post('https://kite.zerodha.com/api/marketwatch/1970823/items',
                             headers=headers,data=data) #GOLD
        if(Response.status_code==200):
            Datas['ZID']=Response.json()['data']['instrument_token']
            Id=Response.json()['data']['id']
            DatasAr.append(Datas)            
            time.sleep(1)    
            a=requests.delete('https://kite.zerodha.com/api/marketwatch/1970823/' + str(Id),headers=headers)
            #a=requests.delete('https://kite.zerodha.com/api/marketwatch/1970820/897537' ,headers=headers)
            #time.sleep(1)    
            requests.delete('https://kite.zerodha.com/api/marketwatch/1970823/' + str(Id),headers=headers)
            #time.sleep(1)    
            #requests.delete('https://kite.zerodha.com/api/marketwatch/1970820/' + str(Id),headers=headers)
    #pd.DataFrame(DatasAr).to_csv("C:\ReadMoneycontrol\Mani 2.0\StockListID-NEW.csv",sep=',',encoding='utf-8',index=False)
    return pd.DataFrame(DatasAr)

    #if(responsecode==True):
        #Final.to_csv(r"C:\ReadMoneycontrol\Mani 2.0\OptionsData\\"+Stock+".csv")
