# -*- coding: utf-8 -*-
"""
Created on Tue Dec 17 20:10:25 2019

@author: lalitha
"""

Tz=FinalCheckResults1[['Index','CGap','PGap','PDiffP','DiffP','MaxHL','MaxHLIdx','MaxHLClr','MaxHLOCP','MaxHP','MaxLP','CHL', 'CHLC','COC','HL', 'HLC','OC', 'PercHL',  'RPercHL','G',
     'SPercCL','SPercHC','SPercHH','SPercHL','SPercLL','SPercOC',
     'TPercCL','TPercHC','TPercHL','TPercHO','TPercOC','TPercOL',       
     'Type','Seq','CFD','CPD','PFD','PPD','SellProfitP','BuyProfitP','HCFib','HCLevel']]
Tz['Label']=100
Tz['Label']=np.select([(Tz['SellProfitP']>0) & (Tz['BuyProfitP']<0),(Tz['SellProfitP']<0) & (Tz['BuyProfitP']>0),(Tz['SellProfitP']<0) & (Tz['BuyProfitP']<0)],[-1,1,-100],Tz['Label'] )
Tz['G1']=np.select([(Tz['G']==True) ,(Tz['G']==False)],[1,0],Tz['G'] )
Tz['MaxHLClr1']=np.select([(Tz['MaxHLClr']=="G") ,(Tz['MaxHLClr']=="R")],[1,0],Tz['MaxHLClr'] )

Tz['Seq1']=np.select([(Tz['Seq']==True) ,(Tz['Seq']==False)],[1,0],Tz['Seq'] )
Tz['Type1']=np.select([(Tz['Type']=="High") ,(Tz['Type']=="Low")],[1,0],Tz['Type'] )
    
  

DataSet1=Tz.dropna()
FeatureDataSet1=DataSet1[['Index','CGap','PGap','PDiffP','DiffP','MaxHL','MaxHLIdx','MaxHLClr1','MaxHLOCP','MaxHP','MaxLP','CHL', 'CHLC','COC','HL', 'HLC','OC', 'PercHL',  'RPercHL','G1',
# 'SPercCL','SPercHC','SPercHH','SPercHL','SPercLL','SPercOC',
 'TPercCL','TPercHC','TPercHL','TPercHO','TPercOC','TPercOL',       
 'Type1','Seq1','CFD','CPD','PFD','PPD','HCFib','HCLevel']]

FeatureDataSet1=DataSet1[['TPercHL','PercHL','G','PFD','CFD']]
Label1=DataSet1['Label']
#FeatureDataSet.shape[0]
X_train1, X_test1, Y_train1, Y_test1 = train_test_split(FeatureDataSet1, Label1, random_state=0)
#regressor1 = DecisionTreeRegressor(splitter="best",max_features="auto")    #splitter="best",min_samples_split=5 
##regressor = DecisionTreeRegressor(splitter="best",min_samples_split=5,min_impurity_decrease=10 )    
#regressor1.fit(X_train1, Y_train1)    
#Y_pred1=regressor1.predict(X_test1)
#print("Accuracy:",metrics.accuracy_score(Y_test1, Y_pred1))


clf1= DecisionTreeClassifier() #criterion="gini"
clf1.fit(X_train1, Y_train1)
yc_pred1=clf1.predict(X_test1)
print("Accuracy:",metrics.accuracy_score(Y_test1, yc_pred1))
    