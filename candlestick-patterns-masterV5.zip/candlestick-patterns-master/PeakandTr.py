# -*- coding: utf-8 -*-
"""
Created on Fri Nov 15 17:48:54 2019

@author: lalitha
"""

Data[['Date','Open','High','Low','Close','V']]
import peakutils
pd.set_option('display.max_columns', 1500)
pd.set_option('display.max_rows', 1500)
(PivotD['L2']+PivotD['L3'])/2

PivotD['H2']
PivotD['H2']-T
PivotD['A1000']

isPeak(Data['High'], len(Data), Data.iloc[4]['High'], 2, 6)
xi=108
print(isPeak(Data['High'][:xi], len(Data['High'][:xi]), Data.iloc[xi-5]['High'], xi-10, xi))    
print(Data.iloc[xi-5]['Date'])
print(Data.iloc[xi]['Date'])

#isTrough
LastPivot=pd.read_csv(r"C:\ReadMoneycontrol\Mani 2.0\Data3\\"+Symbol+"-Pivot.csv",encoding='utf-8')
PivotD=LastPivot.iloc[DateIndex*-1]
i=0
Percentage=0.0002
T=round(Data.iloc[0]['Open']*Percentage,2)
HighList=[]
LowList=[]
while(i<98+2):#len(Data)):
    H=Data.iloc[i]['High']
    L=Data.iloc[i]['Low']
    #H=Data['High'].max()
    #L=Data['Low'].max()
#PivotD
    RangeList=getChartRangeList(H,L,PivotD)
        
    
    for R in RangeList:
        #R="A1000"
        if( H==PivotD[R]):
            #print(R+" High Same" + Data.iloc[i]['Date'])
            HighList.append(i)
        elif( H+T>=PivotD[R]>=H-T):
            #print(str(i)+ "==> "+ R+" High Approx " + Data.iloc[i]['Date'] +" - "+ str(H+T) + " = " + str(PivotD[R]) + " = "+ str(H-T))
            HighList.append(i)
        if( L==PivotD[R]):
            #print(R+" Low Same" + Data.iloc[i]['Date'])
            LowList.append(i)
        elif( L+T>=PivotD[R]>=L-T):
            #print(str(i)+ "==> "+ R+" Low Approx " + Data.iloc[i]['Date'] +" - "+ str(L+T) + " = " + str(PivotD[R]) + " = "+ str(L-T))
            LowList.append(i)    
    offset=5
    if(str(HighList).find(str(i-offset)+"")>0):
        a=isPeak(Data['High'][:i], len(Data['High'][:i]), Data.iloc[i-offset]['High'], i-10, i)
        if(a):
            print(str(i)+ " - " + Data.iloc[i]['Date'] + " HIGH - " +Data.iloc[i-3]['Date'] + " - " + str(a));    
    if(str(LowList).find(str(i-3)+"")>0):
        Trough=isTrough(Data['Low'][:i], len(Data['Low'][:i]), Data.iloc[i-3]['Low'], i-10, i-1)
        if(Trough):
            print(str(i)+ " - "+Data.iloc[i]['Date'] + " Low - " +Data.iloc[i-3]['Date'] + " - " + str(Trough));    


    i=i+1


Data.iloc[102]['Date']
Data.iloc[i]['Date']
i=98+3
if(str(HighList).find(str(i-3)+"")>0):
    print("Found")
    print(isPeak(Data['High'][:i], len(Data['High'][:i]), Data.iloc[i-3]['High'], i-10, i))
    print(str(Data.iloc[i-3]['High']) + " - " + str(Data.iloc[i]['High'])+ " - " + str(Data.iloc[i-10]['High']))
i=47
if(str(LowList).find(str(i-3)+"")>0):
    Trough=isTrough(Data['Low'][:i], len(Data['Low'][:i]), Data.iloc[i-3]['Low'], i-10, i)
    print(str(Data.iloc[i-3]['Low']) + " - " + str(Data.iloc[i]['Low'])+ " - " + str(Data.iloc[i-10]['Low']))
    arr=Data['Low'][:i]
    ii=i-10
    ij=i-1
    n=len(Data['Low'][:i])
    num=Data.iloc[i-3]['Low']
    if (ii >= 0 and arr[ii] < num): 
        print(False)
	# If num is greater than the element 
	# on the right (if exists) 
    if (ij < n and arr[ij] < num): 
        print(False)
    
    if(Trough):
        print(str(i)+ " - "+Data.iloc[i]['Date'] + " Low - " +Data.iloc[i-3]['Date'] + " - " + str(Trough));    



def getCurrentRangeList(H,L,PivotData):
    PS=['IPivot','L1','L2','L3']
    PR=['IPivot','H1','H2','H3']
    PU=['A0','A236','A382','A500','A618','A786','A1000','A1236','A1382','A1500','A1618','A1786','A2000','A2236','A2382','A2500','A2618','A2786','A3000','A3236','A3382','A3500','A3618','A3786','A4000']
    PL=['Z236','Z382','Z500','Z618','Z786','Z1000','Z1236','Z1382','Z1500','Z1618','Z1786','Z2000','Z2236','Z2382','Z2500','Z2618','Z2786','Z3000','Z3236','Z3382','Z3500','Z3618','Z3786','Z4000']
    PFIB=PU+PL
    PFIBD=PU[::-1]+PL
    PRANGED=list(dict.fromkeys(PR[::-1]+PS))
    PRANGE=PR+PS
    FibList=getChartList(H,L,PFIBD,PFIBD,PivotData)
    RangeList=getChartList(H,L,PRANGED,PRANGED,PivotData)
    return FibList+RangeList
    

def getChartRangeList(H,L,PivotData):
    PS=['IPivot','L1','L2','L3']
    PR=['IPivot','H1','H2','H3']
    PU=['A0','A236','A382','A500','A618','A786','A1000','A1236','A1382','A1500','A1618','A1786','A2000','A2236','A2382','A2500','A2618','A2786','A3000','A3236','A3382','A3500','A3618','A3786','A4000']
    PL=['Z236','Z382','Z500','Z618','Z786','Z1000','Z1236','Z1382','Z1500','Z1618','Z1786','Z2000','Z2236','Z2382','Z2500','Z2618','Z2786','Z3000','Z3236','Z3382','Z3500','Z3618','Z3786','Z4000']
    PFIB=PU+PL
    PFIBD=PU[::-1]+PL
    PRANGED=list(dict.fromkeys(PR[::-1]+PS))
    PRANGE=PR+PS
    FibList=getChartList(H,L,PFIBD,PFIBD,PivotData)
    RangeList=getChartList(H,L,PRANGED,PRANGED,PivotData)
    return FibList+RangeList

#RangeList=getChartList(H,L,PRANGED,PRANGED,PivotD)
def getChartList(H,L,PComp,SortSeries,PivotD):
#PComp=PFIB #PFIB #PRANGE
#PComp=PRANGED
#SortSeries=PRANGED
    i=0
    UBound=""
    LBound=""
    PCompRev=PComp[::-1]
    while(i<len(PComp)-1):
        if(PivotD[PComp[i]]>=L<=PivotD[PComp[i+1]]):
            t=1
        elif(PivotD[PComp[i]]>=L):
            t=1
            if(PivotD[PComp[i+1]]<=L):
 #               print(PComp[i+1] + " => "+str(PivotD[PComp[i+1]]))
                LBound=PComp[i+1]
        if(PivotD[PCompRev[i+1]]>=H<=PivotD[PCompRev[i]]):
            t=1
        elif(PivotD[PCompRev[i]]<=H):
            t=1
            if(PivotD[PCompRev[i+1]]>=H):
#                print(PCompRev[i+1] + " -=> "+str(PivotD[PCompRev[i+1]]))
                UBound=PCompRev[i+1]
        i=i+1
    #print(UBound + "= "+  LBound)
    if(UBound!="" and LBound!=""):
        #print("t")
        return SortSeries[SortSeries.index(UBound):SortSeries.index(LBound)+1]
    else:
        #print("f")
        return []






# -*- coding: utf-8 -*-
"""
Created on Fri Nov 15 19:17:24 2019

@author: lalitha
"""

# Python3 implementation of the approach 

# Function that returns true if num is 
# greater than both arr[i] and arr[j] 
def isPeak(arr, n, num, i, j): 

	# If num is smaller than the element 
	# on the left (if exists) 
	if (i >= 0 and arr[i] > num): 
		return False

	# If num is smaller than the element 
	# on the right (if exists) 
	if (j < n and arr[j] > num): 
		return False
	return True

# Function that returns true if num is 
# smaller than both arr[i] and arr[j] 
def isTrough(arr, n, num, i, j): 

	# If num is greater than the element 
	# on the left (if exists) 
	if (i >= 0 and arr[i] < num): 
		return False

	# If num is greater than the element 
	# on the right (if exists) 
	if (j < n and arr[j] < num): 
		return False
	return True

def printPeaksTroughs(arr, n): 

	print("Peaks : ", end = "") 

	# For every element 
	for i in range(n): 

		# If the current element is a peak 
		if (isPeak(arr, n, arr[i], i - 1, i + 1)): 
			print(arr[i], end = " ") 
	print() 

	print("Troughs : ", end = "") 

	# For every element 
	for i in range(n): 

		# If the current element is a trough 
		if (isTrough(arr, n, arr[i], i - 1, i + 1)): 
			print(arr[i], end = " ") 

def Process2(iPercentage,ioffset):    
    ResultAr=[]
    p=-1
    while(p<len(StockList)-1):
        p=p+1
        #print(StockList.iloc[p]['Symbol'])
        Symbol=StockList.iloc[p]['Symbol']
        Data1=DataFrameCollection[StockList.iloc[p]['Symbol']].fillna(0)
        
        LastPivot=pd.read_csv(r"C:\ReadMoneycontrol\Mani 2.0\Data3\\"+Symbol+"-Pivot.csv",encoding='utf-8')
        PivotD=LastPivot.iloc[DateIndex*-1]
        i=0
        Percentage=iPercentage
        offset=ioffset
        T=round(Data1.iloc[0]['Open']*Percentage,2)
        HighList=[]
        LowList=[]
        
        
        while(i<len(Data1)):
            Data=Data1.iloc[:i+1]
            H=Data.iloc[i]['High']
            L=Data.iloc[i]['Low']
            #H=Data['High'].max()
            #L=Data['Low'].max()
        #PivotD
            RangeList=getChartRangeList(H,L,PivotD)
                
            
            for R in RangeList:
                #R="A1000"
                if( H==PivotD[R]):
                    #print(R+" High Same" + Data.iloc[i]['Date'])
                    HighList.append(i)
                elif( H+T>=PivotD[R]>=H-T):
                    #print(str(i)+ "==> "+ R+" High Approx " + Data.iloc[i]['Date'] +" - "+ str(H+T) + " = " + str(PivotD[R]) + " = "+ str(H-T))
                    HighList.append(i)
                if( L==PivotD[R]):
                    #print(R+" Low Same" + Data.iloc[i]['Date'])
                    LowList.append(i)
                elif( L+T>=PivotD[R]>=L-T):
                    #print(str(i)+ "==> "+ R+" Low Approx " + Data.iloc[i]['Date'] +" - "+ str(L+T) + " = " + str(PivotD[R]) + " = "+ str(L-T))
                    LowList.append(i)    
            
            if(str(HighList).find(str(i-offset)+"")>0):
                a=isPeak(Data['High'][:i], len(Data['High'][:i]), Data.iloc[i-offset]['High'], i-(offset*2), i)
                if(a):
                    ResultSt={}
                    Diff=round(Data.iloc[i-offset]['High']-Data.iloc[i]['High'],2)
                    DiffP=round(Diff/Data.iloc[i]['High']*100,2)
                    PDiff=round(Data.iloc[i-(offset*2)]['High']-Data.iloc[i-offset]['High'],2)
                    PDiffP=round(PDiff/Data.iloc[i-offset]['High']*100,2)
                    #print(str(i)+ " - " + Data.iloc[i]['Date'] + " HIGH - " +Data.iloc[i-offset]['Date'] + " - " + str(a) + " - " + str(Diff) + " ~ " + str(DiffP));                    
                    ResultSt['Stock']=Symbol
                    ResultSt['Index']=i
                    ResultSt['CurrentDate']=Data.iloc[i]['Date']
                    ResultSt['Type']='High'
                    ResultSt['SingleDate']=Data.iloc[i-offset]['Date']
                    ResultSt['Diff']=Diff
                    ResultSt['DiffP']=DiffP
                    ResultSt['PDiff']=PDiff
                    ResultSt['PDiffP']=PDiffP
                    
                    
                    ResultSt['PercHL']=round((Data.iloc[:i]['High'].max()-Data.iloc[i-offset]['High']+0.00001)/Data.iloc[i-offset]['High']*100,2)
                    H,L,C,O=list(Data.iloc[i-offset][['High',"Low","Close","Open"]])
                    ResultSt['HLC']=round((H-C)/C*100,2)
                    ResultSt['HL']=round((H-L)/L*100,2)
                    ResultSt['OC']=round((O-C)/C*100,2)
                    ResultSt['G']=O>C
                    ResultAr.append(ResultSt)
            if(str(LowList).find(str(i-offset)+"")>0):
                Trough=isTrough(Data['Low'][:i], len(Data['Low'][:i]), Data.iloc[i-offset]['Low'], i-(offset*2), i-1)
                if(Trough):
                    ResultSt={}
                    Diff=round(Data.iloc[i-offset]['Low']-Data.iloc[i]['Low'],2)
                    DiffP=round(Diff/Data.iloc[i]['Low']*100,2)
                    PDiff=round(Data.iloc[i-(offset*2)]['Low']-Data.iloc[i-offset]['Low'],2)
                    PDiffP=round(PDiff/Data.iloc[i-offset]['Low']*100,2)
                    #print(str(i)+ " - "+Data.iloc[i]['Date'] + " Low - " +Data.iloc[i-offset]['Date'] + " - " + str(Trough)+ " - " + str(Diff) + " ~ " + str(DiffP));    
                    ResultSt['Stock']=Symbol
                    ResultSt['Index']=i
                    ResultSt['CurrentDate']=Data.iloc[i]['Date']
                    ResultSt['Type']='Low'
                    ResultSt['SingleDate']=Data.iloc[i-offset]['Date']
                    ResultSt['Diff']=Diff
                    ResultSt['DiffP']=DiffP
                    ResultSt['PDiff']=PDiff
                    ResultSt['PDiffP']=PDiffP
                    ResultSt['PercHL']=round((Data.iloc[:i]['Low'].min()-Data.iloc[i-offset]['Low']+0.00001)/Data.iloc[i-offset]['Low']*100,2)
                    H,L,C,O=list(Data.iloc[i-offset][['High',"Low","Close","Open"]])
                    ResultSt['HLC']=round((L-C)/C*100,2)
                    ResultSt['HL']=round((H-L)/L*100,2)
                    ResultSt['OC']=round((O-C)/C*100,2)
                    ResultSt['G']=O>C
                    ResultAr.append(ResultSt)
            i=i+1
    
    ResultDF=pd.DataFrame(ResultAr)
    return ResultDF
#ids = df["ID"]
#df[ids.isin(ids[ids.duplicated()])].sort("ID")
ResultAr=[]
TInterval=['3minute','5minute','15minute']
PercentageAr=[0.0002,round(0.0002/3*5,4),round(0.0002/3*15,4)]
OffsetAr=[5,4,2]
iP=PercentageAr[TInterval.index(minute)]
iO=OffsetAr[TInterval.index(minute)]

DataFrameCollection=Min5DF
ResultDF51=Process2(iP,iO)
ResultDF3=Process(iP,3)
ResultDF7=Process(iP,7)
TR=ResultDF7[(ResultDF7['PDiffP']<-0.1) & (ResultDF7['PercHL']>-0.1)].reset_index()
TR=ResultDF7[(ResultDF7['DiffP']>-0.1) & (ResultDF7['PDiffP']<0.1)].reset_index()

TR=ResultDF7[(ResultDF7['DiffP']<0.1) & (ResultDF7['PDiffP']<-0.1)][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]
TR[TR.duplicated(['Stock','SingleDate'])][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]

TR=ResultDF5[(ResultDF5['DiffP']>0.1) & (ResultDF5['PDiffP']<-0.1)][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]
TR[TR.duplicated(['Stock','SingleDate'])][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]

TR=ResultDF5[(ResultDF5['DiffP']<0.1) & (ResultDF5['PDiffP']<-0.1)][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]
TR[TR.duplicated(['Stock','SingleDate'])][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]


TR=ResultDF5[(ResultDF5['DiffP']<-0.1) & (ResultDF5['PDiffP']>0.1)][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]
TR[TR.duplicated(['Stock','SingleDate'])][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]

TR=ResultDF3[(ResultDF3['DiffP']<0.1) & (ResultDF3['PDiffP']<-0.1)][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]
TR[TR.duplicated(['Stock','SingleDate'])][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]


TR=ResultDF3[(ResultDF3['DiffP']>0.1) & (ResultDF3['PDiffP']<-0.1)][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]
TR[TR.duplicated(['Stock','SingleDate'])][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]

TR=ResultDF3[(ResultDF3['DiffP']<-0.1) & (ResultDF3['PDiffP']>0.1)][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]
TR[TR.duplicated(['Stock','SingleDate'])][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]


TR=ResultDF3[(ResultDF3['DiffP']<-0.1) & (ResultDF3['PDiffP']>0.1)].reset_index()
TR=ResultDF7[(ResultDF7['DiffP']<-0.1) & (ResultDF7['PDiffP']>0.1)].reset_index()

TR=ResultDF5
TR[TR.duplicated(['Stock','SingleDate'])][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]

ResultDF5H=getHighDF(ResultDF5)
ResultDF5L=getLowDF(ResultDF5)

ResultDF7H=getHighDF(ResultDF7)
ResultDF7L=getLowDF(ResultDF7)

ResultDF3H=getHighDF(ResultDF3)
ResultDF3L=getLowDF(ResultDF3)

def getHighDF(ResultDF):
    return ResultDF[(ResultDF['Type']=="High") & (ResultDF['DiffP']>0.1) & (ResultDF['PDiffP']<-0.1) & (ResultDF['PercHL']>-0.1) & (ResultDF['PercHL']<0.1) &(ResultDF['G']==False) ][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL']]

def getLowDF(ResultDF):
    return ResultDF[(ResultDF['Type']=="Low") & (ResultDF['DiffP']<-0.1) & (ResultDF['PDiffP']>0.1) & ((ResultDF['PercHL']>-0.1) & (ResultDF['PercHL']<0.1)) &(ResultDF['G']==True) ][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL']]

cDate=parse(ResultDF.iloc[0]['SingleDate']).strftime("%Y-%m-%d")
ResultDF.to_csv("C:\ReadMoneycontrol\Mani 2.0\Data4\\"+cDate+"-"+minute+".csv",sep=',',encoding='utf-8',index=False)
ResultDF=ResultDF.drop_duplicates(subset=None, keep='first', inplace=False)

ResultDF[(ResultDF['Type']=="High") & (ResultDF['DiffP']>0.1) & (ResultDF['PDiffP']<-0.1) & (ResultDF['PercHL']>-0.1) & (ResultDF['PercHL']<0.1) &(ResultDF['G']==False) ][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','G']]
ResultDF[(ResultDF['Type']=="High") & (ResultDF['DiffP']>0.1) & (ResultDF['PDiffP']<-0.1) & (ResultDF['PercHL']>-0.1) & (ResultDF['PercHL']<0.1) &(ResultDF['G']==False) ][['SingleDate','Stock','PercHL','HLC','OC','HL','G']]
gkh=ResultDF[(ResultDF['Type']=="High") & (ResultDF['DiffP']>0.1) & (ResultDF['PDiffP']<-0.1) & (ResultDF['PercHL']>-0.1) & (ResultDF['PercHL']<0.1)].groupby(['CurrentDate'])
gkh1=gkh.count().sort_values(['Diff']).tail(5)
gkh1.iloc[-3:-2].index[0]
gkh.get_group(gkh1.iloc[-1:].index[0])[['SingleDate','Stock','PDiffP','DiffP','PercHL']]

gkh.get_group(gkh1.iloc[-4:-3].index[0])[['SingleDate','Stock','PDiffP','DiffP','PercHL']]

ResultDF[(ResultDF['Type']=="Low") & (ResultDF['DiffP']<-0.1) & (ResultDF['PDiffP']>0.1) & ((ResultDF['PercHL']>-0.1) & (ResultDF['PercHL']<0.1)) &(ResultDF['G']==True) ] [['SingleDate','Stock','PercHL','HLC','OC','HL','G']]
gkl=ResultDF[(ResultDF['Type']=="Low") & (ResultDF['DiffP']<-0.1) & (ResultDF['PDiffP']>0.1) & ((ResultDF['PercHL']>-0.1) & (ResultDF['PercHL']<0.1)) ].groupby(['CurrentDate'])

R=ResultDF5.groupby(['Stock','CurrentDate']).count().sort_values(['Diff']).tail(5)
gkl1=gkl.count().sort_values(['Diff']).tail(5)
gkl1=gkl.count().sort_values(['Diff']).head(5)
gkl1.iloc[-3:-2].index[0]
gkl.get_group(gkl1.iloc[-1:].index[0])[['SingleDate','Stock','PDiffP','DiffP','PercHL']]
gkl.get_group(gkl1.iloc[-2:-1].index[0])[['SingleDate','Stock','PDiffP','DiffP','PercHL']]
gkl.get_group(gkl1.iloc[-7:-6].index[0])[['SingleDate','Stock','PDiffP','DiffP','PercHL']]

#ResultDF[(ResultDF['Type']=="Low") & (ResultDF['Diff']<0) & (ResultDF['PDiff']>0) & ((ResultDF['PercHL']>-0.1) & (ResultDF['PercHL']<0.1)) ][['SingleDate','Stock','PDiffP','DiffP','PercHL']]

ResultDF.dtypes