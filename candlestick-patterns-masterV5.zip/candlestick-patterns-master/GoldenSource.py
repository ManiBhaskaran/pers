# -*- coding: utf-8 -*-
"""
Created on Sat Dec 28 00:47:57 2019

@author: lalitha
"""

Test=T2[ (T2['MaxHL']>.1) & (T2['Type']=='High') & (T2['Index']<=150) 
& (T2['MaxHLClr']=="R") & (T2['G']==False) 

    & 
   ((T2['PDiffP']>T2['CFD']) | (T2['DiffP']>T2['CFD']) ) 
#   & 
#   (T2['TPercHL']-T2['SPercHL']>=T2['CFD']) 
   
   & ((T2['PDiffP']+T2['DiffP']<=0.05) &  (T2['PDiffP']+T2['DiffP']>=-0.05)) 
   ]
