# -*- coding: utf-8 -*-
"""
Created on Sat Feb  2 09:26:58 2019

@author: lalitha
"""
from candlestick import candlestick

import pandas as pd
import datetime
import json
from datetime import timedelta  
import requests
from ehp import *
from dateutil.parser import parse
import numpy as np

def MaRound(n):
    return round(n*100/100,2)

def getPivots(High,Low,Close):
    Points={}
    #pivot,re1,re2,re3,re4,su1,su2,su3,su4,High,Close,Low
    #High=54.93
    #Low=53.09
    #Close=54.23
    pivot= MaRound((High+Low+Close)/3)
    re1 = MaRound(Close+(High-Low)*(1.1/12))
    su1 = MaRound(Close-(High-Low)*(1.1/12))
    re2 = MaRound(Close+(High-Low)*(1.1/6))
    su2 = MaRound(Close-(High-Low)*(1.1/6))
    re3 = MaRound(Close+(High-Low)*(1.1/4))
    su3 = MaRound(Close-(High-Low)*(1.1/4))
    re4 = MaRound(Close+(High-Low)*(1.1/2))
    su4 = MaRound(Close-(High-Low)*(1.1/2))
    re5 = MaRound((High/Low)*Close)
    su5 = MaRound(Close-(re5-Close))
    re41 = MaRound((re5+re4)/2)
    su41 = MaRound((su5+su4)/2)    
    Points["Pivot"]=pivot
    Points["H6"]=re5
    Points["H5"]=re41
    Points["H4"]=re4
    Points["H3"]=re3
    Points["H2"]=re2
    Points["H1"]=re1
    Points["L6"]=su5
    Points["L5"]=su41
    Points["L4"]=su4
    Points["L3"]=su3
    Points["L2"]=su2
    Points["L1"]=su1
    return Points

def ProcessCandles(Df):
    Df = candlestick.bearish_engulfing(Df)
    Df = candlestick.bullish_engulfing(Df)
    Df = candlestick.three_inside_up(Df)
    Df = candlestick.three_inside_down(Df)
    Df = candlestick.three_outside_up(Df)
    Df = candlestick.three_outside_down(Df)
    Df['MovingAverageDown']=Df['low'].rolling(window=10).mean()
    Df['MovingAverageUp']=Df['high'].rolling(window=10).mean()
    Df['MovingAverage']=Df['close'].rolling(window=10).mean()
    Df['EMA10C']=pd.DataFrame.ewm(Df['close'],min_periods=10,adjust=False,span=10).mean()
    Df['EMA10O']=pd.DataFrame.ewm(Df['open'],min_periods=10,adjust=False,span=10).mean()
    Df['EMA10H']=pd.DataFrame.ewm(Df['high'],min_periods=10,adjust=False,span=10).mean()
    Df['EMA10L']=pd.DataFrame.ewm(Df['low'],min_periods=10,adjust=False,span=10).mean()
    return Df


#getPivots
rURL="https://in.investing.com/instruments/HistoricalDataAjax"
Data="curr_id=8849&smlID=300060&header=Crude+Oil+WTI+Futures+Historical+Data&st_date=03%2F02%2F2006&end_date=02%2F02%2F2019&interval_sec=Daily&sort_col=date&sort_ord=DESC&action=historical_data"
#https://in.investing.com/instruments/HistoricalDataAjax
PatternRead= requests.post(rURL,
                                  headers={#'Cookie':'adBlockerNewUserDomains=1545933873; optimizelyEndUserId=oeu1545933885326r0.8381196045732737; _ga=GA1.2.1293495785.1545933889; __gads=ID=d6c605f22775c384:T=1545933894:S=ALNI_MbV20pH_Ga4kGvz2QBdrKhnTQtDsg; __qca=P0-530564802-1545933894749; r_p_s_n=1; G_ENABLED_IDPS=google; _gid=GA1.2.2065111802.1547570711; SideBlockUser=a%3A2%3A%7Bs%3A10%3A%22stack_size%22%3Ba%3A1%3A%7Bs%3A11%3A%22last_quotes%22%3Bi%3A8%3B%7Ds%3A6%3A%22stacks%22%3Ba%3A1%3A%7Bs%3A11%3A%22last_quotes%22%3Ba%3A3%3A%7Bi%3A0%3Ba%3A3%3A%7Bs%3A7%3A%22pair_ID%22%3Bi%3A49774%3Bs%3A10%3A%22pair_title%22%3Bs%3A0%3A%22%22%3Bs%3A9%3A%22pair_link%22%3Bs%3A32%3A%22%2Fcommodities%2Fcrude-oil%3Fcid%3D49774%22%3B%7Di%3A1%3Ba%3A3%3A%7Bs%3A7%3A%22pair_ID%22%3Bs%3A4%3A%228849%22%3Bs%3A10%3A%22pair_title%22%3Bs%3A0%3A%22%22%3Bs%3A9%3A%22pair_link%22%3Bs%3A22%3A%22%2Fcommodities%2Fcrude-oil%22%3B%7Di%3A2%3Ba%3A3%3A%7Bs%3A7%3A%22pair_ID%22%3Bs%3A4%3A%228830%22%3Bs%3A10%3A%22pair_title%22%3Bs%3A0%3A%22%22%3Bs%3A9%3A%22pair_link%22%3Bs%3A17%3A%22%2Fcommodities%2Fgold%22%3B%7D%7D%7D%7D; PHPSESSID=t127q9ns2htigac1b5j8lr2tdg; geoC=IN; comment_notification_204870192=1; gtmFired=OK; StickySession=id.51537812219.831in.investing.com; billboardCounter_56=1; nyxDorf=MDFkNWcvMG03YGBtN3pmZTJnNGs0LTI5YGY%3D; _fbp=fb.1.1547680426904.1355133887; ses_id=Nng3dm5hMDg0cGpsNGU1NzRhZDcyMmFjYmJhazo%2FZHJlcTQ6ZTIwdmFuaiRubTklMjQ3NjM3ZmYxM2JrO2xnMjZlNzZuPTBtNDdqZTQzNWE0Y2Q5MjJhamIxYWo6aWQ%2FZTc0N2UxMGZhZGpgbjM5YzIgNyszd2Z3MWNiMjt6ZyA2OTd2bj0wPzRhajA0NTVlNGFkOTI1YTJiamEwOmtkfGUu',
                                           'Referer':'https://in.investing.com/commodities/crude-oil-historical-data',
                                           'User-Agent':'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36'
                                           ,'X-Requested-With': 'XMLHttpRequest'
                                           ,"Content-Type": "application/x-www-form-urlencoded"
                                           },
                                          data=Data
                                  ) #GOLD
PatternRead.text
CrudeData1 = pd.read_html(PatternRead.text)[0]
i=-1
Pivot=[]
while(i<len(CrudeData1)-1):
    i=i+1
    Res=getPivots(CrudeData1.iloc[i]['High'],CrudeData1.iloc[i]['Low'],CrudeData1.iloc[i]['Price'])
    Res['Date']=CrudeData1.iloc[i]['Date']
    Pivot.append(Res)

List_ = list(CrudeData1['Date'])
List_ = [datetime.datetime.strptime(parse(x).strftime("%m/%d/%Y %I:%M %p"), "%m/%d/%Y %I:%M %p") for x in List_]
CrudeData1['Date']=pd.Series([x for x in List_],index=CrudeData1.index)
Pivotdf=pd.read_json(json.dumps(Pivot))    
CrudeData=CrudeData1.merge(Pivotdf)
CrudeData.to_csv('C:/ReadMoneycontrol/Crude/CRUDEHISTORY.csv',sep=';',encoding='utf-8') 
CrudeData.iloc[3]


TimeIntervals=[900,1800]
URLDict={}
StrTimeIntervals=['15M','30M']
CrudeURL='https://in.investing.com/common/modules/js_instrument_chart/api/data.php?pair_id=8849&pair_id_for_news=8849&chart_type=candlestick&pair_interval=INTERVAL&candle_count=CNT&events=patterns_only&volume_series=yes&period='
#ZincURL='https://in.investing.com/common/modules/js_instrument_chart/api/data.php?pair_id=49794&pair_id_for_news=49794&chart_type=candlestick&pair_interval=INTERVAL&candle_count=CNT&events=patterns_only&volume_series=yes'
#LeadURL='https://in.investing.com/common/modules/js_instrument_chart/api/data.php?pair_id=49784&pair_id_for_news=49784&chart_type=candlestick&pair_interval=INTERVAL&candle_count=CNT&events=patterns_only&volume_series=yes'
#GoldURL='https://in.investing.com/common/modules/js_instrument_chart/api/data.php?pair_id=49778&pair_id_for_news=49778&chart_type=candlestick&pair_interval=INTERVAL&candle_count=CNT&events=patterns_only&volume_series=yes'
#URL=GoldURL
#URL=LeadURL
#URL=CrudeURL
URLDict['Crude']=CrudeURL
#URLDict['Lead']=LeadURL
#URLDict['Zinc']=ZincURL
#URLDict['Gold']=GoldURL


FirstDataSet=True
for URL1 in URLDict:
    #print(URLDict[URL1])
    URL=URLDict[URL1]
    #N1(Res.index[0],'15M','-')
    
    # Find candles where inverted hammer is detected
    cnt=500
    Index=-1
    #if(True):
    for TimeInterval in TimeIntervals:
        Index=Index+1
        #TimeInterval=TimeIntervals[Index]
        rURL=URL.replace('INTERVAL',str(TimeInterval))
        rURL=rURL.replace('CNT',str(cnt))
        #print(rURL)
        PatternRead= requests.get(rURL,
                                  headers={#'Cookie':'adBlockerNewUserDomains=1545933873; optimizelyEndUserId=oeu1545933885326r0.8381196045732737; _ga=GA1.2.1293495785.1545933889; __gads=ID=d6c605f22775c384:T=1545933894:S=ALNI_MbV20pH_Ga4kGvz2QBdrKhnTQtDsg; __qca=P0-530564802-1545933894749; r_p_s_n=1; G_ENABLED_IDPS=google; _gid=GA1.2.2065111802.1547570711; SideBlockUser=a%3A2%3A%7Bs%3A10%3A%22stack_size%22%3Ba%3A1%3A%7Bs%3A11%3A%22last_quotes%22%3Bi%3A8%3B%7Ds%3A6%3A%22stacks%22%3Ba%3A1%3A%7Bs%3A11%3A%22last_quotes%22%3Ba%3A3%3A%7Bi%3A0%3Ba%3A3%3A%7Bs%3A7%3A%22pair_ID%22%3Bi%3A49774%3Bs%3A10%3A%22pair_title%22%3Bs%3A0%3A%22%22%3Bs%3A9%3A%22pair_link%22%3Bs%3A32%3A%22%2Fcommodities%2Fcrude-oil%3Fcid%3D49774%22%3B%7Di%3A1%3Ba%3A3%3A%7Bs%3A7%3A%22pair_ID%22%3Bs%3A4%3A%228849%22%3Bs%3A10%3A%22pair_title%22%3Bs%3A0%3A%22%22%3Bs%3A9%3A%22pair_link%22%3Bs%3A22%3A%22%2Fcommodities%2Fcrude-oil%22%3B%7Di%3A2%3Ba%3A3%3A%7Bs%3A7%3A%22pair_ID%22%3Bs%3A4%3A%228830%22%3Bs%3A10%3A%22pair_title%22%3Bs%3A0%3A%22%22%3Bs%3A9%3A%22pair_link%22%3Bs%3A17%3A%22%2Fcommodities%2Fgold%22%3B%7D%7D%7D%7D; PHPSESSID=t127q9ns2htigac1b5j8lr2tdg; geoC=IN; comment_notification_204870192=1; gtmFired=OK; StickySession=id.51537812219.831in.investing.com; billboardCounter_56=1; nyxDorf=MDFkNWcvMG03YGBtN3pmZTJnNGs0LTI5YGY%3D; _fbp=fb.1.1547680426904.1355133887; ses_id=Nng3dm5hMDg0cGpsNGU1NzRhZDcyMmFjYmJhazo%2FZHJlcTQ6ZTIwdmFuaiRubTklMjQ3NjM3ZmYxM2JrO2xnMjZlNzZuPTBtNDdqZTQzNWE0Y2Q5MjJhamIxYWo6aWQ%2FZTc0N2UxMGZhZGpgbjM5YzIgNyszd2Z3MWNiMjt6ZyA2OTd2bj0wPzRhajA0NTVlNGFkOTI1YTJiamEwOmtkfGUu',
                                           'Referer':'https://in.investing.com/commodities/crude-oil-candlestick',
                                           'User-Agent':'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36'
                                           ,'X-Requested-With': 'XMLHttpRequest'
                                           }
                                  ) #GOLD
        #from lxml.html import parse
        Candles=PatternRead.json()['candles']
        DataSet=pd.DataFrame(data=Candles,columns=['Date','open','high','low','close','volume','volume1'])
        
        List_ = list(DataSet['Date'])
        #List_ = [parse(x).strftime for x in List_]
        List_ = [datetime.datetime.fromtimestamp(x/1000).strftime('%Y-%m-%d %H:%M:%S') for x in List_]
        DataSet['Date']=pd.Series([x for x in List_],index=DataSet.index)
        if(TimeInterval==900):
            CrudeDf15Min=DataSet
            DataSet1=DataSet.sort_values(by='Date',ascending=False)
            CrudeDf15Min=ProcessCandles(CrudeDf15Min)
        elif(TimeInterval==1800):
            CrudeDf30Min=DataSet
            DataSet1=DataSet.sort_values(by='Date',ascending=False)
            CrudeDf30Min=ProcessCandles(CrudeDf30Min)

List_ = list(CrudeDf30Min['Date'])
#parse(List_[0] ).hour
CrudeDf30Min['Hour'] = pd.Series([parse(x).hour for x in List_],index=CrudeDf30Min.index)
CrudeDf30Min=ProcessCandles(CrudeDf30Min)
#a=pd.DataFrame.ewm(CrudeDf30Min['close'],min_periods=10,adjust=False,span=10).mean()
#CrudeDf30Min

List_ = list(CrudeDf15Min['Date'])
#List_ = [parse(x).strftime for x in List_]
List_ = [datetime.datetime.strptime(parse(x).strftime("%m/%d/%Y %I:%M %p"), "%m/%d/%Y %I:%M %p") for x in List_]
CrudeDf15Min['Date']=pd.Series([x for x in List_],index=CrudeDf15Min.index)

List_ = list(CrudeDf30Min['Date'])
#List_ = [parse(x).strftime for x in List_]
List_ = [datetime.datetime.strptime(parse(x).strftime("%m/%d/%Y %I:%M %p"), "%m/%d/%Y %I:%M %p") for x in List_]
CrudeDf30Min['Date']=pd.Series([x for x in List_],index=CrudeDf30Min.index)


CrudeDf30Min.iloc[473-1]

CrudeDf30Min[ (CrudeDf30Min['ThreeOutsideUp']==True)] 

TempData=CrudeDf30Min[ (CrudeDf30Min['ThreeOutsideUp']==True) 
             &(CrudeDf30Min['MovingAverageUp'] < CrudeDf30Min['close'])
             ]

CrudeDf30Min[ (CrudeDf30Min['ThreeOutsideDown']==True) 
             &(CrudeDf30Min['MovingAverageUp'] < CrudeDf30Min['close'])
             ]

CrudeDf30Min[ (CrudeDf30Min['ThreeOutsideDown']==True) ]
CrudeDf30Min[ (CrudeDf30Min['ThreeOutsideDown']==True) 
             & (CrudeDf30Min['EMA10C'] < CrudeDf30Min['open'])
             ]
CrudeDf30Min[ (CrudeDf30Min['ThreeOutsideUp']==True)] 
TempData=CrudeDf30Min[ (CrudeDf30Min['ThreeOutsideUp']==True) & (CrudeDf30Min['Hour']>=9)]

TempData=CrudeDf30Min[ (CrudeDf30Min['ThreeOutsideDown']==True) & (CrudeDf30Min['Hour']>=9)]

CrudeDf30Min[ (CrudeDf30Min['ThreeInsideDown']==True) & (CrudeDf30Min['Hour']>=9)]
CrudeDf30Min[ (CrudeDf30Min['ThreeOutsideDown']==True) & (CrudeDf30Min['Hour']>=9)]
CrudeDf30Min[ (CrudeDf30Min['BearishEngulfing']==True) & (CrudeDf30Min['Hour']>=9)]

CrudeDf30Min[ (CrudeDf30Min['BullishEngulfing']==True) & (CrudeDf30Min['Hour']>=9)]
CrudeDf30Min[ (CrudeDf30Min['ThreeOutsideUp']==True) & (CrudeDf30Min['Hour']>=9)]
CrudeDf30Min[ (CrudeDf30Min['ThreeInsideUp']==True) & (CrudeDf30Min['Hour']>=9)]
TempData=CrudeDf30Min[ (CrudeDf30Min['ThreeOutsideDown']==True) 
             &(CrudeDf30Min['MovingAverageUp'] < CrudeDf30Min['close'])
              ]

CrudeDf30Min.iloc[384]

#CrudeDf30Min = candlestick.doji_star(CrudeDf30Min)
#CrudeDf30Min = candlestick.bearish_harami(CrudeDf30Min)
#CrudeDf30Min = candlestick.bullish_harami(CrudeDf30Min)
#CrudeDf30Min = candlestick.doji(CrudeDf30Min)
#BearishEngulfing
#BullishEngulfing
#TempData=CrudeDf30Min
CrudeDf30Min.dtypes

TempData=CrudeDf30Min[ (CrudeDf30Min['ThreeOutsideUp']==True) & (CrudeDf30Min['Hour']>=9)] #Buy

Index=473
TempData.iloc[0]
Price=0.0075
SignalStatus=Check(CrudeDf30Min,"Buy",Index,Price,Price*1.5,CrudeDf15Min)
print(SignalStatus)

TotalTempData=len(TempData)
ArSignalStatus=[]
PriceDiff={}
ProfitPerPercent={}
Price=0.0025
while(Price<0.02):
    Profit=0
    i=0
    BuySucceed=0
    while(i<TotalTempData):        
        print(str(i) + " -- "+ str(TempData.index[i]))
        SignalStatus=Check(CrudeDf30Min,"Sell",TempData.index[i],Price,Price*1.5,CrudeDf15Min)
        ArSignalStatus.append(SignalStatus)        
        #if(SignalStatus==True):
        #    BuySucceed=BuySucceed+1        
        i=i+1
    #PriceDiff[Price]=BuySucceed/(TotalTempData-1)*100
    #ProfitPerPercent[Price]=Profit
    Price=Price+0.0025
    
ArSignalStatusdf=pd.read_json(json.dumps(ArSignalStatus))
ArSignalStatusdf[(ArSignalStatusdf['Percentage']>=0.0025) & (ArSignalStatusdf['Percentage']<=0.0025+0.002)]['Percentage']
ArSignalStatusdf1=ArSignalStatusdf[(ArSignalStatusdf["Time"].isnull()==False)]

Pricear=[]
#Pricest={}
Price=0.0025
while(Price<0.02):
    Pricest={}
    Pricest["Price"]=Price
    Pricest["TotalSignal"]=len(ArSignalStatusdf1[(ArSignalStatusdf1['Percentage']>=Price) & (ArSignalStatusdf1['Percentage']<=Price+0.002)])
    Pricest["TotalProfit"]=len(ArSignalStatusdf1[(ArSignalStatusdf1['Percentage']>=Price) & (ArSignalStatusdf1['Percentage']<=Price+0.002) & (ArSignalStatusdf['Hit']=="Hit")])
    Pricest["TotalStopLoss"]=len(ArSignalStatusdf1[(ArSignalStatusdf1['Percentage']>=Price) & (ArSignalStatusdf1['Percentage']<=Price+0.002) & (ArSignalStatusdf['Hit']=="StopLoss")])
    Pricest["TotalLProfit"]=len(ArSignalStatusdf1[(ArSignalStatusdf1['Percentage']>=Price) & (ArSignalStatusdf1['Percentage']<=Price+0.002) & (ArSignalStatusdf['Hit']=="LastPrice-Profit")])
    Pricest["TotalLLoss"]=len(ArSignalStatusdf1[(ArSignalStatusdf1['Percentage']>=Price) & (ArSignalStatusdf1['Percentage']<=Price+0.002) & (ArSignalStatusdf['Hit']=="LastPriceHit-Loss")])        
    Pricest["Profit"]=ArSignalStatusdf1[(ArSignalStatusdf1['Percentage']>=Price)  & (ArSignalStatusdf1['Percentage']<=Price+0.002) ]['Profit'].sum()    
    Pricear.append(Pricest)
    Price=Price+0.0025
Pricedf=pd.read_json(json.dumps(Pricear))
Pricedf[['Price','TotalProfit','Profit']]
        
ArSignalStatusdf1[ArSignalStatusdf1['Percentage']==0.0075][['Time','TargetTime']]        

ArSignalStatusdf1[ArSignalStatusdf1['Percentage']==0.005][['Time','TargetTime']]
ArSignalStatusdf1[ArSignalStatusdf1['Percentage']==0.005][['Time','StopLossTime','Profit']]
    
ArSignalStatusdf.iloc[0]
ArSignalStatusdf[ArSignalStatusdf['Percentage']==0.0025]['TotalProfit']
ArSignalStatusdf[(ArSignalStatusdf['Percentage']==0.0025) & (ArSignalStatusdf["Time"].isnull()==False)][['Date','Time','Hit']]
ArSignalStatusdf[ArSignalStatusdf["Time"].isnull()==False]
ArSignalStatusdf[(ArSignalStatusdf['Percentage']==0.0025) * ArSignalStatusdf['Hit']=="BuyHit"][['Time','TargetTime']]
ArSignalStatusdf[(ArSignalStatusdf['Percentage']==0.0025) * ArSignalStatusdf['Hit']=="BuyHit"][['Time','StopLossTime']]
