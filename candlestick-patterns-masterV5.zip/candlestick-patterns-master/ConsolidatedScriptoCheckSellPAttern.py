# -*- coding: utf-8 -*-
"""
Created on Fri Dec 27 23:11:49 2019

@author: lalitha
"""

Test=SData[
        (
        (SData['MaxHL']>1) & (SData['DiffP']<(SData['CFD']*1)) 
#   & (SData['CFD']<.6)
   & (SData['Type']=="High")
   & (SData['Index']<20)
   & (SData['TPercOL']<SData['CFD'])
   & (SData['PercHL']>-.01) & (SData['PercHL']<.2) 
   #& (SData['PercHL']>=.2)
   )

| ((SData['MaxHL']>.1) & (SData['Type']=='High') & (SData['Index']<=150) 
& (SData['MaxHLClr']=="R") & (SData['G']==False) 

    & 
   ((SData['PDiffP']>SData['CFD']) | (SData['DiffP']>SData['CFD']) ) 
#   & 
#   (SData['TPercHL']-SData['SPercHL']>=SData['CFD']) 
   
   & ((SData['PDiffP']+SData['DiffP']<=0.05) &  (SData['PDiffP']+SData['DiffP']>=-0.05)) 
   )



|
(    (SData['PercHL']>-.01) & (SData['PercHL']<.2) &
#`    (SData['Index']>20) &
    (SData['Index']<=20) &
    (SData['CFD']<=1) &
    (SData['CC']<1200) &
    (SData['CGap']>-.01) & (SData['CGap']<1) &
    #(SData['CC']<=600) &
     (SData['TPercOL']<SData['TPercHO']) &
#          (SData['CFD']>.4) &
#    & (SData['TPercHL']>1) &
#     (SData['TPercHL']>=2) &
#     (SData['PercHL']<SData['CFD']) &
#     (SData['TPercHO']>=SData['CFD']*2) &
     (SData['TPercHO']>=SData['CFD']*1.5) &
     (SData['MaxHL']>1) &        
        (SData['Type']=="High") 
        & (SData['HCLevel']!="H1")
        & (((SData['HCFib']=="A1500") | (SData['HCFib']=="A2000") 
        | (SData['HCFib']=="A1786")
        | (SData['HCFib']=="A1618")
        | (SData['HCFib']=="A2236")
        | (SData['HCFib']=="A1236")
        | (SData['HCFib']=="A2382")
        | (SData['HCFib']=="A1382")
        | (SData['HCFib']=="A2500")) 
##(SData['HCLevel']=="H1") | 
        | ((SData['HCLevel']=="H2")| (SData['HCLevel']=="H3")| (SData['HCLevel']=="H4")))
)
]