# -*- coding: utf-8 -*-
"""
Created on Tue Nov 26 07:59:38 2019

@author: lalitha
"""

#Results Up Trend
TR=ResultDF51[(ResultDF51['HLC']!=ResultDF51['OC']) & (ResultDF51['DiffP']<-0.1) & (ResultDF51['PDiffP']>0.1)][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]
TR[TR.duplicated(['Stock','SingleDate'])][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]
TR[TR['Stock']=="PNB"][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]
#Default -- end
#Down Trend
TR=ResultDF51[(ResultDF51['HLC']!=ResultDF51['OC']) & (ResultDF51['DiffP']<0.1) & (ResultDF51['PDiffP']<-0.1)][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]
TR[TR.duplicated(['Stock','SingleDate'])][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]
##Results ......... UP trend
TR=ResultDF51[(ResultDF51['HLC']!=ResultDF51['OC']) & (ResultDF51['DiffP']<0.1) & (ResultDF51['PDiffP']>-0.1)][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]
TR[TR.duplicated(['Stock','SingleDate'])][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]


#########################
####Results Up Trend
TR=ResultDF51[(ResultDF51['HLC']!=ResultDF51['OC']) & (ResultDF51['DiffP']<-0.1) & (ResultDF51['PDiffP']>-0.1)][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]
TR[TR.duplicated(['Stock','SingleDate'])][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]
#Default -- end
#Down Trend
TR=ResultDF51[(ResultDF51['HLC']!=ResultDF51['OC']) & (ResultDF51['DiffP']>0.1) & (ResultDF51['PDiffP']<-1)][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]
TR[TR.duplicated(['Stock','SingleDate'])][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]


##Results ......... Down trend
TR=ResultDF51[(ResultDF51['HLC']!=ResultDF51['OC']) & (ResultDF51['DiffP']<0.1) & (ResultDF51['PDiffP']<-1)][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]
TR[TR.duplicated(['Stock','SingleDate'])][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]
#################
###Up Trend
TR=ResultDF51[(ResultDF51['HLC']!=ResultDF51['OC']) & (ResultDF51['DiffP']>-0.1) & (ResultDF51['PDiffP']>1)][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]
TR[TR.duplicated(['Stock','SingleDate'])][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]
##Results ......... UP trend
TR=ResultDF51[(ResultDF51['HLC']!=ResultDF51['OC']) & (ResultDF51['DiffP']<-0.1) & (ResultDF51['PDiffP']>1)][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]
TR[TR.duplicated(['Stock','SingleDate'])][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]






TR=ResultDF51[(ResultDF51['HLC']!=ResultDF51['OC']) & (ResultDF51['DiffP']<0.1) & (ResultDF51['PDiffP']<-.5)]
TR[['Stock',
        'CurrentDate','SingleDate','PDiffP','DiffP','HL', 'HLC','OC', 'PercHL','G','Type']]

ResultDF5=ResultDF51
TR=ResultDF5[(ResultDF5['HLC']!=ResultDF5['OC']) & (ResultDF5['DiffP']<0.1) & (ResultDF5['PDiffP']<-.5)]
TR[['Stock',
        'CurrentDate','SingleDate','PDiffP','DiffP','HL', 'HLC','OC', 'PercHL','G','Type']]



#Down Trend
TR=ResultDF5[(ResultDF5['HLC']!=ResultDF5['OC']) & (ResultDF5['DiffP']<0.1) & (ResultDF5['PDiffP']<-.5)]
TR[['Stock',
        'CurrentDate','SingleDate','PDiffP','DiffP','HL', 'HLC','OC', 'PercHL','G','Type']]
#Down Trend when type is high
ResultDF5[(ResultDF5['HLC']!=ResultDF5['OC']) & (ResultDF5['DiffP']>0.1) 
          & (ResultDF5['PDiffP']<-.5)][['Stock',
        'CurrentDate','SingleDate','PDiffP','DiffP','HL', 'HLC','OC', 'PercHL','G','Type','Index']]
#Looks Up Trend
TR=ResultDF5[(ResultDF5['HLC']!=ResultDF5['OC']) & (ResultDF5['DiffP']>-0.1) & (ResultDF5['PDiffP']>.5)]
TR[['Stock',
        'CurrentDate','SingleDate','PDiffP','DiffP','HL', 'HLC','OC', 'PercHL','G','Type']]
#TR[TR.duplicated(['Stock','SingleDate'])]
#Up Trend on duplicates
TR=ResultDF5[(ResultDF5['HLC']!=ResultDF5['OC']) & (ResultDF5['DiffP']<-0.1) & (ResultDF5['PDiffP']>.5)]
#[['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]
TR[['Stock',
        'CurrentDate','SingleDate','PDiffP','DiffP','HL', 'HLC','OC', 'PercHL','G','Type']]

#[['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]

#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
