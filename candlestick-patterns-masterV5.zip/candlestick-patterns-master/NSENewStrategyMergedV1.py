# -*- coding: utf-8 -*-
"""
Created on Fri Nov 29 23:04:37 2019

@author: lalitha
"""


import requests
from dateutil.parser import parse
import plotly.graph_objs as go
from plotly import __version__
from plotly.offline import download_plotlyjs, init_notebook_mode, plot, iplot
import numpy as np
import plotly.io as pio
import os

#import datetime
import threading

from candlestick import candlestick
#import datetime
import pandas as pd
import json
import time
from dateutil.parser import parse
from datetime import datetime, timedelta
pd.set_option('display.max_columns', 500)
pd.set_option('display.max_rows', 1500)
#from datetime import datetime

def isPeak(arr, n, num, i, j): 

	# If num is smaller than the element 
	# on the left (if exists) 
	if (i >= 0 and arr[i] > num): 
		return False

	# If num is smaller than the element 
	# on the right (if exists) 
	if (j < n and arr[j] > num): 
		return False
	return True

# Function that returns true if num is 
# smaller than both arr[i] and arr[j] 
def isTrough(arr, n, num, i, j): 

	# If num is greater than the element 
	# on the left (if exists) 
	if (i >= 0 and arr[i] < num): 
		return False

	# If num is greater than the element 
	# on the right (if exists) 
	if (j < n and arr[j] < num): 
		return False
	return True

def printPeaksTroughs(arr, n): 

	print("Peaks : ", end = "") 

	# For every element 
	for i in range(n): 

		# If the current element is a peak 
		if (isPeak(arr, n, arr[i], i - 1, i + 1)): 
			print(arr[i], end = " ") 
	print() 

	print("Troughs : ", end = "") 

	# For every element 
	for i in range(n): 

		# If the current element is a trough 
		if (isTrough(arr, n, arr[i], i - 1, i + 1)): 
			print(arr[i], end = " ") 



def Process(iPercentage,ioffset,DataFrameCollection):    
    ResultAr=[]
    p=-1
    while(p<len(StockList)-1):
        p=p+1
        #print(StockList.iloc[p]['Symbol'])
        Symbol=StockList.iloc[p]['Symbol']
        Data=DataFrameCollection[StockList.iloc[p]['Symbol']].fillna(0)
        LastPivot=pd.read_csv(r"C:\ReadMoneycontrol\Mani 2.0\Data3\\"+Symbol+"-Pivot.csv",encoding='utf-8')
        PivotD=LastPivot.iloc[DateIndex*-1]
        i=0
        Percentage=iPercentage
        offset=ioffset
        T=round(Data.iloc[0]['Open']*Percentage,2)
        HighList=[]
        LowList=[]
        
        
        while(i<len(Data)):
            ResultSt={}
            H=Data.iloc[i]['High']
            L=Data.iloc[i]['Low']
            #H=Data['High'].max()
            #L=Data['Low'].max()
        #PivotD
            RangeList=getChartRangeList(H,L,PivotD)
                
            
            for R in RangeList:
                #R="A1000"
                if( H==PivotD[R]):
                    #print(R+" High Same" + Data.iloc[i]['Date'])
                    HighList.append(i)
                elif( H+T>=PivotD[R]>=H-T):
                    #print(str(i)+ "==> "+ R+" High Approx " + Data.iloc[i]['Date'] +" - "+ str(H+T) + " = " + str(PivotD[R]) + " = "+ str(H-T))
                    HighList.append(i)
                if( L==PivotD[R]):
                    #print(R+" Low Same" + Data.iloc[i]['Date'])
                    LowList.append(i)
                elif( L+T>=PivotD[R]>=L-T):
                    #print(str(i)+ "==> "+ R+" Low Approx " + Data.iloc[i]['Date'] +" - "+ str(L+T) + " = " + str(PivotD[R]) + " = "+ str(L-T))
                    LowList.append(i)    
            
            if(str(HighList).find(str(i-offset)+"")>0):
                a=isPeak(Data['High'][:i], len(Data['High'][:i]), Data.iloc[i-offset]['High'], i-(offset*2), i)
                if(a):
                    #ResultSt={}
                    Diff=round(Data.iloc[i-offset]['High']-Data.iloc[i]['High'],2)
                    DiffP=round(Diff/Data.iloc[i]['High']*100,2)
                    PDiff=round(Data.iloc[i-(offset*2)]['High']-Data.iloc[i-offset]['High'],2)
                    PDiffP=round(PDiff/Data.iloc[i-offset]['High']*100,2)
                    #print(str(i)+ " - " + Data.iloc[i]['Date'] + " HIGH - " +Data.iloc[i-offset]['Date'] + " - " + str(a) + " - " + str(Diff) + " ~ " + str(DiffP));                    
                    ResultSt['Stock']=Symbol
                    ResultSt['Index']=i
                    ResultSt['CurrentDate']=Data.iloc[i]['Date']
                    ResultSt['Type']='High'
                    ResultSt['SingleDate']=Data.iloc[i-offset]['Date']
                    ResultSt['Diff']=Diff
                    ResultSt['DiffP']=DiffP
                    ResultSt['PDiff']=PDiff
                    ResultSt['PDiffP']=PDiffP
                    
                    
                    ResultSt['PercHL']=round((Data.iloc[:i]['High'].max()-Data.iloc[i-offset]['High']+0.00001)/Data.iloc[i-offset]['High']*100,2)
                    H,L,C,O=list(Data.iloc[i-offset][['High',"Low","Close","Open"]])
                    ResultSt['HLC']=round((H-C)/C*100,2)
                    ResultSt['HL']=round((H-L)/L*100,2)
                    ResultSt['OC']=round((O-C)/C*100,2)
                    ResultSt['G']=O>C
                    ResultAr.append(ResultSt)
            if(str(LowList).find(str(i-offset)+"")>0):
                Trough=isTrough(Data['Low'][:i], len(Data['Low'][:i]), Data.iloc[i-offset]['Low'], i-(offset*2), i-1)
                if(Trough):
                    #ResultSt={}
                    Diff=round(Data.iloc[i-offset]['Low']-Data.iloc[i]['Low'],2)
                    DiffP=round(Diff/Data.iloc[i]['Low']*100,2)
                    PDiff=round(Data.iloc[i-(offset*2)]['Low']-Data.iloc[i-offset]['Low'],2)
                    PDiffP=round(PDiff/Data.iloc[i-offset]['Low']*100,2)
                    #print(str(i)+ " - "+Data.iloc[i]['Date'] + " Low - " +Data.iloc[i-offset]['Date'] + " - " + str(Trough)+ " - " + str(Diff) + " ~ " + str(DiffP));    
                    ResultSt['Stock']=Symbol
                    ResultSt['Index']=i
                    ResultSt['CurrentDate']=Data.iloc[i]['Date']
                    ResultSt['Type']='Low'
                    ResultSt['SingleDate']=Data.iloc[i-offset]['Date']
                    ResultSt['Diff']=Diff
                    ResultSt['DiffP']=DiffP
                    ResultSt['PDiff']=PDiff
                    ResultSt['PDiffP']=PDiffP
                    ResultSt['PercHL']=round((Data.iloc[:i]['Low'].min()-Data.iloc[i-offset]['Low']+0.00001)/Data.iloc[i-offset]['Low']*100,2)
                    H,L,C,O=list(Data.iloc[i-offset][['High',"Low","Close","Open"]])
                    ResultSt['HLC']=round((L-C)/C*100,2)
                    ResultSt['HL']=round((H-L)/L*100,2)
                    ResultSt['OC']=round((O-C)/C*100,2)
                    ResultSt['G']=O>C
                    ResultAr.append(ResultSt)
            i=i+1
    
    ResultDF=pd.DataFrame(ResultAr)
    return ResultDF


def getHighDF(ResultDF):
    return ResultDF[(ResultDF['Type']=="High") & (ResultDF['DiffP']>0.1) & (ResultDF['PDiffP']<-0.1) & (ResultDF['PercHL']>-0.1) & (ResultDF['PercHL']<0.1) &(ResultDF['G']==False) ][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL']]

def getLowDF(ResultDF):
    return ResultDF[(ResultDF['Type']=="Low") & (ResultDF['DiffP']<-0.1) & (ResultDF['PDiffP']>0.1) & ((ResultDF['PercHL']>-0.1) & (ResultDF['PercHL']<0.1)) &(ResultDF['G']==True) ][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL']]

def getChartRangeList(H,L,PivotData):
    PS=['IPivot','L1','L2','L3']
    PR=['IPivot','H1','H2','H3']
    PU=['A0','A236','A382','A500','A618','A786','A1000','A1236','A1382','A1500','A1618','A1786','A2000','A2236','A2382','A2500','A2618','A2786','A3000','A3236','A3382','A3500','A3618','A3786','A4000']
    PL=['Z236','Z382','Z500','Z618','Z786','Z1000','Z1236','Z1382','Z1500','Z1618','Z1786','Z2000','Z2236','Z2382','Z2500','Z2618','Z2786','Z3000','Z3236','Z3382','Z3500','Z3618','Z3786','Z4000']
    PFIB=PU+PL
    PFIBD=PU[::-1]+PL
    PRANGED=list(dict.fromkeys(PR[::-1]+PS))
    PRANGE=PR+PS
    FibList=getChartList(H,L,PFIBD,PFIBD,PivotData)
    RangeList=getChartList(H,L,PRANGED,PRANGED,PivotData)
    return FibList+RangeList
    

def getChartList(H,L,PComp,SortSeries,PivotD):
#PComp=PFIB #PFIB #PRANGE
    i=0
    UBound=""
    LBound=""
    PCompRev=PComp[::-1]
    while(i<len(PComp)-1):
        if(PivotD[PComp[i]]>=L<=PivotD[PComp[i+1]]):
            t=1
        elif(PivotD[PComp[i]]>=L):
            t=1
            if(PivotD[PComp[i+1]]<=L):
 #               print(PComp[i+1] + " => "+str(PivotD[PComp[i+1]]))
                LBound=PComp[i+1]
        if(PivotD[PCompRev[i+1]]>=H<=PivotD[PCompRev[i]]):
            t=1
        elif(PivotD[PCompRev[i]]<=H):
            t=1
            if(PivotD[PCompRev[i+1]]>=H):
#                print(PCompRev[i+1] + " -=> "+str(PivotD[PCompRev[i+1]]))
                UBound=PCompRev[i+1]
        i=i+1
    #print(UBound + "= "+  LBound)
    if(UBound!="" and LBound!=""):
        #print("t")
        return SortSeries[SortSeries.index(UBound):SortSeries.index(LBound)+1]
    else:
        #print("f")
        return []

def ProcessZ(iPercentage,ioffset,DataFrameCollection,y,RealTime):    
    global dd
    ResultAr=[]
    p=-1
    while(p<len(StockList)-1):
        p=p+1
        #print(StockList.iloc[p]['Symbol'])
        #iPercentage=iP
        #ioffset=iO
        #y=1
        #Symbol="ZEEL"
        Symbol=StockList.iloc[p]['Symbol']
        Data1=DataFrameCollection[StockList.iloc[p]['Symbol']].fillna(0)
        #Data1=Min5DF[Symbol]
        Data1=candlestick.doji(Data1)
        Data1=candlestick.doji_star(Data1)
        Data1=candlestick.hammer(Data1)
        Data1=candlestick.inverted_hammer(Data1)
        #dd=Data
        if(RealTime==False):
            LastPivot=pd.read_csv(r"C:\ReadMoneycontrol\Mani 2.0\Data3\\"+Symbol+"-Pivot.csv",encoding='utf-8')
            PivotD=LastPivot.iloc[DateIndex*-1]
            PivotD1=LastPivot.iloc[(DateIndex+1)*-1]
        else:
            PivotD=DPivot[DPivot['Symbol']==Symbol].iloc[1]
            PivotD1=DPivot[DPivot['Symbol']==Symbol].iloc[0]
        i=0
        Percentage=iPercentage
        offset=ioffset
        T=round(Data1.iloc[0]['Open']*Percentage,2)
        HighList=[]
        LowList=[]
        
        PHighList=[]
        PLowList=[]
        
        Tempi=-2
        
        FibListar=[]
        LFibListar=[]
        while(i<len(Data1)):
            #print(i)
            FibListSt={}
            #FibListSt={}
            Data=Data1[:i+y]
            ResultSt={}
            H=Data.iloc[i]['High']
            L=Data.iloc[i]['Low']
            #H=Data['High'].max()
            #L=Data['Low'].max()
        #PivotD
            RangeList=getChartRangeList(H,L,PivotD)
            PRangeList=getChartRangeList(H,L,PivotD1)    
            FibListSt["HCFib"]=""
            FibListSt["HPFib"]=""
            FibListSt["HCLevel"]=""
            FibListSt["HPLevel"]=""
            FibListSt["I"]=i
            FibListSt["LCFib"]=""
            FibListSt["LPFib"]=""
            FibListSt["LCLevel"]=""
            FibListSt["LPLevel"]=""
            #LFibListSt["I"]=i
            for R in RangeList:
                Found=False
                #R="A1000"
                if( H==PivotD[R]):
                    #print(R+" High Same" + Data.iloc[i]['Date'])
                    HighList.append(i)
                    Found=True                    
                elif( H+T>=PivotD[R]>=H-T):
                    #print(str(i)+ "==> "+ R+" High Approx " + Data.iloc[i]['Date'] +" - "+ str(H+T) + " = " + str(PivotD[R]) + " = "+ str(H-T))
                    HighList.append(i)
                    Found=True
                if (Found):
                    if((R.find("A")>=0) | (R.find("Z")>=0)):
                        FibListSt["HCFib"]=R
                    else:
                        FibListSt["HCLevel"]=R
                Found=False
                if( L==PivotD[R]):
                    #print(R+" Low Same" + Data.iloc[i]['Date'])
                    LowList.append(i)
                    Found=True
                elif( L+T>=PivotD[R]>=L-T):
                    #print(str(i)+ "==> "+ R+" Low Approx " + Data.iloc[i]['Date'] +" - "+ str(L+T) + " = " + str(PivotD[R]) + " = "+ str(L-T))
                    LowList.append(i)    
                    Found=True                    
                if (Found):
                    if((R.find("A")>=0) | (R.find("Z")>=0)):
                        FibListSt["LCFib"]=R
                    else:
                        FibListSt["LCLevel"]=R
            
            DHighList = [item for item in set(HighList) if HighList.count(item) > 1]
            DLowList = [item for item in set(LowList) if LowList.count(item) > 1]
            
            
            for R in PRangeList:
                Found=False
                #R="A1000"
                if( H==PivotD1[R]):
                    #print(R+" High Same" + Data.iloc[i]['Date'])
                    PHighList.append(i)
                    Found=True                    
                elif( H+T>=PivotD1[R]>=H-T):
                    #print(str(i)+ "==> "+ R+" High Approx " + Data.iloc[i]['Date'] +" - "+ str(H+T) + " = " + str(PivotD[R]) + " = "+ str(H-T))
                    PHighList.append(i)
                    Found=True
                if (Found):
                    if((R.find("A")>=0) | (R.find("Z")>=0)):
                        FibListSt["HPFib"]=R
                    else:
                        FibListSt["HPLevel"]=R
                Found=False
                if( L==PivotD1[R]):
                    #print(R+" Low Same" + Data.iloc[i]['Date'])
                    PLowList.append(i)
                    Found=True
                elif( L+T>=PivotD1[R]>=L-T):
                    #print(str(i)+ "==> "+ R+" Low Approx " + Data.iloc[i]['Date'] +" - "+ str(L+T) + " = " + str(PivotD[R]) + " = "+ str(L-T))
                    PLowList.append(i)    
                    Found=True                    
                if (Found):
                    if((R.find("A")>=0) | (R.find("Z")>=0)):
                        FibListSt["LPFib"]=R
                    else:
                        FibListSt["LPLevel"]=R
            #if(Found):
            FibListar.append(FibListSt)            
            PDHighList = [item for item in set(PHighList) if PHighList.count(item) > 1]
            PDLowList = [item for item in set(PLowList) if PLowList.count(item) > 1]

            TDF=pd.DataFrame(FibListar)
            
            if(str(HighList).find(str(i-offset)+"")>0):                
                a=isPeak(Data['High'][:i], len(Data['High'][:i]), Data.iloc[i-offset]['High'], i-(offset*2), i)
                Signal=[]
                Cnt=1
                Signal.append("Pivot")                
                if(str(DHighList).find(str(i-offset)+"")>0):                
                    Cnt=2
                    Signal.append("Levels")
                
                if(a):
                    pi=1
                    while(pi<=Cnt):
                        #print("HighList :"+str(HighList))
                        ResultSt={}
                        Diff=round(Data.iloc[i-offset]['High']-Data.iloc[i]['High'],2)
                        DiffP=round(Diff/Data.iloc[i]['High']*100,2)
                        PDiff=round(Data.iloc[i-(offset*2)]['High']-Data.iloc[i-offset]['High'],2)
                        PDiffP=round(PDiff/Data.iloc[i-offset]['High']*100,2)
                        #print(str(i)+ " - " + Data.iloc[i]['Date'] + " HIGH - " +Data.iloc[i-offset]['Date'] + " - " + str(a) + " - " + str(Diff) + " ~ " + str(DiffP));                    
                        ResultSt['Stock']=Symbol
                        ResultSt['Index']=i
                        ResultSt['CurrentDate']=Data.iloc[i]['Date']
                        ResultSt['Type']='High'
                        ResultSt['SingleDate']=Data.iloc[i-offset]['Date']
                        ResultSt['Diff']=Diff
                        ResultSt['DiffP']=DiffP
                        ResultSt['PDiff']=PDiff
                        ResultSt['PDiffP']=PDiffP
                        ResultSt['InvertedHammer']=Data.iloc[i-offset]['InvertedHammer']
                        ResultSt['Hammer']=Data.iloc[i-offset]['Hammer']
                        ResultSt['PercHL']=round((Data.iloc[:i]['High'].max()-Data.iloc[i-offset]['High']+0.00001)/Data.iloc[i-offset]['High']*100,2)
                        H,L,C,O=list(Data.iloc[i-offset][['High',"Low","Close","Open"]])
                        ResultSt['HLC']=round((H-C)/C*100,2)
                        ResultSt['HL']=round((H-L)/L*100,2)
                        ResultSt['OC']=round((O-C)/C*100,2)
                        ResultSt['G']=O>C
                        ResultSt['HCFib']=TDF[TDF['I']==i-offset]['HCFib'].iloc[0]
                        ResultSt['HCLevel']=TDF[TDF['I']==i-offset]['HCLevel'].iloc[0]
                        ResultSt['HPFib']=TDF[TDF['I']==i-offset]['HPFib'].iloc[0]
                        ResultSt['HPLevel']=TDF[TDF['I']==i-offset]['HPLevel'].iloc[0]
                        ResultSt['LCFib']=TDF[TDF['I']==i-offset]['LCFib'].iloc[0]
                        ResultSt['LCLevel']=TDF[TDF['I']==i-offset]['LCLevel'].iloc[0]
                        ResultSt['LPFib']=TDF[TDF['I']==i-offset]['LPFib'].iloc[0]
                        ResultSt['LPLevel']=TDF[TDF['I']==i-offset]['LPLevel'].iloc[0]
                        
                        ResultAr.append(ResultSt)
                        Tempi=i
                        pi=pi+1
                        
            if(str(LowList).find(str(i-offset)+"")>0):
                Trough=isTrough(Data['Low'][:i], len(Data['Low'][:i]), Data.iloc[i-offset]['Low'], i-(offset*2), i-1)
                Cnt=1
                if(str(DLowList).find(str(i-offset)+"")>0):                
                    Cnt=2
                
                if(Trough):
                    pi=1
                    while(pi<=Cnt):                
                        ResultSt={}
                        #print("LowList :"+str(LowList))
                        #print(Symbol+"\ti="+str(i) + "\t"+str(i-offset)+"\t"+ str(i-(offset*2)))
                        Diff=round(Data.iloc[i-offset]['Low']-Data.iloc[i]['Low'],2)
                        DiffP=round(Diff/Data.iloc[i]['Low']*100,2)
                        PDiff=round(Data.iloc[i-(offset*2)]['Low']-Data.iloc[i-offset]['Low'],2)
                        PDiffP=round(PDiff/Data.iloc[i-offset]['Low']*100,2)
                        #print(str(i)+ " - "+Data.iloc[i]['Date'] + " Low - " +Data.iloc[i-offset]['Date'] + " - " + str(Trough)+ " - " + str(Diff) + " ~ " + str(DiffP));    
                        ResultSt['Stock']=Symbol
                        ResultSt['Index']=i
                        ResultSt['CurrentDate']=Data.iloc[i]['Date']
                        ResultSt['Type']='Low'
                        ResultSt['SingleDate']=Data.iloc[i-offset]['Date']
                        ResultSt['Diff']=Diff
                        ResultSt['DiffP']=DiffP
                        ResultSt['PDiff']=PDiff
                        ResultSt['PDiffP']=PDiffP
                        ResultSt['InvertedHammer']=Data.iloc[i-offset]['InvertedHammer']
                        ResultSt['Hammer']=Data.iloc[i-offset]['Hammer']
                        ResultSt['PercHL']=round((Data.iloc[:i]['Low'].min()-Data.iloc[i-offset]['Low']+0.00001)/Data.iloc[i-offset]['Low']*100,2)
                        H,L,C,O=list(Data.iloc[i-offset][['High',"Low","Close","Open"]])
                        ResultSt['HLC']=round((L-C)/C*100,2)
                        ResultSt['HL']=round((H-L)/L*100,2)
                        ResultSt['OC']=round((O-C)/C*100,2)
                        
                        ResultSt['HCFib']=TDF[TDF['I']==i-offset]['HCFib'].iloc[0]
                        ResultSt['HCLevel']=TDF[TDF['I']==i-offset]['HCLevel'].iloc[0]
                        ResultSt['HPFib']=TDF[TDF['I']==i-offset]['HPFib'].iloc[0]
                        ResultSt['HPLevel']=TDF[TDF['I']==i-offset]['HPLevel'].iloc[0]
                        ResultSt['LCFib']=TDF[TDF['I']==i-offset]['LCFib'].iloc[0]
                        ResultSt['LCLevel']=TDF[TDF['I']==i-offset]['LCLevel'].iloc[0]
                        ResultSt['LPFib']=TDF[TDF['I']==i-offset]['LPFib'].iloc[0]
                        ResultSt['LPLevel']=TDF[TDF['I']==i-offset]['LPLevel'].iloc[0]
                        
                        ResultSt['G']=O>C
                        ResultAr.append(ResultSt)
                        Tempi=i
                        pi=pi+1
            i=i+1
    
    ResultDF=pd.DataFrame(ResultAr)
    return ResultDF

def dispChart(Data1,filename,Symbol):
    #Data=Data1
    LastPivot=pd.read_csv(r"C:\ReadMoneycontrol\Mani 2.0\Data3\\"+Symbol+"-Pivot.csv",encoding='utf-8')
    #ListData=['IPivot','H1','L1','L2','H2','A0','A236','A382','A500','A786']#,'Z236','Z382','Z500','Z786']
    #ListData=['IPivot','H1','H2','H3','A0','A236','A382','A500','A618','A786','A1000','A1236','A1382','A1500','A1618','A2000']
    PivotD=LastPivot.iloc[DateIndex*-1]
    ListData=getChartRangeList(Data1['High'].max(),Data1['Low'].min(),PivotD)
    #ListData=getChartRangeList(Data['High'].max(),Data['Low'].min(),PivotD)
    #ListData=['IPivot','L1','A0','A236','A382','A500','A786']#,'Z236','Z382','Z500','Z786']
    
    date1=parse(parse(PivotD['Date']).strftime("%Y-%m-%d 09:00"))
    date2=parse(parse(PivotD['Date']).strftime("%Y-%m-%d 15:30"))
    
    Lines=[]
    AxisText=[]
    AxisValue=[]
    AxisX=[]
    
    for la in ListData:
        Position=date2
        Symbol1="+"
        value=PivotD[la]
        color='rgb(100, 100, 100)'
        linestyle=3
        if(la.find("A")>=0):
            color='rgb(0, 255, 0)'
            linestyle=2
        if(la.find("Z")>=0):
            color='rgb(255, 0, 0)'
            linestyle=2
        if(la.find("H")>=0):
            color='rgb(0, 0, 255)'
            linestyle=1
            Position=date1
            Symbol1="-"
        if(la.find("L")>=0):
            color='rgb(255,0 , 255)'
            linestyle=1
            Position=date1
            Symbol1="-"
        
        
        Lines.append(candlestick.CreateLinesV1(date1,date2,value,color,linestyle))
        AxisText.append(la)
        AxisValue.append(value)            
        AxisX.append(candlestick.CurrentDate(candlestick.N1(Position,"10M",Symbol1)))
    
    AxisText.append(Symbol)
    AxisValue.append(max(AxisValue))            
    AxisX.append(candlestick.CurrentDate(candlestick.N1(date1,"4H","+")))
    Datesar=list(Data1['Date'])
    Xar=[]
    Xar.append(Datesar[int(len(Datesar)/2)])
    Yar=[]
    Yar.append(Data1['High'].max()*1.001)
    textAr=[]
    textAr.append(Symbol)
    
    trace0 = go.Scatter(x=AxisX,y=AxisValue,text=AxisText, mode='text')
    
    trace=go.Candlestick(x=Datesar,
                               open=Data1['Open'],
                               high=Data1['High'],
                               low=Data1['Low'],
                               close=Data1['Close'])
    data=[trace,trace0]
    #AxisText=[]
    #AxisValue=[]
    #AxisX=[]
    #data=[trace,trace0]
    Layout={}
    Layout["shapes"]=Lines
    #Layout["annotations"]=AnnotationsAr
       
    #annotations
    
    fig2 = {'data': data,'layout': Layout}

    
#
#    fig1 = go.Figure()
#    
#    List_ = list(Data1['Date'])
#    fig1.add_trace( go.Candlestick(x=List_,
#                               open=Data1['Open'],
#                               high=Data1['High'],
#                               low=Data1['Low'],
#                               close=Data1['Close']))
#    fig1.add_trace(go.Scatter(x=Xar,y=Yar,text=textAr, mode='text'))
#    
    plot(fig2,filename=filename+".html")
    


#DateIndex=4
StockList=pd.read_csv("C:\ReadMoneycontrol\Mani 2.0\StockList.txt")
#DateIndex=126

def LoadData(minute,DateIndex):
    NiftyDay=pd.read_csv(r"C:\ReadMoneycontrol\Mani 2.0\Data\NIFTY50-day.csv")
    #minute="5minute"
    DataFrameCollection={}
    if(DateIndex<len(NiftyDay)-1):
    #while(DateIndex<len(NiftyDay)-1):
        StartDate=NiftyDay.iloc[(DateIndex)*-1]['Date']
        if(DateIndex!=1):
            EndDate=NiftyDay.iloc[(DateIndex-1)*-1]['Date']
        else:
            EndDate=candlestick.N1(parse(StartDate),"1D","+").strftime("%Y-%m-%d")
        Nifty=pd.read_csv(r"C:\ReadMoneycontrol\Mani 2.0\Data\NIFTY50-"+minute+".csv")
        Nifty.columns=['Date', 'Open', 'High', 'Low', 'Close', 'V']
        NiftyD=Nifty[(Nifty['Date']>StartDate) & (Nifty['Date']<EndDate)]
        DataFrameCollection['NIFTY']=NiftyD
        DataFrameCollection['NIFTY'].sort_values('Date',inplace=True)
        DataFrameCollection['NIFTY'].drop_duplicates(subset ="Date", keep = "first", inplace = True) 
        DataFrameCollection['NIFTY'].reset_index(inplace=True,drop=True)
        #DataFrameCollection['NIFTY'][']
        DataFrameCollection['NIFTY']['HLC']=(DataFrameCollection['NIFTY']['High']+DataFrameCollection['NIFTY']['Low']+DataFrameCollection['NIFTY']['Close'])/3
        Comparison={}
        Comparison["NIFTY"]=list(NiftyD['Open'])
        ki=0
        while(ki<len(StockList)): #len(StockList)
            StockName=StockList.iloc[ki]['Symbol']
            ki=ki+1
            #print(StockName)
            Stockdf=pd.read_csv(r"C:\ReadMoneycontrol\Mani 2.0\Data\\"+StockName+"-"+minute+".csv")
            Stockdf.columns=['Date', 'Open', 'High', 'Low', 'Close', 'V']
            StockD=Stockdf[(Stockdf['Date']>StartDate) & (Stockdf['Date']<EndDate)]
            DataFrameCollection[StockName]=StockD
            DataFrameCollection[StockName].sort_values('Date',inplace=True)
            DataFrameCollection[StockName].drop_duplicates(subset ="Date", keep = "first", inplace = True) 

            DataFrameCollection[StockName].reset_index(inplace=True,drop=True)
            DataFrameCollection[StockName]['HLC']=(DataFrameCollection[StockName]['High']+DataFrameCollection[StockName]['Low']+DataFrameCollection[StockName]['Close'])/3
            Comparison[StockName]=list(StockD['Open'])
    return DataFrameCollection
        


def CheckandMarkSequence(ResultDF0T,Interval):
    ar=[]
    #ResultDF03['Seq']=False
    ResultDF0T=ResultDF0T.sort_values(['Stock','SingleDate'],ascending=[True, True]).reset_index(drop=True)
    pd.options.mode.chained_assignment = None
    #Interval="3M"
    ar.append(False)
    for i in range(1, len(ResultDF0T)-1):
        if(str(ResultDF0T['CurrentDate'].dtype)!='datetime64[ns]'):
            PTime=parse(ResultDF0T.iloc[i-1]['CurrentDate'])
            CTime=parse(ResultDF0T.iloc[i]['CurrentDate'])
            NTime=parse(ResultDF0T.iloc[i+1]['CurrentDate'])
        else:
            PTime=ResultDF0T.iloc[i-1]['CurrentDate']
            CTime=ResultDF0T.iloc[i]['CurrentDate']
            NTime=ResultDF0T.iloc[i+1]['CurrentDate']
        
        if((candlestick.N1(CTime,Interval,"-")==PTime) or (candlestick.N1(CTime,Interval,"+")==NTime)):
            ar.append(True)
        else:
            ar.append(False)
    ar.append(False)
    ResultDF0T['Seq']=ar
    return ResultDF0T


def getPastDataZ(ID,StockName):
    global Candles,url 
    global Candles_dict,Datas
    headers={}
    headers['User-Agent'] = 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36'
    StrTimeIntervals=['3minute','5minute','15minute','30minute','day']
    #StrTimeIntervals=['3minute']
    #Increment=[30,60,80,90,90]
    #Increment=[10]
    Increment=[3,3,3,3,3]
    
    #Increment=[1,1,1,1,1]
    #Increment=[3,3,3,3,3]
    #StrTimeIntervals=['day']
    #Duration=850
    Duration=5
    requests.Timeout(120)
    TimeIntervalData={}
    for TimeInterval in StrTimeIntervals: # 54261767
        
        df=pd.DataFrame()
        #print(StockName+"     Running ....."+ TimeInterval )
        #StartDate=N1(datetime.now(),'3D','-')
        StartDate=N1(datetime.now(),str(Duration)+'D','-')
        DateIncr=0        
        #while(DateIncr<3):
        while(DateIncr<Duration):
            DateIncr=DateIncr+Increment[StrTimeIntervals.index(TimeInterval)]+1
            EndDate=N1(StartDate,str(Increment[StrTimeIntervals.index(TimeInterval)])+'D','+')
            StartDateStr=StartDate.strftime("%Y-%m-%d")
            EndDateStr=EndDate.strftime("%Y-%m-%d")
            #print(str(DateIncr)+" --> "+StartDateStr+ ' - ' + EndDateStr)
            url='https://kitecharts-aws.zerodha.com/api/chart/'+str(ID)+'/'+TimeInterval+'?public_token=Pb0MyvJ435vcAjx5fxCTtEV0oD0wdcwT&user_id=RM5678&api_key=kitefront&access_token=mwFtysT9JpZk6B7ZOUH4AqbrJkhUlTnC&'+'from='+StartDateStr+'&to='+EndDateStr+'&ciqrandom=1549306657305'                               
            retry=1
            time.sleep(5)
            while(retry<5):
                Candles = requests.get('https://kitecharts-aws.zerodha.com/api/chart/'+str(ID)+'/'+TimeInterval+
                               '?public_token=Pb0MyvJ435vcAjx5fxCTtEV0oD0wdcwT&user_id=RM5678&api_key=kitefront&access_token=mwFtysT9JpZk6B7ZOUH4AqbrJkhUlTnC&'+
#                               'from=2019-01-08&to=2019-04-05&ciqrandom=1549306657305') #GOLD
                                'from='+StartDateStr+'&to='+EndDateStr+'&ciqrandom=1549306657305',headers=headers) #GOLD
                if(Candles.status_code==200):
                    retry=10
                else:
                    print("Retry " + str(retry) + " ---- "+ str(Candles.status_code))
                    time.sleep(1)
                    retry=retry+1
                    
            Candles_dict = Candles.json()['data']['candles']
            tCandles_df = pd.DataFrame(Candles_dict,columns=['Date', 'open', 'high', 'low', 'close', 'V'])
            List_ = list(tCandles_df['Date'])
            List_ = [datetime.strptime(MParseDate(x).strftime("%m/%d/%Y %I:%M %p"), "%m/%d/%Y %I:%M %p") for x in List_]
            tCandles_df['Date']=pd.Series([x for x in List_],index=tCandles_df.index)
            df=df.append(tCandles_df)
            StartDate=N1(EndDate,'1D','+')
        TimeIntervalData[TimeInterval]=df

#        df.to_csv("C:\\ReadMoneycontrol\\Mani 2.0\\incr1\\"+StockName+"-"+TimeInterval+".csv",sep=',',encoding='utf-8',index=False)
        #time.sleep(1)
    Datas[StockName]=TimeIntervalData
    return df


def MParseDate(Date):
    ts = (np.datetime64(pd.to_datetime(Date)) - np.datetime64('1970-01-01T00:00:00Z')) / np.timedelta64(1, 's')
    return N1(N1(datetime.utcfromtimestamp(ts),'5H',"+"),"30M","+")
seconds_per_unit = {"S": 1, "M": 60, "H": 3600, "D": 86400, "W": 604800}
def N1(date,s,Operation):
    if (Operation=="+"):
        return date+timedelta(seconds=int(s[:-1]) * seconds_per_unit[s[-1]])
    else:
        return date-timedelta(seconds=int(s[:-1]) * seconds_per_unit[s[-1]])



def getRealTimePivot(Datas):
    StockList=pd.read_csv("C:\ReadMoneycontrol\Mani 2.0\StockList.txt")
    DFT=pd.DataFrame()
    ki=0
    while(ki<len(StockList)):
    #if(True):
        StockName=StockList.iloc[ki]['Symbol']
        Data1=Datas[StockName]['day']
        Data1.columns=['Date', 'Open', 'High', 'Low', 'Close', 'V']
        #str(Test['Date'].dtype)
        Stock1=candlestick.AppendPivot(Data1)        
        Stock1['Symbol']=StockName
        if(ki==0):
            DFT=Stock1.iloc[-2:]
        else:
            DFT=DFT.append(Stock1.iloc[-2:])
        ki=ki+1
    return DFT


def getRealTimeData():
    global Datas
    Date1=datetime.now()
    StockList=pd.read_csv("C:\ReadMoneycontrol\Mani 2.0\StockListIDOriginal.txt")
    i=0
#    Datas={}
    while(i<len(StockList)):#len(StockList)):
        StockName=StockList.iloc[i]['StockName']
        ZID=StockList.iloc[i]['ZID']    
        threading.Thread(target=getPastDataZ,args=(ZID,StockName)).start()
        #time.sleep(1)
        #getPastData(ZID,StockName)    
        i=i+1
    while(len(Datas)<len(StockList)-1):
        time.sleep(10)
        print(len(Datas))
        qt=6
    print("finished" + str((datetime.now()-Date1).seconds))
    return Datas


def getSpecificIntervalData(Datas,Interval,DPivot):
    i=0
    StockList=pd.read_csv("C:\ReadMoneycontrol\Mani 2.0\StockList.txt")
    MinDF={}
    CDate=DPivot.iloc[1]['Date']
    while(i<len(StockList)):
        Symbol=StockList.iloc[i]['Symbol']
        TDatas=Datas[Symbol][Interval]
        TDatas.columns=['Date', 'Open', 'High', 'Low', 'Close', 'V']
        MinDF[Symbol]=TDatas[TDatas['Date']>CDate]
        MinDF[Symbol].reset_index(inplace=True,drop=True)
        #print(StockList.iloc[i]['Symbol'])
        i=i+1
    return MinDF

if(False):
    Datas={}
    Datas=getRealTimeData()
    Data1=Datas['SBIN']['day']
    DPivot=getRealTimePivot(Datas)
    Min5DF=getSpecificIntervalData(Datas,"5minute",DPivot)
#    Min15DF=getSpecificIntervalData(Datas,"15minute",DPivot)
    #Pivot Calculation only one Time
    DPivot[DPivot['Symbol']=="GRASIM"].iloc[0]
    DPivot[DPivot['Gap']<-1][['Symbol','Gap','Date']]
if(False):
    ResultAr=[]
    TInterval=['3minute','5minute','15minute']
    PercentageAr=[0.0002,round(0.0002/3*5,4),round(0.0002/3*15,4)]
    OffsetAr=[5,4,2]
    DateIndex=8
    minute="3minute"
    #Min3DF=LoadData(minute,DateIndex)
    #iP=PercentageAr[TInterval.index(minute)]
    #iO=OffsetAr[TInterval.index(minute)]
    #ResultDF03=ProcessY(iP,iO,Min3DF,1)  
    
    minute="5minute"
    Min5DF=LoadData(minute,DateIndex)
    iP=PercentageAr[TInterval.index(minute)]
    
    iO=OffsetAr[TInterval.index(minute)]
    minute="15minute"
    
if(False):
    ResultAr=[]
    TInterval=['3minute','5minute','15minute']
    DateIndex=1
    minute="15minute"
    #Try the 15 minute Precentage for 5 Minute
    PercentageAr=[0.0002,round(0.0002/3*5,4),round(0.0002/3*15,4)]
    OffsetAr=[5,4,4]
    iP=PercentageAr[TInterval.index(minute)]
    iO=OffsetAr[TInterval.index(minute)]
    ResultDF15=ProcessZ(iP,iO,Min15DF,1,True) 
    ResultDF15=CheckandMarkSequence(ResultDF15,"15M")
    ResultDF15=ResultDF15[(ResultDF15['HLC']!=ResultDF15['OC'])]
    
    ResultDF05=ProcessZ(iP,iO,Min5DF,1,False) 
    ResultDF05=CheckandMarkSequence(ResultDF05,"5M")
    ResultDF05=ResultDF05[(ResultDF05['HLC']!=ResultDF05['OC'])]
    ResultDF05=ResultDF15
    T=a(ResultDF15)
    T=a(ResultDF05)
    T[(T['PercHL']==0) & (T['DiffP']<-.4)][['Stock','SingleDate','PDiffP','DiffP','Type', 'HLC','OC', 'PercHL']]
    
    T[(T['PercHL']<=0.1) & (T['PercHL']>=-.01) & (T['DiffP']<-.4)][['Stock','SingleDate','PDiffP','DiffP','Type', 'HLC','OC', 'PercHL']]
    T[(T['PercHL']<=0.1) & (T['PercHL']>=-.01) & (T['DiffP']>.4)][['Stock','SingleDate','PDiffP','DiffP','Type', 'HLC','OC', 'PercHL']]
    
    T[(T['PercHL']==0) & (T['DiffP']>.4)][['Stock','SingleDate','PDiffP','DiffP','Type', 'HLC','OC', 'PercHL']]
    ResultDF15['CurrentDate']
    Min15DF['SBIN']['Date']    



def a(Input):
    #ResultDF05['Stock']=="HDFCBANK"
    #ResultDF05.duplicated(['Stock','SingleDate'],keep=False)
    T=Input[Input.duplicated(['Stock','SingleDate'],keep=False)][['Stock',
    #T=ResultDF05[ResultDF05['Seq']==True][['Stock',
    #T=ResultDF05[(ResultDF05['G']==False) & (ResultDF05['HL']>.3) & (ResultDF05['InvertedHammer']==True)][['Stock',
    #T=ResultDF05[(ResultDF05['G']==False) & (ResultDF05['HL']>.3) & (ResultDF05['Hammer']==True)][['Stock',                                                                                                       
            'CurrentDate','SingleDate','PDiffP','DiffP','HL', 'HLC','OC', 'PercHL','G',
            'Type','Seq','HCFib','HCLevel','LCFib','LCLevel','HPFib','HPLevel','LPFib','LPLevel']]
    return T
