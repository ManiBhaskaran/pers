# -*- coding: utf-8 -*-
"""
Created on Fri Dec 27 09:48:43 2019

@author: lalitha
"""

Datas=getRealTimeData("All")   
#Data1=Datas['SBIN']['day']
DPivot=getRealTimePivot(Datas)
Min5DF=getSpecificIntervalData(Datas,"5minute",DPivot)
minute="5minute"
TInterval=['3minute','5minute','15minute']
PercentageAr=[0.0002,round(0.0002/3*5,4),round(0.0002/3*15,4)]
OffsetAr=[5,4,2]
iP=PercentageAr[TInterval.index(minute)]
iO=OffsetAr[TInterval.index(minute)]
Date1=datetime.now()
ResultDF05=ProcessZ(iP,iO,Min5DF,1,True) 
print("StockNameStockName : " + str((datetime.now()-Date1).microseconds))
print("StockNameStockName : " + str((datetime.now()-Date1).seconds))

ResultDF05=CheckandMarkSequence(ResultDF05,"5M")
ResultDF05=ResultDF05[(ResultDF05['HLC']!=ResultDF05['OC'])]
ResultDF05['CDATE']=pd.to_datetime(ResultDF05['CurrentDate']).dt.strftime("%Y-%b-%d")
ResultDF051=ResultDF05[ResultDF05['CFD']>.3]
Re=ResultDF05
Re=Re[Re['Index']<60]
index=0
CDATES=Re['CDATE'].unique()
SData=Re[(Re['CDATE']==CDATES[index]) & (Re['CFD']>.3)]
#SData=Re
Re.shape[0]
Re[Re['Index']<60].shape[0]
Re=Re[Re['Index']<60]
Re['CDATE']=pd.to_datetime(Re['CurrentDate']).dt.strftime("%Y-%b-%d")

#Re1=Re
Re1['CDATE']=pd.to_datetime(Re1['CurrentDate']).dt.strftime("%Y-%b-%d")
CDATES=Re1['CDATE'].unique()
Re1.drop_duplicates(subset =["Stock","CDATE",'Type'], keep = "first", inplace = True) 
SData=Re1
SData=ResultDF05[(ResultDF05['CDATE']==CDATES[0]) & (ResultDF05['CC']>40)]
S=SData[['Type','Index','Stock','CurrentDate','TPercHO','TPercOL','DiffP','PDiffP','TPercHL','CFD','CPD',
     'CGap','PercHL','HCFib','HCLevel','LCFib','LCLevel','MaxHL','MaxHLClr','MaxHLIdx','CC']]

S['FPrice']=round(S['CC']*(1-S['CFD']/100),2)
S['FSL']=round(S['CC']*(1+S['CFD']/100*1.5),2)
S['LPrice']=round(S['CC']*(1-S['CPD']/100),2)
S['LSL']=round(S['CC']*(1+S['CPD']/100*1.5),2)

S1=S[ 
     #(S['TPercOL']>1) & 
        (S['Type']=='Low') &
        #(S['Index']<=30) &
        (S['Index']>=8) &
        (S['MaxHL']>=1) 
        &

        (S['PercHL']<S['CFD'])
        ]

S2=S[ 
     #(S['TPercHO']>1) & 
        (S['Type']=='High') &
        #(S['Index']<=30) &
        (S['Index']>=8) &
        (S['MaxHL']>=1) 
        &
        (S['PercHL']<S['CFD']) 
        ]


ScfdL=S[ (S['TPercOL']>1) & 
        (S['Type']=='Low') &
#        (S['Index']<=30) &
        (S['Index']>=4) &
        (S['PercHL']<S['CFD']) &
        (S['CFD']>1)]

ScfdH=S[ (S['TPercHO']>1) & 
        (S['Type']=='High') &
#        (S['Index']<=30) &
        (S['Index']>=4) &
        (S['PercHL']<S['CFD']) &
        (S['CFD']>1)]


SGapUpH=S[ (S['CGap']>1) & 
        (S['Type']=='High') &
        (S['Index']<=30) &
        (S['Index']>=5) ]

SGapUpL=S[ (S['CGap']>1) & 
        (S['Type']=='Low') &
        (S['Index']<=30) &
        (S['Index']>=5) ]


SGapDownH=S[ (S['CGap']<-1) & 
        (S['Type']=='High') &
        (S['Index']<=30) &
        (S['Index']>=5) ]

SGapDownL=S[ (S['CGap']<-1) & 
        (S['Type']=='Low') &
        (S['Index']<=30) &
        (S['Index']>=5) ]

#(SData1['MaxHL']>1) & (SData1['MaxHLClr']=="R") & 


#Re=pd.read_csv(r"C:\ReadMoneycontrol\Mani 2.0\Temp1\Temp2\UPLResultsH1.csv")
Re1=Re[['Index','Stock','CurrentDate','Type','G','COC','TPercOL','TPercHO','DiffP','PDiffP','CHL','RPercHL','TPercHL','SPercHL','CFD','CPD',
     'MaxHL','MaxHLClr','MaxHLIdx','Seq','PFD','PGap','CGap','Hammer','InvertedHammer','PercHL','HCFib','HPFib'
     ,'HCLevel','HPLevel','LCFib','LPFib','LCLevel','LPLevel','CC','BuyProfitP',
     'SellProfitP','BuyProfitP1','SellProfitP1']].sort_values(['CurrentDate','Index'],ascending=True)

Re1=Re[['Index','Stock','CurrentDate','Type','G','COC','TPercOL','TPercHO','DiffP','PDiffP','CHL','RPercHL','TPercHL','SPercHL','CFD','CPD',
     'MaxHL','MaxHLClr','MaxHLIdx','Seq','PFD','PGap','CGap','Hammer','InvertedHammer','PercHL','HCFib','HPFib'
     ,'HCLevel','HPLevel','LCFib','LPFib','LCLevel','LPLevel','CC']].sort_values(['CurrentDate','Index'],ascending=True)

#Re1=Re1[round(len(Re)/2):]
Re1=Re1[:round(len(Re)/2)*-1]
Re1['CDATE']=pd.to_datetime(Re1['CurrentDate']).dt.strftime("%Y-%b-%d")
Re1=Tz1
CDATES=Re1['CDATE'].unique()
Re1.drop_duplicates(subset =["Stock","CDATE",'Type'], keep = "first", inplace = True) 
SData=Re1[(Re1['Stock']!="HCLTECH") & (Re1['HCLevel']!="H1") & (Re1['LCLevel']!="L1")]
T2=SData





Test=SData[ 
    (SData['PercHL']>-.01) & (SData['PercHL']<.2) &
#    (SData['Index']>20) &
    (SData['Index']<=20) &
    (SData['CFD']<=1) &
    (SData['CC']<1200) &
    (SData['CGap']>-.01) & (SData['CGap']<1) &
    #(SData['CC']<=600) &
     (SData['TPercOL']<SData['TPercHO']) &
#          (SData['CFD']>.4) &
#    & (SData['TPercHL']>1) &
#     (SData['TPercHL']>=2) &
#     (SData['PercHL']<SData['CFD']) &
#     (SData['TPercHO']>=SData['CFD']*2) &
     (SData['TPercHO']>=SData['CFD']*1.5) &
     (SData['MaxHL']<1) &        
        (SData['Type']=="High") 
        & (SData['HCLevel']!="H1")
        & (((SData['HCFib']=="A1500") | (SData['HCFib']=="A2000") 
        | (SData['HCFib']=="A1786")
        | (SData['HCFib']=="A1618")
        | (SData['HCFib']=="A2236")
        | (SData['HCFib']=="A1236")
        | (SData['HCFib']=="A2382")
        | (SData['HCFib']=="A1382")
        | (SData['HCFib']=="A2500")) 
##(SData['HCLevel']=="H1") | 
        | ((SData['HCLevel']=="H2")| (SData['HCLevel']=="H3")| (SData['HCLevel']=="H4")))
]
Test1=SData[
#     (SData['PercHL']>-.2) & (SData['PercHL']<.2) &
#    (SData['PercHL']<SData['CFD']) &
     #& (SData['TPercHO']<.3) 
     (SData['TPercOL']>=SData['CFD']*2) &
#     (SData['CFD']>.4) &
     (SData['MaxHL']>1) &
     (SData['Index']<=40) &
#     &
        (SData['Type']=="Low") &
        (SData['LCLevel']!="L1")
        & (
        (
        (SData['LCFib']=="Z1500") 
        | (SData['LCFib']=="Z2000") 
        | (SData['LCFib']=="Z1786")
        | (SData['LCFib']=="Z1000")
        | (SData['LCFib']=="Z1236")
        | (SData['LCFib']=="Z786")
        | (SData['LCFib']=="Z236")
        | (SData['LCFib']=="Z1618")
        | (SData['LCFib']=="Z2236")
        | (SData['LCFib']=="Z2382")
        | (SData['LCFib']=="Z2500")) 
        | ((SData['LCLevel']=="L2") 
        |  (SData['LCLevel']=="L3") | (SData['LCLevel']=="L4")))
#      
     ]
Test.groupby([
            'Index'])['BuyProfitP','SellProfitP','BuyProfitP1','SellProfitP1'].count()

   
Test=T2[ (T2['MaxHL']>.1) & (T2['Type']=='High') & (T2['Index']<=150) 
& (T2['MaxHLClr']=="R") & (T2['G']==False) 

    & 
   ((T2['PDiffP']>T2['CFD']) | (T2['DiffP']>T2['CFD']) ) 
#   & 
#   (T2['TPercHL']-T2['SPercHL']>=T2['CFD']) 
   
   & ((T2['PDiffP']+T2['DiffP']<=0.05) &  (T2['PDiffP']+T2['DiffP']>=-0.05)) 
   ]




##################


########

#Test=T2[ (T2['MaxHL']>1) & (T2['DiffP']<(T2['CFD']*-1)) 
#   & (T2['CFD']>.4)
#
#   ]
Test=T2[T2['Stock']=="TCS"]

Test=T2[ (T2['MaxHL']<1) & (T2['DiffP']<(T2['CFD']*1)) 
#   & (T2['CFD']<.6)
   & (T2['Type']=="High")
#   & (T2['LCLevel']=="L2")
#   & (T2['LCFib'].notnull()==True)
   & (T2['HCFib'].isnull()==True)
   & (T2['Index']>20)
#   & (T2['TPercHO']>T2['CFD'])
#   & (T2['TPercOL']<T2['CFD'])
#   & (T2['PercHL']>-.01) & (T2['PercHL']<.2) 
   
   #& (T2['PercHL']>=.2)
   ]

###################################
T2=Tz
Test=T2[ (T2['MaxHL']>1) & (T2['Type']=='High') 
#& ((abs(T2['TPercHL'])-abs(T2['TPercHO']))/abs(T2['TPercHO'])*100<10) 
#& ((T2['HCFib']=="A1500") | (T2['HCFib']=="A2000") 
#        | (T2['HCFib']=="A1786")
#        | (T2['HCFib']=="A1618")
#        | (T2['HCFib']=="A2236")
#        | (T2['HCFib']=="A1236")
#        | (T2['HCFib']=="A2382")
#        | (T2['HCFib']=="A1382")
#        | (T2['HCFib']=="A2500")) 
& (T2['CFD']>.5)
& (T2['CFD']<1)
#& (T2['DiffP']<0)
& (T2['COC']<0)
#& ((T2['CHL']-abs(T2['COC']))/abs(T2['COC'])*100<10)
& (T2['CHL']>.8)
#& (T2['HCLevel']=="H2")
#& (T2['Index']!=T2['MaxHLIdx']) 
#& (T2['Index']>=10) 
#& (T2['MaxHLClr']=="R") 
#& (T2['LCFib'].notnull()==True)  
#& (T2['MaxHLIdx']!=0) 
#& (T2['CGap']<0) 
& (T2['CGap']>0)
#& (T2['G']==False) 

     
   #((T2['PDiffP']>T2['CFD']*3) | (T2['DiffP']>T2['CFD']*3) ) 
#   & 
#   (T2['TPercHL']-T2['SPercHL']>=T2['CFD']) 
   
#   & ((T2['PDiffP']+T2['DiffP']<=0.05) &  (T2['PDiffP']+T2['DiffP']>=-0.05)) 
   ]

Test=T2[
        (T2['COC']<=-.0695)
        & (T2['COC']>=-1.235)
        & (T2['DiffP']>-1.045)
        ]
#Test=Test[Test['BuyProfitP']<0.6]
print(Test[Test['SellProfitP']>0]['SellProfitP'].sum())
print(Test[Test['BuyProfitP']>0]['BuyProfitP'].sum())

Test.groupby('CDATE')[['BuyProfitP','SellProfitP','BuyProfitP1','SellProfitP1']].count()
Test[(Test['SellProfitP']>0) & (Test['BuyProfitP']>0)]['BuyProfitP'].sum()
SP=Test[Test['SellProfitP']>0].shape[0]
BP=Test[Test['BuyProfitP']>0].shape[0]
TotalTest=Test.shape[0]
print("SellProfit Count :- "+str(SP) + " out of " +str(TotalTest) + "  --   "+str(round(SP/TotalTest*100,2)))
print("BuyProfit Count :- "+str(BP) + " out of " +str(TotalTest) + "  --   "+str(round(BP/TotalTest*100,2)))
#print("BuyProfit Count :- "+str(Test[Test['BuyProfitP']>0].shape[0]) + " out of " +str(Test.shape[0]))
print("SellProfit1 Count :- "+str(Test[Test['SellProfitP1']>0].shape[0]) + " out of " +str(Test.shape[0]))
print("BuyProfit1 Count :- "+str(Test[Test['BuyProfitP1']>0].shape[0]) + " out of " +str(Test.shape[0]))
Test[['BuyProfitP','SellProfitP','BuyProfitP1','SellProfitP1']].sum()

Test1=T2[
        (T2['DiffP']>T2['PFD']*1)
        & (T2['DiffP']>T2['CFD']*1)
#        & (T2['PDiffP']==0)
#         (T2['LPFib'].notnull()==False)  &
#         (T2['HPFib'].notnull()==True)  &
#          (T2['Type']=="Low")
#          & ((T2['TPercHO']>T2['CFD']*1)
#          | (T2['TPercOL']<T2['CFD']))
#          &(T2['CFD']<1.5)
#&          ((T2['PDiffP']>T2['CFD']) | (T2['DiffP']>T2['CFD']) ) 
#          & (T2['MaxHL']<1)
          & (T2['Index']>8)
#         & (T2['PercHL']>-.01) & (T2['PercHL']<.2) 
         #& ((T2['HCFib']=="A1382")
         #| (T2['HCFib']=="A1786"))
         ]
#[['BuyProfitP','SellProfitP','BuyProfitP1','SellProfitP1']].sum()

Test1.groupby('Type')[['BuyProfitP','SellProfitP','BuyProfitP1','SellProfitP1']].sum()
Test1.groupby('Type')[['BuyProfitP','SellProfitP','BuyProfitP1','SellProfitP1']].count()
Test.groupby('InvertedHammer')[['BuyProfitP','SellProfitP','BuyProfitP1','SellProfitP1']].sum()


print(Test1[Test1['SellProfitP']>0]['SellProfitP'].sum())
print(Test1[Test1['BuyProfitP']>0]['BuyProfitP'].sum())

SP=Test1[Test1['SellProfitP']>0].shape[0]
BP=Test1[Test1['BuyProfitP']>0].shape[0]
TotalTest=Test1.shape[0]
print("SellProfit Count :- "+str(SP) + " out of " +str(TotalTest) + "  --   "+str(round(100-(TotalTest-SP)/SP*100,2)))
print("BuyProfit Count :- "+str(BP) + " out of " +str(TotalTest) + "  --   "+str(round(100-(TotalTest-BP)/BP*100,2)))
#print("BuyProfit Count :- "+str(Test[Test['BuyProfitP']>0].shape[0]) + " out of " +str(Test.shape[0]))
print("SellProfit1 Count :- "+str(Test1[Test1['SellProfitP1']>0].shape[0]) + " out of " +str(Test1.shape[0]))
print("BuyProfit1 Count :- "+str(Test1[Test1['BuyProfitP1']>0].shape[0]) + " out of " +str(Test1.shape[0]))

Test1[['BuyProfitP','SellProfitP','BuyProfitP1','SellProfitP1']].sum()






Test=SData[ 
    (SData['PercHL']>-.2) & (SData['PercHL']<.2) &
     #& (SData['TPercOL']<.3) 
#          (SData['CFD']>.4) &
#    & (SData['TPercHL']>1) &
#     (SData['TPercHL']>=2) &
#     (SData['PercHL']<SData['CFD']) &
     (SData['TPercHO']>=SData['CFD']*2) &
     (SData['MaxHL']>1) &        
        (SData['Type']=="High") 
        & (((SData['HCFib']=="A1500") | (SData['HCFib']=="A2000") 
        | (SData['HCFib']=="A1786")
        | (SData['HCFib']=="A1618")
        | (SData['HCFib']=="A2236")
        | (SData['HCFib']=="A1236")
        | (SData['HCFib']=="A2382")
        | (SData['HCFib']=="A1382")
        | (SData['HCFib']=="A2500")) 
#(SData['HCLevel']=="H1") | 
        | ((SData['HCLevel']=="H2")| (SData['HCLevel']=="H3")| (SData['HCLevel']=="H4")))
][['Index','Stock','CurrentDate','TPercHO','TPercOL','DiffP','PDiffP','TPercHL','CFD','CPD',
     'CGap','PercHL','HCFib','HCLevel','MaxHL','MaxHLClr','MaxHLIdx','CC']].sort_values('Index',ascending=False)

Test['PPoints']=round(Test['CC']*(Test['CFD']/100),2)
Test['SLPoints']=round(Test['CC']*(Test['CFD']/100*1.5),2)    
Test['FPrice']=round(Test['CC']*(1-Test['CFD']/100),2)
Test['FSL']=round(Test['CC']*(1+Test['CFD']/100*1.5),2)
Test['LPrice']=round(Test['CC']*(1-Test['CPD']/100),2)
Test['LSL']=round(Test['CC']*(1+Test['CPD']/100*1.5),2)

Test1=SData[
     (SData['PercHL']>-.2) & (SData['PercHL']<.2) &
#    (SData['PercHL']<SData['CFD']) &
     #& (SData['TPercHO']<.3) 
     (SData['TPercOL']>=SData['CFD']*2) &
#     (SData['CFD']>.4) &
     (SData['MaxHL']>1) &
#     &
        (SData['Type']=="Low") &
        (SData['LCLevel']!="L1")
#        & (
#        (
#        (SData['LCFib']=="Z1500") 
#        | (SData['LCFib']=="Z2000") 
#        | (SData['LCFib']=="Z1786")
#        | (SData['LCFib']=="Z1000")
#        | (SData['LCFib']=="Z1236")
#        | (SData['LCFib']=="Z786")
#        | (SData['LCFib']=="Z236")
#        | (SData['LCFib']=="Z1618")
#        | (SData['LCFib']=="Z2236")
#        | (SData['LCFib']=="Z2382")
#        | (SData['LCFib']=="Z2500")) 
#        | ((SData['LCLevel']=="L1") | (SData['LCLevel']=="L2") 
#        |  (SData['LCLevel']=="L3") | (SData['LCLevel']=="L4")))
#      
     ][['Index','Stock','CurrentDate','TPercHO','TPercOL','DiffP','PDiffP','TPercHL','CFD','CPD',
     'CGap','PercHL','LCFib','LCLevel','MaxHL','MaxHLClr','MaxHLIdx','CC']].sort_values('Index',ascending=False)
Test1['PPoints']=round(Test1['CC']*(Test1['CFD']/100),2)
Test1['SLPoints']=round(Test1['CC']*(Test1['CFD']/100*1.5),2)
Test1['Price']=round(Test1['CC']*(1+Test1['CFD']/100),2)
Test1['SL']=round(Test1['CC']*(1-Test1['CFD']/100*1.5),2)
Test1['LPrice']=round(Test1['CC']*(1+Test1['CPD']/100),2)
Test1['LSL']=round(Test1['CC']*(1-Test1['CPD']/100*1.5),2)


