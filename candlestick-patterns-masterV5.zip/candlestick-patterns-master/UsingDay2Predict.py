# -*- coding: utf-8 -*-
"""
Created on Sat Dec 28 22:09:20 2019

@author: lalitha
"""
#https://www.moneycontrol.com/news/business/markets/technical-classroom-how-to-use-single-candlestick-chart-pattern-for-trading-3266531.html
AllStockList="C:\ReadMoneycontrol\Mani 2.0\StockListAll.txt"
StockList=pd.read_csv(AllStockList)
#.5 for Day
Diff=0.3
i=0
while(i<len(StockList)-1):
    StockName=StockList.StockName[i]
    #Data1=pd.read_csv(r"C:\ReadMoneycontrol\Mani 2.0\Data\\"+StockName+"-30minute.csv")
    Data1=pd.read_csv(r"C:\ReadMoneycontrol\Mani 2.0\Data\\"+StockName+"-day.csv")
    Data1.columns=['Date', 'Open', 'High', 'Low', 'Close', 'V']
    Data1=candlestick.hammer(Data1)
    Data1=Data1.sort_values('Date',ascending=False)
    Data1['MaxH5']=Data1['High'].shift(1).rolling(5).max()
    Data1['MaxH1']=Data1['High'].shift(1).rolling(1).max()
    Data1['MaxH3']=Data1['High'].shift(1).rolling(3).max()
    Data1['MinL5']=Data1['Low'].shift(1).rolling(5).min()
    Data1['MinL1']=Data1['Low'].shift(1).rolling(1).min()
    Data1['MinL3']=Data1['Low'].shift(1).rolling(3).min()
    Data1=Data1.sort_values('Date',ascending=True)

    #Data1=candlestick.inverted_hammer(Data1)
    #Data1=candlestick.hanging_man(Data1)
    Data1['Gap']=round((Data1['Open']-Data1['Close'].shift(1))/Data1['Close'].shift(1)*100,2)
    Data1['Down']=( (Data1['Low'].shift(1)<Data1['Low'].shift(2))& (Data1['Low'].shift(2)<Data1['Low'].shift(3)))
    Data1['UP']=( (Data1['High'].shift(1)<Data1['High'].shift(2))& (Data1['High'].shift(2)<Data1['High'].shift(3)))
    Data1['LP0']=round((Data1['Low']-Data1['Low'].shift(1))/Data1['Low'].shift(1)*100,2)
    Data1['LP1']=round((Data1['Low'].shift(1)-Data1['Low'].shift(2))/Data1['Low'].shift(2)*100,2)
    Data1['LP2']=round( (Data1['Low'].shift(2)-Data1['Low'].shift(3))/Data1['Low'].shift(3)*100,2)
    Data1['Symbol']=StockName
    #Data1[Data1['Hammer']==True][['Date','Gap','Down','UP','LP1','LP2']]
    Result=Data1[(Data1['Hammer']==True) &
          (
          ((Data1['Down']==True) & (Data1['LP1']<Diff*-1) & (Data1['LP2']<-1*Diff))      
          | 
          ((Data1['UP']==True) & (Data1['LP1']>Diff) &  (Data1['LP2']>Diff))
          )
          ]
    if(i==0):
        CResult=Result
    else:
        CResult=CResult.append(Result)
    i=i+1
CResult1=CResult[CResult['UP']==True]
CResult1=CResult[CResult['Down']==True]
CResult1['CUp']=(round((CResult1['MaxH1']-CResult1['Close'])/CResult1['Close']*100,2))
CResult1['CDown']=(round((CResult1['MinL1']-CResult1['Close'])/CResult1['Close']*100,2))
CResult1['LPP']=CResult1['LP1']+CResult1['LP2']
CResult1[['Date','Close','MaxH5','CUp','CDown','LPP','LP1','LP2']]
CResult1=CResult1.sort_values('Date')

Down=CResult1[CResult1['Down']==True]
Up=CResult1[CResult1['UP']==True]


Data1=pd.read_csv(r"C:\ReadMoneycontrol\Mani 2.0\Data\\"+StockName+"-day.csv")
Data1.columns=['Date', 'Open', 'High', 'Low', 'Close', 'V']
Re=pd.read_csv(r"C:\ReadMoneycontrol\Mani 2.0\Report\15minuteFO15Min.csv")
Re['CurrentDate']=pd.to_datetime(Re.CurrentDate)
i=5
cnt=0
First=True
Zresults=0
while(i<len(CResult1)-1):
    Index=-1*i
    SearchStock=CResult1.iloc[Index].Symbol
    SearchDate=CResult1.iloc[Index].Date
    SearchDate=Data1.iloc[Data1[Data1['Date']==SearchDate].index[0]+1]['Date']
    #SearchDate1=candlestick.N1(parse(SearchDate),"1D","+")
    StartDate=parse(parse(SearchDate).strftime("%Y-%m-%d 09:15"))
    EndDate=parse(parse(SearchDate).strftime("%Y-%m-%d 15:15"))
    Tresult=Re[(Re['Stock']==SearchStock)
    & ( Re['CurrentDate']>StartDate)
    & ( Re['CurrentDate']<EndDate)]
    if(len(Tresult)>0):        
        #i=len(CResult1)
#        print("found")
        if(First):
            Zresults=Tresult
            First=False
        else:
            Zresults=Zresults.append(Tresult)
        cnt=cnt+1
        if(cnt>30):
            i=len(CResult1)
    i=i+1
    

C=Zresults[Zresults['Type']=='Low'][['Index','Stock','CurrentDate','Type','TPercOL','TPercHO','DiffP','PDiffP','TPercHL','SPercHL','CFD','CPD',
     'Seq','PFD','PGap','G','CGap','Hammer','InvertedHammer','PercHL','HCFib','HPFib'
     ,'HCLevel','HPLevel','LCFib','LPFib','LCLevel','LPLevel','MaxHL','MaxHLClr','MaxHLIdx','CC']].sort_values(['CurrentDate','Index'],ascending=True)
C1=C[ (C['MaxHL']>1)
     #(C['PercHL']>-.2) & (C['PercHL']<.2)
     ]    
#Data1['BELT']=((Data1['Close'] > Data1['Open'])
## & (Data1['Low'].rolling(10).min()==Data1['Low'])
# & ( ((Data1['Close'] - Data1['Open']) / (Data1['High'] - Data1['Low'])) > .5)
# & ( ((Data1['Close'].shift(1) - Data1['Low']) / (Data1['High'] - Data1['Low']) > .6))
# & ( 
#    (Data1['High'] - Data1['Low']) > .2 * 
#        (
#                (Data1['High'].shift(5) - Data1['Low'].shift(5)) + 
#                (Data1['High'].shift(4) - Data1['Low'].shift(4)) + 
#                (Data1['High'].shift(3) - Data1['Low'].shift(3)) + 
#                (Data1['High'].shift(2) - Data1['Low'].shift(2)) + 
#                (Data1['High'].shift(1) - Data1['Low'].shift(1))
#        )
#    )                
# & (Data1['High'] > Data1['Low'].shift(1) ) & (Data1['Close'] < Data1['High'].shift(1)))
#Data1[Data1['BELT']==True]
#

Data1['HighDown']=( (Data1['High'].shift(1)<Data1['High'].shift(2))& (Data1['High'].shift(2)<Data1['High'].shift(3)))
Data1['LowDown']=( (Data1['Low'].shift(1)<Data1['Low'].shift(2))& (Data1['Low'].shift(2)<Data1['Low'].shift(3)))
Data1[(Data1['HighDown']==True) & (Data1['LowDown']==True) 
      &(Data1['Open']<Data1['Close'])
      &(Data1['Low']>Data1['Low'].shift(1))
      &(Data1['High']>Data1['High'].shift(3))
      & (Data1['Low'].rolling(10).min()==Data1['Low'].shift(1))
      & (Data1['Low'].rolling(30).min()==Data1['Low'].shift(1))
]['Date']


Data1['HighDown']=( (Data1['High'].shift(2)<Data1['High'].shift(3))) #& (Data1['High'].shift(2)<Data1['High'].shift(3)))
Data1['LowDown']=( (Data1['Low'].shift(2)<Data1['Low'].shift(3))) #& (Data1['Low'].shift(2)<Data1['Low'].shift(3)))
Data1[(Data1['HighDown']==True) & (Data1['LowDown']==True) 
      &(Data1['Open'].shift(1)<Data1['Close'].shift(1))
      &(Data1['Low'].shift(1)>Data1['Low'].shift(2))
      &(Data1['High'].shift(1)>Data1['High'].shift(3))
      & (Data1['Low'].rolling(10).min()==Data1['Low'].shift(2))
      & (Data1['Low'].rolling(30).min()==Data1['Low'].shift(2))
      &(Data1['Open']<Data1['Close'])
      &(Data1['High']>Data1['High'].shift(1))
]['Date']





#
#
#Data1['MHT']=(Data1['High'].rolling(5).max()==Data1['High'])
#Data1['largeBody']=((Data1['High']>=Data1['Open']*(1+0.01)) & (Data1['Close']>=Data1['Open']))
#Data1['blackBody']=(Data1['Open']>Data1['Close'])
#Data1['smallUpperShadow']=( 
#                            (
#                            (Data1['Close']>=Data1['Open']) &   
#                            (Data1['High']<=Data1['Close']*(1+0.0025))
#                            )
#                            |
#                            (
#                                    (Data1['blackBody']==True) & 
#                                    (Data1['High']<=Data1['Open']*(1+0.0025))
#                            )
#                        )
#                            
#Data1[Data1['MHT']==True]
#Data1['Belt']=( (Data1['largeBody']==True) & (Data1['blackBody']==True) & (Data1['smallUpperShadow']==True ) & (Data1['MHT']==True))
##smallUpperShadow=(whiteBody AND H<=C*(1+0.0025)) OR (blackBody AND H<=O*(1+0.0025));
##beltHoldBearish=LargeBody AND BlackBody AND smalluppershadow AND MHT;
#
##Data1[Data1['HangingMan']==True][['Date','Gap','Down','UP','LP1','LP2']]
##Data1[Data1['InvertedHammer']==True][['Date','Gap','Down','UP','LP0','LP1','LP2']]
