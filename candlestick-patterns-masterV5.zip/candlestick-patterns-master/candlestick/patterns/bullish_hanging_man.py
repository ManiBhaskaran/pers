from candlestick.patterns.candlestick_finder import CandlestickFinder
from candlestick import candlestick

class BullishHangingMan(CandlestickFinder):
    def __init__(self, target=None):
        super().__init__(self.get_class_name(), 2, target=target)

    def logic(self, idx):
        candle = self.data.iloc[idx]
        prev_candle = self.data.iloc[idx + 1 * self.multi_coeff]
        prev1_candle = self.data.iloc[idx + 2 * self.multi_coeff]
        prev2_candle = self.data.iloc[idx + 3 * self.multi_coeff]
        prev3_candle = self.data.iloc[idx + 4 * self.multi_coeff]
        prev4_candle = self.data.iloc[idx + 5 * self.multi_coeff]

        C = candle[self.close_column]
        O = candle[self.open_column]
        H = candle[self.high_column]
        L = candle[self.low_column]
        
        #print(candle)
        #Downtrend =  L < candle['MovingAverageDown'];
        #Uptrend =  H > candle['MovingAverageUp'];

        C1 = prev_candle[self.close_column]
        O1 = prev_candle[self.open_column]
        H1 = prev_candle[self.high_column]
        L1 = prev_candle[self.low_column]        
        C2 = prev1_candle[self.close_column]
        O2 = prev1_candle[self.open_column]
        H2 = prev1_candle[self.high_column]
        L2 = prev1_candle[self.low_column]
        H3 = prev2_candle[self.high_column]
        L3 = prev2_candle[self.low_column]
        H4 = prev3_candle[self.high_column]
        L4 = prev3_candle[self.low_column]
        H5 = prev4_candle[self.high_column]
        L5 = prev4_candle[self.low_column]
        
        dtrend = (L1 < L2) & (L2 < L3) & (L3 < L4)
        utrend = (H1 > H2) & (H2 > H3) & (H3 > H4)
        LongWhiteCandle  = ((C>O) & ((C-O)/(.001+H-L)>.6))
        LongBlackCandle = ((O>C) & ((O-C)/(.001+H-L)>.6)) 
        MHT= utrend & (H>H1)
        
        BullishEngulfing  = (LongWhiteCandle  &  dtrend  &  (O1>C1)  &  (C>O)  &  (C>= O1)  &  (C1>= O)  &  ((C-O)>(O1-C1))); 
        BearishEngulfing  = (MHT  &  utrend   &  LongBlackCandle  &  (C1>O1)  &  (O>C)  &  (O>= C1)  &  (O1>= C)  &  ((O-C)>(C1-O1)));
        #bodyLength           = abs(close-open);
        #upperShadowLength    = abs(high-open);
        #lowerShadowLength    = abs(high-low);
        #isBearishSpinningTop = bodyLength < upperShadowLength and bodyLength < lowerShadowLength

        #isBearishSpinningTop = ((C>O) and ((H-L)>(3*(C-O))) and (((H-C)/(H-L))<.5) and (((O-L)/(H-L))<.5)) 
        #isBearishSpinningTop = ((O>C) and ((H-L)>(3*(O-C))) and (((H-O)/(H-L))<.5) and (((C-L)/(H-L))<.5)) and Uptrend
        #isThreeInsideUp=((O2>C2) and (C1>O1) and (C1<=O2) and (C2<=O1) and ((C1-O1)<(O2-C2)) and (C>O) and (C>C1) and (O>O1))
		                  #((O2>C2) and (C1>O1) and (C1<=O2) and (C2<=O1) and ((C1-O1)<(O2-C2)) and (C>O) and (C>C1) and (O>O1))
		#((O2>C2) and (C1>O1) and (C1>=O2) and (C2>=O1) and ((C1-O1)>(O2-C2)) and  (C>O) and  (C>C1))
        #if(isThreeOutsideUp):
        #    print(candle)
        #AND Downtrend; 
        return BullishEngulfing;
    
        
        #candlestick.approximateEqual
        # return (prev_close > prev_open and
        #        abs(prev_close - prev_open) / (prev_high - prev_low) >= 0.7 and
        #        0.3 > abs(close - open) / (high - low) >= 0.1 and
        #        high < prev_close and
        #        low > prev_open)

        #return (prev_close > prev_open and
        #        prev_open <= close < open <= prev_close and
        #        open - close < prev_close - prev_open)