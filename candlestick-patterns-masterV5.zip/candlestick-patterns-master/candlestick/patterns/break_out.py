# -*- coding: utf-8 -*-
"""
Created on Wed Apr 17 06:00:39 2019

@author: lalitha
"""

def BreakOut(previousDayHigh,previousDayLow,todayHigh,todayLow,i):
    #global Signals
    Signal={}
#previousDayHigh=199.5
#previousDayLow=194.4
#todayHigh=194.65
#todayLow=192.75
    profitPercent =0.7*.01
    stopLossPercent=0.8*.01
    mulFactor1 = 0.45
    mulFactor2 = 0.75
    factor1 = mulFactor1 * (previousDayHigh - previousDayLow)
    factor2 = mulFactor2 * (previousDayHigh - previousDayLow)
    buyAt =0
    buyTarget =0
    buyStopLoss =0
    sellAt =0
    sellTarget =0
    sellStopLoss =0
    NoData=False
    message=str(i)+" ==> "
    if ((todayHigh - todayLow) < factor1):
        buyAt = todayLow + factor1;
        buyTarget = todayLow + factor1 + (todayLow + factor1) * profitPercent;
        buyStopLoss = todayLow + factor1 - (todayLow + factor1) * stopLossPercent;
        sellAt = todayHigh - factor1;
        sellTarget = todayHigh - factor1 - (todayHigh - factor1) * profitPercent;
        sellStopLoss = todayHigh - factor1 + (todayHigh - factor1) * stopLossPercent
    elif(((todayHigh - todayLow) > factor1) and ((todayHigh - todayLow) < factor2)):
        buyAt = todayLow + factor2;
        buyTarget = todayLow + factor2 + (todayLow + factor2) * profitPercent;
        buyStopLoss = todayLow + factor2 - (todayLow + factor2) * stopLossPercent;
        sellAt = todayHigh - factor2;
        sellTarget = todayHigh - factor2 - (todayHigh - factor2) * profitPercent;
        sellStopLoss = todayHigh - factor2 + (todayHigh - factor2) * stopLossPercent
    else:
        NoData=True
    Signal["WHigh"]=todayHigh
    Signal["WLow"]=todayLow
    Signal['Buy']=buyAt
    Signal['BuyT']=buyTarget
    Signal['BuySL']=buyStopLoss
    Signal['Sell']=sellAt
    Signal['SellT']=sellTarget
    Signal['SellSL']=sellStopLoss
    message = message + "\tBuy At " + str(math.ceil(buyAt * 100) / 100) + ". Target = " + str(math.ceil(buyTarget * 100) / 100) + ". Stoploss = " + str(math.ceil(buyStopLoss * 100) / 100) + "\n"
    message = message + "\t\tSell At " + str(math.ceil(sellAt * 100) / 100) + ". Target = " + str(math.ceil(sellTarget * 100) / 100) + ". Stoploss = " + str(math.ceil(sellStopLoss * 100) / 100) + ""
    #print(message)
    if(buyAt!=0):
        BreakOutSignals.append(Signal)
    return NoData

def drawBreakOutChart(Data,FileName,quotes):
    # Add data
    
    

    #date1=N1(parse(LeadData.iloc[DateIndex]['Date'].strftime("%Y-%m-%d 04:00")),"1D","+") #For India Data
    
    month = list(Data.index)[:-1]
    Buy= list(Data['Buy'])[:-1]
    BuyT= list(Data['BuyT'])[:-1]
    BuySL = list(Data['BuySL'])[:-1]
    Sell = list(Data['Sell'])[:-1]
    SellT = list(Data['SellT'])[:-1]
    SellSL = list(Data['SellSL'])[:-1]
    WLow = list(Data['WLow'])[:-1]
    WHigh = list(Data['WHigh'])[:-1]
    month=List_
    trace = go.Candlestick(x=List_,
                           open=quotes['open'],
                           high=quotes['high'],
                           low=quotes['low'],
                           close=quotes['close'])
    
    # Create and style traces
    trace0 = go.Scatter(
        x = month,
        y = Buy,
        name = 'Buy',
        line = dict(
            color = ('rgb(0, 255, 0)'),
            width = 1)
    )
    trace1 = go.Scatter(
        x = month,
        y = BuyT,
        name = 'BuyT',
        line = dict(
            color = ('rgb(22, 255, 0)'),
            width = 4,
            dash = 'dash')
    )
    trace2 = go.Scatter(
        x = month,
        y = BuySL,
        name = 'BuySL',
        line = dict(
            color = ('rgb(0, 255, 0)'),
            width = 4,
            dash = 'dot') # dash options include 'dash', 'dot', and 'dashdot'
    )
    trace3 = go.Scatter(
        x = month,
        y = Sell,
        name = 'Sell',
        line = dict(
            color = ('rgb(255, 0, 0)'),
            width = 1)
    )
    trace4 = go.Scatter(
        x = month,
        y = SellT,
        name = 'SellT',
        line = dict(
            color = ('rgb(255, 0, 0)'),
            width = 4,
            dash = 'dash')
    )
    trace5 = go.Scatter(
        x = month,
        y = SellSL,
        name = 'SellSL',
        line = dict(
            color = ('rgb(255, 0, 0)'),
            width = 4,
            dash = 'dot')
    )
    trace6 = go.Scatter(
        x = month,
        y = WLow,
        name = 'WLow',
        line = dict(
            color = ('rgb(1,1,1)'),
            width = 1)
    )
    trace7 = go.Scatter(
        x = month,
        y = WHigh,
        name = 'WHigh',
        line = dict(
            color = ('rgb(200,200,200)'),
            width = 1)
    ) 
    return [trace,trace0, trace1, trace2, trace3, trace4, trace5,trace6, trace7]
    
#    # Edit the layout
#    layout = dict(title = 'Average High and Low Temperatures in New York',
#                  xaxis = dict(title = 'Month'),
#                  yaxis = dict(title = 'Temperature (degrees F)'),
#                  )
#    
#    fig = dict(data=data, layout=layout)
#    plot(fig, filename=FileName,auto_open=True)