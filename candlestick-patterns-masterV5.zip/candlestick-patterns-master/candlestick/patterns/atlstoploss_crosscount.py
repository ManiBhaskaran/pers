from candlestick.patterns.candlestick_finder import CandlestickFinder


class AtlstoplossCrosscount(CandlestickFinder):
    def __init__(self, target=None):
        super().__init__(self.get_class_name(), 9, target=target)

    def logic(self, idx):
        df= self.data
        if((df.iloc[idx]['SIGNAL']!=df.iloc[idx+ 1 * self.multi_coeff]['SIGNAL']) and idx>9):
            if(df.iloc[idx]['SIGNAL']=="up"):
                i=1
                Big=True
                while(i<=8):
                   if((df.iloc[idx+ i * self.multi_coeff]['Close']>df.iloc[idx+ i * self.multi_coeff]['CCOL']) and Big):
                       t=5
                   else:
                       Big=False
                       return i-2
                   i=i+1
            elif(df.iloc[idx]['SIGNAL']=="down"):
                i=1
                Big=True
                while(i<=8):
                   if((df.iloc[idx+ i * self.multi_coeff]['Close']<df.iloc[idx+ i * self.multi_coeff]['CCOL']) and Big):
                       t=5
                   else:
                       Big=False
                       return i-2
                   i=i+1
            else:
                return -2
                
        else:
            return -1
            