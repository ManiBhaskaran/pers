# -*- coding: utf-8 -*-
"""
Created on Sat Oct 19 17:36:08 2019

@author: lalitha
"""
from candlestick import candlestick
import threading
import time
import requests
import datetime
import pandas as pd
import json
#from datetime import timedelta  
from datetime import datetime, timedelta
import requests
from ehp import *
from dateutil.parser import parse
import numpy as np
import plotly.graph_objs as go
from plotly import __version__
from plotly.offline import download_plotlyjs, init_notebook_mode, plot, iplot
import numpy as np
import plotly.io as pio
import os
from plotly.tools import FigureFactory as FF
import time

def getLiveData():
    global CrudeDf30Min
    global CrudeDf15Min
    StrTimeIntervals=['15minute','30minute']
    for TimeInterval in StrTimeIntervals: # 54261767
        Candles = requests.get('https://kitecharts-aws.zerodha.com/api/chart/54334983/'+TimeInterval+'?public_token=Pb0MyvJ435vcAjx5fxCTtEV0oD0wdcwT&user_id=RM5678&api_key=kitefront&access_token=mwFtysT9JpZk6B7ZOUH4AqbrJkhUlTnC&from=2019-01-08&to=2019-04-05&ciqrandom=1549306657305') #GOLD
        Candles_dict = Candles.json()['data']['candles']
        Candles_df = pd.DataFrame(Candles_dict,columns=['Date', 'open', 'high', 'low', 'close', 'V'])
        #candles5min_df['T'] = pd.to_datetime(candles5min_df['T'], unit='ms')
        #List_ = list(Candles_df['Date'])
        #List_ = [parse(x) for x in List_]
        #Candles_df['Date']=pd.Series([x for x in List_],index=Candles_df.index)
        List_ = list(Candles_df['Date'])
    #List_ = [parse(x).strftime for x in List_]
        List_ = [datetime.strptime(MParseDate(x).strftime("%m/%d/%Y %I:%M %p"), "%m/%d/%Y %I:%M %p") for x in List_]
        Candles_df['Date']=pd.Series([x for x in List_],index=Candles_df.index)
        if(TimeInterval=="15minute"):
            CrudeDf15Min=Candles_df
            CrudeDf15Min=ProcessCandles(CrudeDf15Min)
            List_ = list(CrudeDf15Min['Date'])
            #parse(List_[0] ).hour
            CrudeDf15Min['Hour'] = pd.Series([x.hour for x in List_],index=CrudeDf15Min.index)

        else:
            CrudeDf30Min=Candles_df
            CrudeDf30Min=ProcessCandles(CrudeDf30Min)
            List_ = list(CrudeDf30Min['Date'])
#parse(List_[0] ).hour
            CrudeDf30Min['Hour'] = pd.Series([x.hour for x in List_],index=CrudeDf30Min.index)


def MParseDate(Date):
    ts = (np.datetime64(pd.to_datetime(Date)) - np.datetime64('1970-01-01T00:00:00Z')) / np.timedelta64(1, 's')
    return N1(N1(datetime.utcfromtimestamp(ts),'5H',"+"),"30M","+")
seconds_per_unit = {"S": 1, "M": 60, "H": 3600, "D": 86400, "W": 604800}
def N1(date,s,Operation):
    if (Operation=="+"):
        return date+timedelta(seconds=int(s[:-1]) * seconds_per_unit[s[-1]])
    else:
        return date-timedelta(seconds=int(s[:-1]) * seconds_per_unit[s[-1]])


def getPastData(ID,StockName):
    global Candles,url 
    global Candles_dict,Datas
    headers={}
    headers['User-Agent'] = 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36'
    StrTimeIntervals=['3minute','5minute','15minute','30minute','day']
    #StrTimeIntervals=['3minute']
    #Increment=[30,60,80,90,90]
    #Increment=[10]
    Increment=[3,3,3,3,3]
    
    #Increment=[1,1,1,1,1]
    #Increment=[3,3,3,3,3]
    #StrTimeIntervals=['day']
    #Duration=850
    Duration=5
    requests.Timeout(120)
    TimeIntervalData={}
    for TimeInterval in StrTimeIntervals: # 54261767
        
        df=pd.DataFrame()
        #print(StockName+"     Running ....."+ TimeInterval )
        #StartDate=N1(datetime.now(),'3D','-')
        StartDate=N1(datetime.now(),str(Duration)+'D','-')
        DateIncr=0        
        #while(DateIncr<3):
        while(DateIncr<Duration):
            DateIncr=DateIncr+Increment[StrTimeIntervals.index(TimeInterval)]+1
            EndDate=N1(StartDate,str(Increment[StrTimeIntervals.index(TimeInterval)])+'D','+')
            StartDateStr=StartDate.strftime("%Y-%m-%d")
            EndDateStr=EndDate.strftime("%Y-%m-%d")
            #print(str(DateIncr)+" --> "+StartDateStr+ ' - ' + EndDateStr)
            url='https://kitecharts-aws.zerodha.com/api/chart/'+str(ID)+'/'+TimeInterval+'?public_token=Pb0MyvJ435vcAjx5fxCTtEV0oD0wdcwT&user_id=RM5678&api_key=kitefront&access_token=mwFtysT9JpZk6B7ZOUH4AqbrJkhUlTnC&'+'from='+StartDateStr+'&to='+EndDateStr+'&ciqrandom=1549306657305'                               
            retry=1
            time.sleep(5)
            while(retry<5):
                Candles = requests.get('https://kitecharts-aws.zerodha.com/api/chart/'+str(ID)+'/'+TimeInterval+
                               '?public_token=Pb0MyvJ435vcAjx5fxCTtEV0oD0wdcwT&user_id=RM5678&api_key=kitefront&access_token=mwFtysT9JpZk6B7ZOUH4AqbrJkhUlTnC&'+
#                               'from=2019-01-08&to=2019-04-05&ciqrandom=1549306657305') #GOLD
                                'from='+StartDateStr+'&to='+EndDateStr+'&ciqrandom=1549306657305',headers=headers) #GOLD
                if(Candles.status_code==200):
                    retry=10
                else:
                    print("Retry " + str(retry) + " ---- "+ str(Candles.status_code))
                    time.sleep(1)
                    retry=retry+1
                    
            Candles_dict = Candles.json()['data']['candles']
            tCandles_df = pd.DataFrame(Candles_dict,columns=['Date', 'open', 'high', 'low', 'close', 'V'])
            List_ = list(tCandles_df['Date'])
            List_ = [datetime.strptime(MParseDate(x).strftime("%m/%d/%Y %I:%M %p"), "%m/%d/%Y %I:%M %p") for x in List_]
            tCandles_df['Date']=pd.Series([x for x in List_],index=tCandles_df.index)
            df=df.append(tCandles_df)
            StartDate=N1(EndDate,'1D','+')
        TimeIntervalData[TimeInterval]=df

#        df.to_csv("C:\\ReadMoneycontrol\\Mani 2.0\\incr1\\"+StockName+"-"+TimeInterval+".csv",sep=',',encoding='utf-8',index=False)
        #time.sleep(1)
    Datas[StockName]=TimeIntervalData
    return df
#        if(TimeInterval=="15minute"):
#            CrudeDf15Min=Candles_df
#            CrudeDf15Min=ProcessCandles(CrudeDf15Min)
#            List_ = list(CrudeDf15Min['Date'])
#            #parse(List_[0] ).hour
#            CrudeDf15Min['Hour'] = pd.Series([x.hour for x in List_],index=CrudeDf15Min.index)
#
#        else:
#            CrudeDf30Min=Candles_df
#            CrudeDf30Min=ProcessCandles(CrudeDf30Min)
#            List_ = list(CrudeDf30Min['Date'])
##parse(List_[0] ).hour
#            CrudeDf30Min['Hour'] = pd.Series([x.hour for x in List_],index=CrudeDf30Min.index)


def getPastDayData(ID,StockName):
    global Candles,url 
    global Candles_dict 

    StrTimeIntervals=['day']
    #Increment=[30,60,80,90,90]
    Increment=[9]
    #StrTimeIntervals=['day']
    requests.Timeout(120)
    for TimeInterval in StrTimeIntervals: # 54261767
        df=pd.DataFrame()
        #print(StockName+"     Running ....."+ TimeInterval )
        StartDate=N1(datetime.now(),'8D','-')
        DateIncr=0        
        while(DateIncr<8):
            DateIncr=DateIncr+Increment[StrTimeIntervals.index(TimeInterval)]+1
            EndDate=N1(StartDate,str(Increment[StrTimeIntervals.index(TimeInterval)])+'D','+')
            StartDateStr=StartDate.strftime("%Y-%m-%d")
            EndDateStr=EndDate.strftime("%Y-%m-%d")
            print(str(DateIncr)+" --> "+StartDateStr+ ' - ' + EndDateStr)
            url='https://kitecharts-aws.zerodha.com/api/chart/'+str(ID)+'/'+TimeInterval+'?public_token=Pb0MyvJ435vcAjx5fxCTtEV0oD0wdcwT&user_id=RM5678&api_key=kitefront&access_token=mwFtysT9JpZk6B7ZOUH4AqbrJkhUlTnC&'+'from='+StartDateStr+'&to='+EndDateStr+'&ciqrandom=1549306657305'                               
            retry=1
            time.sleep(5)
            while(retry<5):
                Candles = requests.get('https://kitecharts-aws.zerodha.com/api/chart/'+str(ID)+'/'+TimeInterval+
                               '?public_token=Pb0MyvJ435vcAjx5fxCTtEV0oD0wdcwT&user_id=RM5678&api_key=kitefront&access_token=mwFtysT9JpZk6B7ZOUH4AqbrJkhUlTnC&'+
#                               'from=2019-01-08&to=2019-04-05&ciqrandom=1549306657305') #GOLD
                                'from='+StartDateStr+'&to='+EndDateStr+'&ciqrandom=1549306657305') #GOLD
                if(Candles.status_code==200):
                    retry=10
                else:
                    print("Retry " + str(retry) + " ---- "+ str(Candles.status_code))
                    time.sleep(10)
                    retry=retry+1
                    
            Candles_dict = Candles.json()['data']['candles']
            tCandles_df = pd.DataFrame(Candles_dict,columns=['Date', 'open', 'high', 'low', 'close', 'V'])
            List_ = list(tCandles_df['Date'])
            List_ = [datetime.strptime(MParseDate(x).strftime("%m/%d/%Y %I:%M %p"), "%m/%d/%Y %I:%M %p") for x in List_]
            tCandles_df['Date']=pd.Series([x for x in List_],index=tCandles_df.index)
            df=df.append(tCandles_df)
            StartDate=N1(EndDate,'1D','+')
        df['STOCK']=StockName
        df.to_csv("C:\\ReadMoneycontrol\\Mani 2.0\\incr\\DAILY"+"-"+TimeInterval+".csv",sep=',',encoding='utf-8',index=False,mode='a')
    return df


def getStockID():
    StockList=pd.read_csv("C:\ReadMoneycontrol\Mani 2.0\StockList.txt")
    headers = {'Content-type': 'application/x-www-form-urlencoded', 'Accept': 'application/json, text/plain, */*',
               'cookie':'kf_session=Qcu23AvCUpGbVRFIs5RPFOtMjXrHcTAd; _gid=GA1.2.1400456528.1571445914'
               ,'x-csrftoken':'QuRGDUqha8xIe5li576C4lRfIBot4DFb'
               ,'referer':'https://kite.zerodha.com/chart/web/ciq/NSE/VEDL/784129'}
    i=0
    DatasAr=[]
    
    while(i<len(StockList)):
        Datas={}
        
        StockName=StockList.iloc[i]['Symbol']
        Datas['StockName']=StockName
        i=i+1
        data="segment=NSE&tradingsymbol="+StockName.replace("&","%26")+"&watch_id=1970820&weight=1"
        Response = requests.post('https://kite.zerodha.com/api/marketwatch/1970820/items',
                             headers=headers,data=data) #GOLD
        Datas['ZID']=Response.json()['data']['instrument_token']
        DatasAr.append(Datas)
        
        requests.delete('https://kite.zerodha.com/api/marketwatch/1970820/' + str(Datas['ZID']),headers=headers)
        a=requests.delete('https://kite.zerodha.com/api/marketwatch/1970820/897537' ,headers=headers)
        time.sleep(1)    
    pd.DataFrame(DatasAr).to_csv("C:\ReadMoneycontrol\Mani 2.0\StockListID.csv",sep=',',encoding='utf-8',index=False)

Date1=datetime.now()
StockList=pd.read_csv("C:\ReadMoneycontrol\Mani 2.0\StockListIDOriginal.txt")
i=111111111110
Datas={}
while(i<len(StockList)):#len(StockList)):
    StockName=StockList.iloc[i]['StockName']
    ZID=StockList.iloc[i]['ZID']    
    threading.Thread(target=getPastData,args=(ZID,StockName)).start()
    #time.sleep(1)
    #getPastData(ZID,StockName)    
    i=i+1
#while(len(Datas)<len(StockList)):
#    time.sleep(10)
#    print(len(Datas))
#    qt=6
#print("finished" + str((datetime.now()-Date1).seconds))

StockList=pd.read_csv("C:\ReadMoneycontrol\Mani 2.0\StockList.txt")
ki=0
#while(ki<len(StockList)):
if(False):
    StockName=StockList.iloc[ki]['Symbol']
    ki=ki+1
    print(StockName)
    Stock=pd.read_csv(r"C:\ReadMoneycontrol\Mani 2.0\Data\\"+StockName+"-day.csv",encoding='utf-8')
    LastPivot=pd.read_csv(r"C:\ReadMoneycontrol\Mani 2.0\Data3\\"+StockName+"-Pivot.csv",encoding='utf-8')
    Stock.columns=['Date', 'Open', 'High', 'Low', 'Close', 'V']
    LastPivot.columns=['Date', 'Open', 'High', 'Low', 'Close', 'V', 'H1', 'H2', 'H3', 'H4',
       'IPivot', 'L1', 'L2', 'L3', 'L4', 'A0', 'A1000', 'A1236', 'A1382',
       'A1500', 'A1618', 'A1786', 'A2000', 'A2236', 'A236', 'A2382', 'A2500',
       'A2618', 'A2786', 'A3000', 'A3236', 'A3382', 'A3500', 'A3618', 'A3786',
       'A382', 'A4000', 'A500', 'A618', 'A786', 'Z1000', 'Z1236', 'Z1382',
       'Z1500', 'Z1618', 'Z1786', 'Z2000', 'Z2236', 'Z236', 'Z2382', 'Z2500',
       'Z2618', 'Z2786', 'Z3000', 'Z3236', 'Z3382', 'Z3500', 'Z3618', 'Z3786',
       'Z382', 'Z4000', 'Z500', 'Z618', 'Z786']
    #Stock.columns=['Date', 'Open', 'High', 'Low', 'Close', 'V']
    #DateIndex=10
    
    LastPivot[LastPivot['Date']==LastPivot.iloc[len(LastPivot)-3]['Date']]
    #Stock1=candlestick.AppendPivot(Stock[Stock['Date']>=LastPivot.iloc[len(LastPivot)-2]['Date']])   
    Stock1=candlestick.AppendPivot(Stock[Stock['Date']>=LastPivot.iloc[len(LastPivot)-3]['Date']])   
    Data1=Stock[Stock['Date']>=LastPivot.iloc[len(LastPivot)-3]['Date']]
    Data1=Datas['SBIN']['day']
    Data1.columns=['Date', 'Open', 'High', 'Low', 'Close', 'V']
    
    #str(Test['Date'].dtype)
    Stock1=candlestick.AppendPivot(Test)
    Stock1.iloc[-1]
#    Stock1=candlestick.AppendPivot(Stock)
    #NIFTY1.iloc[-1]
    #NIFTY1.iloc[0]['High']
#    Stock1.to_csv(r"C:\ReadMoneycontrol\Mani 2.0\Data3\\"+StockName+"-Pivot.csv",sep=',',encoding='utf-8',index=False,mode='a',header=False)


#len(Datas)
#Datas['NIFTY50']['3minute']

#StockList=pd.read_csv("C:\ReadMoneycontrol\Mani 2.0\StockListIDOriginal.txt")
i=1000
while(i<len(StockList)):
    StockName=StockList.iloc[i]['StockName']
    ZID=StockList.iloc[i]['ZID']
    threading.Thread(target=getPastDayData,args=(ZID,StockName)).start()
    time.sleep(1)
#    getPastDayData(ZID,StockName)
    i=i+1

#getPastData(256265,'NIFTY')
#https://kite.zerodha.com/api/marketwatch/1970820/738139158
#Delete