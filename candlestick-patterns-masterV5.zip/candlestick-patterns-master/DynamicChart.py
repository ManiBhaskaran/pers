import pandas as pd
import numpy as np
import dash
from dash.dependencies import Input, Output
import dash_core_components as dcc
import dash_html_components as html
import plotly.graph_objs as go

data1 = {'Col1':['A', 'B', 'C', 'D', 'E'],
        'Col2':list(np.random.randn(5))}
data2 = {'Col1':['F', 'G', 'H', 'I', 'J'],
        'Col2':list(np.random.randn(5))}
data3 = {'Col1':['K', 'L', 'M', 'N', 'O'],
        'Col2':list(np.random.randn(5))}

df1 = pd.DataFrame(data1, columns=['Col1', 'Col2'])
df2 = pd.DataFrame(data2, columns=['Col1', 'Col2'])
df3 = pd.DataFrame(data3, columns=['Col1', 'Col2'])


app = dash.Dash()

app.layout = html.Div([
        html.Div([dcc.Dropdown(
                 id='dropdown',
                 options=[{'label': 'Dataset 1', 'value': 1},
                          {'label': 'Dataset 2', 'value': 2},
                          {'label': 'Dataset 3', 'value': 3}],
                 placeholder='Select the dataset...',
                 )]),

        html.Div(id='output'),

        html.Div(id='pie-chart-div')
    ])

@app.callback(
    dash.dependencies.Output('output', 'children'),
    [dash.dependencies.Input('dropdown', 'value')])
def update_output(selected):
    if selected==1:
        df = df1
    elif selected==2:
        df = df2
    elif selected==3:
        df = df3

    columns = df.Col1.values

    divs=[]
    for i in range(len(columns)):
        divs.append(
            dcc.Graph(
                figure=go.Figure(
                    data=[go.Bar(
                                x=[10],
                                y=[columns[i]],
                                orientation = 'h',
                                text=['Column number {}: {}'.format(i+1, columns[i])],
                                textposition = 'inside',
                                marker = dict(color = 'rgb(158,202,225)'),
                            )
                        ],
                    layout=go.Layout(
                        xaxis=dict(showticklabels=False, fixedrange=True),
                        yaxis=dict(showticklabels=False, fixedrange=True),
                    )
                ),
                hoverData='',
                style={'width': 400, 'height':250, 'padding': 1},
                id='dynamic-text-area-{}'.format(i)
            ),
        )

        divs.append(html.Div(style={'height': '1'}))




        @app.callback(dash.dependencies.Output('pie-chart-div', 'children'),
              [dash.dependencies.Input('dropdown', 'value'),
               dash.dependencies.Input('dynamic-text-area-{}'.format(i), 'hoverData')])
        def update_graph(df, hoverData):
            values = [df[df.Col1==hoverData].Col2.iloc[0], sum(df.Col2)]
            labels = ['Selected column','All other columns']
            trace = go.Pie(values=values, labels = labels)
            fig = dcc.Graph(
                id='graph',
                figure={
                    'data': [trace],
                    'layout': {
                        'height': 400,
                        'width': 400,
                        'showlegend': False
                    }
                }
            )
            return fig



    return divs



if __name__ == '__main__':
    app.run_server(debug=True)