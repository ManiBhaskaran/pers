# -*- coding: utf-8 -*-
"""
Created on Fri Jan  3 21:28:03 2020

@author: lalitha
"""

#df=pd.read_csv("C:\ReadMoneycontrol\Mani 2.0\Sample.csv")
#df['Vol'].cumsum()
#
#df.groupby(['Date'])['Vol'].apply(lambda x: x.cumsum())

SBIN5Min['CV']=SBIN5Min.groupby(['CDATE'])['V'].apply(lambda x: x.cumsum())
SBIN5Min['CDayHigh']=SBIN5Min.groupby(['CDATE'])['High'].apply(lambda x: x.cummax())
SBIN5Min['CDayLow']=SBIN5Min.groupby(['CDATE'])['Low'].apply(lambda x: x.cummin())
#SBIN5Min['COpen']=
FirstOpen=pd.DataFrame(SBIN5Min.groupby(['CDATE']).apply(lambda x: x['Open'].iloc[0]))
FirstOpen.columns=['DayOpen']
FirstOpen['CDATE']=FirstOpen.index
SBIN5Min=SBIN5Min.merge(FirstOpen,on=['CDATE'])
#SBIN5Min.groupby(['CDATE'])['Low'].count()
SBIN5Min['SMAV20']=SBIN5Min['V'].shift(1).rolling(20).mean()
SBIN5Min=candlestick.HA(SBIN5Min)
#SBIN5Min=candlestick.heikenashi(SBIN5Min)
#Dt=SBIN5Min[['Date','Open','High','Low','Close','DayOpen','HA_Close', 'HA_Open',
#       'HA_High', 'HA_Low','CDayHigh','CDayLow']]
#SBIN5Min['SMAV20'].head(30)

Sdf=candlestick.Newmacd(SBIN5Min,"Close")
SBIN5Min['MACD']=Sdf['MACD']
#SCandle['RSI']=SRSIValue
#Candle['Close']=Candle['Close']
SBIN5Min['Signal']=Sdf['Signal']
SBIN5Min['Crossover']=Sdf['Crossover']
Sdf=candlestick.Ichimoku(SBIN5Min,9,26,52,-26)
SBIN5Min.merge(Sdf)
C=SBIN5Min[
        (SBIN5Min['Close']>SBIN5Min['Close'].shift(1).rolling(20).max())
       &(SBIN5Min['V']>SBIN5Min['SMAV20']) 
       &(SBIN5Min['Close'].shift(1)>SBIN5Min['Close'].shift(2).rolling(20).max())
       &(SBIN5Min['V'].shift(1)>SBIN5Min['SMAV20'].shift(1)) 
       &(SBIN5Min['CV']>SBIN5Min['PVolumeSMA5'])
       #&(SBIN5Min['CV']>SBIN5Min['PVolumeSMA10'])
       #&(SBIN5Min['CV']>SBIN5Min['PVolumeSMA15'])
       #&(SBIN5Min['V']>SBIN5Min['CV'].shift(1).rolling(5).min())
       
        ]

C=SBIN5Min[
        (SBIN5Min['MACD']<SBIN5Min['Signal'])
        & (SBIN5Min['MACD']<=0)
        & ((SBIN5Min['MACD'].shift(1)>SBIN5Min['Signal'].shift(1)-.1)
        & (SBIN5Min['MACD'].shift(2)>SBIN5Min['Signal'].shift(2)-.1)
        )
        &( (SBIN5Min['Indx']<=10)
        |
        (SBIN5Min['Indx']==24))
        #& (SBIN5Min['MACD']<=0)
        ]
CC=SBIN5Min[
        (SBIN5Min['MACD']<SBIN5Min['Signal'])
        & (SBIN5Min['MACD']<=0)
        & ((SBIN5Min['MACD'].shift(1)>SBIN5Min['Signal'].shift(1))
        & (SBIN5Min['MACD'].shift(2)>SBIN5Min['Signal'].shift(2))
        )
        &( (SBIN5Min['Indx']<=10)
        |
        (SBIN5Min['Indx']==24))
        #& (SBIN5Min['MACD']<=0)
        ]

C3=pd.concat([C1C, C]).drop_duplicates(keep=False)



C4=SBIN5Min[
        (SBIN5Min['MACD']<SBIN5Min['Signal'])
        & (SBIN5Min['MACD']<=0)
        & ((SBIN5Min['MACD'].shift(1)>SBIN5Min['Signal'].shift(1)-.1)
        & (SBIN5Min['MACD'].shift(2)>SBIN5Min['Signal'].shift(2)-.1)
        & (SBIN5Min['MACD'].shift(3)>SBIN5Min['Signal'].shift(3))
        & (SBIN5Min['MACD'].shift(4)>SBIN5Min['Signal'].shift(4))
        & (SBIN5Min['MACD'].shift(5)>SBIN5Min['Signal'].shift(5))
        & (SBIN5Min['MACD'].shift(6)>SBIN5Min['Signal'].shift(6))
        & (SBIN5Min['MACD'].shift(12)>SBIN5Min['Signal'].shift(12))
        )
#        &( (SBIN5Min['Indx']<=10)
 #       |
#        (SBIN5Min['Indx']==24))
        #& (SBIN5Min['MACD']<=0)
        ]



D=SBIN5Min[
        (SBIN5Min['MACD']>SBIN5Min['Signal'])
        & (SBIN5Min['MACD']>3)
        & ((SBIN5Min['MACD'].shift(1)<SBIN5Min['Signal'].shift(1)+.1)
        & (SBIN5Min['MACD'].shift(2)<SBIN5Min['Signal'].shift(2)+.1)
        )
        #&( (SBIN5Min['Indx']<=10)
        #|
        #(SBIN5Min['Indx']==24))
        #& (SBIN5Min['MACD']<=0)
        ]


Dt1=SBIN5Min[
        (SBIN5Min['HA_High']>SBIN5Min['HA_High'].shift(1))
       &(SBIN5Min['V']>SBIN5Min['V'].shift(1))  
       & ( (SBIN5Min['CDayHigh']-SBIN5Min['CDayLow']) > (SBIN5Min['PDayHigh']-SBIN5Min['PDayLow']))
       &(SBIN5Min['Close']>SBIN5Min['DayOpen'])  
       &(SBIN5Min['Close']>SBIN5Min['PDayClose'])
       & ( (SBIN5Min['CDayHigh']-SBIN5Min['CDayLow']) > (SBIN5Min['PDayHigh'].shift(1)-SBIN5Min['PDayLow'].shift(1)))
       #&(SBIN5Min['DayRSI14'].shift(1)>SBIN5Min['DayRSI14'].shift(2))
       &(SBIN5Min['senkou_span_a']<SBIN5Min['senkou_span_b'])
       #&(SBIN5Min['senkou_span_a']>SBIN5Min['senkou_span_b'])
#       &(SBIN5Min['PDayClose']>SBIN5Min['DaySMA50'])
#       SBIN5Min.columns
        ]

Dt2=SBIN5Min[
        (SBIN5Min['HA_High']<SBIN5Min['HA_High'].shift(1))
       &(SBIN5Min['V']>SBIN5Min['V'].shift(1))  
       & ( (SBIN5Min['CDayHigh']-SBIN5Min['CDayLow']) < (SBIN5Min['PDayHigh']-SBIN5Min['PDayLow']))
       &(SBIN5Min['Close']<SBIN5Min['DayOpen'])  
       &(SBIN5Min['Close']<SBIN5Min['PDayClose'])
       & ( (SBIN5Min['CDayHigh']-SBIN5Min['CDayLow']) < (SBIN5Min['PDayHigh'].shift(1)-SBIN5Min['PDayLow'].shift(1)))
       #&(SBIN5Min['DayRSI14'].shift(1)>SBIN5Min['DayRSI14'].shift(2))
       &(SBIN5Min['senkou_span_a']<SBIN5Min['senkou_span_b'])
       &(SBIN5Min['Close']<SBIN5Min['DaySMA50'])
#       SBIN5Min.columns
        ]
###NEED to Improve
IntraDayBuyNotWorking=SBIN5Min[
        (
                (SBIN5Min['Close']>SBIN5Min['SMA-C-21']) &
                (SBIN5Min['Close']>SBIN5Min['SMA-C-10']) &
                (SBIN5Min['Close']>SBIN5Min['SMA-C-150']) &
                (SBIN5Min['Close'].shift(1)>SBIN5Min['SMA-C-21'].shift(1)) &
                (SBIN5Min['Close'].shift(1)>SBIN5Min['SMA-C-10'].shift(1)) &
                (SBIN5Min['Close'].shift(2)>SBIN5Min['SMA-C-21'].shift(2)) &
                (SBIN5Min['Close'].shift(2)>SBIN5Min['SMA-C-10'].shift(2)) 
                & (SBIN5Min['V']>SBIN5Min['SMA-V-20']) 
                & (SBIN5Min['Indx']<2) 
                )
        ][['Date','Open','High','Low','Close','DayOpen','HA_Close', 'HA_Open',
       'HA_High', 'HA_Low','CDayHigh','CDayLow','SMA-C-21','SMA-C-10','SMA-C-21-1','SMA-C-10-1','PDayClose', 'PDayOpen']]
IntraDayBuyNotWorking['PPER']=round((IntraDayBuyNotWorking['PDayClose']-IntraDayBuyNotWorking['PDayOpen']+0.00001)/IntraDayBuyNotWorking['PDayOpen']*100,2)
IntraDayBuyNotWorking['SMADIFF']=round((IntraDayBuyNotWorking['SMA-C-10']-IntraDayBuyNotWorking['SMA-C-21']+0.00001)/IntraDayBuyNotWorking['SMA-C-21']*10000)


SBIN5Min['SMA-C-CrossOver']= ((SBIN5Min['SMA-C-21'].shift(1)<SBIN5Min['SMA-C-10'].shift(1)) &
                             (SBIN5Min['SMA-C-21'].shift(2)<SBIN5Min['SMA-C-10'].shift(2)) &
                             (SBIN5Min['SMA-C-21'].shift(3)<SBIN5Min['SMA-C-10'].shift(3))
                             )
#(SBIN5Min['Low']<SBIN5Min['SMA-C-10'])
IntraDayBuyTemp=SBIN5Min[['Date','Indx','Open','High','Low','Close','DayOpen','HA_Close', 'HA_Open',
       'HA_High', 'HA_Low','CDayHigh','CDayLow','SMA-C-21','SMA-C-10','SMA-C-21-1','SMA-C-10-1','SMA-C-CrossOver']]

IntraDayBuy=SBIN5Min[
        (
                #( (SBIN5Min['Close']>SBIN5Min['SMA-C-21']) & (SBIN5Min['Open']<SBIN5Min['SMA-C-21'])) &
            (
                (
                    (SBIN5Min['Close']>SBIN5Min['SMA-C-21']) &
                    (SBIN5Min['SMA-C-10']>SBIN5Min['SMA-C-21']) &
                    ( (SBIN5Min['Close']>SBIN5Min['SMA-C-21']) & 
                     (
                             (SBIN5Min['Low']<SBIN5Min['SMA-C-10']) |
                             (SBIN5Min['SMA-C-21'].shift(1)<SBIN5Min['SMA-C-10'].shift(1)) |
                             (SBIN5Min['SMA-C-21'].shift(2)<SBIN5Min['SMA-C-10'].shift(2)) |
                             (SBIN5Min['SMA-C-21'].shift(3)<SBIN5Min['SMA-C-10'].shift(3))
                             
                     )
                )
                )
#            |
#                (
#                    (SBIN5Min['Close'].shift(1)>SBIN5Min['SMA-C-21'].shift(1)) &
#                    (SBIN5Min['SMA-C-10'].shift(1)>SBIN5Min['SMA-C-21'].shift(1)) &
#                    ( (SBIN5Min['Close'].shift(1)>SBIN5Min['SMA-C-21'].shift(1)) 
#                    & (SBIN5Min['Low'].shift(1)<SBIN5Min['SMA-C-10'].shift(1))) 
#                )
            ) &
                
                #( (SBIN5Min['Low']<SBIN5Min['SMA-C-10'])) & #(SBIN5Min['Close']>SBIN5Min['SMA-C-10']) & 
                
                #( (SBIN5Min['Close']>SBIN5Min['SMA-C-21']) & (SBIN5Min['Low']<SBIN5Min['SMA-C-21'])) &
                #( (SBIN5Min['Close']>SBIN5Min['SMA-C-10']) & (SBIN5Min['Low']<SBIN5Min['SMA-C-10'])) &
                #(SBIN5Min['Close'].shift(1)>SBIN5Min['SMA-C-21'].shift(1)) &
                #(SBIN5Min['Close'].shift(1)>SBIN5Min['SMA-C-10'].shift(1)) &
                #(SBIN5Min['Close'].shift(2)>SBIN5Min['SMA-C-21'].shift(2)) &
                #(SBIN5Min['Close'].shift(2)>SBIN5Min['SMA-C-10'].shift(2)) 
              #   (SBIN5Min['CV']>SBIN5Min['PDayVolumeSMA10']) &
              (SBIN5Min['SMA-C-10']>SBIN5Min['SMA-C-21']) &
              (SBIN5Min['SMA-C-10'].shift(1)>SBIN5Min['SMA-C-21'].shift(1)) &
                (SBIN5Min['Indx']<40) 
                )
        ][['Date','Open','High','Low','Close','DayOpen','HA_Close', 'HA_Open',
       'HA_High', 'HA_Low','CDayHigh','CDayLow','SMA-C-21','SMA-C-10','SMA-C-21-1','SMA-C-10-1','SMA-C-CrossOver','PDayClose', 'PDayOpen']]
IntraDayBuy['PPER']=round((IntraDayBuy['PDayClose']-IntraDayBuy['PDayOpen']+0.00001)/IntraDayBuy['PDayOpen']*100,2)
IntraDayBuy['SMADIFF']=round((IntraDayBuy['SMA-C-10']-IntraDayBuy['SMA-C-21']+0.00001)/IntraDayBuy['SMA-C-21']*10000)


#https://www.pythonforfinance.net/2019/06/26/ichimoku-trading-strategy-with-python/
#https://github.com/kumotrader/ichimoku-crypto


IntraDayBuy=SBIN5Min[
        (
                #( (SBIN5Min['Close']>SBIN5Min['SMA-C-21']) & (SBIN5Min['Open']<SBIN5Min['SMA-C-21'])) &
            (
                (
                    (SBIN5Min['Close']>SBIN5Min['SMA-C-21']) &
                    (SBIN5Min['SMA-C-10']>SBIN5Min['SMA-C-21']) &
                    (SBIN5Min['Close']>SBIN5Min['SMA-C-150']) 
                    & ( (SBIN5Min['Close']>SBIN5Min['SMA-C-21']) & 
                     (
                             (SBIN5Min['Low']<SBIN5Min['SMA-C-10']) |
                             (SBIN5Min['SMA-C-21'].shift(1)<SBIN5Min['SMA-C-10'].shift(1)) |
                             (SBIN5Min['SMA-C-21'].shift(2)<SBIN5Min['SMA-C-10'].shift(2)) |
                             (SBIN5Min['SMA-C-21'].shift(3)<SBIN5Min['SMA-C-10'].shift(3))
                             
                     )
                )
                )
#            |
#                (
#                    (SBIN5Min['Close'].shift(1)>SBIN5Min['SMA-C-21'].shift(1)) &
#                    (SBIN5Min['SMA-C-10'].shift(1)>SBIN5Min['SMA-C-21'].shift(1)) &
#                    ( (SBIN5Min['Close'].shift(1)>SBIN5Min['SMA-C-21'].shift(1)) 
#                    & (SBIN5Min['Low'].shift(1)<SBIN5Min['SMA-C-10'].shift(1))) 
#                )
            ) &


(
 (
    (SBIN5Min['SMA-C-10'].shift(1)>SBIN5Min['SMA-C-21'].shift(1)) &
    (SBIN5Min['SMA-C-10'].shift(2)>SBIN5Min['SMA-C-21'].shift(2)) &
    (SBIN5Min['SMA-C-10'].shift(3)>SBIN5Min['SMA-C-21'].shift(3)) &
    (SBIN5Min['SMA-C-10'].shift(4)>SBIN5Min['SMA-C-21'].shift(4)) &
    (SBIN5Min['SMA-C-10'].shift(5)>SBIN5Min['SMA-C-21'].shift(5)) &
    (SBIN5Min['SMA-C-10'].shift(6)>SBIN5Min['SMA-C-21'].shift(6)) &
    (SBIN5Min['SMA-C-10'].shift(7)>SBIN5Min['SMA-C-21'].shift(7)) &
    (SBIN5Min['SMA-C-10'].shift(8)>SBIN5Min['SMA-C-21'].shift(8)) &
    (SBIN5Min['SMA-C-10'].shift(9)>SBIN5Min['SMA-C-21'].shift(9)) &
    (SBIN5Min['SMA-C-10'].shift(10)>SBIN5Min['SMA-C-21'].shift(10)) &
    (SBIN5Min['SMA-C-10'].shift(11)>SBIN5Min['SMA-C-21'].shift(11)) &
    (SBIN5Min['SMA-C-10'].shift(12)>SBIN5Min['SMA-C-21'].shift(12)) &
    (SBIN5Min['SMA-C-10'].shift(13)>SBIN5Min['SMA-C-21'].shift(13)) &
    (SBIN5Min['SMA-C-10'].shift(14)>SBIN5Min['SMA-C-21'].shift(14)) &
    (SBIN5Min['SMA-C-10'].shift(15)>SBIN5Min['SMA-C-21'].shift(15)) &
    (SBIN5Min['SMA-C-10'].shift(16)>SBIN5Min['SMA-C-21'].shift(16)) &
    (SBIN5Min['SMA-C-10'].shift(17)>SBIN5Min['SMA-C-21'].shift(17)) &
    (SBIN5Min['SMA-C-10'].shift(18)>SBIN5Min['SMA-C-21'].shift(18)) &
    (SBIN5Min['SMA-C-10'].shift(19)>SBIN5Min['SMA-C-21'].shift(19)) &
    (SBIN5Min['SMA-C-10'].shift(20)>SBIN5Min['SMA-C-21'].shift(20)) &
    (SBIN5Min['SMA-C-10'].shift(21)>SBIN5Min['SMA-C-21'].shift(21)) &
    (SBIN5Min['SMA-C-10'].shift(22)>SBIN5Min['SMA-C-21'].shift(22)) &
    (SBIN5Min['SMA-C-10'].shift(23)>SBIN5Min['SMA-C-21'].shift(23)) &
    (SBIN5Min['SMA-C-10'].shift(24)>SBIN5Min['SMA-C-21'].shift(24)) &
    (SBIN5Min['SMA-C-10'].shift(25)>SBIN5Min['SMA-C-21'].shift(25)) &
    (SBIN5Min['SMA-C-10'].shift(26)>SBIN5Min['SMA-C-21'].shift(26))  &
    (SBIN5Min['SMA-C-150'].shift(20)<SBIN5Min['SMA-C-21'].shift(20)) &
    (SBIN5Min['SMA-C-150'].shift(21)<SBIN5Min['SMA-C-21'].shift(21)) &
    (SBIN5Min['SMA-C-150'].shift(22)<SBIN5Min['SMA-C-21'].shift(22)) &
    (SBIN5Min['SMA-C-150'].shift(23)<SBIN5Min['SMA-C-21'].shift(23)) &
    (SBIN5Min['SMA-C-150'].shift(24)<SBIN5Min['SMA-C-21'].shift(24)) &
    (SBIN5Min['SMA-C-150'].shift(25)<SBIN5Min['SMA-C-21'].shift(25)) &
    (SBIN5Min['SMA-C-150'].shift(26)<SBIN5Min['SMA-C-21'].shift(26)) 

 )
# |
# (
#    (SBIN5Min['SMA-C-10'].shift(1)<SBIN5Min['SMA-C-21'].shift(1)) &
#    (SBIN5Min['SMA-C-10'].shift(2)<SBIN5Min['SMA-C-21'].shift(2)) &
#    (SBIN5Min['SMA-C-10'].shift(3)<SBIN5Min['SMA-C-21'].shift(3)) &
#    (SBIN5Min['SMA-C-10'].shift(4)<SBIN5Min['SMA-C-21'].shift(4)) &
#    (SBIN5Min['SMA-C-10'].shift(5)<SBIN5Min['SMA-C-21'].shift(5)) &
#    (SBIN5Min['SMA-C-10'].shift(6)<SBIN5Min['SMA-C-21'].shift(6)) &
#    (SBIN5Min['SMA-C-10'].shift(7)<SBIN5Min['SMA-C-21'].shift(7)) &
#    (SBIN5Min['SMA-C-10'].shift(8)<SBIN5Min['SMA-C-21'].shift(8)) &
#    (SBIN5Min['SMA-C-10'].shift(9)<SBIN5Min['SMA-C-21'].shift(9)) &
#    (SBIN5Min['SMA-C-10'].shift(10)<SBIN5Min['SMA-C-21'].shift(10)) &
#    (SBIN5Min['SMA-C-10'].shift(11)<SBIN5Min['SMA-C-21'].shift(11)) &
#    (SBIN5Min['SMA-C-10'].shift(12)<SBIN5Min['SMA-C-21'].shift(12)) &
#    (SBIN5Min['SMA-C-10'].shift(13)<SBIN5Min['SMA-C-21'].shift(13)) &
#    (SBIN5Min['SMA-C-10'].shift(14)<SBIN5Min['SMA-C-21'].shift(14)) &
#    (SBIN5Min['SMA-C-10'].shift(15)<SBIN5Min['SMA-C-21'].shift(15)) &
#    (SBIN5Min['SMA-C-10'].shift(16)<SBIN5Min['SMA-C-21'].shift(16)) &
#    (SBIN5Min['SMA-C-10'].shift(17)<SBIN5Min['SMA-C-21'].shift(17)) &
#    (SBIN5Min['SMA-C-10'].shift(18)<SBIN5Min['SMA-C-21'].shift(18)) &
#    (SBIN5Min['SMA-C-10'].shift(19)<SBIN5Min['SMA-C-21'].shift(19)) &
#    (SBIN5Min['SMA-C-10'].shift(20)<SBIN5Min['SMA-C-21'].shift(20)) &
#    (SBIN5Min['SMA-C-10'].shift(21)<SBIN5Min['SMA-C-21'].shift(21)) &
#    (SBIN5Min['SMA-C-10'].shift(22)<SBIN5Min['SMA-C-21'].shift(22)) &
#    (SBIN5Min['SMA-C-10'].shift(23)<SBIN5Min['SMA-C-21'].shift(23)) &
#    (SBIN5Min['SMA-C-10'].shift(24)<SBIN5Min['SMA-C-21'].shift(24)) &
#    (SBIN5Min['SMA-C-10'].shift(25)<SBIN5Min['SMA-C-21'].shift(25)) &
#    (SBIN5Min['SMA-C-10'].shift(26)<SBIN5Min['SMA-C-21'].shift(26)) 
# )
) &
 
               (SBIN5Min['SMA-C-10']>SBIN5Min['SMA-C-21']) &
#              (SBIN5Min['SMA-C-10'].shift(1)>SBIN5Min['SMA-C-21'].shift(1)) &
                (SBIN5Min['Indx']==0) 
                )
        ][['Date','Open','High','Low','Close','DayOpen','HA_Close', 'HA_Open',
       'HA_High', 'HA_Low','CDayHigh','CDayLow','SMA-C-21','SMA-C-10','SMA-C-21-1','SMA-C-10-1','PDayClose', 'PDayOpen']]
IntraDayBuy['PPER']=round((IntraDayBuy['PDayClose']-IntraDayBuy['PDayOpen']+0.00001)/IntraDayBuy['PDayOpen']*100,2)
IntraDayBuy['SMADIFF']=round((IntraDayBuy['SMA-C-10']-IntraDayBuy['SMA-C-21']+0.00001)/IntraDayBuy['SMA-C-21']*10000)










IntraDaySell=SBIN5Min[
        (
            (
                (
                    (SBIN5Min['Close']<SBIN5Min['SMA-C-21']) &
                    (SBIN5Min['SMA-C-10']<SBIN5Min['SMA-C-21']) &
                    (SBIN5Min['Close']<SBIN5Min['SMA-C-150']) 
                    & ( (SBIN5Min['Close']<SBIN5Min['SMA-C-21']) & 
                     (
                             (SBIN5Min['Low']>SBIN5Min['SMA-C-10']) |
                             (SBIN5Min['SMA-C-21'].shift(1)>SBIN5Min['SMA-C-10'].shift(1)) |
                             (SBIN5Min['SMA-C-21'].shift(2)>SBIN5Min['SMA-C-10'].shift(2)) |
                             (SBIN5Min['SMA-C-21'].shift(3)>SBIN5Min['SMA-C-10'].shift(3))
                             
                     )
                )
                )
#            |
#                (
#                    (SBIN5Min['Close'].shift(1)>SBIN5Min['SMA-C-21'].shift(1)) &
#                    (SBIN5Min['SMA-C-10'].shift(1)>SBIN5Min['SMA-C-21'].shift(1)) &
#                    ( (SBIN5Min['Close'].shift(1)>SBIN5Min['SMA-C-21'].shift(1)) 
#                    & (SBIN5Min['Low'].shift(1)<SBIN5Min['SMA-C-10'].shift(1))) 
#                )
            ) &


(
# (
#    (SBIN5Min['SMA-C-10'].shift(1)>SBIN5Min['SMA-C-21'].shift(1)) &
#    (SBIN5Min['SMA-C-10'].shift(2)>SBIN5Min['SMA-C-21'].shift(2)) &
#    (SBIN5Min['SMA-C-10'].shift(3)>SBIN5Min['SMA-C-21'].shift(3)) &
#    (SBIN5Min['SMA-C-10'].shift(4)>SBIN5Min['SMA-C-21'].shift(4)) &
#    (SBIN5Min['SMA-C-10'].shift(5)>SBIN5Min['SMA-C-21'].shift(5)) &
#    (SBIN5Min['SMA-C-10'].shift(6)>SBIN5Min['SMA-C-21'].shift(6)) &
#    (SBIN5Min['SMA-C-10'].shift(7)>SBIN5Min['SMA-C-21'].shift(7)) &
#    (SBIN5Min['SMA-C-10'].shift(8)>SBIN5Min['SMA-C-21'].shift(8)) &
#    (SBIN5Min['SMA-C-10'].shift(9)>SBIN5Min['SMA-C-21'].shift(9)) &
#    (SBIN5Min['SMA-C-10'].shift(10)>SBIN5Min['SMA-C-21'].shift(10)) &
#    (SBIN5Min['SMA-C-10'].shift(11)>SBIN5Min['SMA-C-21'].shift(11)) &
#    (SBIN5Min['SMA-C-10'].shift(12)>SBIN5Min['SMA-C-21'].shift(12)) &
#    (SBIN5Min['SMA-C-10'].shift(13)>SBIN5Min['SMA-C-21'].shift(13)) &
#    (SBIN5Min['SMA-C-10'].shift(14)>SBIN5Min['SMA-C-21'].shift(14)) &
#    (SBIN5Min['SMA-C-10'].shift(15)>SBIN5Min['SMA-C-21'].shift(15)) &
#    (SBIN5Min['SMA-C-10'].shift(16)>SBIN5Min['SMA-C-21'].shift(16)) &
#    (SBIN5Min['SMA-C-10'].shift(17)>SBIN5Min['SMA-C-21'].shift(17)) &
#    (SBIN5Min['SMA-C-10'].shift(18)>SBIN5Min['SMA-C-21'].shift(18)) &
#    (SBIN5Min['SMA-C-10'].shift(19)>SBIN5Min['SMA-C-21'].shift(19)) &
#    (SBIN5Min['SMA-C-10'].shift(20)>SBIN5Min['SMA-C-21'].shift(20)) &
#    (SBIN5Min['SMA-C-10'].shift(21)>SBIN5Min['SMA-C-21'].shift(21)) &
#    (SBIN5Min['SMA-C-10'].shift(22)>SBIN5Min['SMA-C-21'].shift(22)) &
#    (SBIN5Min['SMA-C-10'].shift(23)>SBIN5Min['SMA-C-21'].shift(23)) &
#    (SBIN5Min['SMA-C-10'].shift(24)>SBIN5Min['SMA-C-21'].shift(24)) &
#    (SBIN5Min['SMA-C-10'].shift(25)>SBIN5Min['SMA-C-21'].shift(25)) &
#    (SBIN5Min['SMA-C-10'].shift(26)>SBIN5Min['SMA-C-21'].shift(26)) 
# )
# |
 (
    (SBIN5Min['SMA-C-10'].shift(1)<SBIN5Min['SMA-C-21'].shift(1)) &
    (SBIN5Min['SMA-C-10'].shift(2)<SBIN5Min['SMA-C-21'].shift(2)) &
    (SBIN5Min['SMA-C-10'].shift(3)<SBIN5Min['SMA-C-21'].shift(3)) &
    (SBIN5Min['SMA-C-10'].shift(4)<SBIN5Min['SMA-C-21'].shift(4)) &
    (SBIN5Min['SMA-C-10'].shift(5)<SBIN5Min['SMA-C-21'].shift(5)) &
    (SBIN5Min['SMA-C-10'].shift(6)<SBIN5Min['SMA-C-21'].shift(6)) &
    (SBIN5Min['SMA-C-10'].shift(7)<SBIN5Min['SMA-C-21'].shift(7)) &
    (SBIN5Min['SMA-C-10'].shift(8)<SBIN5Min['SMA-C-21'].shift(8)) &
    (SBIN5Min['SMA-C-10'].shift(9)<SBIN5Min['SMA-C-21'].shift(9)) &
    (SBIN5Min['SMA-C-10'].shift(10)<SBIN5Min['SMA-C-21'].shift(10)) &
    (SBIN5Min['SMA-C-10'].shift(11)<SBIN5Min['SMA-C-21'].shift(11)) &
    (SBIN5Min['SMA-C-10'].shift(12)<SBIN5Min['SMA-C-21'].shift(12)) &
    (SBIN5Min['SMA-C-10'].shift(13)<SBIN5Min['SMA-C-21'].shift(13)) &
    (SBIN5Min['SMA-C-10'].shift(14)<SBIN5Min['SMA-C-21'].shift(14)) &
    (SBIN5Min['SMA-C-10'].shift(15)<SBIN5Min['SMA-C-21'].shift(15)) &
    (SBIN5Min['SMA-C-10'].shift(16)<SBIN5Min['SMA-C-21'].shift(16)) &
    (SBIN5Min['SMA-C-10'].shift(17)<SBIN5Min['SMA-C-21'].shift(17)) &
    (SBIN5Min['SMA-C-10'].shift(18)<SBIN5Min['SMA-C-21'].shift(18)) &
    (SBIN5Min['SMA-C-10'].shift(19)<SBIN5Min['SMA-C-21'].shift(19)) &
    (SBIN5Min['SMA-C-10'].shift(20)<SBIN5Min['SMA-C-21'].shift(20)) &
    (SBIN5Min['SMA-C-10'].shift(21)<SBIN5Min['SMA-C-21'].shift(21)) &
    (SBIN5Min['SMA-C-10'].shift(22)<SBIN5Min['SMA-C-21'].shift(22)) &
    (SBIN5Min['SMA-C-10'].shift(23)<SBIN5Min['SMA-C-21'].shift(23)) &
    (SBIN5Min['SMA-C-10'].shift(24)<SBIN5Min['SMA-C-21'].shift(24)) &
    (SBIN5Min['SMA-C-10'].shift(25)<SBIN5Min['SMA-C-21'].shift(25)) &
    (SBIN5Min['SMA-C-10'].shift(26)<SBIN5Min['SMA-C-21'].shift(26)) &
    (SBIN5Min['SMA-C-150'].shift(20)>SBIN5Min['SMA-C-21'].shift(20)) &
    (SBIN5Min['SMA-C-150'].shift(21)>SBIN5Min['SMA-C-21'].shift(21)) &
    (SBIN5Min['SMA-C-150'].shift(22)>SBIN5Min['SMA-C-21'].shift(22)) &
    (SBIN5Min['SMA-C-150'].shift(23)>SBIN5Min['SMA-C-21'].shift(23)) &
    (SBIN5Min['SMA-C-150'].shift(24)>SBIN5Min['SMA-C-21'].shift(24)) &
    (SBIN5Min['SMA-C-150'].shift(25)>SBIN5Min['SMA-C-21'].shift(25)) &
    (SBIN5Min['SMA-C-150'].shift(26)>SBIN5Min['SMA-C-21'].shift(26)) 
 )
) &
 
               (SBIN5Min['SMA-C-10']<SBIN5Min['SMA-C-21']) &
#              (SBIN5Min['SMA-C-10'].shift(1)<SBIN5Min['SMA-C-21'].shift(1)) &
                (SBIN5Min['Indx']==0) 
                )
        ][['Date','Open','High','Low','Close','DayOpen','HA_Close', 'HA_Open',
       'HA_High', 'HA_Low','CDayHigh','CDayLow','SMA-C-21','SMA-C-10','SMA-C-21-1','SMA-C-10-1','PDayClose', 'PDayOpen']]
IntraDaySell['PPER']=round((IntraDaySell['PDayClose']-IntraDaySell['PDayOpen']+0.00001)/IntraDaySell['PDayOpen']*100,2)
IntraDaySell['SMADIFF']=round((IntraDaySell['SMA-C-10']-IntraDaySell['SMA-C-21']+0.00001)/IntraDaySell['SMA-C-21']*10000)









IntraDayBuy=SBIN5Min[
        (
                #( (SBIN5Min['Close']>SBIN5Min['SMA-C-21']) & (SBIN5Min['Open']<SBIN5Min['SMA-C-21'])) &
            (
                (
                    (SBIN5Min['Close']>SBIN5Min['SMA-C-21']) &
                    (SBIN5Min['SMA-C-10']>SBIN5Min['SMA-C-21']) &
                    (SBIN5Min['Close']>SBIN5Min['SMA-C-150']) 
#                    & ( (SBIN5Min['Close']>SBIN5Min['SMA-C-21']) & 
#                     (
#                             (SBIN5Min['Low']<SBIN5Min['SMA-C-10']) |
#                             (SBIN5Min['SMA-C-21'].shift(1)<SBIN5Min['SMA-C-10'].shift(1)) |
#                             (SBIN5Min['SMA-C-21'].shift(2)<SBIN5Min['SMA-C-10'].shift(2)) |
#                             (SBIN5Min['SMA-C-21'].shift(3)<SBIN5Min['SMA-C-10'].shift(3))
#                             
#                     )
#                )
                )
#            |
#                (
#                    (SBIN5Min['Close'].shift(1)>SBIN5Min['SMA-C-21'].shift(1)) &
#                    (SBIN5Min['SMA-C-10'].shift(1)>SBIN5Min['SMA-C-21'].shift(1)) &
#                    ( (SBIN5Min['Close'].shift(1)>SBIN5Min['SMA-C-21'].shift(1)) 
#                    & (SBIN5Min['Low'].shift(1)<SBIN5Min['SMA-C-10'].shift(1))) 
#                )
            ) &


(
 (
    (SBIN5Min['SMA-C-10'].shift(1)>SBIN5Min['SMA-C-21'].shift(1)) &
    (SBIN5Min['SMA-C-10'].shift(2)>SBIN5Min['SMA-C-21'].shift(2)) &
    (SBIN5Min['SMA-C-10'].shift(3)>SBIN5Min['SMA-C-21'].shift(3)) &
    (SBIN5Min['SMA-C-10'].shift(4)>SBIN5Min['SMA-C-21'].shift(4)) &
    (SBIN5Min['SMA-C-10'].shift(5)>SBIN5Min['SMA-C-21'].shift(5)) &
    (SBIN5Min['SMA-C-10'].shift(6)>SBIN5Min['SMA-C-21'].shift(6)) &
    (SBIN5Min['SMA-C-10'].shift(7)>SBIN5Min['SMA-C-21'].shift(7)) &
    (SBIN5Min['SMA-C-10'].shift(8)>SBIN5Min['SMA-C-21'].shift(8)) &
    (SBIN5Min['SMA-C-10'].shift(9)>SBIN5Min['SMA-C-21'].shift(9)) &
    (SBIN5Min['SMA-C-10'].shift(10)>SBIN5Min['SMA-C-21'].shift(10)) &
    (SBIN5Min['SMA-C-10'].shift(11)>SBIN5Min['SMA-C-21'].shift(11)) &
    (SBIN5Min['SMA-C-10'].shift(12)>SBIN5Min['SMA-C-21'].shift(12)) 
#    &(SBIN5Min['SMA-C-10'].shift(13)>SBIN5Min['SMA-C-21'].shift(13)) &
#    (SBIN5Min['SMA-C-10'].shift(14)>SBIN5Min['SMA-C-21'].shift(14)) &
#    (SBIN5Min['SMA-C-10'].shift(15)>SBIN5Min['SMA-C-21'].shift(15)) &
#    (SBIN5Min['SMA-C-10'].shift(16)>SBIN5Min['SMA-C-21'].shift(16)) &
#    (SBIN5Min['SMA-C-10'].shift(17)>SBIN5Min['SMA-C-21'].shift(17)) &
#    (SBIN5Min['SMA-C-10'].shift(18)>SBIN5Min['SMA-C-21'].shift(18)) &
#    (SBIN5Min['SMA-C-10'].shift(19)>SBIN5Min['SMA-C-21'].shift(19)) &
#    (SBIN5Min['SMA-C-10'].shift(20)>SBIN5Min['SMA-C-21'].shift(20)) &
#    (SBIN5Min['SMA-C-10'].shift(21)>SBIN5Min['SMA-C-21'].shift(21)) &
#    (SBIN5Min['SMA-C-10'].shift(22)>SBIN5Min['SMA-C-21'].shift(22)) &
#    (SBIN5Min['SMA-C-10'].shift(23)>SBIN5Min['SMA-C-21'].shift(23)) &
#    (SBIN5Min['SMA-C-10'].shift(24)>SBIN5Min['SMA-C-21'].shift(24)) &
#    (SBIN5Min['SMA-C-10'].shift(25)>SBIN5Min['SMA-C-21'].shift(25)) &
#    (SBIN5Min['SMA-C-10'].shift(26)>SBIN5Min['SMA-C-21'].shift(26))  &
#    (SBIN5Min['SMA-C-150'].shift(20)<SBIN5Min['SMA-C-21'].shift(20)) &
#    (SBIN5Min['SMA-C-150'].shift(21)<SBIN5Min['SMA-C-21'].shift(21)) &
#    (SBIN5Min['SMA-C-150'].shift(22)<SBIN5Min['SMA-C-21'].shift(22)) &
#    (SBIN5Min['SMA-C-150'].shift(23)<SBIN5Min['SMA-C-21'].shift(23)) &
#    (SBIN5Min['SMA-C-150'].shift(24)<SBIN5Min['SMA-C-21'].shift(24)) &
#    (SBIN5Min['SMA-C-150'].shift(25)<SBIN5Min['SMA-C-21'].shift(25)) &
#    (SBIN5Min['SMA-C-150'].shift(26)<SBIN5Min['SMA-C-21'].shift(26)) 

 )
# |
# (
#    (SBIN5Min['SMA-C-10'].shift(1)<SBIN5Min['SMA-C-21'].shift(1)) &
#    (SBIN5Min['SMA-C-10'].shift(2)<SBIN5Min['SMA-C-21'].shift(2)) &
#    (SBIN5Min['SMA-C-10'].shift(3)<SBIN5Min['SMA-C-21'].shift(3)) &
#    (SBIN5Min['SMA-C-10'].shift(4)<SBIN5Min['SMA-C-21'].shift(4)) &
#    (SBIN5Min['SMA-C-10'].shift(5)<SBIN5Min['SMA-C-21'].shift(5)) &
#    (SBIN5Min['SMA-C-10'].shift(6)<SBIN5Min['SMA-C-21'].shift(6)) &
#    (SBIN5Min['SMA-C-10'].shift(7)<SBIN5Min['SMA-C-21'].shift(7)) &
#    (SBIN5Min['SMA-C-10'].shift(8)<SBIN5Min['SMA-C-21'].shift(8)) &
#    (SBIN5Min['SMA-C-10'].shift(9)<SBIN5Min['SMA-C-21'].shift(9)) &
#    (SBIN5Min['SMA-C-10'].shift(10)<SBIN5Min['SMA-C-21'].shift(10)) &
#    (SBIN5Min['SMA-C-10'].shift(11)<SBIN5Min['SMA-C-21'].shift(11)) &
#    (SBIN5Min['SMA-C-10'].shift(12)<SBIN5Min['SMA-C-21'].shift(12)) &
#    (SBIN5Min['SMA-C-10'].shift(13)<SBIN5Min['SMA-C-21'].shift(13)) &
#    (SBIN5Min['SMA-C-10'].shift(14)<SBIN5Min['SMA-C-21'].shift(14)) &
#    (SBIN5Min['SMA-C-10'].shift(15)<SBIN5Min['SMA-C-21'].shift(15)) &
#    (SBIN5Min['SMA-C-10'].shift(16)<SBIN5Min['SMA-C-21'].shift(16)) &
#    (SBIN5Min['SMA-C-10'].shift(17)<SBIN5Min['SMA-C-21'].shift(17)) &
#    (SBIN5Min['SMA-C-10'].shift(18)<SBIN5Min['SMA-C-21'].shift(18)) &
#    (SBIN5Min['SMA-C-10'].shift(19)<SBIN5Min['SMA-C-21'].shift(19)) &
#    (SBIN5Min['SMA-C-10'].shift(20)<SBIN5Min['SMA-C-21'].shift(20)) &
#    (SBIN5Min['SMA-C-10'].shift(21)<SBIN5Min['SMA-C-21'].shift(21)) &
#    (SBIN5Min['SMA-C-10'].shift(22)<SBIN5Min['SMA-C-21'].shift(22)) &
#    (SBIN5Min['SMA-C-10'].shift(23)<SBIN5Min['SMA-C-21'].shift(23)) &
#    (SBIN5Min['SMA-C-10'].shift(24)<SBIN5Min['SMA-C-21'].shift(24)) &
#    (SBIN5Min['SMA-C-10'].shift(25)<SBIN5Min['SMA-C-21'].shift(25)) &
#    (SBIN5Min['SMA-C-10'].shift(26)<SBIN5Min['SMA-C-21'].shift(26)) 
# )
) &
 
               (SBIN5Min['SMA-C-10']>SBIN5Min['SMA-C-21']) &
               (SBIN5Min['RSI14']>=67) & 
               (SBIN5Min['RSI14'].shift(1)<SBIN5Min['RSI14']) & 
               #(SBIN5Min['RSI14'].shift(2)<SBIN5Min['RSI14'].shift(1)) &
#              (SBIN5Min['SMA-C-10'].shift(1)>SBIN5Min['SMA-C-21'].shift(1)) &
                (SBIN5Min['Indx']<=7) 
                )
        ][['Date','Open','High','Low','Close','DayOpen','HA_Close', 'HA_Open','RSI14',
       'HA_High', 'HA_Low','CDayHigh','CDayLow','SMA-C-21','SMA-C-10','SMA-C-21-1','SMA-C-10-1','PDayClose', 'PDayOpen']]
IntraDayBuy['PPER']=round((IntraDayBuy['PDayClose']-IntraDayBuy['PDayOpen']+0.00001)/IntraDayBuy['PDayOpen']*100,2)
IntraDayBuy['SMADIFF']=round((IntraDayBuy['SMA-C-10']-IntraDayBuy['SMA-C-21']+0.00001)/IntraDayBuy['SMA-C-21']*10000)



