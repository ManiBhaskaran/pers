# -*- coding: utf-8 -*-
"""
Created on Tue Feb 11 22:28:24 2020

@author: lalitha
"""

import pandas as pd
import json
import jhtalib as ta
from candlestick import candlestick
DIRNIFTY="C:\ReadMoneycontrol\Mani 2.0"
DIRFO="C:\ReadMoneycontrol\Mani 2.0\\2"
DIRNIFTYStockList="C:\ReadMoneycontrol\Mani 2.0\StockList.txt"
DIRFOStockList="C:\ReadMoneycontrol\Mani 2.0\StockList-New.txt"
DIRNIFTYStockListID="C:\ReadMoneycontrol\Mani 2.0\StockListIDOriginal.txt"
DIRFOStockListID="C:\ReadMoneycontrol\Mani 2.0\StockListID-NEW.csv"
def isPeak(arr, n, num, i, j): 

	# If num is smaller than the element 
	# on the left (if exists) 
	if (i >= 0 and arr[i] > num): 
		return False

	# If num is smaller than the element 
	# on the right (if exists) 
	if (j < n and arr[j] > num): 
		return False
	return True

# Function that returns true if num is 
# smaller than both arr[i] and arr[j] 
def isTrough(arr, n, num, i, j): 

	# If num is greater than the element 
	# on the left (if exists) 
	if (i >= 0 and arr[i] < num): 
		return False

	# If num is greater than the element 
	# on the right (if exists) 
	if (j < n and arr[j] < num): 
		return False
	return True

def printPeaksTroughs(arr, n): 

	print("Peaks : ", end = "") 

	# For every element 
	for i in range(n): 

		# If the current element is a peak 
		if (isPeak(arr, n, arr[i], i - 1, i + 1)): 
			print(arr[i], end = " ") 
	print() 

	print("Troughs : ", end = "") 

	# For every element 
	for i in range(n): 

		# If the current element is a trough 
		if (isTrough(arr, n, arr[i], i - 1, i + 1)): 
			print(arr[i], end = " ") 

#def getTarget(x,A,B):    
#    return round((x[A]-x[B])/x[B]*100,2)
StockList=pd.read_csv(DIRNIFTYStockList)
#if(False):
p=10000 #####NEED TO CHANGE TO -1
while(p<len(StockList)-1):
    p=p+1
    #print(StockList.iloc[p]['Symbol'])
    #iPercentage=iP
    #ioffset=iO
    #y=1
    #Symbol="ZEEL"
    #DataFrameCollection=Min5DF
    #RealTime=False
    Symbol="YESBANK"
    Symbol=StockList.iloc[p]['Symbol']
    
    
    Data1=pd.read_csv(r"C:\ReadMoneycontrol\Mani 2.0\Data\\"+Symbol+"-15minute.csv")
    Data1.columns=['Date', 'Open', 'High', 'Low', 'Close', 'V']
    n=len(Data1)
    HighV=[]
    HighSt={}
    LowV=[]
    LowSt={}
    arr=list(Data1['High'])
    aLow=list(Data1['Low'])
    for i in range(n): 
        if(isPeak(arr, n, arr[i], i - 3, i + 3)):
            HighSt={}        
            H,L,C,O=list(Data1.iloc[i][['High',"Low","Close","Open"]])
            HighSt['Stock']=Symbol
            HighSt['Date']=Data1.iloc[i].Date
            HighSt['Type']="High"
            HighSt['CHigh']=H
            HighSt['CLow']=L            
            HighSt['HighIdx']=i
            HighSt['HLC']=round((H-C)/C*100,2)
            HighSt['HL']=round((H-L)/L*100,2)
            HighSt['OC']=round((O-C)/C*100,2)
            HighSt['G']=O>C
            
            k=0
            
            while(k<=12):
                k=k+4
                k1=str(k)
                PH,PL,PC,PO=list(Data1.iloc[i-k][['High',"Low","Close","Open"]])
                if(i+k+1<=n-k):
                    FH,FL,FC,FO=list(Data1.iloc[i+k][['High',"Low","Close","Open"]])
                else:
                    FH,FL,FC,FO=list(Data1.iloc[i][['High',"Low","Close","Open"]])
                HighSt['PHigh'+k1]=PH
                HighSt['PLow'+k1]=PL
                HighSt['FHigh'+k1]=FH
                HighSt['FLow'+k1]=FL
                HighSt['PHLC'+k1]=round((PH-PC)/PC*100,2)
                HighSt['PHL'+k1]=round((PH-PL)/PL*100,2)
                HighSt['POC'+k1]=round((PO-PC)/PC*100,2)
                HighSt['PG'+k1]=PO>PC
                HighSt['FHLC'+k1]=round((FH-FC)/FC*100,2)
                HighSt['FHL'+k1]=round((FH-FL)/FL*100,2)
                HighSt['FOC'+k1]=round((FO-FC)/FC*100,2)
                HighSt['FG'+k1]=FO>FC
                HighSt['CPH'+k1]=round((HighSt['CHigh']-HighSt['PLow'+k1]+0.0001)/HighSt['PLow'+k1]*100,2)       
                HighSt['CFH'+k1]=round((HighSt['CHigh']-HighSt['FLow'+k1]+0.0001)/HighSt['FLow'+k1]*100,2)                   
            HighV.append(HighSt)
        if(isTrough(aLow, n, aLow[i], i - 3, i + 3)):
            LowSt={}        
            H,L,C,O=list(Data1.iloc[i][['High',"Low","Close","Open"]])
            LowSt['Stock']=Symbol
            LowSt['Date']=Data1.iloc[i].Date
            LowSt['Type']="High"
            LowSt['CHigh']=H
            LowSt['CLow']=L            
            LowSt['HighIdx']=i
            LowSt['HLC']=round((H-C)/C*100,2)
            LowSt['HL']=round((H-L)/L*100,2)
            LowSt['OC']=round((O-C)/C*100,2)
            LowSt['G']=O>C
            
            k=0
            
            while(k<=12):
                k=k+4
                k1=str(k)
                PH,PL,PC,PO=list(Data1.iloc[i-k][['High',"Low","Close","Open"]])
                if(i+k+1<=n-k):
                    FH,FL,FC,FO=list(Data1.iloc[i+k][['High',"Low","Close","Open"]])
                else:
                    FH,FL,FC,FO=list(Data1.iloc[i][['High',"Low","Close","Open"]])
                LowSt['PHigh'+k1]=PH
                LowSt['PLow'+k1]=PL
                LowSt['FHigh'+k1]=FH
                LowSt['FLow'+k1]=FL
                LowSt['PHLC'+k1]=round((PH-PC)/PC*100,2)
                LowSt['PHL'+k1]=round((PH-PL)/PL*100,2)
                LowSt['POC'+k1]=round((PO-PC)/PC*100,2)
                LowSt['PG'+k1]=PO>PC
                LowSt['FHLC'+k1]=round((FH-FC)/FC*100,2)
                LowSt['FHL'+k1]=round((FH-FL)/FL*100,2)
                LowSt['FOC'+k1]=round((FO-FC)/FC*100,2)
                LowSt['FG'+k1]=FO>FC
                LowSt['CPH'+k1]=round((LowSt['CLow']-LowSt['PHigh'+k1]+0.0001)/LowSt['PHigh'+k1]*100,2)       
                LowSt['CFH'+k1]=round((LowSt['CLow']-LowSt['FHigh'+k1]+0.0001)/LowSt['FHigh'+k1]*100,2)                   
            LowV.append(LowSt)
    ResultHDF=pd.DataFrame(HighV)
    ResultHDF['HighM']=round(ResultHDF['CHigh']/10,1)*10
    ResultLDF=pd.DataFrame(LowV)
    ResultLDF['LowM']=round(ResultLDF['CLow']/10,1)*10
    T1=ResultLDF[ResultLDF['CPH8']<-3]
    
    T1=ResultHDF[ResultHDF['CPH8']>2]
    T1[['LowM','CLow']]
    
def getClassicPivot(Data,Prefix):
    
    Data[Prefix+"IPivot"]=candlestick.MaRound((Data['Close'].shift(1)+Data['High'].shift(1)+Data['Low'].shift(1))/3)
    Data[Prefix+"H4"]=candlestick.MaRound(Data[Prefix+"IPivot"]+((Data['High'].shift(1)-Data['Low'].shift(1))*3))   
    Data[Prefix+"H3A"]=candlestick.MaRound(Data[Prefix+"IPivot"]+((Data['High'].shift(1)-Data['Low'].shift(1))*2.5))   
    Data[Prefix+"H3"]=candlestick.MaRound(Data[Prefix+"IPivot"]+((Data['High'].shift(1)-Data['Low'].shift(1))*2))   
    Data[Prefix+"H2A"]=candlestick.MaRound(Data[Prefix+"IPivot"]+((Data['High'].shift(1)-Data['Low'].shift(1))*1.5))   
    Data[Prefix+"H2"]=candlestick.MaRound(Data[Prefix+"IPivot"]+((Data['High'].shift(1)-Data['Low'].shift(1))))      
    Data[Prefix+"H1"]=candlestick.MaRound(2*Data[Prefix+"IPivot"]-Data["Low"].shift(1))    
    Data[Prefix+"IPivot-H"]=round((Data[Prefix+"IPivot"]+Data[Prefix+"H1"])/2,2)
    Data[Prefix+"L4"]=candlestick.MaRound(Data[Prefix+"IPivot"]-((Data['High'].shift(1)-Data['Low'].shift(1))*3))
    Data[Prefix+"L3A"]=candlestick.MaRound(Data[Prefix+"IPivot"]-((Data['High'].shift(1)-Data['Low'].shift(1))*2.5))
    Data[Prefix+"L3"]=candlestick.MaRound(Data[Prefix+"IPivot"]-((Data['High'].shift(1)-Data['Low'].shift(1))*2))
    Data[Prefix+"L2A"]=candlestick.MaRound(Data[Prefix+"IPivot"]-((Data['High'].shift(1)-Data['Low'].shift(1))*1.5))   
    Data[Prefix+"L2"]=candlestick.MaRound(Data[Prefix+"IPivot"]-((Data['High'].shift(1)-Data['Low'].shift(1))))      
    Data[Prefix+"L1"]=candlestick.MaRound(2*Data[Prefix+"IPivot"]-Data["High"].shift(1))        
    Data[Prefix+"IPivot-L"]=round((Data[Prefix+"IPivot"]+Data[Prefix+"L1"])/2,2)
    Data[Prefix+'HL']=Data['High'].shift(1)-Data['Low'].shift(1)
    Data[Prefix+'PDayLow']=Data['Low'].shift(1)
    Data[Prefix+'PDayHigh']=Data['High'].shift(1)
    Data[Prefix+'PDayClose']=Data['Close'].shift(1)
    Data[Prefix+'PDayOpen']=Data['Open'].shift(1)
    Data[Prefix+'PDayV']=Data['V'].shift(1)
    return Data

def getFiboPivot(Data,Prefix):
    Data[Prefix+"IPivot"]=candlestick.MaRound((Data['Close'].shift(1)+Data['High'].shift(1)+Data['Low'].shift(1))/3)
    Data[Prefix+"H3"]=candlestick.MaRound(Data[Prefix+"IPivot"]+((Data["High"].shift(1)-Data["Low"].shift(1))*.1))
    Data[Prefix+"H2A"]=candlestick.MaRound(Data[Prefix+"IPivot"]+((Data["High"].shift(1)-Data["Low"].shift(1))*.786))
    Data[Prefix+"H2"]=candlestick.MaRound(Data[Prefix+"IPivot"]+((Data["High"].shift(1)-Data["Low"].shift(1))*.618))
    Data[Prefix+"H1A"]=candlestick.MaRound(Data[Prefix+"IPivot"]+((Data["High"].shift(1)-Data["Low"].shift(1))*.500))
    Data[Prefix+"H1"]=candlestick.MaRound(Data[Prefix+"IPivot"]+((Data["High"].shift(1)-Data["Low"].shift(1))*.382))
    Data[Prefix+"IPivot-H"]=candlestick.MaRound(Data[Prefix+"IPivot"]+((Data["High"].shift(1)-Data["Low"].shift(1))*.286))
    Data[Prefix+"IPivot-L"]=candlestick.MaRound(Data[Prefix+"IPivot"]-((Data["High"].shift(1)-Data["Low"].shift(1))*.286))
    Data[Prefix+"L1"]=candlestick.MaRound(Data[Prefix+"IPivot"]-((Data["High"].shift(1)-Data["Low"].shift(1))*.382))
    Data[Prefix+"L1A"]=candlestick.MaRound(Data[Prefix+"IPivot"]-((Data["High"].shift(1)-Data["Low"].shift(1))*.500))
    Data[Prefix+"L2"]=candlestick.MaRound(Data[Prefix+"IPivot"]-((Data["High"].shift(1)-Data["Low"].shift(1))*.618))
    Data[Prefix+"L2A"]=candlestick.MaRound(Data[Prefix+"IPivot"]-((Data["High"].shift(1)-Data["Low"].shift(1))*.786))
    Data[Prefix+"L3"]=candlestick.MaRound(Data[Prefix+"IPivot"]-((Data["High"].shift(1)-Data["Low"].shift(1))*.1))
    return Data

#x=DayData2.iloc[-9]
def CheckMatchingPivot(x):
    C=['IPivot','H4','H3','H2','H1','L4','L3','L2','L1']
    F=['IPivot','H3','H2A','H2','H1A','H1','IPivot-H','IPivot-L','L1','L1A','L2','L2A','L3']
    #F=['IPivot','H3','H2','H1','L1','L2','L3']
    Pairs=""
    First=True
    ar=[]
    Middle=["-M-","-W-","-D-"]
    Perc=[.3,.3,.3]
    for M in Middle:
        for CD in C:
            FValue=x["C"+M+CD]
            #if(FValue)
            for M1 in Middle:
                for FD in F:
                    SValue=x["F"+M1+FD]
                    if((M1!=M) & (FD!="IPivot")):                    
                        if(FindDiff(FValue,SValue,Perc[Middle.index(M1)]/100)):
                            if(First==False):
                                Pairs=Pairs+"--"
                            S=round((SValue-FValue)/FValue*10000)
                            Pairs=Pairs+"(C"+M+CD+"["+str(FValue)+"],"+"F"+M1+FD+"["+str(SValue)+"]**"+str(S)+")"
                            First=False
                            ar.append("C"+M+CD+" ("+str(FValue)+")")
                            ar.append("F"+M1+FD+" ("+str(SValue)+")")
    
    CFS=['A0','A236','A382','A500','A618','A786','A1000','A1236','A1382','A1500','A1618','A1786','Z236','Z382','Z500','Z618','Z786','Z1000','Z1236','Z1382','Z1500','Z1618','Z1786']
    #F=['IPivot','H3','H2A','H2','H1A','H1','IPivot-H','IPivot-L','L1','L1A','L2','L2A','L3']
    FFS=['A0','A236','A382','A500','A618','A786','A1000','A1236','A1382','A1500','A1618','A1786','Z236','Z382','Z500','Z618','Z786','Z1000','Z1236','Z1382','Z1500','Z1618','Z1786']

    Middle=["-M-","-W-"]
    Middle1=["-D-"]
    #Perc=[.3,.3,.3]
    for M in Middle:
        for CD in CFS:
            FValue=x["FS"+M+CD]
            for M1 in Middle1:
                for FD in FFS:
                    SValue=x["FS"+M1+FD]
                    if((M1!=M) & (FD!="IPivot111")):                    
                        if(FindDiff(FValue,SValue,Perc[Middle1.index(M1)]/100)):
                            if(First==False):
                                Pairs=Pairs+"--"
                            S=round((SValue-FValue)/FValue*10000)
                            Pairs=Pairs+"(FS"+M+CD+"["+str(FValue)+"],"+"FS"+M1+FD+"["+str(SValue)+"]**"+str(S)+")"
                            First=False
                            ar.append("FS"+M+CD+" ("+str(FValue)+")")
                            ar.append("FS"+M1+FD+" ("+str(SValue)+")")

    #CFS=['A0','A236','A382','A500','A618','A786','A1000','A1236','A1382','A1500','A1618','A1786','Z236','Z382','Z500','Z618','Z786','Z1000','Z1236','Z1382','Z1500','Z1618','Z1786']
    #F=['IPivot','H3','H2A','H2','H1A','H1','IPivot-H','IPivot-L','L1','L1A','L2','L2A','L3']
    #FFS=['A0','A236','A382','A500','A618','A786','A1000','A1236','A1382','A1500','A1618','A1786','Z236','Z382','Z500','Z618','Z786','Z1000','Z1236','Z1382','Z1500','Z1618','Z1786']

    Middle=["-M-","-W-","-D-"]
    #Middle=["-M-","-W-"]
    #Middle1=["-D-"]
    #Perc=[.3,.3,.3]
    for M in Middle:
        for CD in C:
            FValue=x["C"+M+CD]
            for M1 in Middle1:
                for FD in FFS:
                    SValue=x["FS"+M1+FD]
                    if((M1!=M) & (FD!="IPivot111")):                    
                        if(FindDiff(FValue,SValue,Perc[Middle.index(M1)]/100)):
                            if(First==False):
                                Pairs=Pairs+"--"
                            S=round((SValue-FValue)/FValue*10000)
                            Pairs=Pairs+"(C"+M+CD+"["+str(FValue)+"],"+"FS"+M1+FD+"["+str(SValue)+"]**"+str(S)+")"
                            First=False
                            ar.append("C"+M+CD+" ("+str(FValue)+")")
                            ar.append("FS"+M1+FD+" ("+str(SValue)+")")

    for M in Middle:
        for CD in F:
            FValue=x["F"+M+CD]
            for M1 in Middle1:
                for FD in FFS:
                    SValue=x["FS"+M1+FD]
                    if((M1!=M) & (FD!="IPivot111")):                    
                        if(FindDiff(FValue,SValue,Perc[Middle.index(M1)]/100)):
                            if(First==False):
                                Pairs=Pairs+"--"
                            S=round((SValue-FValue)/FValue*10000)
                            Pairs=Pairs+"(F"+M+CD+"["+str(FValue)+"],"+"FS"+M1+FD+"["+str(SValue)+"]**"+str(S)+")"
                            First=False
                            ar.append("F"+M+CD+" ("+str(FValue)+")")
                            ar.append("FS"+M1+FD+" ("+str(SValue)+")")
    
    b={}
    b['T']=ar                        
    df=pd.DataFrame(b).reset_index()
    #T1=
    t=df[df.groupby(['T'])['index'].transform('count') > 1].groupby('T').count().reset_index().sort_values('index',ascending=False).to_json(orient='values')+Pairs
    #T=df[df.groupby(['T'])['index'].transform('count') > 1].groupby('T').count().reset_index()        
    return df[df.groupby(['T'])['index'].transform('count') > 1].groupby('T').count().reset_index().to_json(orient='values')+Pairs

def CheckMatchingFib(x):
    C=['A0','A236','A382','A500','A618','A786','A1000','A1236','A1382','A1500','A1618','A1786','Z236','Z382','Z500','Z618','Z786','Z1000','Z1236','Z1382','Z1500','Z1618','Z1786']
    #F=['IPivot','H3','H2A','H2','H1A','H1','IPivot-H','IPivot-L','L1','L1A','L2','L2A','L3']
    F=['A0','A236','A382','A500','A618','A786','A1000','A1236','A1382','A1500','A1618','A1786','Z236','Z382','Z500','Z618','Z786','Z1000','Z1236','Z1382','Z1500','Z1618','Z1786']
    #F=['IPivot','H3','H2','H1','L1','L2','L3']
    Pairs=""
    First=True
    ar=[]
    Middle=["-M-","-W-"]
    Middle1=["-D-"]
    Perc=[.3,.3,.3]
    for M in Middle:
        for CD in C:
            FValue=x["FS"+M+CD]
            for M1 in Middle1:
                for FD in F:
                    SValue=x["FS"+M1+FD]
                    if((M1!=M) & (FD!="IPivot111")):                    
                        if(FindDiff(FValue,SValue,Perc[Middle1.index(M1)]/100)):
                            if(First==False):
                                Pairs=Pairs+"--"
                            S=round((SValue-FValue)/FValue*10000)
                            Pairs=Pairs+"(FS"+M+CD+"["+str(FValue)+"],"+"FS"+M1+FD+"["+str(SValue)+"]**"+str(S)+")"
                            First=False
                            ar.append("FS"+M+CD+" ("+str(FValue)+")")
                            ar.append("FS"+M1+FD+" ("+str(SValue)+")")
    b={}
    b['T']=ar                        
    df=pd.DataFrame(b).reset_index()
    #T=df[df.groupby(['T'])['index'].transform('count') > 1].groupby('T').count().reset_index()        
    return df[df.groupby(['T'])['index'].transform('count') > 1].groupby('T').count().reset_index().to_json(orient='values')+Pairs


def FindDiff(A,B,t):
#    A=321
#    B=325
#    t=1/100
    tl=candlestick.MaRound(A*t)
    #print(tl)
    if((B+tl)>A>(B-tl)):
        return True
    #    print(True)
    else:
        return False
     #   print(False)
    
def CheckLatest():
    p=-1 #####NEED TO CHANGE TO -1
    First=True
    while(p<len(StockList)-1):
        p=p+1
        #print(StockList.iloc[p]['Symbol'])
        #iPercentage=iP
        #ioffset=iO
        #y=1
        #Symbol="ZEEL"
        #DataFrameCollection=Min5DF
        #RealTime=False
        
        Symbol=StockList.iloc[p]['Symbol']
        
        Symbol="TCS"
        Data1=pd.read_csv(r"C:\ReadMoneycontrol\Mani 2.0\Data\\"+Symbol+"-5minute.csv")
        Data1=Data1.sort_values(['Date'],ascending=True)
        DayData1=pd.read_csv(r"C:\ReadMoneycontrol\Mani 2.0\Data\\"+Symbol+"-day.csv")
        DayData1.columns=['Date', 'Open', 'High', 'Low', 'Close', 'V']
        Data1.columns=['Date', 'Open', 'High', 'Low', 'Close', 'V']
        
        
       
        
        #DayData1['CWeek']=pd.to_datetime(DayData1['Date']).dt.strftime("%Y-")
        DayData1['CWeek']=pd.to_datetime(DayData1['Date']).dt.strftime("%Y-")+pd.to_datetime(DayData1['Date']).dt.weekofyear.map("{:02}".format)
        DayData1['CMonth']=pd.to_datetime(DayData1['Date']).dt.strftime("%Y-%m")
        
        #WeekData['WHigh']=DayData1.groupby(['CWeek'])['High'].apply(lambda x: x.cummax())
        #WeekData['WLow']=DayData1.groupby(['CWeek'])['Low'].apply(lambda x: x.cummin())
        #WeekData['WWeek']=DayData1.groupby(['CWeek'])['CWeek'].apply(lambda x: x['CWeek'].iloc[0])
        #Week=pd.DataFrame(DayData1.groupby(['CWeek']).apply(lambda x: x['CWeek'].iloc[0]))
        #WeekData['WWeek']=list(DayData1['CWeek'].unique())
          #SBIN5Min['COpen']=
        WeekDataDate=pd.DataFrame(DayData1.groupby(['CWeek']).apply(lambda x: x['CWeek'].iloc[0]))
        WeekDataDate.reset_index(inplace=True,drop=True)
        WeekDataDate.columns=['CWeek']        
        WeekDataO=pd.DataFrame(DayData1.groupby(['CWeek']).apply(lambda x: x['Open'].iloc[0]))
        WeekDataO.columns=['Open']
        WeekDataC=pd.DataFrame(DayData1.groupby(['CWeek']).apply(lambda x: x['Close'].iloc[-1]))
        WeekDataC.columns=['Close']
        WeekDataH=pd.DataFrame(DayData1.groupby(['CWeek']).apply(lambda x: x['High'].max()))
        WeekDataH.columns=['High']
        WeekDataL=pd.DataFrame(DayData1.groupby(['CWeek']).apply(lambda x: x['Low'].min()))
        WeekDataL.columns=['Low']
        WeekDataV=pd.DataFrame(DayData1.groupby(['CWeek']).apply(lambda x: x['V'].sum()))
        WeekDataV.columns=['V']
        

        WeekData=pd.merge(pd.merge(pd.merge(pd.merge(pd.merge(WeekDataDate,WeekDataO,on=['CWeek']),WeekDataH,on=['CWeek']),WeekDataL,on=['CWeek']),WeekDataC,on=['CWeek']),WeekDataV,on=['CWeek'])
        
        #WeekData.columns=['CWeek', 'WOpen', 'WHigh', 'WLow', 'WClose', 'WV']
        
        MonthDataDate=pd.DataFrame(DayData1.groupby(['CMonth']).apply(lambda x: x['CMonth'].iloc[0]))
        MonthDataDate.reset_index(inplace=True,drop=True)
        MonthDataDate.columns=['CMonth']
        MonthDataO=pd.DataFrame(DayData1.groupby(['CMonth']).apply(lambda x: x['Open'].iloc[0]))
        MonthDataO.columns=['Open']
        MonthDataC=pd.DataFrame(DayData1.groupby(['CMonth']).apply(lambda x: x['Close'].iloc[-1]))
        MonthDataC.columns=['Close']
        MonthDataH=pd.DataFrame(DayData1.groupby(['CMonth']).apply(lambda x: x['High'].max()))
        MonthDataH.columns=['High']
        MonthDataL=pd.DataFrame(DayData1.groupby(['CMonth']).apply(lambda x: x['Low'].min()))
        MonthDataL.columns=['Low']
        MonthDataV=pd.DataFrame(DayData1.groupby(['CMonth']).apply(lambda x: x['V'].sum()))
        MonthDataV.columns=['V']
        MonthData=pd.merge(pd.merge(pd.merge(pd.merge(pd.merge(MonthDataDate,MonthDataO,on=['CMonth']),MonthDataH,on=['CMonth']),MonthDataL,on=['CMonth']),MonthDataC,on=['CMonth']),MonthDataV,on=['CMonth'])
        
        
        DayData1['CDATE']=pd.to_datetime(DayData1['Date']).dt.strftime("%Y-%b-%d")  
        DayData1=getClassicPivot(DayData1,"C-D-")
        DayData1=getFiboPivot(DayData1,"F-D-")
        DayData1=candlestick.AppendPivotV2(DayData1,"FS-D-")
        
        WeekData=getClassicPivot(WeekData,"C-W-")
        WeekData=getFiboPivot(WeekData,"F-W-")
        WeekData=candlestick.AppendPivotV2(WeekData,"FS-W-")
        MonthData=getClassicPivot(MonthData,"C-M-")
        MonthData=getFiboPivot(MonthData,"F-M-")
        MonthData=candlestick.AppendPivotV2(MonthData,"FS-M-")
        WeekData.rename(columns={'Open': 'WOpen', 'High': 'WHigh','Low': 'WLow', 'Close': 'WClose', 'V': 'WV'}, inplace=True)
        MonthData.rename(columns={'Open': 'MOpen', 'High': 'MHigh','Low': 'MLow', 'Close': 'MClose', 'V': 'MV'}, inplace=True)        
        
        DayData2=pd.merge(pd.merge(DayData1,WeekData,on="CWeek"),MonthData,on="CMonth")
        #WeekData.drop(['columnheading1', 'columnheading2'], axis=1, inplace=True)
        DayData2['Matching']=DayData2.apply(lambda x: CheckMatchingPivot(x),axis=1) 
        #DayData2['Matching2']=DayData2.apply(lambda x: CheckMatchingFib(x),axis=1) 
        C=DayData2[['Date','Open','Low','High','Matching']]
#        C1=['IPivot','H4','H3A','H3','H2A','H2','H1','IPivot-H','L4','L3A','L3','L2A','L2','L1','IPivot-L']
#
#        F1=['IPivot','H3','H2A','H2','H1A','H1','IPivot-H','IPivot-L','L1','L1A','L2','L2A','L3']
#        
#        C=['IPivot','H4','H3','H2','H1','L4','L3','L2','L1']
#        F=['IPivot','H3','H2A','H2','H1A','H1','IPivot-H','IPivot-L','L1','L1A','L2','L2A','L3']
        
        
        #Data1.columns=['Date', 'Open', 'High', 'Low', 'Close', 'V']
        
        DayData2=DayData1[['Date','CDATE','C-D-PDayLow', 'C-D-PDayHigh','C-D-PDayClose', 'C-D-PDayOpen','C-D-PDayV']]
        Data1['Stock']=Symbol
        Data1=Data1[['Date','Stock', 'Open', 'High', 'Low', 'Close', 'V']]
        Data1.drop_duplicates(subset ="Date", keep = "first", inplace = True)         
        Data1['CDATE']=pd.to_datetime(Data1['Date']).dt.strftime("%Y-%b-%d")
        
        merged = Data1.merge(DayData1, on=['CDATE'], how='left')
        CustomMerge=merged[['Date_x','HL','PDayLow','PDayHigh','PDayClose','PDayOpen',
                        'H1','H2','H2A','H3','H3A','H4','IPivot-H',"IPivot",
                        "L1","L2",'L2A',"L3",'L3A',"L4",'IPivot-L']]
        CustomMerge.columns=['Date', 'HL', 'PDayLow','PDayHigh','PDayClose','PDayOpen',
                         'H1','H2','H2A','H3','H3A','H4','IPivot-H',"IPivot",
                        "L1","L2",'L2A',"L3",'L3A',"L4",'IPivot-L']
        
        Data1=Data1.merge(DayData2, on=['CDATE'], how='left')
        #Data1['C-D-PDayV']=Data1['C-D-PDayV']/1000000
        Data1['V']=Data1['V']/1000000
        Data1['V']=Data1['V']/1000
        #Data1[Data1['V']>Data1['C-D-PDayV']/1]
        
        #Data1['PivotC']=Data1.apply(lambda x: CheckPivotRange(x),axis=1)   
        #Data1['PivotV']=Data1.apply(lambda x: CheckPivotRangeV(x),axis=1)   
        Data1.reset_index(inplace=True,drop=True)
        Data1['RSI14']=ta.RSI(Data1,14)
        Data1['EMA-RSI-50']=Data1['RSI14'].ewm(span=50, adjust=False).mean()
        Data1['EMA-RSI-150']=Data1['RSI14'].ewm(span=150, adjust=False).mean()
        
        Data1['PHx4']=Data1['High'].shift(1).rolling(4).max()
        Data1['PHn4']=Data1['High'].shift(1).rolling(4).min()
        Data1['PLx4']=Data1['Low'].shift(1).rolling(4).max()            
        Data1['PLn4']=Data1['Low'].shift(1).rolling(4).min()            
        
        Data1['PHx8']=Data1['High'].shift(1).rolling(8).max()
        Data1['PHn8']=Data1['High'].shift(1).rolling(8).min()
        Data1['PLx8']=Data1['Low'].shift(1).rolling(8).max()            
        Data1['PLn8']=Data1['Low'].shift(1).rolling(8).min()            
        
        Data1['PHx12']=Data1['High'].shift(1).rolling(12).max()
        Data1['PHn12']=Data1['High'].shift(1).rolling(12).min()
        Data1['PLx12']=Data1['Low'].shift(1).rolling(12).max()            
        Data1['PLn12']=Data1['Low'].shift(1).rolling(12).min()            
        
        Data1['PHH4']=((Data1['High'].shift(1)>Data1['High'].shift(2)) & (Data1['High'].shift(2)>Data1['High'].shift(3)) & (Data1['High']>Data1['High'].shift(1)))
        Data1['PLL4']=((Data1['Low']>Data1['Low'].shift(1)) & (Data1['Low'].shift(1)>Data1['Low'].shift(2)) & (Data1['Low'].shift(2)>Data1['Low'].shift(3)))
        
        Data1['PHH8']=((Data1['High']>Data1['High'].shift(1)) & (Data1['High'].shift(1)>Data1['High'].shift(2)) & (Data1['High'].shift(2)>Data1['High'].shift(3)) 
                        & (Data1['High'].shift(3)>Data1['High'].shift(4)) & (Data1['High'].shift(4)>Data1['High'].shift(5)) & (Data1['High'].shift(5)>Data1['High'].shift(6))
                        )
        Data1['PLL8']=((Data1['Low']>Data1['Low'].shift(1)) & (Data1['Low'].shift(1)>Data1['Low'].shift(2)) & (Data1['Low'].shift(2)>Data1['Low'].shift(3))
                        & (Data1['Low'].shift(3)>Data1['Low'].shift(4)) & (Data1['Low'].shift(4)>Data1['Low'].shift(5)) & (Data1['Low'].shift(5)>Data1['Low'].shift(6))
                        )
        
        Data1['P-HH4']=((Data1['High'].shift(1)<Data1['High'].shift(2)) & (Data1['High'].shift(2)<Data1['High'].shift(3)) & (Data1['High']<Data1['High'].shift(1)))
        Data1['P-LL4']=((Data1['Low']<Data1['Low'].shift(1)) & (Data1['Low'].shift(1)<Data1['Low'].shift(2)) & (Data1['Low'].shift(2)<Data1['Low'].shift(3)))
        
        Data1['P-HH8']=((Data1['High']<Data1['High'].shift(1)) & (Data1['High'].shift(1)<Data1['High'].shift(2)) & (Data1['High'].shift(2)<Data1['High'].shift(3)) 
                        & (Data1['High'].shift(3)<Data1['High'].shift(4)) & (Data1['High'].shift(4)<Data1['High'].shift(5)) & (Data1['High'].shift(5)<Data1['High'].shift(6))
                        )
        Data1['P-LL8']=((Data1['Low']<Data1['Low'].shift(1)) & (Data1['Low'].shift(1)<Data1['Low'].shift(2)) & (Data1['Low'].shift(2)<Data1['Low'].shift(3))
                        & (Data1['Low'].shift(3)<Data1['Low'].shift(4)) & (Data1['Low'].shift(4)<Data1['Low'].shift(5)) & (Data1['Low'].shift(5)<Data1['Low'].shift(6))
                        )
        
        
#        Data1=candlestick.bearish_engulfing(Data1)
#        Data1=candlestick.bullish_engulfing(Data1)
#        Data1=candlestick.bullish_hanging_man(Data1)
#        Data1=candlestick.hanging_man(Data1)
        Data1['LowestLow']=(Data1['Low']==Data1['Low'].rolling(5).min())
        Data1['HighestHigh']=(Data1['High']==Data1['High'].rolling(5).max())
        #Data1=Data1.drop(["BearishHammer"],axis=1)
        #Data1=Data1.drop(["BullishHammer"],axis=1)
#        Data1=candlestick.hammer(Data1)
#        #mkhammer
#        Data1=candlestick.bearish_hammer(Data1)
#        Data1=candlestick.bullish_hammer(Data1)
        #a=Data1[Data1['BullishHammer']==True][['Date','PivotC','LowestLow','HighestHigh','P-HH4','PHLn4','PLHx4','Close','FHx4','FLn4']]
        #b=Data1[Data1['BearishHammer']==True][['Date','PivotC','LowestLow','HighestHigh','P-HH4','PHLn4','PLHx4','Close','FHx4','FLn4']]
        #Data1=Data1.sort_values('Date',ascending=True)  
        Data1=Data1.sort_values('Date',ascending=False)  
        
        Data1=candlestick.three_outside_up(Data1)
        Data1=candlestick.three_outside_down(Data1)
        
        Data1['FH1']=Data1['High'].shift(1)
        Data1['FL1']=Data1['Low'].shift(1)
        Data1['FHx4']=Data1['High'].shift(1).rolling(4).max()
        Data1['FHn4']=Data1['High'].shift(1).rolling(4).min()
        Data1['FLx4']=Data1['Low'].shift(1).rolling(4).max()            
        Data1['FLn4']=Data1['Low'].shift(1).rolling(4).min()            
        
        Data1['FHx8']=Data1['High'].shift(1).rolling(8).max()
        Data1['FHn8']=Data1['High'].shift(1).rolling(8).min()
        Data1['FLx8']=Data1['Low'].shift(1).rolling(8).max()            
        Data1['FLn8']=Data1['Low'].shift(1).rolling(8).min()            
        
        Data1['FHx12']=Data1['High'].shift(1).rolling(12).max()
        Data1['FHn12']=Data1['High'].shift(1).rolling(12).min()
        Data1['FLx12']=Data1['Low'].shift(1).rolling(12).max()            
        Data1['FLn12']=Data1['Low'].shift(1).rolling(12).min()            
        
        Data1['FHH4']=((Data1['High'].shift(1)>Data1['High'].shift(2)) & (Data1['High'].shift(2)>Data1['High'].shift(3)) & (Data1['High']>Data1['High'].shift(1)))
        Data1['FLL4']=((Data1['Low']>Data1['Low'].shift(1)) & (Data1['Low'].shift(1)>Data1['Low'].shift(2)) & (Data1['Low'].shift(2)>Data1['Low'].shift(3)))
        
        Data1=Data1.sort_values('Date',ascending=True)  
        Data1['Date']=pd.to_datetime(Data1['Date'])
        Data1['Indx']=((Data1['Date']-pd.to_datetime(pd.to_datetime(Data1['CDATE']).dt.strftime("%Y-%m-%d 09:15"))).dt.seconds/60/5).astype(int)
        
        
        
        #Data1['Peak4']=
#        a=Data1[((Data1['High']>Data1['PHx4']) & (Data1['High']>Data1['PHn4']) &
#                (Data1['High']>Data1['FHx4']) & (Data1['High']>Data1['FHn4'])
#                )]
        
        if(len(Data1)>0):
            if(First):            
                Final=Data1
            else:                
                Final=Final.append(Data1)
            First=False

if(False):
    Final["PHLn4"]=round((Final['High']-Final['PLn4'])/Final['PLn4']*100,2)
    #Data1["PHLn4"]=round((Data1['High']-Data1['PLn4'])/Data1['PLn4']*100,2)
    #Data1["PLHx4"]=round((Data1['PHx4']-Data1['Low'])/Data1['Low']*100,2)
    Final["PHLn4"]=round((Final['High']-Final['PLn4'])/Final['PLn4']*100,2)
    Final["PLLn4"]=round((Final['Low']-Final['PLn4'])/Final['PLn4']*100,2)
    Final["PHHx4"]=round((Final['High']-Final['PHx4'])/Final['PHx4']*100,2)
    Final["PLHx4"]=round((Final['PHx4']-Final['Low'])/Final['Low']*100,2)
    Final["PHHx8"]=round((Final['High']-Final['PHx8'])/Final['PHx8']*100,2)
    Final["PLHx8"]=round((Final['PHx8']-Final['Low'])/Final['Low']*100,2)
    Final["PHHx12"]=round((Final['High']-Final['PHx12'])/Final['PHx12']*100,2)
    Final["PLHx12"]=round((Final['PHx12']-Final['Low'])/Final['Low']*100,2)
    #Final["PHLn12"]=round((Final['High']-Final['PLn12'])/Final['PLn12']*100,2)
    
    Final["FHLn4"]=round((Final['High']-Final['FLn4'])/Final['FLn4']*100,2)
    #Data1["FHLn4"]=round((Data1['High']-Data1['FLn4'])/Data1['FLn4']*100,2)
    #Data1["FLHx4"]=round((Data1['FHx4']-Data1['Low'])/Data1['Low']*100,2)
    Final["FHLn4"]=round((Final['High']-Final['FLn4'])/Final['FLn4']*100,2)
    Final["FLLn4"]=round((Final['Low']-Final['FLn4'])/Final['FLn4']*100,2)
    Final["FHHx4"]=round((Final['High']-Final['FHx4'])/Final['FHx4']*100,2)
    Final["FLHx4"]=round((Final['FHx4']-Final['Low'])/Final['Low']*100,2)
    Final["FHHx8"]=round((Final['High']-Final['FHx8'])/Final['FHx8']*100,2)
    Final["FLHx8"]=round((Final['FHx8']-Final['Low'])/Final['Low']*100,2)
    Final["FHHx12"]=round((Final['High']-Final['FHx12'])/Final['FHx12']*100,2)
    
    Final["FLHx12"]=round((Final['FHx12']-Final['Low'])/Final['Low']*100,2)
    
    Final["FHLn12"]=round((Final['High']-Final['FLn12'])/Final['FLn12']*100,2)
    Final["PHLn12"]=round((Final['High']-Final['PLn12'])/Final['PLn12']*100,2)
    Final['FHLn12HH']=((Final['FHLn12']>Final['FHLn12'].shift(1)) & (Final['FHLn12']>Final['FHLn12'].shift(2)) & (Final['FHLn12']>Final['FHLn12'].shift(3)) )    

    Final["PLHn4"]=round((Final['PHx4']-Final['Low'])/Final['Low']*100,2)
    
    #Final['PivotV']=Final.apply(lambda x: CheckPivotRangeV(x),axis=1)   
    b=Final[(Final['PHH4']==Final['PLL4']) & (Final['PLL4']==True) & 
                    (Final['High']>Final['FH1']) & (Final['Low']>Final['FL1'])]
    C=b[['Date','Stock','Open','High','Low','Close','PivotC','PivotV','CDATE','PHLn4']]       
    a=C[(C['CDATE']=='2020-Feb-11') & (C['PHLn4']>2)] 
    
    b1=Final[(Final['PHH8']==Final['PLL8']) & (Final['PLL8']==True) & 
                    (Final['High']>Final['FH1']) & (Final['Low']>Final['FLn4'])]
    c1=b1[['Date','Stock','Open','High','Low','Close','PivotC','PivotV','CDATE','PHLn8']]       
    a1=c1[(c1['CDATE']=='2020-Feb-11') & (c1['PHLn8']>2)] 
    
    
    
    b2=Final[(Final['P-HH4']==Final['P-LL4']) & (Final['P-LL4']==True) & 
                    (Final['High']<Final['FH1']) & (Final['Low']<Final['FL1'])]
    c2=b2[['Date','Stock','Open','High','Low','Close','PivotC','PivotV','CDATE','PLHn4']]       
    
    a=Final[Final['BullishHammer']==True][['Date','Stock','CDATE','PivotC','LowestLow','HighestHigh',
           'PHH4','PLL4',
           'RSI14','P-HH4','P-LL4','PHLn4','PLLn4','PLHx4','PHHx4',
           'PHHx8','PLHx8','PHHx12','PLHx12','Close','FHx4','FLn4','FHx8','FLn8']]
    b=Final[Final['BearishHammer']==True][['Date','Stock','CDATE','PivotC','LowestLow','HighestHigh',
           'PHH4','PLL4',
           'RSI14','P-HH4','P-LL4','PHLn4','PLLn4','PLHx4','PHHx4','Close','FHx4','FLn4','FHx8','FLn8','FHx12','FLn12']]
        
        
    a=Final[(Final['BullishHammer']==True) & (Final['PLHx4']>1)]
    a2=a[(a['CDATE']=='2020-Feb-13') & (a['LowestLow']==True)] 
    b2=b[(b['CDATE']=='2020-Feb-13') & (b['HighestHigh']==True)] 
    
    a2=a[(a['CDATE']=='2020-Feb-10') ] 
    b2=b[(b['CDATE']=='2020-Feb-10') ] 
    Final['FHLn12HH']=((Final['FHLn12']>Final['FHLn12'].shift(1)) & (Final['FHLn12']>Final['FHLn12'].shift(2))
    & (Final['FHLn12']>Final['FHLn12'].shift(3)) 
    & (Final['FHLn12']>Final['FHLn12'].shift(4)))
    Final['PHLn12HH']=((Final['PHLn12']>Final['PHLn12'].shift(1)) & (Final['PHLn12']>Final['PHLn12'].shift(2))
    & (Final['PHLn12']>Final['PHLn12'].shift(3)) 
    & (Final['PHLn12']>Final['PHLn12'].shift(4)))
    
    Final['FLHx12LL']=((Final['FLHx12']<Final['FLHx12'].shift(1)) & (Final['FLHx12']<Final['FLHx12'].shift(2))
    & (Final['FLHx12']<Final['FLHx12'].shift(3)) 
    & (Final['FLHx12']<Final['FLHx12'].shift(4)))
    Final['PLHx12LL']=((Final['PLHx12']<Final['PLHx12'].shift(1)) & (Final['PLHx12']<Final['PLHx12'].shift(2))
    & (Final['PLHx12']<Final['PLHx12'].shift(3)) 
    & (Final['PLHx12']<Final['PLHx12'].shift(4)))
    
    #& (Final['FHLn12']>Final['FHLn12'].shift(5)))
    C=Final[(Final['CDATE']=='2020-Feb-03') ][['Date','FHLn12','PHLn12','FHLn12HH','PHLn12HH']]
    
    HighList=Final[(Final['FHLn12']>2) & (Final['PHLn12']>2) &
          (Final['PHLn12HH']==True) & (Final['FHLn12HH']==True)]['High']
    
    HighList=Final[(Final['FHLn12']>2) & (Final['PHLn12']>2) &
          (Final['PHLn12HH']==True) & (Final['FHLn12HH']==True)]['High']
    
    Final[(Final['FHLn12']>2) & (Final['PHLn12']>2) &
          (Final['PHLn12HH']==True) & (Final['FHLn12HH']==True)][['Date','FHLn12','PHLn12','FHLn12HH','PHLn12HH']]
    
    Final=pd.read_csv(r"C:\ReadMoneycontrol\Mani 2.0\GapUpStrategy\Report.csv")
    Final.to_csv("C:\ReadMoneycontrol\Mani 2.0\GapUpStrategy\Report.csv",sep=',',encoding='utf-8',index=False)
    #& (C['PHLn4']>2)] 


#& (C["PivotC"]!="0")]
                #ConsolidatedFilteredStock=ConsolidatedFilteredStock.append(FilteredStock)
def CheckPivotRange(x):
    H=x['High']
    L=x['Low']
    List=['H1','H2','H2A','H3','H3A','H4','IPivot-H',"IPivot",
                        "L1","L2",'L2A',"L3",'L3A',"L4",'IPivot-L']
    for LI in List:        
        if((H>=x[LI]) & (x[LI]>=L)):
            return LI
    return "0"

def CheckPivotRangeV(x):
    H=x['High']
    L=x['Low']
    List=['H1','H2','H2A','H3','H3A','H4','IPivot-H',"IPivot",
                        "L1","L2",'L2A',"L3",'L3A',"L4",'IPivot-L']
    for LI in List:        
        if((H>=x[LI]) & (x[LI]>=L)):
            H1=(H-x[LI]+0.0001)/x[LI]*100
            L1=(x[LI]-L+0.001)/L*100
            if (H1>L1):
                return round(H1,2)
            else:
                return round(L1,2)*-1
    return 100
    
minute="15minute"
TInterval=['3minute','5minute','15minute']
PercentageAr=[0.0002,round(0.0002/3*5,4),round(0.0002/3*15,4)]
OffsetAr=[5,4,3]
iP=PercentageAr[TInterval.index(minute)]
iO=OffsetAr[TInterval.index(minute)]


def ProcessZ(iPercentage,ioffset,DataFrameCollection,y,RealTime):    
    global dd
    ResultAr=[]
    p=0 #####NEED TO CHANGE TO -1
    while(p<len(StockList)-1):
        p=p+1
        #print(StockList.iloc[p]['Symbol'])
        #iPercentage=iP
        #ioffset=iO
        #y=1
        #Symbol="ZEEL"
        #DataFrameCollection=Min5DF
        #RealTime=False
        Symbol=StockList.iloc[p]['Symbol']
        #Data1=DataFrameCollection[StockList.iloc[p]['Symbol']].fillna(0)
        #Data1=Min5DF[Symbol]
        i=0
        Percentage=iPercentage
        offset=ioffset
        T=round(Data1.iloc[0]['Open']*Percentage,2)
        
        HighList=[]
        LowList=[]
        
        PHighList=[]
        PLowList=[]
      
        Tempi=-2
        
        FibListar=[]
        LFibListar=[]
        MaxHL=[]
        MaxOC=[]
        MaxOCP=[]
        MaxHP=[]
        MaxLP=[]
        MaxBP=[]
        while(i<len(Data1)):
            #print(i)
             #FibListSt={}
            Data=Data1[:i+y]
            ResultSt={}
            H,L,C,O=list(Data.iloc[i][['High',"Low","Close","Open"]])
            MaxHL.append(round((H-L+0.000001)/L*100,2))
            
            MaxOCP.append(round((O-C+0.000001)/C*100,2))
            if(O>C):
                MaxHP.append(round((H-O+0.000001)/O*100,2))
                MaxLP.append(round((C-L+0.000001)/L*100,2))
                MaxBP.append(round((O-C+0.000001)/C*100,2))
                MaxOC.append("R")
            else:
                MaxHP.append(round((H-C+0.000001)/C*100,2))
                MaxLP.append(round((O-L+0.000001)/L*100,2))
                MaxBP.append(round((C-O+0.000001)/O*100,2))
                MaxOC.append("G")
            #H=Data['High'].max()
            #L=Data['Low'].max()
        #PivotD
            RangeList=getChartRangeList(H,L,PivotD)
            PRangeList=getChartRangeList(H,L,PivotD1)    
            FibListSt["HCFib"]=""
            FibListSt["HPFib"]=""
            FibListSt["HCLevel"]=""
            FibListSt["HPLevel"]=""
            FibListSt["I"]=i
            FibListSt["LCFib"]=""
            FibListSt["LPFib"]=""
            FibListSt["LCLevel"]=""
            FibListSt["LPLevel"]=""
            #LFibListSt["I"]=i
            for R in RangeList:
                Found=False
                #R="A1000"
                if( H==PivotD[R]):
                    #print(R+" High Same" + Data.iloc[i]['Date'])
                    HighList.append(i)
                    Found=True                    
                elif( H+T>=PivotD[R]>=H-T):
                    #print(str(i)+ "==> "+ R+" High Approx " + Data.iloc[i]['Date'] +" - "+ str(H+T) + " = " + str(PivotD[R]) + " = "+ str(H-T))
                    HighList.append(i)
                    Found=True
                if (Found):
                    if((R.find("A")>=0) | (R.find("Z")>=0)):
                        FibListSt["HCFib"]=R
                    else:
                        FibListSt["HCLevel"]=R
                Found=False
                if( L==PivotD[R]):
                    #print(R+" Low Same" + Data.iloc[i]['Date'])
                    LowList.append(i)
                    Found=True
                elif( L+T>=PivotD[R]>=L-T):
                    #print(str(i)+ "==> "+ R+" Low Approx " + Data.iloc[i]['Date'] +" - "+ str(L+T) + " = " + str(PivotD[R]) + " = "+ str(L-T))
                    LowList.append(i)    
                    Found=True                    
                if (Found):
                    if((R.find("A")>=0) | (R.find("Z")>=0)):
                        FibListSt["LCFib"]=R
                    else:
                        FibListSt["LCLevel"]=R
            
            DHighList = [item for item in set(HighList) if HighList.count(item) > 1]
            DLowList = [item for item in set(LowList) if LowList.count(item) > 1]
            
            
            for R in PRangeList:
                Found=False
                #R="A1000"
                if( H==PivotD1[R]):
                    #print(R+" High Same" + Data.iloc[i]['Date'])
                    PHighList.append(i)
                    Found=True                    
                elif( H+T>=PivotD1[R]>=H-T):
                    #print(str(i)+ "==> "+ R+" High Approx " + Data.iloc[i]['Date'] +" - "+ str(H+T) + " = " + str(PivotD[R]) + " = "+ str(H-T))
                    PHighList.append(i)
                    Found=True
                if (Found):
                    if((R.find("A")>=0) | (R.find("Z")>=0)):
                        FibListSt["HPFib"]=R
                    else:
                        FibListSt["HPLevel"]=R
                Found=False
                if( L==PivotD1[R]):
                    #print(R+" Low Same" + Data.iloc[i]['Date'])
                    PLowList.append(i)
                    Found=True
                elif( L+T>=PivotD1[R]>=L-T):
                    #print(str(i)+ "==> "+ R+" Low Approx " + Data.iloc[i]['Date'] +" - "+ str(L+T) + " = " + str(PivotD[R]) + " = "+ str(L-T))
                    PLowList.append(i)    
                    Found=True                    
                if (Found):
                    if((R.find("A")>=0) | (R.find("Z")>=0)):
                        FibListSt["LPFib"]=R
                    else:
                        FibListSt["LPLevel"]=R
            #if(Found):
            FibListar.append(FibListSt)            
            PDHighList = [item for item in set(PHighList) if PHighList.count(item) > 1]
            PDLowList = [item for item in set(PLowList) if PLowList.count(item) > 1]

            TDF=pd.DataFrame(FibListar)
            
            if(str(HighList).find(str(i-offset)+"")>0):                
                a=isPeak(Data['High'][:i], len(Data['High'][:i]), Data.iloc[i-offset]['High'], i-(offset*2), i)
                Signal=[]
                Cnt=1
                Signal.append("Pivot")                
                if(str(DHighList).find(str(i-offset)+"")>0):                
                    Cnt=2
                    Signal.append("Levels")
                
                if(a):
                    pi=1
                    while(pi<=Cnt):
                        #print("HighList :"+str(HighList))
                        ResultSt={}
                        Diff=round(Data.iloc[i-offset]['High']-Data.iloc[i]['High'],2)
                        DiffP=round(Diff/Data.iloc[i]['High']*100,2)
                        PDiff=round(Data.iloc[i-(offset*2)]['High']-Data.iloc[i-offset]['High'],2)
                        PDiffP=round(PDiff/Data.iloc[i-offset]['High']*100,2)
                        #print(str(i)+ " - " + Data.iloc[i]['Date'] + " HIGH - " +Data.iloc[i-offset]['Date'] + " - " + str(a) + " - " + str(Diff) + " ~ " + str(DiffP));                    
                        ResultSt['Stock']=Symbol
                        ResultSt['Index']=i
                        ResultSt['CGap']=CGap
                        ResultSt['PGap']=PGap
                        ResultSt['CurrentDate']=Data.iloc[i]['Date']
                        ResultSt['Type']='High'
                        ResultSt['SingleDate']=Data.iloc[i-offset]['Date']
                        ResultSt['Diff']=Diff
                        ResultSt['DiffP']=DiffP
                        ResultSt['PDiff']=PDiff
                        ResultSt['PDiffP']=PDiffP
                        ResultSt['InvertedHammer']=Data.iloc[i-offset]['InvertedHammer']
                        ResultSt['Hammer']=Data.iloc[i-offset]['Hammer']
                        ResultSt['PercHL']=round((Data.iloc[:i]['High'].max()-Data.iloc[i-offset]['High']+0.00001)/Data.iloc[i-offset]['High']*100,2)
                        ResultSt['RPercHL']=round((Data.iloc[:i]['Low'].min()-Data.iloc[i-offset]['High']+0.00001)/Data.iloc[i-offset]['High']*100,2)
                        ResultSt['TPercHL']=round((Data.iloc[:i]['High'].max()-Data.iloc[:i]['Low'].min()+0.00001)/Data.iloc[:i]['Low'].min()*100,2)
                        
                        ResultSt['SPercHH']=round((Data.iloc[:i-offset]['High'].max()-Data.iloc[i-offset]['High']+0.00001)/Data.iloc[i-offset]['High']*100,2)
                        ResultSt['SPercLL']=round((Data.iloc[:i-offset]['Low'].min()-Data.iloc[i-offset]['Low']+0.00001)/Data.iloc[i-offset]['Low']*100,2)
                        ResultSt['SPercHL']=round((Data.iloc[:i-offset]['High'].max()-Data.iloc[i-offset]['Low']+0.00001)/Data.iloc[i-offset]['Low']*100,2)
                        ResultSt['SPercCL']=round((Data.iloc[i-offset]['Close']-Data.iloc[:i-offset]['Low'].min()+0.00001)/Data.iloc[:i-offset]['Low'].min()*100,2)
                        ResultSt['SPercHC']=round((Data.iloc[:i-offset]['High'].max()-Data.iloc[i-offset]['Close']+0.00001)/Data.iloc[i-offset]['Close']*100,2)
                        ResultSt['SPercOC']=round((Data.iloc[0]['Open']-Data.iloc[i-offset]['Close']+0.00001)/Data.iloc[i-offset]['Close']*100,2)
                        
                        
                        ResultSt['TPercOC']=round((Data.iloc[0]['Open']-Data.iloc[i]['Close']+0.00001)/Data.iloc[i]['Close']*100,2)
                        ResultSt['TPercOL']=round((Data.iloc[0]['Open']-Data.iloc[:i]['Low'].min()+0.00001)/Data.iloc[:i]['Low'].min()*100,2)
                        ResultSt['TPercHO']=round((Data.iloc[:i]['High'].max()-Data.iloc[0]['Open']+0.00001)/Data.iloc[0]['Open']*100,2)
                        ResultSt['TPercCL']=round((Data.iloc[i]['Close']-Data.iloc[:i]['Low'].min()+0.00001)/Data.iloc[:i]['Low'].min()*100,2)
                        ResultSt['TPercHC']=round((Data.iloc[:i]['High'].max()-Data.iloc[i]['Close']+0.00001)/Data.iloc[i]['Close']*100,2)
                        
          
                        H,L,C,O=list(Data.iloc[i-offset][['High',"Low","Close","Open"]])
                        
                        ResultSt['HLC']=round((H-C)/C*100,2)
                        ResultSt['HL']=round((H-L)/L*100,2)
                        ResultSt['OC']=round((O-C)/C*100,2)
                        ResultSt['G']=O>C
                        ResultSt['CFD']=CFD                        
                        ResultSt['PFD']=PFD
                        ResultSt['CPD']=CPD
                        ResultSt['PPD']=PPD
                        CH,CL,CC,CO=list(Data.iloc[i][['High',"Low","Close","Open"]])                        
                        ResultSt['CC']=CC
                        ResultSt['SC']=C
                        ResultSt['MaxHL']=max(MaxHL)
                        ResultSt['MaxHLIdx']=MaxHL.index(max(MaxHL))
                        ResultSt['MaxHLClr']=MaxOC[MaxHL.index(max(MaxHL))]
                        ResultSt['MaxHLOCP']=MaxOCP[MaxHL.index(max(MaxHL))]
                        ResultSt['MaxHP']=MaxHP[MaxHL.index(max(MaxHL))]
                        ResultSt['MaxLP']=MaxLP[MaxHL.index(max(MaxHL))]
                        ResultSt['MaxBP']=MaxBP[MaxHL.index(max(MaxHL))]
                        #ResultSt['MaxHLOCP']=MaxOCP[MaxHL.index(max(MaxHL))]
                        
                        ResultSt['CHLC']=round((CH-CC)/CC*100,2)
                        ResultSt['CHL']=round((CH-CL)/CL*100,2)
                        ResultSt['COC']=round((CO-CC)/CC*100,2)
                        ResultSt['HCFibV']=100
                        ResultSt['HCLevelV']=100
                        ResultSt['HPFibV']=100
                        ResultSt['HPLevelV']=100
                        ResultSt['LCFibV']=100
                        ResultSt['LCLevelV']=100
                        ResultSt['LPFibV']=100
                        ResultSt['LPLevelV']=100
    
                        
                        ResultSt['HCFib']=TDF[TDF['I']==i-offset]['HCFib'].iloc[0]
                        ResultSt['HCLevel']=TDF[TDF['I']==i-offset]['HCLevel'].iloc[0]
                        ResultSt['HPFib']=TDF[TDF['I']==i-offset]['HPFib'].iloc[0]
                        ResultSt['HPLevel']=TDF[TDF['I']==i-offset]['HPLevel'].iloc[0]
                        ResultSt['LCFib']=TDF[TDF['I']==i-offset]['LCFib'].iloc[0]
                        ResultSt['LCLevel']=TDF[TDF['I']==i-offset]['LCLevel'].iloc[0]
                        ResultSt['LPFib']=TDF[TDF['I']==i-offset]['LPFib'].iloc[0]
                        ResultSt['LPLevel']=TDF[TDF['I']==i-offset]['LPLevel'].iloc[0]
                        
                        if(len(ResultSt['HCFib'])>1):
                            ResultSt['HCFibV']=round(((PivotD[ResultSt['HCFib']]-H)+0.000001)/H*10000,2)
                        if(len(ResultSt['HCLevel'])>1):
                            ResultSt['HCLevelV']=round(((PivotD[ResultSt['HCLevel']]-H)+0.000001)/H*10000,2)
                        if(len(ResultSt['HPFib'])>1):
                            ResultSt['HPFibV']=round(((PivotD[ResultSt['HPFib']]-H)+0.000001)/H*10000,2)
                        if(len(ResultSt['HPLevel'])>1):
                            ResultSt['HPLevelV']=round(((PivotD[ResultSt['HPLevel']]-H)+0.000001)/H*10000,2)

                        if(len(ResultSt['LCFib'])>1):
                            ResultSt['LCFibV']=round(((PivotD[ResultSt['LCFib']]-H)+0.000001)/H*10000,2)
                        if(len(ResultSt['LCLevel'])>1):
                            ResultSt['LCLevelV']=round(((PivotD[ResultSt['LCLevel']]-H)+0.000001)/H*10000,2)
                        if(len(ResultSt['LPFib'])>1):
                            ResultSt['LPFibV']=round(((PivotD[ResultSt['LPFib']]-H)+0.000001)/H*10000,2)
                        if(len(ResultSt['LPLevel'])>1):
                            ResultSt['LPLevelV']=round(((PivotD[ResultSt['LPLevel']]-H)+0.000001)/H*10000,2)
                        
                        
                        ResultSt['HCFib1']=TDF[TDF['I']==i]['HCFib'].iloc[0]
                        ResultSt['HCLevel1']=TDF[TDF['I']==i]['HCLevel'].iloc[0]
                        ResultSt['HPFib1']=TDF[TDF['I']==i]['HPFib'].iloc[0]
                        ResultSt['HPLevel1']=TDF[TDF['I']==i]['HPLevel'].iloc[0]
                        ResultSt['LCFib1']=TDF[TDF['I']==i]['LCFib'].iloc[0]
                        ResultSt['LCLevel1']=TDF[TDF['I']==i]['LCLevel'].iloc[0]
                        ResultSt['LPFib1']=TDF[TDF['I']==i]['LPFib'].iloc[0]
                        ResultSt['LPLevel1']=TDF[TDF['I']==i]['LPLevel'].iloc[0]
                        ResultAr.append(ResultSt)
                        Tempi=i
                        pi=pi+1
                        
#            if(str(LowList).find(str(i-offset)+"")>0):
#                Trough=isTrough(Data['Low'][:i], len(Data['Low'][:i]), Data.iloc[i-offset]['Low'], i-(offset*2), i-1)
#                Cnt=1
#                if(str(DLowList).find(str(i-offset)+"")>0):                
#                    Cnt=2
#                
#                if(Trough):
#                    pi=1
#                    while(pi<=Cnt):                
#                        ResultSt={}
#                        H,L,C,O=list(Data.iloc[i-offset][['High',"Low","Close","Open"]])
#                        CH,CL,CC,CO=list(Data.iloc[i][['High',"Low","Close","Open"]])
#                        #print("LowList :"+str(LowList))
#                        #print(Symbol+"\ti="+str(i) + "\t"+str(i-offset)+"\t"+ str(i-(offset*2)))
#                        Diff=round(Data.iloc[i-offset]['Low']-Data.iloc[i]['Low'],2)
#                        DiffP=round(Diff/Data.iloc[i]['Low']*100,2)
#                        PDiff=round(Data.iloc[i-(offset*2)]['Low']-Data.iloc[i-offset]['Low'],2)
#                        PDiffP=round(PDiff/Data.iloc[i-offset]['Low']*100,2)
#                        #print(str(i)+ " - "+Data.iloc[i]['Date'] + " Low - " +Data.iloc[i-offset]['Date'] + " - " + str(Trough)+ " - " + str(Diff) + " ~ " + str(DiffP));    
#                        ResultSt['Stock']=Symbol
#                        ResultSt['Index']=i
#                        ResultSt['CGap']=CGap
#                        ResultSt['PGap']=PGap
#                        ResultSt['CurrentDate']=Data.iloc[i]['Date']
#                        ResultSt['Type']='Low'
#                        ResultSt['SingleDate']=Data.iloc[i-offset]['Date']
#                        ResultSt['Diff']=Diff
#                        ResultSt['DiffP']=DiffP
#                        ResultSt['PDiff']=PDiff
#                        ResultSt['PDiffP']=PDiffP
#                        ResultSt['InvertedHammer']=Data.iloc[i-offset]['InvertedHammer']
#                        ResultSt['Hammer']=Data.iloc[i-offset]['Hammer']
#                        ResultSt['PercHL']=round((Data.iloc[:i]['Low'].min()-Data.iloc[i-offset]['Low']+0.00001)/Data.iloc[i-offset]['Low']*100,2)
#                        ResultSt['RPercHL']=round((Data.iloc[:i]['High'].max()-Data.iloc[i-offset]['Low']+0.00001)/Data.iloc[i-offset]['Low']*100,2)
#                        ResultSt['TPercHL']=round((Data.iloc[:i]['High'].max()-Data.iloc[:i]['Low'].min()+0.00001)/Data.iloc[:i]['Low'].min()*100,2)
#                        ResultSt['CC']=CC
#                        ResultSt['SC']=C
#                        ResultSt['SPercHH']=round((Data.iloc[:i-offset]['High'].max()-Data.iloc[i-offset]['High']+0.00001)/Data.iloc[i-offset]['High']*100,2)
#                        ResultSt['SPercLL']=round((Data.iloc[:i-offset]['Low'].min()-Data.iloc[i-offset]['Low']+0.00001)/Data.iloc[i-offset]['Low']*100,2)
#                        ResultSt['SPercHL']=round((Data.iloc[:i-offset]['High'].max()-Data.iloc[i-offset]['Low']+0.00001)/Data.iloc[i-offset]['Low']*100,2)
#                        ResultSt['SPercCL']=round((Data.iloc[i-offset]['Close']-Data.iloc[:i-offset]['Low'].min()+0.00001)/Data.iloc[:i-offset]['Low'].min()*100,2)
#                        ResultSt['SPercHC']=round((Data.iloc[:i-offset]['High'].max()-Data.iloc[i-offset]['Close']+0.00001)/Data.iloc[i-offset]['Close']*100,2)
#                        ResultSt['SPercOC']=round((Data.iloc[0]['Open']-Data.iloc[i-offset]['Close']+0.00001)/Data.iloc[i-offset]['Close']*100,2)
#                        
#                        
#                        ResultSt['TPercOC']=round((Data.iloc[0]['Open']-Data.iloc[i]['Close']+0.00001)/Data.iloc[i]['Close']*100,2)
#                        ResultSt['TPercOL']=round((Data.iloc[0]['Open']-Data.iloc[:i]['Low'].min()+0.00001)/Data.iloc[:i]['Low'].min()*100,2)
#                        ResultSt['TPercHO']=round((Data.iloc[:i]['High'].max()-Data.iloc[0]['Open']+0.00001)/Data.iloc[0]['Open']*100,2)
#                        ResultSt['TPercCL']=round((Data.iloc[i]['Close']-Data.iloc[:i]['Low'].min()+0.00001)/Data.iloc[:i]['Low'].min()*100,2)
#                        ResultSt['TPercHC']=round((Data.iloc[:i]['High'].max()-Data.iloc[i]['Close']+0.00001)/Data.iloc[i]['Close']*100,2)
#                        
#          
#                        
#                        
#                        
#                        ResultSt['HLC']=round((L-C)/C*100,2)
#                        ResultSt['HL']=round((H-L)/L*100,2)
#                        ResultSt['OC']=round((O-C)/C*100,2)
#                        
#                        ResultSt['HCFib']=TDF[TDF['I']==i-offset]['HCFib'].iloc[0]
#                        ResultSt['HCLevel']=TDF[TDF['I']==i-offset]['HCLevel'].iloc[0]
#                        ResultSt['HPFib']=TDF[TDF['I']==i-offset]['HPFib'].iloc[0]
#                        ResultSt['HPLevel']=TDF[TDF['I']==i-offset]['HPLevel'].iloc[0]
#                        ResultSt['LCFib']=TDF[TDF['I']==i-offset]['LCFib'].iloc[0]
#                        ResultSt['LCLevel']=TDF[TDF['I']==i-offset]['LCLevel'].iloc[0]
#                        ResultSt['LPFib']=TDF[TDF['I']==i-offset]['LPFib'].iloc[0]
#                        ResultSt['LPLevel']=TDF[TDF['I']==i-offset]['LPLevel'].iloc[0]
#                        
#                        ResultSt['G']=O>C
#                        ResultSt['CFD']=CFD
#                        ResultSt['PFD']=PFD
#                        ResultSt['CPD']=CPD
#                        ResultSt['PPD']=PPD
#                        
#                        
#                        ResultSt['MaxHL']=max(MaxHL)
#                        ResultSt['MaxHLIdx']=MaxHL.index(max(MaxHL))
#                        ResultSt['MaxHLClr']=MaxOC[MaxHL.index(max(MaxHL))]
#                        ResultSt['MaxHLOCP']=MaxOCP[MaxHL.index(max(MaxHL))]
#                        ResultSt['MaxHP']=MaxHP[MaxHL.index(max(MaxHL))]
#                        ResultSt['MaxLP']=MaxLP[MaxHL.index(max(MaxHL))]
#                        ResultSt['MaxBP']=MaxBP[MaxHL.index(max(MaxHL))]
#                        ResultSt['CHLC']=round((CL-CC)/CC*100,2)
#                        ResultSt['CHL']=round((CH-CL)/CL*100,2)
#                        ResultSt['COC']=round((CO-CC)/CC*100,2)
#                        ResultSt['HCFibV']=100
#                        ResultSt['HCLevelV']=100
#                        ResultSt['HPFibV']=100
#                        ResultSt['HPLevelV']=100
#                        ResultSt['LCFibV']=100
#                        ResultSt['LCLevelV']=100
#                        ResultSt['LPFibV']=100
#                        ResultSt['LPLevelV']=100
#                        
#                        if(len(ResultSt['HCFib'])>1):
#                        	ResultSt['HCFibV']=round(((PivotD[ResultSt['HCFib']]-L)+0.000001)/L*10000,2)
#                        if(len(ResultSt['HCLevel'])>1):
#                            ResultSt['HCLevelV']=round(((PivotD[ResultSt['HCLevel']]-L)+0.000001)/L*10000,2)
#                        if(len(ResultSt['HPFib'])>1):
#                            ResultSt['HPFibV']=round(((PivotD[ResultSt['HPFib']]-L)+0.000001)/L*10000,2)
#                        if(len(ResultSt['HPLevel'])>1):
#                            ResultSt['HPLevelV']=round(((PivotD[ResultSt['HPLevel']]-L)+0.000001)/L*10000,2)
#
#                        if(len(ResultSt['LCFib'])>1):
#                            ResultSt['LCFibV']=round(((PivotD[ResultSt['LCFib']]-L)+0.000001)/L*10000,2)
#                        if(len(ResultSt['LCLevel'])>1):
#                            ResultSt['LCLevelV']=round(((PivotD[ResultSt['LCLevel']]-L)+0.000001)/L*10000,2)
#                        if(len(ResultSt['LPFib'])>1):
#                            ResultSt['LPFibV']=round(((PivotD[ResultSt['LPFib']]-L)+0.000001)/L*10000,2)
#                        if(len(ResultSt['LPLevel'])>1):
#                            ResultSt['LPLevelV']=round(((PivotD[ResultSt['LPLevel']]-L)+0.000001)/L*10000,2)
#                          
#                        ResultSt['HCFib1']=TDF[TDF['I']==i]['HCFib'].iloc[0]
#                        ResultSt['HCLevel1']=TDF[TDF['I']==i]['HCLevel'].iloc[0]
#                        ResultSt['HPFib1']=TDF[TDF['I']==i]['HPFib'].iloc[0]
#                        ResultSt['HPLevel1']=TDF[TDF['I']==i]['HPLevel'].iloc[0]
#                        ResultSt['LCFib1']=TDF[TDF['I']==i]['LCFib'].iloc[0]
#                        ResultSt['LCLevel1']=TDF[TDF['I']==i]['LCLevel'].iloc[0]
#                        ResultSt['LPFib1']=TDF[TDF['I']==i]['LPFib'].iloc[0]
#                        ResultSt['LPLevel1']=TDF[TDF['I']==i]['LPLevel'].iloc[0]
#                        
#                        ResultAr.append(ResultSt)
#                        Tempi=i
#                        pi=pi+1
#            i=i+1
    
    ResultDF=pd.DataFrame(ResultAr)
    return ResultDF

MaxRSI=65
MaxRSI1=65-10
HRSI=80
MinRSI=30
LRSI=19
a=Data1[(
       (Data1['RSI14']>MaxRSI-10) & 
       (Data1['RSI14'].shift(1)>MaxRSI-10) &
       (Data1['RSI14'].shift(2)>MaxRSI-10) &
       (Data1['RSI14'].shift(3)>MaxRSI-10) &
       (Data1['RSI14'].shift(4)>MaxRSI-10) &
       (Data1['RSI14'].shift(5)>MaxRSI-10) &
       (Data1['RSI14'].shift(6)>MaxRSI) &
       (Data1['RSI14'].shift(7)>MaxRSI) &
       (Data1['RSI14'].shift(8)>MaxRSI) &
       (Data1['RSI14'].shift(9)>MaxRSI) &
       (Data1['RSI14'].shift(10)>MaxRSI) &
       ( 
        ( (Data1['EMA-RSI-50'].shift(1)>MaxRSI1) & (Data1['EMA-RSI-50'].shift(1)>Data1['RSI14'].shift(1)) |
          (Data1['EMA-RSI-50'].shift(2)>MaxRSI1) & (Data1['EMA-RSI-50'].shift(2)>Data1['RSI14'].shift(2)) |
          (Data1['EMA-RSI-50'].shift(3)>MaxRSI1) & (Data1['EMA-RSI-50'].shift(3)>Data1['RSI14'].shift(3)) |
          (Data1['EMA-RSI-50'].shift(4)>MaxRSI1) & (Data1['EMA-RSI-50'].shift(4)>Data1['RSI14'].shift(4)) |
          (Data1['EMA-RSI-50'].shift(5)>MaxRSI1) & (Data1['EMA-RSI-50'].shift(5)>Data1['RSI14'].shift(5)) |
          (Data1['EMA-RSI-50'].shift(6)>MaxRSI1) & (Data1['EMA-RSI-50'].shift(6)>Data1['RSI14'].shift(6)) |
          (Data1['EMA-RSI-50'].shift(7)>MaxRSI1) & (Data1['EMA-RSI-50'].shift(7)>Data1['RSI14'].shift(7)) 
        ) &
          (Data1['EMA-RSI-150']>MaxRSI1-5) & (Data1['EMA-RSI-150']>Data1['RSI14']) 
       ))
        ]

MaxRSI=65
MaxRSI1=65-10
HRSI=78
MinRSI=30
LRSI=19

a=Data1[(
       (Data1['RSI14']>MaxRSI-10) & 
       (Data1['RSI14'].shift(1)>MaxRSI-10) &
       (Data1['RSI14'].shift(2)>MaxRSI-10) &
       (Data1['RSI14'].shift(3)>MaxRSI-10) &
       (Data1['RSI14'].shift(4)>MaxRSI-10) &
       (Data1['RSI14'].shift(5)>MaxRSI-10) &
       (Data1['RSI14'].shift(6)>MaxRSI) &
       (Data1['RSI14'].shift(7)>MaxRSI) &
       (Data1['RSI14'].shift(8)>MaxRSI) &
       (Data1['RSI14'].shift(9)>MaxRSI) &
       (Data1['RSI14'].shift(10)>MaxRSI) 
       & (
               (Data1['RSI14'].shift(6)>HRSI) |
               (Data1['RSI14'].shift(7)>HRSI) |
               (Data1['RSI14'].shift(8)>HRSI) |
               (Data1['RSI14'].shift(9)>HRSI) |
               (Data1['RSI14'].shift(10)>HRSI) 
        )
#       & ( 
#        ( (Data1['EMA-RSI-50'].shift(1)>MaxRSI1) & (Data1['EMA-RSI-50'].shift(1)>Data1['RSI14'].shift(1)) |
#          (Data1['EMA-RSI-50'].shift(2)>MaxRSI1) & (Data1['EMA-RSI-50'].shift(2)>Data1['RSI14'].shift(2)) |
#          (Data1['EMA-RSI-50'].shift(3)>MaxRSI1) & (Data1['EMA-RSI-50'].shift(3)>Data1['RSI14'].shift(3)) |
#          (Data1['EMA-RSI-50'].shift(4)>MaxRSI1) & (Data1['EMA-RSI-50'].shift(4)>Data1['RSI14'].shift(4)) |
#          (Data1['EMA-RSI-50'].shift(5)>MaxRSI1) & (Data1['EMA-RSI-50'].shift(5)>Data1['RSI14'].shift(5)) |
#          (Data1['EMA-RSI-50'].shift(6)>MaxRSI1) & (Data1['EMA-RSI-50'].shift(6)>Data1['RSI14'].shift(6)) |
#          (Data1['EMA-RSI-50'].shift(7)>MaxRSI1) & (Data1['EMA-RSI-50'].shift(7)>Data1['RSI14'].shift(7)) 
#        ) &
#          (Data1['EMA-RSI-150']>MaxRSI1-5) & (Data1['EMA-RSI-150']>Data1['RSI14']) 
#       )
        )
        ]
        
        ['Date']
      
      
      