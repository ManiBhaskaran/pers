# -*- coding: utf-8 -*-
"""
Created on Sun Nov 24 22:34:25 2019

@author: lalitha
"""

from datetime import datetime, timedelta
import requests
from dateutil.parser import parse
import plotly.graph_objs as go
from plotly import __version__
from plotly.offline import download_plotlyjs, init_notebook_mode, plot, iplot
import numpy as np
import plotly.io as pio
import os


from candlestick import candlestick
import datetime
import pandas as pd
import json
import time
from dateutil.parser import parse
pd.set_option('display.max_columns', 500)
pd.set_option('display.max_rows', 1500)
def isPeak(arr, n, num, i, j): 

	# If num is smaller than the element 
	# on the left (if exists) 
	if (i >= 0 and arr[i] > num): 
		return False

	# If num is smaller than the element 
	# on the right (if exists) 
	if (j < n and arr[j] > num): 
		return False
	return True

# Function that returns true if num is 
# smaller than both arr[i] and arr[j] 
def isTrough(arr, n, num, i, j): 

	# If num is greater than the element 
	# on the left (if exists) 
	if (i >= 0 and arr[i] < num): 
		return False

	# If num is greater than the element 
	# on the right (if exists) 
	if (j < n and arr[j] < num): 
		return False
	return True

def printPeaksTroughs(arr, n): 

	print("Peaks : ", end = "") 

	# For every element 
	for i in range(n): 

		# If the current element is a peak 
		if (isPeak(arr, n, arr[i], i - 1, i + 1)): 
			print(arr[i], end = " ") 
	print() 

	print("Troughs : ", end = "") 

	# For every element 
	for i in range(n): 

		# If the current element is a trough 
		if (isTrough(arr, n, arr[i], i - 1, i + 1)): 
			print(arr[i], end = " ") 



def Process(iPercentage,ioffset,DataFrameCollection,y):    
    global dd
    ResultAr=[]
    p=-1
    while(p<len(StockList)-1):
        p=p+1
        #print(StockList.iloc[p]['Symbol'])
        Symbol=StockList.iloc[p]['Symbol']
        Data1=DataFrameCollection[StockList.iloc[p]['Symbol']].fillna(0)
        Data1=candlestick.doji(Data1)
        Data1=candlestick.doji_star(Data1)
        Data1=candlestick.hammer(Data1)
        Data1=candlestick.inverted_hammer(Data1)
        #dd=Data
        LastPivot=pd.read_csv(r"C:\ReadMoneycontrol\Mani 2.0\Data3\\"+Symbol+"-Pivot.csv",encoding='utf-8')
        PivotD=LastPivot.iloc[DateIndex*-1]
        #PivotD1=LastPivot.iloc[DateIndex-1*-1]
        i=0
        Percentage=iPercentage
        offset=ioffset
        T=round(Data1.iloc[0]['Open']*Percentage,2)
        HighList=[]
        LowList=[]
        
        Tempi=-2
        while(i<len(Data1)):
            Data=Data1[:i+y]
            ResultSt={}
            H=Data.iloc[i]['High']
            L=Data.iloc[i]['Low']
            #H=Data['High'].max()
            #L=Data['Low'].max()
        #PivotD
            RangeList=getChartRangeList(H,L,PivotD)
                
            
            for R in RangeList:
                #R="A1000"
                if( H==PivotD[R]):
                    #print(R+" High Same" + Data.iloc[i]['Date'])
                    HighList.append(i)
                elif( H+T>=PivotD[R]>=H-T):
                    #print(str(i)+ "==> "+ R+" High Approx " + Data.iloc[i]['Date'] +" - "+ str(H+T) + " = " + str(PivotD[R]) + " = "+ str(H-T))
                    HighList.append(i)
                if( L==PivotD[R]):
                    #print(R+" Low Same" + Data.iloc[i]['Date'])
                    LowList.append(i)
                elif( L+T>=PivotD[R]>=L-T):
                    #print(str(i)+ "==> "+ R+" Low Approx " + Data.iloc[i]['Date'] +" - "+ str(L+T) + " = " + str(PivotD[R]) + " = "+ str(L-T))
                    LowList.append(i)    
            
            DHighList = [item for item in set(HighList) if HighList.count(item) > 1]
            DLowList = [item for item in set(LowList) if LowList.count(item) > 1]
            if(str(HighList).find(str(i-offset)+"")>0):                
                a=isPeak(Data['High'][:i], len(Data['High'][:i]), Data.iloc[i-offset]['High'], i-(offset*2), i)
                Cnt=1
                if(str(DHighList).find(str(i-offset)+"")>0):                
                    Cnt=2
                
                if(a):
                    pi=1
                    while(pi<=Cnt):
                        print("HighList :"+str(HighList))
                        ResultSt={}
                        Diff=round(Data.iloc[i-offset]['High']-Data.iloc[i]['High'],2)
                        DiffP=round(Diff/Data.iloc[i]['High']*100,2)
                        PDiff=round(Data.iloc[i-(offset*2)]['High']-Data.iloc[i-offset]['High'],2)
                        PDiffP=round(PDiff/Data.iloc[i-offset]['High']*100,2)
                        #print(str(i)+ " - " + Data.iloc[i]['Date'] + " HIGH - " +Data.iloc[i-offset]['Date'] + " - " + str(a) + " - " + str(Diff) + " ~ " + str(DiffP));                    
                        ResultSt['Stock']=Symbol
                        ResultSt['Index']=i
                        ResultSt['CurrentDate']=Data.iloc[i]['Date']
                        ResultSt['Type']='High'
                        ResultSt['SingleDate']=Data.iloc[i-offset]['Date']
                        ResultSt['Diff']=Diff
                        ResultSt['DiffP']=DiffP
                        ResultSt['PDiff']=PDiff
                        ResultSt['PDiffP']=PDiffP
                        ResultSt['InvertedHammer']=Data.iloc[i-offset]['InvertedHammer']
                        ResultSt['Hammer']=Data.iloc[i-offset]['Hammer']
                        ResultSt['PercHL']=round((Data.iloc[:i]['High'].max()-Data.iloc[i-offset]['High']+0.00001)/Data.iloc[i-offset]['High']*100,2)
                        H,L,C,O=list(Data.iloc[i-offset][['High',"Low","Close","Open"]])
                        ResultSt['HLC']=round((H-C)/C*100,2)
                        ResultSt['HL']=round((H-L)/L*100,2)
                        ResultSt['OC']=round((O-C)/C*100,2)
                        ResultSt['G']=O>C
                        ResultAr.append(ResultSt)
                        Tempi=i
                        pi=pi+1
                        
            if(str(LowList).find(str(i-offset)+"")>0):
                Trough=isTrough(Data['Low'][:i], len(Data['Low'][:i]), Data.iloc[i-offset]['Low'], i-(offset*2), i-1)
                Cnt=1
                if(str(DLowList).find(str(i-offset)+"")>0):                
                    Cnt=2
                
                if(Trough):
                    pi=1
                    while(pi<=Cnt):                
                        ResultSt={}
                        print("LowList :"+str(LowList))
                        #print(Symbol+"\ti="+str(i) + "\t"+str(i-offset)+"\t"+ str(i-(offset*2)))
                        Diff=round(Data.iloc[i-offset]['Low']-Data.iloc[i]['Low'],2)
                        DiffP=round(Diff/Data.iloc[i]['Low']*100,2)
                        PDiff=round(Data.iloc[i-(offset*2)]['Low']-Data.iloc[i-offset]['Low'],2)
                        PDiffP=round(PDiff/Data.iloc[i-offset]['Low']*100,2)
                        #print(str(i)+ " - "+Data.iloc[i]['Date'] + " Low - " +Data.iloc[i-offset]['Date'] + " - " + str(Trough)+ " - " + str(Diff) + " ~ " + str(DiffP));    
                        ResultSt['Stock']=Symbol
                        ResultSt['Index']=i
                        ResultSt['CurrentDate']=Data.iloc[i]['Date']
                        ResultSt['Type']='Low'
                        ResultSt['SingleDate']=Data.iloc[i-offset]['Date']
                        ResultSt['Diff']=Diff
                        ResultSt['DiffP']=DiffP
                        ResultSt['PDiff']=PDiff
                        ResultSt['PDiffP']=PDiffP
                        ResultSt['InvertedHammer']=Data.iloc[i-offset]['InvertedHammer']
                        ResultSt['Hammer']=Data.iloc[i-offset]['Hammer']
                        ResultSt['PercHL']=round((Data.iloc[:i]['Low'].min()-Data.iloc[i-offset]['Low']+0.00001)/Data.iloc[i-offset]['Low']*100,2)
                        H,L,C,O=list(Data.iloc[i-offset][['High',"Low","Close","Open"]])
                        ResultSt['HLC']=round((L-C)/C*100,2)
                        ResultSt['HL']=round((H-L)/L*100,2)
                        ResultSt['OC']=round((O-C)/C*100,2)
                        ResultSt['G']=O>C
                        ResultAr.append(ResultSt)
                        Tempi=i
                        pi=pi+1
            i=i+1
    
    ResultDF=pd.DataFrame(ResultAr)
    return ResultDF



def ProcessZ(iPercentage,ioffset,DataFrameCollection,y):    
    global dd
    ResultAr=[]
    p=-1
    while(p<len(StockList)-1):
        p=p+1
        #print(StockList.iloc[p]['Symbol'])
        #iPercentage=iP
        #ioffset=iO
        #y=1
        #Symbol="ASIANPAINT"
        Symbol=StockList.iloc[p]['Symbol']
        Data1=DataFrameCollection[StockList.iloc[p]['Symbol']].fillna(0)
        Data1=Min5DF[Symbol]
        Data1=candlestick.doji(Data1)
        Data1=candlestick.doji_star(Data1)
        Data1=candlestick.hammer(Data1)
        Data1=candlestick.inverted_hammer(Data1)
        #dd=Data
        LastPivot=pd.read_csv(r"C:\ReadMoneycontrol\Mani 2.0\Data3\\"+Symbol+"-Pivot.csv",encoding='utf-8')
        PivotD=LastPivot.iloc[DateIndex*-1]
        PivotD1=LastPivot.iloc[(DateIndex+1)*-1]
        #LastPivot.iloc[DateIndex*-1]['Date']
        
        
        i=0
        Percentage=iPercentage
        offset=ioffset
        T=round(Data1.iloc[0]['Open']*Percentage,2)
        HighList=[]
        LowList=[]
        
        PHighList=[]
        PLowList=[]
        
        Tempi=-2
        
        FibListar=[]
        LFibListar=[]
        while(i<len(Data1)):
            FibListSt={}
            #FibListSt={}
            Data=Data1[:i+y]
            ResultSt={}
            H=Data.iloc[i]['High']
            L=Data.iloc[i]['Low']
            #H=Data['High'].max()
            #L=Data['Low'].max()
        #str(PivotD)
        #PivotD1['Date']
            RangeList=getChartRangeList(H,L,PivotD)
            PRangeList=getChartRangeList(H,L,PivotD1)    
            FibListSt["HCFib"]=""
            FibListSt["HPFib"]=""
            FibListSt["HCLevel"]=""
            FibListSt["HPLevel"]=""
            FibListSt["I"]=i
            FibListSt["LCFib"]=""
            FibListSt["LPFib"]=""
            FibListSt["LCLevel"]=""
            FibListSt["LPLevel"]=""
            #LFibListSt["I"]=i
            for R in RangeList:
                Found=False
                #R="A1000"
                if( H==PivotD[R]):
                    #print(R+" High Same" + Data.iloc[i]['Date'])
                    HighList.append(i)
                    Found=True                    
                elif( H+T>=PivotD[R]>=H-T):
                    #print(str(i)+ "==> "+ R+" High Approx " + Data.iloc[i]['Date'] +" - "+ str(H+T) + " = " + str(PivotD[R]) + " = "+ str(H-T))
                    HighList.append(i)
                    Found=True
                if (Found):
                    if((R.find("A")>=0) | (R.find("Z")>=0)):
                        FibListSt["HCFib"]=R
                    else:
                        FibListSt["HCLevel"]=R
                Found=False
                if( L==PivotD[R]):
                    #print(R+" Low Same" + Data.iloc[i]['Date'])
                    LowList.append(i)
                    Found=True
                elif( L+T>=PivotD[R]>=L-T):
                    #print(str(i)+ "==> "+ R+" Low Approx " + Data.iloc[i]['Date'] +" - "+ str(L+T) + " = " + str(PivotD[R]) + " = "+ str(L-T))
                    LowList.append(i)    
                    Found=True                    
                if (Found):
                    if((R.find("A")>=0) | (R.find("Z")>=0)):
                        FibListSt["LCFib"]=R
                    else:
                        FibListSt["LCLevel"]=R
            
            DHighList = [item for item in set(HighList) if HighList.count(item) > 1]
            DLowList = [item for item in set(LowList) if LowList.count(item) > 1]
            
            
            for R in PRangeList:
                Found=False
                #R="A1000"
                if( H==PivotD1[R]):
                    #print(R+" High Same" + Data.iloc[i]['Date'])
                    PHighList.append(i)
                    Found=True                    
                elif( H+T>=PivotD1[R]>=H-T):
                    #print(str(i)+ "==> "+ R+" High Approx " + Data.iloc[i]['Date'] +" - "+ str(H+T) + " = " + str(PivotD[R]) + " = "+ str(H-T))
                    PHighList.append(i)
                    Found=True
                if (Found):
                    if((R.find("A")>=0) | (R.find("Z")>=0)):
                        FibListSt["HPFib"]=R
                    else:
                        FibListSt["HPLevel"]=R
                Found=False
                if( L==PivotD1[R]):
                    #print(R+" Low Same" + Data.iloc[i]['Date'])
                    PLowList.append(i)
                    Found=True
                elif( L+T>=PivotD1[R]>=L-T):
                    #print(str(i)+ "==> "+ R+" Low Approx " + Data.iloc[i]['Date'] +" - "+ str(L+T) + " = " + str(PivotD[R]) + " = "+ str(L-T))
                    PLowList.append(i)    
                    Found=True                    
                if (Found):
                    if((R.find("A")>=0) | (R.find("Z")>=0)):
                        FibListSt["LPFib"]=R
                    else:
                        FibListSt["LPLevel"]=R
            #if(Found):
            FibListar.append(FibListSt)            
            PDHighList = [item for item in set(PHighList) if PHighList.count(item) > 1]
            PDLowList = [item for item in set(PLowList) if PLowList.count(item) > 1]

            TDF=pd.DataFrame(FibListar)
            
            if(str(HighList).find(str(i-offset)+"")>0):                
                a=isPeak(Data['High'][:i], len(Data['High'][:i]), Data.iloc[i-offset]['High'], i-(offset*2), i)
                Signal=[]
                Cnt=1
                Signal.append("Pivot")                
                if(str(DHighList).find(str(i-offset)+"")>0):                
                    Cnt=2
                    Signal.append("Levels")
                
                if(a):
                    pi=1
                    while(pi<=Cnt):
                        #print("HighList :"+str(HighList))
                        ResultSt={}
                        Diff=round(Data.iloc[i-offset]['High']-Data.iloc[i]['High'],2)
                        DiffP=round(Diff/Data.iloc[i]['High']*100,2)
                        PDiff=round(Data.iloc[i-(offset*2)]['High']-Data.iloc[i-offset]['High'],2)
                        PDiffP=round(PDiff/Data.iloc[i-offset]['High']*100,2)
                        #print(str(i)+ " - " + Data.iloc[i]['Date'] + " HIGH - " +Data.iloc[i-offset]['Date'] + " - " + str(a) + " - " + str(Diff) + " ~ " + str(DiffP));                    
                        ResultSt['Stock']=Symbol
                        ResultSt['Index']=i
                        ResultSt['CurrentDate']=Data.iloc[i]['Date']
                        ResultSt['Type']='High'
                        ResultSt['SingleDate']=Data.iloc[i-offset]['Date']
                        ResultSt['Diff']=Diff
                        ResultSt['DiffP']=DiffP
                        ResultSt['PDiff']=PDiff
                        ResultSt['PDiffP']=PDiffP
                        ResultSt['InvertedHammer']=Data.iloc[i-offset]['InvertedHammer']
                        ResultSt['Hammer']=Data.iloc[i-offset]['Hammer']
                        ResultSt['PercHL']=round((Data.iloc[:i]['High'].max()-Data.iloc[i-offset]['High']+0.00001)/Data.iloc[i-offset]['High']*100,2)
                        H,L,C,O=list(Data.iloc[i-offset][['High',"Low","Close","Open"]])
                        ResultSt['HLC']=round((H-C)/C*100,2)
                        ResultSt['HL']=round((H-L)/L*100,2)
                        ResultSt['OC']=round((O-C)/C*100,2)
                        ResultSt['G']=O>C
                        ResultSt['HCFib']=TDF[TDF['I']==i-offset]['HCFib'].iloc[0]
                        ResultSt['HCLevel']=TDF[TDF['I']==i-offset]['HCLevel'].iloc[0]
                        ResultSt['HPFib']=TDF[TDF['I']==i-offset]['HPFib'].iloc[0]
                        ResultSt['HPLevel']=TDF[TDF['I']==i-offset]['HPLevel'].iloc[0]
                        ResultSt['LCFib']=TDF[TDF['I']==i-offset]['LCFib'].iloc[0]
                        ResultSt['LCLevel']=TDF[TDF['I']==i-offset]['LCLevel'].iloc[0]
                        ResultSt['LPFib']=TDF[TDF['I']==i-offset]['LPFib'].iloc[0]
                        ResultSt['LPLevel']=TDF[TDF['I']==i-offset]['LPLevel'].iloc[0]
                        
                        ResultAr.append(ResultSt)
                        Tempi=i
                        pi=pi+1
                        
            if(str(LowList).find(str(i-offset)+"")>0):
                Trough=isTrough(Data['Low'][:i], len(Data['Low'][:i]), Data.iloc[i-offset]['Low'], i-(offset*2), i-1)
                Cnt=1
                if(str(DLowList).find(str(i-offset)+"")>0):                
                    Cnt=2
                
                if(Trough):
                    pi=1
                    while(pi<=Cnt):                
                        ResultSt={}
                        #print("LowList :"+str(LowList))
                        #print(Symbol+"\ti="+str(i) + "\t"+str(i-offset)+"\t"+ str(i-(offset*2)))
                        Diff=round(Data.iloc[i-offset]['Low']-Data.iloc[i]['Low'],2)
                        DiffP=round(Diff/Data.iloc[i]['Low']*100,2)
                        PDiff=round(Data.iloc[i-(offset*2)]['Low']-Data.iloc[i-offset]['Low'],2)
                        PDiffP=round(PDiff/Data.iloc[i-offset]['Low']*100,2)
                        #print(str(i)+ " - "+Data.iloc[i]['Date'] + " Low - " +Data.iloc[i-offset]['Date'] + " - " + str(Trough)+ " - " + str(Diff) + " ~ " + str(DiffP));    
                        ResultSt['Stock']=Symbol
                        ResultSt['Index']=i
                        ResultSt['CurrentDate']=Data.iloc[i]['Date']
                        ResultSt['Type']='Low'
                        ResultSt['SingleDate']=Data.iloc[i-offset]['Date']
                        ResultSt['Diff']=Diff
                        ResultSt['DiffP']=DiffP
                        ResultSt['PDiff']=PDiff
                        ResultSt['PDiffP']=PDiffP
                        ResultSt['InvertedHammer']=Data.iloc[i-offset]['InvertedHammer']
                        ResultSt['Hammer']=Data.iloc[i-offset]['Hammer']
                        ResultSt['PercHL']=round((Data.iloc[:i]['Low'].min()-Data.iloc[i-offset]['Low']+0.00001)/Data.iloc[i-offset]['Low']*100,2)
                        H,L,C,O=list(Data.iloc[i-offset][['High',"Low","Close","Open"]])
                        ResultSt['HLC']=round((L-C)/C*100,2)
                        ResultSt['HL']=round((H-L)/L*100,2)
                        ResultSt['OC']=round((O-C)/C*100,2)
                        
                        ResultSt['HCFib']=TDF[TDF['I']==i-offset]['HCFib'].iloc[0]
                        ResultSt['HCLevel']=TDF[TDF['I']==i-offset]['HCLevel'].iloc[0]
                        ResultSt['HPFib']=TDF[TDF['I']==i-offset]['HPFib'].iloc[0]
                        ResultSt['HPLevel']=TDF[TDF['I']==i-offset]['HPLevel'].iloc[0]
                        ResultSt['LCFib']=TDF[TDF['I']==i-offset]['LCFib'].iloc[0]
                        ResultSt['LCLevel']=TDF[TDF['I']==i-offset]['LCLevel'].iloc[0]
                        ResultSt['LPFib']=TDF[TDF['I']==i-offset]['LPFib'].iloc[0]
                        ResultSt['LPLevel']=TDF[TDF['I']==i-offset]['LPLevel'].iloc[0]
                        
                        ResultSt['G']=O>C
                        ResultAr.append(ResultSt)
                        Tempi=i
                        pi=pi+1
            i=i+1
    
    ResultDF=pd.DataFrame(ResultAr)
    return ResultDF



def getHighDF(ResultDF):
    return ResultDF[(ResultDF['Type']=="High") & (ResultDF['DiffP']>0.1) & (ResultDF['PDiffP']<-0.1) & (ResultDF['PercHL']>-0.1) & (ResultDF['PercHL']<0.1) &(ResultDF['G']==False) ][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL']]

def getLowDF(ResultDF):
    return ResultDF[(ResultDF['Type']=="Low") & (ResultDF['DiffP']<-0.1) & (ResultDF['PDiffP']>0.1) & ((ResultDF['PercHL']>-0.1) & (ResultDF['PercHL']<0.1)) &(ResultDF['G']==True) ][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL']]

def getChartRangeList(H,L,PivotData):
    PS=['IPivot','L1','L2','L3']
    PR=['IPivot','H1','H2','H3']
    PU=['A0','A236','A382','A500','A618','A786','A1000','A1236','A1382','A1500','A1618','A1786','A2000','A2236','A2382','A2500','A2618','A2786','A3000','A3236','A3382','A3500','A3618','A3786','A4000']
    PL=['Z236','Z382','Z500','Z618','Z786','Z1000','Z1236','Z1382','Z1500','Z1618','Z1786','Z2000','Z2236','Z2382','Z2500','Z2618','Z2786','Z3000','Z3236','Z3382','Z3500','Z3618','Z3786','Z4000']
    PFIB=PU+PL
    PFIBD=PU[::-1]+PL
    PRANGED=list(dict.fromkeys(PR[::-1]+PS))
    PRANGE=PR+PS
    FibList=getChartList(H,L,PFIBD,PFIBD,PivotData)
    RangeList=getChartList(H,L,PRANGED,PRANGED,PivotData)
    return FibList+RangeList
    

def getChartList(H,L,PComp,SortSeries,PivotD):
#PComp=PFIB #PFIB #PRANGE
    i=0
    UBound=""
    LBound=""
    PCompRev=PComp[::-1]
    while(i<len(PComp)-1):
        if(PivotD[PComp[i]]>=L<=PivotD[PComp[i+1]]):
            t=1
        elif(PivotD[PComp[i]]>=L):
            t=1
            if(PivotD[PComp[i+1]]<=L):
 #               print(PComp[i+1] + " => "+str(PivotD[PComp[i+1]]))
                LBound=PComp[i+1]
        if(PivotD[PCompRev[i+1]]>=H<=PivotD[PCompRev[i]]):
            t=1
        elif(PivotD[PCompRev[i]]<=H):
            t=1
            if(PivotD[PCompRev[i+1]]>=H):
#                print(PCompRev[i+1] + " -=> "+str(PivotD[PCompRev[i+1]]))
                UBound=PCompRev[i+1]
        i=i+1
    #print(UBound + "= "+  LBound)
    if(UBound!="" and LBound!=""):
        #print("t")
        return SortSeries[SortSeries.index(UBound):SortSeries.index(LBound)+1]
    else:
        #print("f")
        return []

        


def dispChart(Data1,filename,Symbol):
    #Data=Data1
    LastPivot=pd.read_csv(r"C:\ReadMoneycontrol\Mani 2.0\Data3\\"+Symbol+"-Pivot.csv",encoding='utf-8')
    #ListData=['IPivot','H1','L1','L2','H2','A0','A236','A382','A500','A786']#,'Z236','Z382','Z500','Z786']
    #ListData=['IPivot','H1','H2','H3','A0','A236','A382','A500','A618','A786','A1000','A1236','A1382','A1500','A1618','A2000']
    PivotD=LastPivot.iloc[DateIndex*-1]
    ListData=getChartRangeList(Data1['High'].max(),Data1['Low'].min(),PivotD)
    #ListData=getChartRangeList(Data['High'].max(),Data['Low'].min(),PivotD)
    #ListData=['IPivot','L1','A0','A236','A382','A500','A786']#,'Z236','Z382','Z500','Z786']
    
    date1=parse(parse(PivotD['Date']).strftime("%Y-%m-%d 09:00"))
    date2=parse(parse(PivotD['Date']).strftime("%Y-%m-%d 15:30"))
    
    Lines=[]
    AxisText=[]
    AxisValue=[]
    AxisX=[]
    
    for la in ListData:
        Position=date2
        Symbol1="+"
        value=PivotD[la]
        color='rgb(100, 100, 100)'
        linestyle=3
        if(la.find("A")>=0):
            color='rgb(0, 255, 0)'
            linestyle=2
        if(la.find("Z")>=0):
            color='rgb(255, 0, 0)'
            linestyle=2
        if(la.find("H")>=0):
            color='rgb(0, 0, 255)'
            linestyle=1
            Position=date1
            Symbol1="-"
        if(la.find("L")>=0):
            color='rgb(255,0 , 255)'
            linestyle=1
            Position=date1
            Symbol1="-"
        
        
        Lines.append(candlestick.CreateLinesV1(date1,date2,value,color,linestyle))
        AxisText.append(la)
        AxisValue.append(value)            
        AxisX.append(candlestick.CurrentDate(candlestick.N1(Position,"10M",Symbol1)))
    
    AxisText.append(Symbol)
    AxisValue.append(max(AxisValue))            
    AxisX.append(candlestick.CurrentDate(candlestick.N1(date1,"4H","+")))
    Datesar=list(Data1['Date'])
    Xar=[]
    Xar.append(Datesar[int(len(Datesar)/2)])
    Yar=[]
    Yar.append(Data1['High'].max()*1.001)
    textAr=[]
    textAr.append(Symbol)
    
    trace0 = go.Scatter(x=AxisX,y=AxisValue,text=AxisText, mode='text')
    
    trace=go.Candlestick(x=Datesar,
                               open=Data1['Open'],
                               high=Data1['High'],
                               low=Data1['Low'],
                               close=Data1['Close'])
    data=[trace,trace0]
    #AxisText=[]
    #AxisValue=[]
    #AxisX=[]
    #data=[trace,trace0]
    Layout={}
    Layout["shapes"]=Lines
    #Layout["annotations"]=AnnotationsAr
       
    #annotations
    
    fig2 = {'data': data,'layout': Layout}

    
#
#    fig1 = go.Figure()
#    
#    List_ = list(Data1['Date'])
#    fig1.add_trace( go.Candlestick(x=List_,
#                               open=Data1['Open'],
#                               high=Data1['High'],
#                               low=Data1['Low'],
#                               close=Data1['Close']))
#    fig1.add_trace(go.Scatter(x=Xar,y=Yar,text=textAr, mode='text'))
#    
    plot(fig2,filename=filename+".html")
    
NiftyDay=pd.read_csv(r"C:\ReadMoneycontrol\Mani 2.0\Data\NIFTY50-day.csv")
#DateIndex=4
StockList=pd.read_csv("C:\ReadMoneycontrol\Mani 2.0\StockList.txt")
#DateIndex=126

def LoadData(minute,DateIndex):
    #minute="5minute"
    DataFrameCollection={}
    if(DateIndex<len(NiftyDay)-1):
    #while(DateIndex<len(NiftyDay)-1):
        StartDate=NiftyDay.iloc[(DateIndex)*-1]['Date']
        if(DateIndex!=1):
            EndDate=NiftyDay.iloc[(DateIndex-1)*-1]['Date']
        else:
            EndDate=candlestick.N1(parse(StartDate),"1D","+").strftime("%Y-%m-%d")
        Nifty=pd.read_csv(r"C:\ReadMoneycontrol\Mani 2.0\Data\NIFTY50-"+minute+".csv")
        Nifty.columns=['Date', 'Open', 'High', 'Low', 'Close', 'V']
        NiftyD=Nifty[(Nifty['Date']>StartDate) & (Nifty['Date']<EndDate)]
        DataFrameCollection['NIFTY']=NiftyD
        DataFrameCollection['NIFTY'].sort_values('Date',inplace=True)
        DataFrameCollection['NIFTY'].drop_duplicates(subset ="Date", keep = "first", inplace = True) 
        DataFrameCollection['NIFTY'].reset_index(inplace=True,drop=True)
        #DataFrameCollection['NIFTY'][']
        DataFrameCollection['NIFTY']['HLC']=(DataFrameCollection['NIFTY']['High']+DataFrameCollection['NIFTY']['Low']+DataFrameCollection['NIFTY']['Close'])/3
        Comparison={}
        Comparison["NIFTY"]=list(NiftyD['Open'])
        ki=0
        while(ki<len(StockList)): #len(StockList)
            StockName=StockList.iloc[ki]['Symbol']
            ki=ki+1
            #print(StockName)
            Stockdf=pd.read_csv(r"C:\ReadMoneycontrol\Mani 2.0\Data\\"+StockName+"-"+minute+".csv")
            Stockdf.columns=['Date', 'Open', 'High', 'Low', 'Close', 'V']
            StockD=Stockdf[(Stockdf['Date']>StartDate) & (Stockdf['Date']<EndDate)]
            DataFrameCollection[StockName]=StockD
            DataFrameCollection[StockName].sort_values('Date',inplace=True)
            DataFrameCollection[StockName].drop_duplicates(subset ="Date", keep = "first", inplace = True) 

            DataFrameCollection[StockName].reset_index(inplace=True,drop=True)
            DataFrameCollection[StockName]['HLC']=(DataFrameCollection[StockName]['High']+DataFrameCollection[StockName]['Low']+DataFrameCollection[StockName]['Close'])/3
            Comparison[StockName]=list(StockD['Open'])
    return DataFrameCollection
        


if(False):
    ResultAr=[]
    TInterval=['3minute','5minute','15minute']
    PercentageAr=[0.0002,round(0.0002/3*5,4),round(0.0002/3*15,4)]
    OffsetAr=[5,4,2]
    DateIndex=19
    minute="3minute"
    Min3DF=LoadData(minute,DateIndex)
    iP=PercentageAr[TInterval.index(minute)]
    iO=OffsetAr[TInterval.index(minute)]
    ResultDF03=Process(iP,iO,Min3DF,1)  
    ResultDF3=ResultDF03
    ResultDF03=ResultDF03[(ResultDF03['HLC']!=ResultDF03['OC'])]
    ResultDF03[ResultDF03.duplicated(['Stock','SingleDate'],keep=False)][['Stock','SingleDate','PDiffP','DiffP','PercHL','G','Type']]
    minute="5minute"
    Min5DF=LoadData(minute,DateIndex)
    
        
    iP=PercentageAr[TInterval.index(minute)]
    iO=OffsetAr[TInterval.index(minute)]
    ResultDF05=ProcessZ(iP,iO,Min5DF,1)  
    ResultDF05=Process(iP,iO,Min5DF,1)  
    ResultDF5=ResultDF05
    ResultDF05=ResultDF05[(ResultDF05['HLC']!=ResultDF05['OC'])]
    ResultDF05[ResultDF05.duplicated(['Stock','SingleDate'],keep=False)][['Stock','SingleDate','PDiffP','DiffP','PercHL','G','Type']]
    T1=ResultDF05[ResultDF05.duplicated(['Stock','SingleDate'],keep=False)][['Stock','SingleDate','PDiffP','DiffP','PercHL','G','Type']]
    T1[T1['DiffP']<-.2]
    #ResultDF03['Seq']=False
    ar=[]
    ResultDF03=ResultDF03.sort_values(['Stock','SingleDate'],ascending=[True, True]).reset_index(drop=True)
    pd.options.mode.chained_assignment = None
    Interval="3M"
    #i=888
    
    ResultDF03[ResultDF03['Stock']=="BRITANNIA"]
    ar.append(False)
    for i in range(1, len(ResultDF03)-1):
        
        PTime=parse(ResultDF03.iloc[i-1]['CurrentDate'])
        CTime=parse(ResultDF03.iloc[i]['CurrentDate'])
        NTime=parse(ResultDF03.iloc[i+1]['CurrentDate'])
        if((candlestick.N1(CTime,Interval,"-")==PTime) or (candlestick.N1(CTime,Interval,"+")==NTime)):
            #print("t")
            ar.append(True)
        else:
            ar.append(False)
            #ResultDF03.iloc[i]['Seq']=True
    #    i=i+1
    ar.append(False)
    len(ar)
    
    ResultDF03['Seq']=ar
    ResultDF5=ResultDF05
    ResultDF05=ResultDF05[(ResultDF05['HLC']!=ResultDF05['OC'])]
    ResultDF05[ResultDF05.duplicated(['Stock','SingleDate'],keep=False)][['Stock','SingleDate','PDiffP','DiffP','PercHL','G','Type']]
    
    ResultDF03[['Stock','SingleDate','PDiffP','DiffP','PercHL','Seq']]
    ResultDF05[['Stock','SingleDate','DiffP','PercHL','Hammer']].head()
    ResultDF05['Hammer']
    
    ResultDF05[(ResultDF05['HLC']>=0.3) & (ResultDF05['InvertedHammer']==True)][['Stock',
            'SingleDate','PDiffP','DiffP','HL', 
            'HLC','OC', 'PercHL','G','Type']]
    
    
    ResultDF05[(ResultDF05['HLC']<=-0.3) & (ResultDF05['Hammer']==True)][['Stock',
            'SingleDate','PDiffP','DiffP','HL', 
            'HLC','OC', 'PercHL','G','Type']]
    
    ResultDF05[(ResultDF05['Stock']=="BRITANNIA") & (ResultDF05['Hammer']==True)][['Stock',
            'SingleDate','PDiffP','DiffP','HL', 
            'HLC','OC', 'PercHL','G','Type']]
    
    ResultDF05[(ResultDF05['G']==False) & (ResultDF05['HL']>.3) & (ResultDF05['Hammer']==True)][['Stock',
            'SingleDate','PDiffP','DiffP','HL', 
            'HLC','OC', 'PercHL','G','Type']]
    
    
    ResultDF05[(ResultDF05['G']==False) & (ResultDF05['HL']>.3) & (ResultDF05['InvertedHammer']==True)][['Stock',
            'SingleDate','PDiffP','DiffP','HL', 
            'HLC','OC', 'PercHL','G','Type']]

#ResultDF03.iloc[i+1]    
#
#
#
#
#ResultDF05=Process(iP,iO,Min5DF)  
#ResultDF5=ResultDF05
#ResultAr=[]
#TInterval=['3minute','5minute','15minute']
#PercentageAr=[0.0002,round(0.0002/3*5,4),round(0.0002/3*15,4)]
#OffsetAr=[5,4,2]
#iP=PercentageAr[TInterval.index(minute)]
#iO=OffsetAr[TInterval.index(minute)]
#
#ResultDF05[ResultDF05['Stock']=='KOTAKBANK']
#
#Min5DF["KOTAKBANK"][:10]
#
##Up Trend on duplicates
#TR=ResultDF5[(ResultDF5['HLC']!=ResultDF5['OC']) & (ResultDF5['DiffP']<-0.1) & (ResultDF5['PDiffP']>1)]
##[['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL','Type']]
#TR[['Stock',
#        'CurrentDate','SingleDate','PDiffP','DiffP','HL', 'HLC','OC', 'PercHL','G','Type']]
#
#
#
##Looks Up Trend
#TR=ResultDF5[(ResultDF5['HLC']!=ResultDF5['OC']) & (ResultDF5['DiffP']>-0.1) & (ResultDF5['PDiffP']>1)]
#TR[['Stock',
#        'CurrentDate','SingleDate','PDiffP','DiffP','HL', 'HLC','OC', 'PercHL','G','Type']]
##TR[TR.duplicated(['Stock','SingleDate'])]
#
##Down Trend
#TR=ResultDF5[(ResultDF5['HLC']!=ResultDF5['OC']) & (ResultDF5['DiffP']<0.1) & (ResultDF5['PDiffP']<-1)]
#TR[['Stock',
#        'CurrentDate','SingleDate','PDiffP','DiffP','HL', 'HLC','OC', 'PercHL','G','Type']]