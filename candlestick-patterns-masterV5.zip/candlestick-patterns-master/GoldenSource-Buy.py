# -*- coding: utf-8 -*-
"""
Created on Sat Dec 28 00:47:57 2019

@author: lalitha
"""

Test=T2[ (T2['MaxHL']>1) & (T2['DiffP']<(T2['CFD']*-1)) 
   & (T2['CFD']<.6)
   & (T2['Type']=="Low")
   & (T2['Index']<40)
   & (T2['TPercOL']>T2['CFD'])
   ]

Test1=T2[(T2['InvertedHammer']==True)  
         & (T2['Type']=="High")
         & (T2['PercHL']>-.01) & (T2['PercHL']<.2) 
         & ((T2['HCFib']=="A1382")
         | (T2['HCFib']=="A1786"))
         ]




Test=T2[ (T2['MaxHL']>1) & (T2['Type']=='High') 
& (T2['CFD']>.5)
#& (T2['DiffP']<=0)
& (T2['COC']>1)
& (T2['CHL']>.8)
& (T2['Index']<=3) 
& (T2['MaxHLClr']=="G") 
& (T2['MaxHLIdx']==0) 
& (T2['CGap']<2) 

   ]
