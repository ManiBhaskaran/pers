# -*- coding: utf-8 -*-
"""
Created on Tue Dec 10 19:38:29 2019

@author: lalitha
"""

import pandas as pd
from dateutil.parser import parse
from datetime import datetime, timedelta
minute="5minute"
Re=pd.read_csv(r"C:\ReadMoneycontrol\Mani 2.0\Report\15minuteFO15MinFilter.csv")

Re=pd.read_csv(r"C:\ReadMoneycontrol\Mani 2.0\Temp1\Temp2\TCSResultsH1.csv")
Re=pd.read_csv(r"C:\ReadMoneycontrol\Mani 2.0\ConsolidatedPL\ConsolidatedPL.csv")
Re1=Re[['Index','Stock','CurrentDate','Type','TPercOL','TPercHO','DiffP','PDiffP','TPercHL','CFD','CPD',
     'CGap','PercHL','HCFib','HCLevel','LCFib','LCLevel','MaxHL','MaxHLClr','MaxHLIdx','CC','BuyProfitP','SellProfitP','BuyProfitP1','SellProfitP1']].sort_values(['CurrentDate','Index'],ascending=True)
Re1['CDATE']=pd.to_datetime(Re1['CurrentDate']).dt.strftime("%Y-%b-%d")
CDATES=Re1['CDATE'].unique()
Re1.drop_duplicates(subset =["Stock","CDATE",'Type'], keep = "first", inplace = True) 
SData=Re1




Re1.groupby([
            'Index'])['BuyProfitP','SellProfitP','BuyProfitP1','SellProfitP1'].count()
    
ResultDF05=pd.read_csv(r"C:\ReadMoneycontrol\Mani 2.0\Report\\"+minute+'FO191-400.txt')#5minuteV3.First90
ResultDF05=ResultDF05[ResultDF05['CFD']>.3]

ResultDF05.shape[0]
ResultDF05[ResultDF05['Index']<60].shape[0]
ResultDF05=ResultDF05[ResultDF05['Index']<60]
ResultDF05['CDATE']=pd.to_datetime(ResultDF05['CurrentDate']).dt.strftime("%Y-%b-%d")
ResultDF05.drop_duplicates(subset =["Stock","CurrentDate",'Type'], keep = "first", inplace = True) 

FinalCheckResults=pd.read_csv("C:\ReadMoneycontrol\Mani 2.0\Temp\\FinalCheckResults-100-1.csv")
#ResultDF05=pd.read_csv("C:\ReadMoneycontrol\Mani 2.0\Temp\FinalCheckResults-1-1.csv")
#NiftyDay=pd.read_csv(r"C:\ReadMoneycontrol\Mani 2.0\Data\NIFTY50-day.csv")
pd.set_option('display.max_columns', 500)
pd.set_option('display.max_rows', 1500)
#T2.dtypes
T2=ResultDF05[['Stock','CC',
            'CurrentDate','SingleDate','Index','CGap','PGap','PDiffP','DiffP','MaxHL','MaxHLIdx','MaxHLClr','MaxHLOCP','MaxHP','MaxLP','CHL', 'CHLC','COC','HL', 'HLC','OC', 'PercHL',  'RPercHL','G',
     'SPercCL','SPercHC','SPercHH','SPercHL','SPercLL','SPercOC','TPercCL','TPercHC','TPercHL','TPercHO','TPercOC','TPercOL',       
     'Type','Seq','CFD','CPD','PFD','PPD','HCFib','HCFibV','HCLevel','HCLevelV','LCFib','LCFibV',
            'LCLevel','LCLevelV','HPFib','HPFibV','HPLevel','HPLevelV','LPFib','LPFibV','LPLevel','LPLevelV',
            'HCFib1','LCFib1','HCLevel1','LCLevel1']]
T2[ (T2['MaxHL']>.1) & (T2['Type']=='High') & (T2['Index']<=150) 
& (T2['MaxHLClr']=="R") & (T2['G']==True) & 
   ((T2['PDiffP']>T2['CFD']) | (T2['DiffP']>T2['CFD']) ) & 
   (T2['TPercHL']-T2['SPercHL']>=T2['CFD']) &
   ((T2['PDiffP']+T2['DiffP']<=0.05) &
    (T2['PDiffP']+T2['DiffP']>=-0.05)) ].to_html("C:\ReadMoneycontrol\Mani 2.0\Temp\Results01-01.2-Down.html")


T2[ (T2['MaxHL']>1) & (T2['Type']=='High') & (T2['Index']<=15) & (T2['MaxHLClr']=="G") & 
   ((T2['PDiffP']>T2['CFD']) | (T2['DiffP']>T2['CFD']) ) 
   & (T2['PDiffP']>0.4)
   #& ((T2['PDiffP']+T2['DiffP']<=0.05) &  (T2['PDiffP']+T2['DiffP']>=-0.05)) 
  ].to_html("C:\ReadMoneycontrol\Mani 2.0\Temp\Results01.1.html")

CheckDF=T2[ (T2['MaxHL']>1) & (T2['Type']=='High') & (T2['Index']<=15) & (T2['MaxHLClr']=="G") & 
   ((T2['PDiffP']>T2['CFD']) | (T2['DiffP']>T2['CFD']) ) 
   & (T2['PDiffP']>0.4)
   #& ((T2['PDiffP']+T2['DiffP']<=0.05) &  (T2['PDiffP']+T2['DiffP']>=-0.05)) 
  ]

T2[ (T2['MaxHL']>1) & (T2['Type']=='Low') & (T2['Index']<=15) & (T2['MaxHLClr']=="R") & (T2['G']==False) & 
   ((T2['PDiffP']>T2['CFD']) | (T2['DiffP']>T2['CFD']) ) & 
   ((T2['PDiffP']+T2['DiffP']<=0.05) &  
    (T2['PDiffP']+T2['DiffP']>=-0.05)) ].to_html("C:\ReadMoneycontrol\Mani 2.0\Temp\Results01-DownTrend.html") 


T2[ (T2['MaxHL']>.5) & (T2['Type']=='Low') & (T2['Index']<=15) & (T2['MaxHLClr']=="R") & (T2['G']==True) & 
   ((T2['PDiffP']>T2['CFD']) | (T2['DiffP']>T2['CFD']) ) & 
   ((T2['PDiffP']+T2['DiffP']<=0.05) &  
    (T2['PDiffP']+T2['DiffP']>=-0.05)) ].to_html("C:\ReadMoneycontrol\Mani 2.0\Temp\Results01-UpTrend.html") 



T2[ (T2['MaxHL']>.5) & (T2['Type']=='High') & (T2['Index']<=15) & #(T2['Index']<=40) & 
   (T2['CFD']>0.4) & 
   #(T2['MaxHLClr']=="G") & 
   ((T2['PDiffP']>T2['CFD']) | (T2['DiffP']>T2['CFD']) ) & 
   ((T2['PDiffP']+T2['DiffP']<=0.05) &  
    (T2['PDiffP']+T2['DiffP']>=-0.05)) ].to_html("C:\ReadMoneycontrol\Mani 2.0\Temp\Results01-D2.html") 

T2[ (T2['MaxHL']>.1) & (T2['Type']=='High') & (T2['Index']<=150) 
& (T2['MaxHLClr']=="R") & (T2['G']==False) & 
   ((T2['PDiffP']>T2['CFD']) | (T2['DiffP']>T2['CFD']) ) & 
   (T2['TPercHL']-T2['SPercHL']>=T2['CFD']) &
   ((T2['PDiffP']+T2['DiffP']<=0.05) &  (T2['PDiffP']+T2['DiffP']>=-0.05)) ].to_html("C:\ReadMoneycontrol\Mani 2.0\Temp\Results01-01.2-Down.html")

T2[ (T2['MaxHL']>.1) & (T2['Type']=='High') & (T2['Index']<=150) 
& (T2['MaxHLClr']=="R") & (T2['G']==False) & 
   ((T2['PDiffP']>T2['CFD']) | (T2['DiffP']>T2['CFD']) ) & 
   (T2['TPercHL']-T2['SPercHL']<=T2['CFD']) &
   ((T2['PDiffP']+T2['DiffP']<=0.05) &  (T2['PDiffP']+T2['DiffP']>=-0.05)) ].to_html("C:\ReadMoneycontrol\Mani 2.0\Temp\Results01-01.2-Down.html")

T2[ (T2['CFD']>1) ][['Stock','CurrentDate','CFD','Type','PDiffP','DiffP','PercHL']]
T2[ (T2['CFD']>1) & (T2['Type']=='High') & (T2['PDiffP']>T2['CFD']) & (T2['DiffP']<-.4)][['Stock','CurrentDate','CFD','Type','PDiffP','DiffP','PercHL']].to_html("C:\ReadMoneycontrol\Mani 2.0\Temp\Results-CFDGT1-Down.html")
T2[ (T2['CFD']>1) & (T2['Type']=='Low') & (T2['PDiffP']>T2['CFD']) & (T2['DiffP']<-.4)][['Stock','CurrentDate','CFD','Type','PDiffP','DiffP','PercHL']].to_html("C:\ReadMoneycontrol\Mani 2.0\Temp\Results-CFDGT1-UP.html")

T2[ (T2['CFD']>1) & (T2['PDiffP']>T2['CFD']) & (T2['DiffP']<-.4)][['Stock','CurrentDate','CFD','Type','PDiffP','DiffP','PercHL']]

T2[ (T2['CGap']<-1)][['Stock','CurrentDate','CGap','CFD','Type','PDiffP','DiffP','PercHL']]

T2[ (T2['MaxHL']>1) & (T2['DiffP']<(T2['CFD']*-1)) 
   & (T2['CFD']>.4)].to_html("C:\ReadMoneycontrol\Mani 2.0\Temp\Results01-01.UP Trend.html")








import pandas as pd
from dateutil.parser import parse
from datetime import datetime, timedelta
minute="5minute"

Re=pd.read_csv(r"C:\ReadMoneycontrol\Mani 2.0\Report\\"+minute+'V3.First90.csv')#5minuteV3.First90

Re=pd.read_csv(r"C:\ReadMoneycontrol\Mani 2.0\Temp2.1\RELIANCEResultsH1.csv")
Re1=Re[['Index','Stock','CurrentDate','Type','TPercOL','TPercHO','DiffP','PDiffP','TPercHL','CFD','CPD',
     'CGap','PercHL','HCFib','HCLevel','LCFib','LCLevel','MaxHL','MaxHLClr','MaxHLIdx','CC','BuyProfitP','SellProfitP','BuyProfitP1','SellProfitP1']].sort_values(['CurrentDate','Index'],ascending=True)


ResultDF05=ResultDF05[ResultDF05['CFD']>.3]
Re=ResultDF05

'''

Datas=getRealTimeData("All1")   
#Data1=Datas['SBIN']['day']
#DPivot=getRealTimePivot(Datas)
Min5DF=getSpecificIntervalData(Datas,"5minute",DPivot)
minute="5minute"
TInterval=['3minute','5minute','15minute']
PercentageAr=[0.0002,round(0.0002/3*5,4),round(0.0002/3*15,4)]
OffsetAr=[5,4,2]
iP=PercentageAr[TInterval.index(minute)]
iO=OffsetAr[TInterval.index(minute)]
Date1=datetime.now()
ResultDF05=ProcessZ(iP,iO,Min5DF,1,True) 
print("StockNameStockName : " + str((datetime.now()-Date1).microseconds))
print("StockNameStockName : " + str((datetime.now()-Date1).seconds))

ResultDF05=CheckandMarkSequence(ResultDF05,"5M")
ResultDF05=ResultDF05[(ResultDF05['HLC']!=ResultDF05['OC'])]
ResultDF05['CDATE']=pd.to_datetime(ResultDF05['CurrentDate']).dt.strftime("%Y-%b-%d")
ResultDF051=ResultDF05[ResultDF05['CFD']>.3]
Re=ResultDF05
Re=Re[Re['Index']<60]
index=0
CDATES=Re['CDATE'].unique()
SData=Re[(Re['CDATE']==CDATES[index]) & (Re['CFD']>.3)]
#SData=Re
Re.shape[0]
Re[Re['Index']<60].shape[0]
Re=Re[Re['Index']<60]
Re['CDATE']=pd.to_datetime(Re['CurrentDate']).dt.strftime("%Y-%b-%d")

CDATES=Re['CDATE'].unique()

#ResultDF05['Stock'].unique().shape
#SData=FinalCheckResults[FinalCheckResults['CDATE']==CDATES[11]]
#SData.shape
index=0
SData=Re[(Re['CDATE']==CDATES[index]) & (Re['CFD']>.3)]
#SData1=Re[(Re['CDATE']==CDATES[index]) ]
#SData1[(SData1['MaxHLIdx']==0)].groupby([
#            'Index','MaxHLClr'])['MaxHL'].sum().head(6)
#SData1[(SData1['MaxHLIdx']==0)].groupby([
#            'Index','MaxHLClr'])['MaxHL'].count().head(6)
#SData1[(SData1['MaxHLIdx']==0)].groupby([
#            'Index','MaxHLClr'])['MaxHL'].mean().head(6)
#
SData=ResultDF05[(ResultDF05['CDATE']==CDATES[0]) & (ResultDF05['CC']>40)]
S=SData[['Type','Index','Stock','CurrentDate','TPercHO','TPercOL','DiffP','PDiffP','TPercHL','CFD','CPD',
     'CGap','PercHL','HCFib','HCLevel','LCFib','LCLevel','MaxHL','MaxHLClr','MaxHLIdx','CC']]

S['FPrice']=round(S['CC']*(1-S['CFD']/100),2)
S['FSL']=round(S['CC']*(1+S['CFD']/100*1.5),2)
S['LPrice']=round(S['CC']*(1-S['CPD']/100),2)
S['LSL']=round(S['CC']*(1+S['CPD']/100*1.5),2)

S1=S[ (S['TPercOL']>1) & 
        (S['Type']=='Low') &
        (S['Index']<=30) &
        (S['Index']>=8) &
        (S['PercHL']<S['CFD'])]

S2=S[ (S['TPercHO']>1) & 
        (S['Type']=='High') &
        (S['Index']<=30) &
        (S['Index']>=8) &
        (S['PercHL']<S['CFD']) ]


ScfdL=S[ (S['TPercOL']>1) & 
        (S['Type']=='Low') &
#        (S['Index']<=30) &
        (S['Index']>=4) &
        (S['PercHL']<S['CFD']) &
        (S['CFD']>1)]

ScfdH=S[ (S['TPercHO']>1) & 
        (S['Type']=='High') &
#        (S['Index']<=30) &
        (S['Index']>=4) &
        (S['PercHL']<S['CFD']) &
        (S['CFD']>1)]


SGapUpH=S[ (S['CGap']>1) & 
        (S['Type']=='High') &
        (S['Index']<=30) &
        (S['Index']>=5) ]

SGapUpL=S[ (S['CGap']>1) & 
        (S['Type']=='Low') &
        (S['Index']<=30) &
        (S['Index']>=5) ]


SGapDownH=S[ (S['CGap']<-1) & 
        (S['Type']=='High') &
        (S['Index']<=30) &
        (S['Index']>=5) ]

SGapDownL=S[ (S['CGap']<-1) & 
        (S['Type']=='Low') &
        (S['Index']<=30) &
        (S['Index']>=5) ]

#(SData1['MaxHL']>1) & (SData1['MaxHLClr']=="R") & 
Test=SData[ 
    (SData['PercHL']>-.2) & (SData['PercHL']<.2) &
     #& (SData['TPercOL']<.3) 
#          (SData['CFD']>.4) &
#    & (SData['TPercHL']>1) &
#     (SData['TPercHL']>=2) &
#     (SData['PercHL']<SData['CFD']) &
     (SData['TPercHO']>=SData['CFD']*2) &
        
        (SData['Type']=="High") 
        & (((SData['HCFib']=="A1500") | (SData['HCFib']=="A2000") 
        | (SData['HCFib']=="A1786")
        | (SData['HCFib']=="A1618")
        | (SData['HCFib']=="A2236")
        | (SData['HCFib']=="A1236")
        | (SData['HCFib']=="A2382")
        | (SData['HCFib']=="A1382")
        | (SData['HCFib']=="A2500")) | ((SData['HCLevel']=="H1") | (SData['HCLevel']=="H2")))
][['Index','Stock','CurrentDate','TPercHO','TPercOL','DiffP','PDiffP','TPercHL','CFD','CPD',
     'CGap','PercHL','HCFib','HCLevel','MaxHL','MaxHLClr','MaxHLIdx','CC']].sort_values('Index',ascending=True)

Test['PPoints']=round(Test['CC']*(Test['CFD']/100),2)
Test['SLPoints']=round(Test['CC']*(Test['CFD']/100*1.5),2)    
Test['FPrice']=round(Test['CC']*(1-Test['CFD']/100),2)
Test['FSL']=round(Test['CC']*(1+Test['CFD']/100*1.5),2)
Test['LPrice']=round(Test['CC']*(1-Test['CPD']/100),2)
Test['LSL']=round(Test['CC']*(1+Test['CPD']/100*1.5),2)

Test1=SData[
     (SData['PercHL']>-.2) & (SData['PercHL']<.2) &
#    (SData['PercHL']<SData['CFD']) &
     #& (SData['TPercHO']<.3) 
     (SData['TPercOL']>=SData['CFD']*2) &
#     (SData['CFD']>.4) &
#     (SData['TPercHL']>2) 
#     &
        (SData['Type']=="Low") 
#        & (
#        (
#        (SData['LCFib']=="Z1500") 
#        | (SData['LCFib']=="Z2000") 
#        | (SData['LCFib']=="Z1786")
#        | (SData['LCFib']=="Z1000")
#        | (SData['LCFib']=="Z1236")
#        | (SData['LCFib']=="Z786")
#        | (SData['LCFib']=="Z236")
#        | (SData['LCFib']=="Z1618")
#        | (SData['LCFib']=="Z2236")
#        | (SData['LCFib']=="Z2382")
#        | (SData['LCFib']=="Z2500")) 
#        | ((SData['LCLevel']=="L1") | (SData['LCLevel']=="L2") 
#        |  (SData['LCLevel']=="L3") | (SData['LCLevel']=="L4")))
#      
     ][['Index','Stock','CurrentDate','TPercHO','TPercOL','DiffP','PDiffP','TPercHL','CFD','CPD',
     'CGap','PercHL','LCFib','LCLevel','MaxHL','MaxHLClr','MaxHLIdx','CC']].sort_values('Index',ascending=True)
Test1['PPoints']=round(Test1['CC']*(Test1['CFD']/100),2)
Test1['SLPoints']=round(Test1['CC']*(Test1['CFD']/100*1.5),2)
Test1['Price']=round(Test1['CC']*(1+Test1['CFD']/100),2)
Test1['SL']=round(Test1['CC']*(1-Test1['CFD']/100*1.5),2)
Test1['LPrice']=round(Test1['CC']*(1+Test1['CPD']/100),2)
Test1['LSL']=round(Test1['CC']*(1-Test1['CPD']/100*1.5),2)





'''


Re.shape[0]
Re[Re['Index']<60].shape[0]
Re=Re[Re['Index']<60]
Re['CDATE']=pd.to_datetime(Re['CurrentDate']).dt.strftime("%Y-%b-%d")

CDATES=Re['CDATE'].unique()
#ResultDF05['Stock'].unique().shape
#SData=FinalCheckResults[FinalCheckResults['CDATE']==CDATES[11]]
#SData.shape
index=0
SData=Re[(Re['CDATE']==CDATES[index]) & (Re['CFD']>.3)]
#SData1=Re[(Re['CDATE']==CDATES[index]) ]
#SData1[(SData1['MaxHLIdx']==0)].groupby([
#            'Index','MaxHLClr'])['MaxHL'].sum().head(6)
#SData1[(SData1['MaxHLIdx']==0)].groupby([
#            'Index','MaxHLClr'])['MaxHL'].count().head(6)
#SData1[(SData1['MaxHLIdx']==0)].groupby([
#            'Index','MaxHLClr'])['MaxHL'].mean().head(6)
#
#S=SData[['Index','Stock','CurrentDate','TPercHO','TPercOL','DiffP','PDiffP','TPercHL','CFD','CPD',
#     'CGap','PercHL','HCFib','HCLevel','LCFib','LCLevel','MaxHL','MaxHLClr','MaxHLIdx','CC']]
#
#S['FPrice']=round(S['CC']*(1-S['CFD']/100),2)
#S['FSL']=round(S['CC']*(1+S['CFD']/100*1.5),2)
#S['LPrice']=round(S['CC']*(1-S['CPD']/100),2)
#S['LSL']=round(S['CC']*(1+S['CPD']/100*1.5),2)
#


#(SData1['MaxHL']>1) & (SData1['MaxHLClr']=="R") & 
Test=SData[ 
        #(SData['PercHL']>-.2) & (SData['PercHL']<.2) &
     #& (SData['TPercOL']<.3) 
     
#    & (SData['TPercHL']>1) &
#     (SData['TPercHL']>=2) &
     (SData['TPercHO']>=SData['CFD']*2) &
        
        (SData['Type']=="High") 
#        & (((SData['HCFib']=="A1500") | (SData['HCFib']=="A2000") 
#        | (SData['HCFib']=="A1786")
#        | (SData['HCFib']=="A1618")
#        | (SData['HCFib']=="A2236")
#        | (SData['HCFib']=="A1236")
#        | (SData['HCFib']=="A2382")
#        | (SData['HCFib']=="A1382")
#        | (SData['HCFib']=="A2500")) | ((SData['HCLevel']=="H1") | (SData['HCLevel']=="H2")))
][['Index','Stock','CurrentDate','TPercHO','TPercOL','DiffP','PDiffP','TPercHL','CFD','CPD',
     'CGap','PercHL','HCFib','HCLevel','MaxHL','MaxHLClr','MaxHLIdx','CC']].sort_values('Index',ascending=True)
     
Test['FPrice']=round(Test['CC']*(1-Test['CFD']/100),2)
Test['FSL']=round(Test['CC']*(1+Test['CFD']/100*1.5),2)
Test['LPrice']=round(Test['CC']*(1-Test['CPD']/100),2)
Test['LSL']=round(Test['CC']*(1+Test['CPD']/100*1.5),2)

Test1=SData[
        #(SData['PercHL']>-.2) & (SData['PercHL']<.2) &
     #& (SData['TPercHO']<.3) 
     (SData['TPercOL']>=SData['CFD']*2.5) &
#     (SData['TPercHL']>1) 
#     &
        (SData['Type']=="Low") 
#        & (((SData['LCFib']=="Z1500") | (SData['LCFib']=="Z2000") 
#        | (SData['LCFib']=="Z1786")
#        | (SData['LCFib']=="Z1000")
#        | (SData['LCFib']=="Z1236")
#        | (SData['LCFib']=="Z786")
#        | (SData['LCFib']=="Z1618")
#        | (SData['LCFib']=="Z2236")
#        | (SData['LCFib']=="Z2382")
#        | (SData['LCFib']=="Z2500")) 
#        | ((SData['LCLevel']=="L1") | (SData['LCLevel']=="L2") 
#        |  (SData['LCLevel']=="L3") | (SData['LCLevel']=="L4")))
#      
     ][['Index','Stock','CurrentDate','TPercHO','TPercOL','DiffP','PDiffP','TPercHL','CFD','CPD',
     'CGap','PercHL','LCFib','LCLevel','MaxHL','MaxHLClr','MaxHLIdx','CC']].sort_values('Index',ascending=True)

Test1['Price']=round(Test1['CC']*(1+Test1['CFD']/100),2)
Test1['SL']=round(Test1['CC']*(1-Test1['CFD']/100*1.5),2)
Test1['LPrice']=round(Test1['CC']*(1+Test1['CPD']/100),2)
Test1['LSL']=round(Test1['CC']*(1-Test1['CPD']/100*1.5),2)







Test=Re[['Index','Stock','CurrentDate','Type','TPercOL','TPercHO','DiffP','PDiffP','TPercHL','CFD','CPD',
     'CGap','PercHL','HCFib','HCLevel','LCFib','LCLevel','MaxHL','MaxHLClr','MaxHLIdx','CC']].sort_values(['CurrentDate','Index'],ascending=True)

Re1.groupby([
            'Index'])['BuyProfitP','SellProfitP','BuyProfitP1','SellProfitP1'].count()


Re1=Re[['Index','Stock','CurrentDate','Type','TPercOL','TPercHO','DiffP','PDiffP','TPercHL','CFD','CPD',
     'CGap','PercHL','HCFib','HCLevel','LCFib','LCLevel','MaxHL','MaxHLClr','MaxHLIdx','CC','BuyProfitP','SellProfitP','BuyProfitP1','SellProfitP1']].sort_values(['CurrentDate','Index'],ascending=True)
Re1=Re1[200:]
Re1['CDATE']=pd.to_datetime(Re1['CurrentDate']).dt.strftime("%Y-%b-%d")
CDATES=Re1['CDATE'].unique()
Re1.drop_duplicates(subset =["Stock","CDATE",'Type'], keep = "first", inplace = True) 
uc=Re1[
     (Re1['Type']=='High') & 
     (Re1['HCLevel']!='H1') & 
     (Re1['TPercHO']>=Re1['CFD']*2) 
     ]
Re1[
#     (Re1['PercHL']>-.2) & (Re1['PercHL']<.2)) &
     #(Re1['PercHL']<Re1['CFD']) &
     (Re1['Type']=='High') & 
     (Re1['HCLevel']!='H1') & 
     (Re1['TPercHO']>=Re1['CFD']*2) 
     
#     (Re1['DiffP']>.1) &
     #(Re1['TPercHL']>1.9) 
#     & (Re1['TPercHO']>1)
#     & (Re1['TPercOL']<Re1['CFD']/2)
#     & (Re1['PDiffP']<Re1['CFD']) 
#     & (Re1['Index']<15) 
     ][['BuyProfitP','SellProfitP','BuyProfitP1','SellProfitP1']].sum()



ulow=Re1[
#     (Re1['PercHL']>-.2) & (Re1['PercHL']<.2)) &
#     (Re1['PercHL']<Re1['CFD']) &
     (Re1['Type']=='Low') & 
     (Re1['TPercOL']>=Re1['CFD']*2) &
     (Re1['LCLevel']!='L1') 
#     (Re1['DiffP']<-.1) &
#     (Re1['TPercHL']>1.9) 
#     & (Re1['Index']<15) 
     ]

Re1[
#     (Re1['PercHL']>-.2) & (Re1['PercHL']<.2)) &
#     (Re1['PercHL']<Re1['CFD']) &
     (Re1['Type']=='Low') & 
     (Re1['TPercOL']>=Re1['CFD']*2) &
     (Re1['LCLevel']!='L1') 
#     (Re1['DiffP']<-.1) &
#     (Re1['TPercHL']>1.9) 
#     & (Re1['Index']<15) 
     ][['BuyProfitP','SellProfitP','BuyProfitP1','SellProfitP1']].sum()

Test=Re1[(
     (Re1['PercHL']>-.2) & (Re1['PercHL']<.2)) &
     (Re1['Type']=='Low') 
     #& (Re1['DiffP']<-.1) 
     & (Re1['TPercHO']<.3) 
     
    & (Re1['TPercHL']>1.9) 
     ]

Test['FPrice']=round(Test['CC']*(1-Test['CFD']/100),2)
Test['FSL']=round(Test['CC']*(1+Test['CFD']/100*1.5),2)
Test['LPrice']=round(Test['CC']*(1-Test['CPD']/100),2)
Test['LSL']=round(Test['CC']*(1+Test['CPD']/100*1.5),2)


D1=Re1[(
     (Re1['PercHL']>-.2) & (Re1['PercHL']<.2)) &
     (Re1['Type']=='Low') 
     #& (Re1['DiffP']<-.1) 
     & (Re1['TPercHO']>.3) 
     
    & (Re1['TPercHL']>1.9) 
     ]
[['BuyProfitP','SellProfitP','BuyProfitP1','SellProfitP1']].sum()

Test1=Re1[(
     (Re1['PercHL']>-.2) & (Re1['PercHL']<.2)) &
     (Re1['Type']=='High') 
     #& (Re1['DiffP']>.1) &
     & (Re1['TPercHL']>1.9) 
     & (Re1['TPercOL']<.3) 
     ]

Test1['Price']=round(Test1['CC']*(1+Test1['CFD']/100),2)
Test1['SL']=round(Test1['CC']*(1-Test1['CFD']/100*1.5),2)
Test1['LPrice']=round(Test1['CC']*(1+Test1['CPD']/100),2)
Test1['LSL']=round(Test1['CC']*(1-Test1['CPD']/100*1.5),2)



c1=Re1[(
     (Re1['PercHL']>-.2) & (Re1['PercHL']<.2)) &
     (Re1['Type']=='High') 
     #& (Re1['DiffP']>.1) &
     & (Re1['TPercHL']>1.9) 
     & (Re1['TPercOL']>.3) 
     ]