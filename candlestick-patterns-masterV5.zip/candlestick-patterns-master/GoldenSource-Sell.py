# -*- coding: utf-8 -*-
"""
Created on Sat Dec 28 00:47:57 2019

@author: lalitha
"""

Test1=T2[
         (T2['LPFib'].notnull()==True)  &
         (T2['HPFib'].notnull()==False)  &
          (T2['Type']=="High")
          & ((T2['TPercHO']>T2['CFD']*1)
          | (T2['TPercOL']<T2['CFD']))
          &(T2['CFD']<1.5)
#&          ((T2['PDiffP']>T2['CFD']) | (T2['DiffP']>T2['CFD']) ) 
          & (T2['MaxHL']>1)
         & (T2['PercHL']>-.01) & (T2['PercHL']<.2) 
         #& ((T2['HCFib']=="A1382")
         #| (T2['HCFib']=="A1786"))
         ]



Test=T2[ (T2['MaxHL']>1) & (T2['DiffP']<(T2['CFD']*1)) 
   & (T2['CFD']<.6)
   & (T2['Type']=="High")
   & (T2['Index']<20)
   & (T2['TPercOL']<T2['CFD'])
   & (T2['PercHL']>-.01) & (T2['PercHL']<.2) 
   #& (T2['PercHL']>=.2)
   ]


Test=SData[ (SData['MaxHL']>.1) & (SData['Type']=='High') & (SData['Index']<=150) 
& (SData['MaxHLClr']=="R") & (SData['G']==False) 

    & 
   ((SData['PDiffP']>SData['CFD']) | (SData['DiffP']>SData['CFD']) ) 
#   & 
#   (SData['TPercHL']-SData['SPercHL']>=SData['CFD']) 
   
   & ((SData['PDiffP']+SData['DiffP']<=0.05) &  (SData['PDiffP']+SData['DiffP']>=-0.05)) 
   ]



Test=SData[ 
    (SData['PercHL']>-.01) & (SData['PercHL']<.2) &
#    (SData['Index']>20) &
    (SData['Index']<=20) &
    (SData['CFD']<=1) &
    (SData['CC']<1200) &
    (SData['CGap']>-.01) & (SData['CGap']<1) &
    #(SData['CC']<=600) &
     (SData['TPercOL']<SData['TPercHO']) &
#          (SData['CFD']>.4) &
#    & (SData['TPercHL']>1) &
#     (SData['TPercHL']>=2) &
#     (SData['PercHL']<SData['CFD']) &
#     (SData['TPercHO']>=SData['CFD']*2) &
     (SData['TPercHO']>=SData['CFD']*1.5) &
     (SData['MaxHL']>1) &        
        (SData['Type']=="High") 
        & (SData['HCLevel']!="H1")
        & (((SData['HCFib']=="A1500") | (SData['HCFib']=="A2000") 
        | (SData['HCFib']=="A1786")
        | (SData['HCFib']=="A1618")
        | (SData['HCFib']=="A2236")
        | (SData['HCFib']=="A1236")
        | (SData['HCFib']=="A2382")
        | (SData['HCFib']=="A1382")
        | (SData['HCFib']=="A2500")) 
##(SData['HCLevel']=="H1") | 
        | ((SData['HCLevel']=="H2")| (SData['HCLevel']=="H3")| (SData['HCLevel']=="H4")))
]





























###############################
#TO BE Evaluated


Test=T2[ (T2['MaxHL']>1) & (T2['Type']=='High') 
#& ((abs(T2['TPercHL'])-abs(T2['TPercHO']))/abs(T2['TPercHO'])*100<10) 
#& ((T2['HCFib']=="A1500") | (T2['HCFib']=="A2000") 
#        | (T2['HCFib']=="A1786")
#        | (T2['HCFib']=="A1618")
#        | (T2['HCFib']=="A2236")
#        | (T2['HCFib']=="A1236")
#        | (T2['HCFib']=="A2382")
#        | (T2['HCFib']=="A1382")
#        | (T2['HCFib']=="A2500")) 
& (T2['CFD']>.5)
& (T2['CFD']<1)
#& (T2['DiffP']<=0)
& (T2['COC']>1)
& (T2['CHL']>.8)
#& (T2['Index']<=10) 
& (T2['MaxHLClr']=="R") 
#& (T2['MaxHLIdx']!=0) 
& (T2['CGap']<1) 
& (T2['CGap']>-1)
#& (T2['G']==False) 

     
   #((T2['PDiffP']>T2['CFD']*3) | (T2['DiffP']>T2['CFD']*3) ) 
#   & 
#   (T2['TPercHL']-T2['SPercHL']>=T2['CFD']) 
   
#   & ((T2['PDiffP']+T2['DiffP']<=0.05) &  (T2['PDiffP']+T2['DiffP']>=-0.05)) 
   ]