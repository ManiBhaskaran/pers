
"""
Created on Fri Nov 29 23:04:37 2019

@author: lalitha
"""

import jhtalib as ta
import requests
from dateutil.parser import parse
import plotly.graph_objs as go
from plotly import __version__
from plotly.offline import download_plotlyjs, init_notebook_mode, plot, iplot
import numpy as np
import plotly.io as pio
import os


from sklearn.model_selection import train_test_split    
from sklearn.tree import DecisionTreeRegressor
from sklearn.tree import DecisionTreeClassifier
from sklearn import metrics


#import datetime
import threading

from candlestick import candlestick
#import datetime
import pandas as pd
import json
import time
from dateutil.parser import parse
from datetime import datetime, timedelta
pd.set_option('display.max_columns', 500)
pd.set_option('display.max_rows', 1500)
#from datetime import datetime

DIRNIFTY="C:\ReadMoneycontrol\Mani 2.0"
DIRFO="C:\ReadMoneycontrol\Mani 2.0\\2"
DIRNIFTYStockList="C:\ReadMoneycontrol\Mani 2.0\StockList.txt"
DIRFOStockList="C:\ReadMoneycontrol\Mani 2.0\StockList-New.txt"
DIRNIFTYStockListID="C:\ReadMoneycontrol\Mani 2.0\StockListIDOriginal.txt"
DIRFOStockListID="C:\ReadMoneycontrol\Mani 2.0\StockListID-NEW.csv"

DataDir=DIRNIFTY
#StockListFile=DIRFOStockList
#RealTime=DIRFOStockListID
#DataDir=DIRNIFTY
StockListFile=DIRNIFTYStockList
RealTime=DIRNIFTYStockListID

StockList=pd.read_csv(StockListFile)


def isPeak(arr, n, num, i, j): 

	# If num is smaller than the element 
	# on the left (if exists) 
	if (i >= 0 and arr[i] > num): 
		return False

	# If num is smaller than the element 
	# on the right (if exists) 
	if (j < n and arr[j] > num): 
		return False
	return True

# Function that returns true if num is 
# smaller than both arr[i] and arr[j] 
def isTrough(arr, n, num, i, j): 

	# If num is greater than the element 
	# on the left (if exists) 
	if (i >= 0 and arr[i] < num): 
		return False

	# If num is greater than the element 
	# on the right (if exists) 
	if (j < n and arr[j] < num): 
		return False
	return True

def printPeaksTroughs(arr, n): 

	print("Peaks : ", end = "") 

	# For every element 
	for i in range(n): 

		# If the current element is a peak 
		if (isPeak(arr, n, arr[i], i - 1, i + 1)): 
			print(arr[i], end = " ") 
	print() 

	print("Troughs : ", end = "") 

	# For every element 
	for i in range(n): 

		# If the current element is a trough 
		if (isTrough(arr, n, arr[i], i - 1, i + 1)): 
			print(arr[i], end = " ") 



def Process(iPercentage,ioffset,DataFrameCollection):    
    ResultAr=[]
    p=-1
    while(p<len(StockList)-1):
        p=p+1
        #print(StockList.iloc[p]['Symbol'])
        Symbol=StockList.iloc[p]['Symbol']
        Data=DataFrameCollection[StockList.iloc[p]['Symbol']].fillna(0)
        LastPivot=pd.read_csv(DataDir+r"\Data3\\"+Symbol+"-Pivot.csv",encoding='utf-8')
        PivotD=LastPivot.iloc[DateIndex*-1]
        i=0
        Percentage=iPercentage
        offset=ioffset
        T=round(Data.iloc[0]['Open']*Percentage,2)
        HighList=[]
        LowList=[]
        
        
        while(i<len(Data)):
            ResultSt={}
            H=Data.iloc[i]['High']
            L=Data.iloc[i]['Low']
            #H=Data['High'].max()
            #L=Data['Low'].max()
        #PivotD
            RangeList=getChartRangeList(H,L,PivotD)
                
            
            for R in RangeList:
                #R="A1000"
                if( H==PivotD[R]):
                    #print(R+" High Same" + Data.iloc[i]['Date'])
                    HighList.append(i)
                elif( H+T>=PivotD[R]>=H-T):
                    #print(str(i)+ "==> "+ R+" High Approx " + Data.iloc[i]['Date'] +" - "+ str(H+T) + " = " + str(PivotD[R]) + " = "+ str(H-T))
                    HighList.append(i)
                if( L==PivotD[R]):
                    #print(R+" Low Same" + Data.iloc[i]['Date'])
                    LowList.append(i)
                elif( L+T>=PivotD[R]>=L-T):
                    #print(str(i)+ "==> "+ R+" Low Approx " + Data.iloc[i]['Date'] +" - "+ str(L+T) + " = " + str(PivotD[R]) + " = "+ str(L-T))
                    LowList.append(i)    
            
            if(str(HighList).find(str(i-offset)+"")>0):
                a=isPeak(Data['High'][:i], len(Data['High'][:i]), Data.iloc[i-offset]['High'], i-(offset*2), i)
                if(a):
                    #ResultSt={}
                    Diff=round(Data.iloc[i-offset]['High']-Data.iloc[i]['High'],2)
                    DiffP=round(Diff/Data.iloc[i]['High']*100,2)
                    PDiff=round(Data.iloc[i-(offset*2)]['High']-Data.iloc[i-offset]['High'],2)
                    PDiffP=round(PDiff/Data.iloc[i-offset]['High']*100,2)
                    #print(str(i)+ " - " + Data.iloc[i]['Date'] + " HIGH - " +Data.iloc[i-offset]['Date'] + " - " + str(a) + " - " + str(Diff) + " ~ " + str(DiffP));                    
                    ResultSt['Stock']=Symbol
                    ResultSt['Index']=i
                    ResultSt['CurrentDate']=Data.iloc[i]['Date']
                    ResultSt['Type']='High'
                    ResultSt['SingleDate']=Data.iloc[i-offset]['Date']
                    ResultSt['Diff']=Diff
                    ResultSt['DiffP']=DiffP
                    ResultSt['PDiff']=PDiff
                    ResultSt['PDiffP']=PDiffP
                    
                    
                    ResultSt['PercHL']=round((Data.iloc[:i]['High'].max()-Data.iloc[i-offset]['High']+0.00001)/Data.iloc[i-offset]['High']*100,2)
                    H,L,C,O=list(Data.iloc[i-offset][['High',"Low","Close","Open"]])
                    ResultSt['HLC']=round((H-C)/C*100,2)
                    ResultSt['HL']=round((H-L)/L*100,2)
                    ResultSt['OC']=round((O-C)/C*100,2)
                    ResultSt['G']=O>C
                    ResultAr.append(ResultSt)
            if(str(LowList).find(str(i-offset)+"")>0):
                Trough=isTrough(Data['Low'][:i], len(Data['Low'][:i]), Data.iloc[i-offset]['Low'], i-(offset*2), i-1)
                if(Trough):
                    #ResultSt={}
                    Diff=round(Data.iloc[i-offset]['Low']-Data.iloc[i]['Low'],2)
                    DiffP=round(Diff/Data.iloc[i]['Low']*100,2)
                    PDiff=round(Data.iloc[i-(offset*2)]['Low']-Data.iloc[i-offset]['Low'],2)
                    PDiffP=round(PDiff/Data.iloc[i-offset]['Low']*100,2)
                    #print(str(i)+ " - "+Data.iloc[i]['Date'] + " Low - " +Data.iloc[i-offset]['Date'] + " - " + str(Trough)+ " - " + str(Diff) + " ~ " + str(DiffP));    
                    ResultSt['Stock']=Symbol
                    ResultSt['Index']=i
                    ResultSt['CurrentDate']=Data.iloc[i]['Date']
                    ResultSt['Type']='Low'
                    ResultSt['SingleDate']=Data.iloc[i-offset]['Date']
                    ResultSt['Diff']=Diff
                    ResultSt['DiffP']=DiffP
                    ResultSt['PDiff']=PDiff
                    ResultSt['PDiffP']=PDiffP
                    ResultSt['PercHL']=round((Data.iloc[:i]['Low'].min()-Data.iloc[i-offset]['Low']+0.00001)/Data.iloc[i-offset]['Low']*100,2)
                    H,L,C,O=list(Data.iloc[i-offset][['High',"Low","Close","Open"]])
                    ResultSt['HLC']=round((L-C)/C*100,2)
                    ResultSt['HL']=round((H-L)/L*100,2)
                    ResultSt['OC']=round((O-C)/C*100,2)
                    ResultSt['G']=O>C
                    ResultAr.append(ResultSt)
            i=i+1
    
    ResultDF=pd.DataFrame(ResultAr)
    return ResultDF


def getHighDF(ResultDF):
    return ResultDF[(ResultDF['Type']=="High") & (ResultDF['DiffP']>0.1) & (ResultDF['PDiffP']<-0.1) & (ResultDF['PercHL']>-0.1) & (ResultDF['PercHL']<0.1) &(ResultDF['G']==False) ][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL']]

def getLowDF(ResultDF):
    return ResultDF[(ResultDF['Type']=="Low") & (ResultDF['DiffP']<-0.1) & (ResultDF['PDiffP']>0.1) & ((ResultDF['PercHL']>-0.1) & (ResultDF['PercHL']<0.1)) &(ResultDF['G']==True) ][['SingleDate','Stock','PDiffP','DiffP','PercHL','HLC','OC','HL']]

def getChartRangeList(H,L,PivotData):
    PS=['IPivot','L1','L2','L3']
    PR=['IPivot','H1','H2','H3']
    PU=['A0','A236','A382','A500','A618','A786','A1000','A1236','A1382','A1500','A1618','A1786','A2000','A2236','A2382','A2500','A2618','A2786','A3000','A3236','A3382','A3500','A3618','A3786','A4000']
    PL=['Z236','Z382','Z500','Z618','Z786','Z1000','Z1236','Z1382','Z1500','Z1618','Z1786','Z2000','Z2236','Z2382','Z2500','Z2618','Z2786','Z3000','Z3236','Z3382','Z3500','Z3618','Z3786','Z4000']
    PFIB=PU+PL
    PFIBD=PU[::-1]+PL
    PRANGED=list(dict.fromkeys(PR[::-1]+PS))
    PRANGE=PR+PS
    FibList=getChartList(H,L,PFIBD,PFIBD,PivotData)
    RangeList=getChartList(H,L,PRANGED,PRANGED,PivotData)
    return FibList+RangeList
    

def getChartList(H,L,PComp,SortSeries,PivotD):
#PComp=PFIB #PFIB #PRANGE
    i=0
    UBound=""
    LBound=""
    PCompRev=PComp[::-1]
    while(i<len(PComp)-1):
        if(PivotD[PComp[i]]>=L<=PivotD[PComp[i+1]]):
            t=1
        elif(PivotD[PComp[i]]>=L):
            t=1
            if(PivotD[PComp[i+1]]<=L):
 #               print(PComp[i+1] + " => "+str(PivotD[PComp[i+1]]))
                LBound=PComp[i+1]
        if(PivotD[PCompRev[i+1]]>=H<=PivotD[PCompRev[i]]):
            t=1
        elif(PivotD[PCompRev[i]]<=H):
            t=1
            if(PivotD[PCompRev[i+1]]>=H):
#                print(PCompRev[i+1] + " -=> "+str(PivotD[PCompRev[i+1]]))
                UBound=PCompRev[i+1]
        i=i+1
    #print(UBound + "= "+  LBound)
    if(UBound!="" and LBound!=""):
        #print("t")
        return SortSeries[SortSeries.index(UBound):SortSeries.index(LBound)+1]
    else:
        #print("f")
        return []

def ProcessZ(iPercentage,ioffset,DataFrameCollection,y,RealTime):    
    global dd
    ResultAr=[]
    p=0 #####NEED TO CHANGE TO -1
    while(p<len(StockList)-1):
        p=p+1
        #print(StockList.iloc[p]['Symbol'])
        #iPercentage=iP
        #ioffset=iO
        #y=1
        #Symbol="ZEEL"
        #DataFrameCollection=Min5DF
        #RealTime=False
        Symbol=StockList.iloc[p]['Symbol']
        Data1=DataFrameCollection[StockList.iloc[p]['Symbol']].fillna(0)
        #Data1=Min5DF[Symbol]
        Data1=candlestick.doji(Data1)
        Data1=candlestick.doji_star(Data1)
        Data1=candlestick.hammer(Data1)
        Data1=candlestick.inverted_hammer(Data1)
        if(str(Data1['Date'].dtype)=='object'):
            SearchDate=parse(Data1['Date'][0]).strftime("%Y-%m-%d")
        else:
            SearchDate=Data1['Date'][0].strftime("%Y-%m-%d")
        #dd=Data
        if(RealTime==False):
            LastPivot=pd.read_csv(DataDir+r"\Data3\\"+Symbol+"-Pivot.csv",encoding='utf-8')
            LastPivot.drop_duplicates(subset =["Date"], keep = "first", inplace = True)
            LastPivot.reset_index(inplace=True)
#            PivotD=LastPivot.iloc[DateIndex*-1]
#            PivotD1=LastPivot.iloc[(DateIndex+1)*-1]
#            PivotD2=LastPivot.iloc[(DateIndex+2)*-1]
            

            PivotDPD=LastPivot[LastPivot['Date']==SearchDate]
            Idx=PivotDPD.index[0]
            PivotD=LastPivot.iloc[Idx]
            PivotD1=LastPivot.iloc[Idx-1]
            PivotD2=LastPivot.iloc[Idx-2]
            CGap=round((PivotD['Open']-PivotD1['Close']+0.000001)/PivotD1['Close']*100,2)
            PGap=round((PivotD1['Open']-PivotD2['Close']+0.000001)/PivotD2['Close']*100,2)
        else:
            PivotD=DPivot[DPivot['Symbol']==Symbol].iloc[1]
            PivotD1=DPivot[DPivot['Symbol']==Symbol].iloc[0]
            CGap=round((PivotD['Open']-PivotD1['Close']+0.000001)/PivotD1['Close']*100,2)
            PGap=0
        i=0
        Percentage=iPercentage
        offset=ioffset
        T=round(Data1.iloc[0]['Open']*Percentage,2)
        
        HighList=[]
        LowList=[]
        
        PHighList=[]
        PLowList=[]
        CFD=round((PivotD['A236']-PivotD['A0'])/PivotD['A0']*100,2)
        PFD=round((PivotD1['A236']-PivotD1['A0'])/PivotD1['A0']*100,2)
        CPD=round((PivotD['H2']-PivotD['H1'])/PivotD['H1']*100,2)
        PPD=round((PivotD1['H2']-PivotD1['H1'])/PivotD1['H1']*100,2)
        
        Tempi=-2
        
        FibListar=[]
        LFibListar=[]
        MaxHL=[]
        MaxOC=[]
        MaxOCP=[]
        MaxHP=[]
        MaxLP=[]
        MaxBP=[]
        while(i<len(Data1)):
            #print(i)
            FibListSt={}
            #FibListSt={}
            Data=Data1[:i+y]
            ResultSt={}
            H,L,C,O=list(Data.iloc[i][['High',"Low","Close","Open"]])
            MaxHL.append(round((H-L+0.000001)/L*100,2))
            
            MaxOCP.append(round((O-C+0.000001)/C*100,2))
            if(O>C):
                MaxHP.append(round((H-O+0.000001)/O*100,2))
                MaxLP.append(round((C-L+0.000001)/L*100,2))
                MaxBP.append(round((O-C+0.000001)/C*100,2))
                MaxOC.append("R")
            else:
                MaxHP.append(round((H-C+0.000001)/C*100,2))
                MaxLP.append(round((O-L+0.000001)/L*100,2))
                MaxBP.append(round((C-O+0.000001)/O*100,2))
                MaxOC.append("G")
            #H=Data['High'].max()
            #L=Data['Low'].max()
        #PivotD
            RangeList=getChartRangeList(H,L,PivotD)
            PRangeList=getChartRangeList(H,L,PivotD1)    
            FibListSt["HCFib"]=""
            FibListSt["HPFib"]=""
            FibListSt["HCLevel"]=""
            FibListSt["HPLevel"]=""
            FibListSt["I"]=i
            FibListSt["LCFib"]=""
            FibListSt["LPFib"]=""
            FibListSt["LCLevel"]=""
            FibListSt["LPLevel"]=""
            #LFibListSt["I"]=i
            for R in RangeList:
                Found=False
                #R="A1000"
                if( H==PivotD[R]):
                    #print(R+" High Same" + Data.iloc[i]['Date'])
                    HighList.append(i)
                    Found=True                    
                elif( H+T>=PivotD[R]>=H-T):
                    #print(str(i)+ "==> "+ R+" High Approx " + Data.iloc[i]['Date'] +" - "+ str(H+T) + " = " + str(PivotD[R]) + " = "+ str(H-T))
                    HighList.append(i)
                    Found=True
                if (Found):
                    if((R.find("A")>=0) | (R.find("Z")>=0)):
                        FibListSt["HCFib"]=R
                    else:
                        FibListSt["HCLevel"]=R
                Found=False
                if( L==PivotD[R]):
                    #print(R+" Low Same" + Data.iloc[i]['Date'])
                    LowList.append(i)
                    Found=True
                elif( L+T>=PivotD[R]>=L-T):
                    #print(str(i)+ "==> "+ R+" Low Approx " + Data.iloc[i]['Date'] +" - "+ str(L+T) + " = " + str(PivotD[R]) + " = "+ str(L-T))
                    LowList.append(i)    
                    Found=True                    
                if (Found):
                    if((R.find("A")>=0) | (R.find("Z")>=0)):
                        FibListSt["LCFib"]=R
                    else:
                        FibListSt["LCLevel"]=R
            
            DHighList = [item for item in set(HighList) if HighList.count(item) > 1]
            DLowList = [item for item in set(LowList) if LowList.count(item) > 1]
            
            
            for R in PRangeList:
                Found=False
                #R="A1000"
                if( H==PivotD1[R]):
                    #print(R+" High Same" + Data.iloc[i]['Date'])
                    PHighList.append(i)
                    Found=True                    
                elif( H+T>=PivotD1[R]>=H-T):
                    #print(str(i)+ "==> "+ R+" High Approx " + Data.iloc[i]['Date'] +" - "+ str(H+T) + " = " + str(PivotD[R]) + " = "+ str(H-T))
                    PHighList.append(i)
                    Found=True
                if (Found):
                    if((R.find("A")>=0) | (R.find("Z")>=0)):
                        FibListSt["HPFib"]=R
                    else:
                        FibListSt["HPLevel"]=R
                Found=False
                if( L==PivotD1[R]):
                    #print(R+" Low Same" + Data.iloc[i]['Date'])
                    PLowList.append(i)
                    Found=True
                elif( L+T>=PivotD1[R]>=L-T):
                    #print(str(i)+ "==> "+ R+" Low Approx " + Data.iloc[i]['Date'] +" - "+ str(L+T) + " = " + str(PivotD[R]) + " = "+ str(L-T))
                    PLowList.append(i)    
                    Found=True                    
                if (Found):
                    if((R.find("A")>=0) | (R.find("Z")>=0)):
                        FibListSt["LPFib"]=R
                    else:
                        FibListSt["LPLevel"]=R
            #if(Found):
            FibListar.append(FibListSt)            
            PDHighList = [item for item in set(PHighList) if PHighList.count(item) > 1]
            PDLowList = [item for item in set(PLowList) if PLowList.count(item) > 1]

            TDF=pd.DataFrame(FibListar)
            
            if(str(HighList).find(str(i-offset)+"")>0):                
                a=isPeak(Data['High'][:i], len(Data['High'][:i]), Data.iloc[i-offset]['High'], i-(offset*2), i)
                Signal=[]
                Cnt=1
                Signal.append("Pivot")                
                if(str(DHighList).find(str(i-offset)+"")>0):                
                    Cnt=2
                    Signal.append("Levels")
                
                if(a):
                    pi=1
                    while(pi<=Cnt):
                        #print("HighList :"+str(HighList))
                        ResultSt={}
                        Diff=round(Data.iloc[i-offset]['High']-Data.iloc[i]['High'],2)
                        DiffP=round(Diff/Data.iloc[i]['High']*100,2)
                        PDiff=round(Data.iloc[i-(offset*2)]['High']-Data.iloc[i-offset]['High'],2)
                        PDiffP=round(PDiff/Data.iloc[i-offset]['High']*100,2)
                        #print(str(i)+ " - " + Data.iloc[i]['Date'] + " HIGH - " +Data.iloc[i-offset]['Date'] + " - " + str(a) + " - " + str(Diff) + " ~ " + str(DiffP));                    
                        ResultSt['Stock']=Symbol
                        ResultSt['Index']=i
                        ResultSt['CGap']=CGap
                        ResultSt['PGap']=PGap
                        ResultSt['CurrentDate']=Data.iloc[i]['Date']
                        ResultSt['Type']='High'
                        ResultSt['SingleDate']=Data.iloc[i-offset]['Date']
                        ResultSt['Diff']=Diff
                        ResultSt['DiffP']=DiffP
                        ResultSt['PDiff']=PDiff
                        ResultSt['PDiffP']=PDiffP
                        ResultSt['InvertedHammer']=Data.iloc[i-offset]['InvertedHammer']
                        ResultSt['Hammer']=Data.iloc[i-offset]['Hammer']
                        ResultSt['PercHL']=round((Data.iloc[:i]['High'].max()-Data.iloc[i-offset]['High']+0.00001)/Data.iloc[i-offset]['High']*100,2)
                        ResultSt['RPercHL']=round((Data.iloc[:i]['Low'].min()-Data.iloc[i-offset]['High']+0.00001)/Data.iloc[i-offset]['High']*100,2)
                        ResultSt['TPercHL']=round((Data.iloc[:i]['High'].max()-Data.iloc[:i]['Low'].min()+0.00001)/Data.iloc[:i]['Low'].min()*100,2)
                        
                        ResultSt['SPercHH']=round((Data.iloc[:i-offset]['High'].max()-Data.iloc[i-offset]['High']+0.00001)/Data.iloc[i-offset]['High']*100,2)
                        ResultSt['SPercLL']=round((Data.iloc[:i-offset]['Low'].min()-Data.iloc[i-offset]['Low']+0.00001)/Data.iloc[i-offset]['Low']*100,2)
                        ResultSt['SPercHL']=round((Data.iloc[:i-offset]['High'].max()-Data.iloc[i-offset]['Low']+0.00001)/Data.iloc[i-offset]['Low']*100,2)
                        ResultSt['SPercCL']=round((Data.iloc[i-offset]['Close']-Data.iloc[:i-offset]['Low'].min()+0.00001)/Data.iloc[:i-offset]['Low'].min()*100,2)
                        ResultSt['SPercHC']=round((Data.iloc[:i-offset]['High'].max()-Data.iloc[i-offset]['Close']+0.00001)/Data.iloc[i-offset]['Close']*100,2)
                        ResultSt['SPercOC']=round((Data.iloc[0]['Open']-Data.iloc[i-offset]['Close']+0.00001)/Data.iloc[i-offset]['Close']*100,2)
                        
                        
                        ResultSt['TPercOC']=round((Data.iloc[0]['Open']-Data.iloc[i]['Close']+0.00001)/Data.iloc[i]['Close']*100,2)
                        ResultSt['TPercOL']=round((Data.iloc[0]['Open']-Data.iloc[:i]['Low'].min()+0.00001)/Data.iloc[:i]['Low'].min()*100,2)
                        ResultSt['TPercHO']=round((Data.iloc[:i]['High'].max()-Data.iloc[0]['Open']+0.00001)/Data.iloc[0]['Open']*100,2)
                        ResultSt['TPercCL']=round((Data.iloc[i]['Close']-Data.iloc[:i]['Low'].min()+0.00001)/Data.iloc[:i]['Low'].min()*100,2)
                        ResultSt['TPercHC']=round((Data.iloc[:i]['High'].max()-Data.iloc[i]['Close']+0.00001)/Data.iloc[i]['Close']*100,2)
                        
          
                        H,L,C,O=list(Data.iloc[i-offset][['High',"Low","Close","Open"]])
                        
                        ResultSt['HLC']=round((H-C)/C*100,2)
                        ResultSt['HL']=round((H-L)/L*100,2)
                        ResultSt['OC']=round((O-C)/C*100,2)
                        ResultSt['G']=O>C
                        ResultSt['CFD']=CFD                        
                        ResultSt['PFD']=PFD
                        ResultSt['CPD']=CPD
                        ResultSt['PPD']=PPD
                        CH,CL,CC,CO=list(Data.iloc[i][['High',"Low","Close","Open"]])                        
                        ResultSt['CC']=CC
                        ResultSt['SC']=C
                        ResultSt['MaxHL']=max(MaxHL)
                        ResultSt['MaxHLIdx']=MaxHL.index(max(MaxHL))
                        ResultSt['MaxHLClr']=MaxOC[MaxHL.index(max(MaxHL))]
                        ResultSt['MaxHLOCP']=MaxOCP[MaxHL.index(max(MaxHL))]
                        ResultSt['MaxHP']=MaxHP[MaxHL.index(max(MaxHL))]
                        ResultSt['MaxLP']=MaxLP[MaxHL.index(max(MaxHL))]
                        ResultSt['MaxBP']=MaxBP[MaxHL.index(max(MaxHL))]
                        #ResultSt['MaxHLOCP']=MaxOCP[MaxHL.index(max(MaxHL))]
                        
                        ResultSt['CHLC']=round((CH-CC)/CC*100,2)
                        ResultSt['CHL']=round((CH-CL)/CL*100,2)
                        ResultSt['COC']=round((CO-CC)/CC*100,2)
                        ResultSt['HCFibV']=100
                        ResultSt['HCLevelV']=100
                        ResultSt['HPFibV']=100
                        ResultSt['HPLevelV']=100
                        ResultSt['LCFibV']=100
                        ResultSt['LCLevelV']=100
                        ResultSt['LPFibV']=100
                        ResultSt['LPLevelV']=100
    
                        
                        ResultSt['HCFib']=TDF[TDF['I']==i-offset]['HCFib'].iloc[0]
                        ResultSt['HCLevel']=TDF[TDF['I']==i-offset]['HCLevel'].iloc[0]
                        ResultSt['HPFib']=TDF[TDF['I']==i-offset]['HPFib'].iloc[0]
                        ResultSt['HPLevel']=TDF[TDF['I']==i-offset]['HPLevel'].iloc[0]
                        ResultSt['LCFib']=TDF[TDF['I']==i-offset]['LCFib'].iloc[0]
                        ResultSt['LCLevel']=TDF[TDF['I']==i-offset]['LCLevel'].iloc[0]
                        ResultSt['LPFib']=TDF[TDF['I']==i-offset]['LPFib'].iloc[0]
                        ResultSt['LPLevel']=TDF[TDF['I']==i-offset]['LPLevel'].iloc[0]
                        
                        if(len(ResultSt['HCFib'])>1):
                            ResultSt['HCFibV']=round(((PivotD[ResultSt['HCFib']]-H)+0.000001)/H*10000,2)
                        if(len(ResultSt['HCLevel'])>1):
                            ResultSt['HCLevelV']=round(((PivotD[ResultSt['HCLevel']]-H)+0.000001)/H*10000,2)
                        if(len(ResultSt['HPFib'])>1):
                            ResultSt['HPFibV']=round(((PivotD[ResultSt['HPFib']]-H)+0.000001)/H*10000,2)
                        if(len(ResultSt['HPLevel'])>1):
                            ResultSt['HPLevelV']=round(((PivotD[ResultSt['HPLevel']]-H)+0.000001)/H*10000,2)

                        if(len(ResultSt['LCFib'])>1):
                            ResultSt['LCFibV']=round(((PivotD[ResultSt['LCFib']]-H)+0.000001)/H*10000,2)
                        if(len(ResultSt['LCLevel'])>1):
                            ResultSt['LCLevelV']=round(((PivotD[ResultSt['LCLevel']]-H)+0.000001)/H*10000,2)
                        if(len(ResultSt['LPFib'])>1):
                            ResultSt['LPFibV']=round(((PivotD[ResultSt['LPFib']]-H)+0.000001)/H*10000,2)
                        if(len(ResultSt['LPLevel'])>1):
                            ResultSt['LPLevelV']=round(((PivotD[ResultSt['LPLevel']]-H)+0.000001)/H*10000,2)
                        
                        
                        ResultSt['HCFib1']=TDF[TDF['I']==i]['HCFib'].iloc[0]
                        ResultSt['HCLevel1']=TDF[TDF['I']==i]['HCLevel'].iloc[0]
                        ResultSt['HPFib1']=TDF[TDF['I']==i]['HPFib'].iloc[0]
                        ResultSt['HPLevel1']=TDF[TDF['I']==i]['HPLevel'].iloc[0]
                        ResultSt['LCFib1']=TDF[TDF['I']==i]['LCFib'].iloc[0]
                        ResultSt['LCLevel1']=TDF[TDF['I']==i]['LCLevel'].iloc[0]
                        ResultSt['LPFib1']=TDF[TDF['I']==i]['LPFib'].iloc[0]
                        ResultSt['LPLevel1']=TDF[TDF['I']==i]['LPLevel'].iloc[0]
                        ResultAr.append(ResultSt)
                        Tempi=i
                        pi=pi+1
                        
            if(str(LowList).find(str(i-offset)+"")>0):
                Trough=isTrough(Data['Low'][:i], len(Data['Low'][:i]), Data.iloc[i-offset]['Low'], i-(offset*2), i-1)
                Cnt=1
                if(str(DLowList).find(str(i-offset)+"")>0):                
                    Cnt=2
                
                if(Trough):
                    pi=1
                    while(pi<=Cnt):                
                        ResultSt={}
                        H,L,C,O=list(Data.iloc[i-offset][['High',"Low","Close","Open"]])
                        CH,CL,CC,CO=list(Data.iloc[i][['High',"Low","Close","Open"]])
                        #print("LowList :"+str(LowList))
                        #print(Symbol+"\ti="+str(i) + "\t"+str(i-offset)+"\t"+ str(i-(offset*2)))
                        Diff=round(Data.iloc[i-offset]['Low']-Data.iloc[i]['Low'],2)
                        DiffP=round(Diff/Data.iloc[i]['Low']*100,2)
                        PDiff=round(Data.iloc[i-(offset*2)]['Low']-Data.iloc[i-offset]['Low'],2)
                        PDiffP=round(PDiff/Data.iloc[i-offset]['Low']*100,2)
                        #print(str(i)+ " - "+Data.iloc[i]['Date'] + " Low - " +Data.iloc[i-offset]['Date'] + " - " + str(Trough)+ " - " + str(Diff) + " ~ " + str(DiffP));    
                        ResultSt['Stock']=Symbol
                        ResultSt['Index']=i
                        ResultSt['CGap']=CGap
                        ResultSt['PGap']=PGap
                        ResultSt['CurrentDate']=Data.iloc[i]['Date']
                        ResultSt['Type']='Low'
                        ResultSt['SingleDate']=Data.iloc[i-offset]['Date']
                        ResultSt['Diff']=Diff
                        ResultSt['DiffP']=DiffP
                        ResultSt['PDiff']=PDiff
                        ResultSt['PDiffP']=PDiffP
                        ResultSt['InvertedHammer']=Data.iloc[i-offset]['InvertedHammer']
                        ResultSt['Hammer']=Data.iloc[i-offset]['Hammer']
                        ResultSt['PercHL']=round((Data.iloc[:i]['Low'].min()-Data.iloc[i-offset]['Low']+0.00001)/Data.iloc[i-offset]['Low']*100,2)
                        ResultSt['RPercHL']=round((Data.iloc[:i]['High'].max()-Data.iloc[i-offset]['Low']+0.00001)/Data.iloc[i-offset]['Low']*100,2)
                        ResultSt['TPercHL']=round((Data.iloc[:i]['High'].max()-Data.iloc[:i]['Low'].min()+0.00001)/Data.iloc[:i]['Low'].min()*100,2)
                        ResultSt['CC']=CC
                        ResultSt['SC']=C
                        ResultSt['SPercHH']=round((Data.iloc[:i-offset]['High'].max()-Data.iloc[i-offset]['High']+0.00001)/Data.iloc[i-offset]['High']*100,2)
                        ResultSt['SPercLL']=round((Data.iloc[:i-offset]['Low'].min()-Data.iloc[i-offset]['Low']+0.00001)/Data.iloc[i-offset]['Low']*100,2)
                        ResultSt['SPercHL']=round((Data.iloc[:i-offset]['High'].max()-Data.iloc[i-offset]['Low']+0.00001)/Data.iloc[i-offset]['Low']*100,2)
                        ResultSt['SPercCL']=round((Data.iloc[i-offset]['Close']-Data.iloc[:i-offset]['Low'].min()+0.00001)/Data.iloc[:i-offset]['Low'].min()*100,2)
                        ResultSt['SPercHC']=round((Data.iloc[:i-offset]['High'].max()-Data.iloc[i-offset]['Close']+0.00001)/Data.iloc[i-offset]['Close']*100,2)
                        ResultSt['SPercOC']=round((Data.iloc[0]['Open']-Data.iloc[i-offset]['Close']+0.00001)/Data.iloc[i-offset]['Close']*100,2)
                        
                        
                        ResultSt['TPercOC']=round((Data.iloc[0]['Open']-Data.iloc[i]['Close']+0.00001)/Data.iloc[i]['Close']*100,2)
                        ResultSt['TPercOL']=round((Data.iloc[0]['Open']-Data.iloc[:i]['Low'].min()+0.00001)/Data.iloc[:i]['Low'].min()*100,2)
                        ResultSt['TPercHO']=round((Data.iloc[:i]['High'].max()-Data.iloc[0]['Open']+0.00001)/Data.iloc[0]['Open']*100,2)
                        ResultSt['TPercCL']=round((Data.iloc[i]['Close']-Data.iloc[:i]['Low'].min()+0.00001)/Data.iloc[:i]['Low'].min()*100,2)
                        ResultSt['TPercHC']=round((Data.iloc[:i]['High'].max()-Data.iloc[i]['Close']+0.00001)/Data.iloc[i]['Close']*100,2)
                        
          
                        
                        
                        
                        ResultSt['HLC']=round((L-C)/C*100,2)
                        ResultSt['HL']=round((H-L)/L*100,2)
                        ResultSt['OC']=round((O-C)/C*100,2)
                        
                        ResultSt['HCFib']=TDF[TDF['I']==i-offset]['HCFib'].iloc[0]
                        ResultSt['HCLevel']=TDF[TDF['I']==i-offset]['HCLevel'].iloc[0]
                        ResultSt['HPFib']=TDF[TDF['I']==i-offset]['HPFib'].iloc[0]
                        ResultSt['HPLevel']=TDF[TDF['I']==i-offset]['HPLevel'].iloc[0]
                        ResultSt['LCFib']=TDF[TDF['I']==i-offset]['LCFib'].iloc[0]
                        ResultSt['LCLevel']=TDF[TDF['I']==i-offset]['LCLevel'].iloc[0]
                        ResultSt['LPFib']=TDF[TDF['I']==i-offset]['LPFib'].iloc[0]
                        ResultSt['LPLevel']=TDF[TDF['I']==i-offset]['LPLevel'].iloc[0]
                        
                        ResultSt['G']=O>C
                        ResultSt['CFD']=CFD
                        ResultSt['PFD']=PFD
                        ResultSt['CPD']=CPD
                        ResultSt['PPD']=PPD
                        
                        
                        ResultSt['MaxHL']=max(MaxHL)
                        ResultSt['MaxHLIdx']=MaxHL.index(max(MaxHL))
                        ResultSt['MaxHLClr']=MaxOC[MaxHL.index(max(MaxHL))]
                        ResultSt['MaxHLOCP']=MaxOCP[MaxHL.index(max(MaxHL))]
                        ResultSt['MaxHP']=MaxHP[MaxHL.index(max(MaxHL))]
                        ResultSt['MaxLP']=MaxLP[MaxHL.index(max(MaxHL))]
                        ResultSt['MaxBP']=MaxBP[MaxHL.index(max(MaxHL))]
                        ResultSt['CHLC']=round((CL-CC)/CC*100,2)
                        ResultSt['CHL']=round((CH-CL)/CL*100,2)
                        ResultSt['COC']=round((CO-CC)/CC*100,2)
                        ResultSt['HCFibV']=100
                        ResultSt['HCLevelV']=100
                        ResultSt['HPFibV']=100
                        ResultSt['HPLevelV']=100
                        ResultSt['LCFibV']=100
                        ResultSt['LCLevelV']=100
                        ResultSt['LPFibV']=100
                        ResultSt['LPLevelV']=100
                        
                        if(len(ResultSt['HCFib'])>1):
                        	ResultSt['HCFibV']=round(((PivotD[ResultSt['HCFib']]-L)+0.000001)/L*10000,2)
                        if(len(ResultSt['HCLevel'])>1):
                            ResultSt['HCLevelV']=round(((PivotD[ResultSt['HCLevel']]-L)+0.000001)/L*10000,2)
                        if(len(ResultSt['HPFib'])>1):
                            ResultSt['HPFibV']=round(((PivotD[ResultSt['HPFib']]-L)+0.000001)/L*10000,2)
                        if(len(ResultSt['HPLevel'])>1):
                            ResultSt['HPLevelV']=round(((PivotD[ResultSt['HPLevel']]-L)+0.000001)/L*10000,2)

                        if(len(ResultSt['LCFib'])>1):
                            ResultSt['LCFibV']=round(((PivotD[ResultSt['LCFib']]-L)+0.000001)/L*10000,2)
                        if(len(ResultSt['LCLevel'])>1):
                            ResultSt['LCLevelV']=round(((PivotD[ResultSt['LCLevel']]-L)+0.000001)/L*10000,2)
                        if(len(ResultSt['LPFib'])>1):
                            ResultSt['LPFibV']=round(((PivotD[ResultSt['LPFib']]-L)+0.000001)/L*10000,2)
                        if(len(ResultSt['LPLevel'])>1):
                            ResultSt['LPLevelV']=round(((PivotD[ResultSt['LPLevel']]-L)+0.000001)/L*10000,2)
                          
                        ResultSt['HCFib1']=TDF[TDF['I']==i]['HCFib'].iloc[0]
                        ResultSt['HCLevel1']=TDF[TDF['I']==i]['HCLevel'].iloc[0]
                        ResultSt['HPFib1']=TDF[TDF['I']==i]['HPFib'].iloc[0]
                        ResultSt['HPLevel1']=TDF[TDF['I']==i]['HPLevel'].iloc[0]
                        ResultSt['LCFib1']=TDF[TDF['I']==i]['LCFib'].iloc[0]
                        ResultSt['LCLevel1']=TDF[TDF['I']==i]['LCLevel'].iloc[0]
                        ResultSt['LPFib1']=TDF[TDF['I']==i]['LPFib'].iloc[0]
                        ResultSt['LPLevel1']=TDF[TDF['I']==i]['LPLevel'].iloc[0]
                        
                        ResultAr.append(ResultSt)
                        Tempi=i
                        pi=pi+1
            i=i+1
    
    ResultDF=pd.DataFrame(ResultAr)
    return ResultDF

def dispChart(Data1,filename,Symbol,LiveData):
    #Data=Data1
    if(LiveData==False):
        
        LastPivot=pd.read_csv(DataDir+r"\Data3\\"+Symbol+"-Pivot.csv",encoding='utf-8')
    #ListData=['IPivot','H1','L1','L2','H2','A0','A236','A382','A500','A786']#,'Z236','Z382','Z500','Z786']
    #ListData=['IPivot','H1','H2','H3','A0','A236','A382','A500','A618','A786','A1000','A1236','A1382','A1500','A1618','A2000']
        
        if(str(Data1['Date'].dtype)=='object'):
            SearchDate=parse(Data1['Date'][0]).strftime("%Y-%m-%d")
        else:
            SearchDate=Data1['Date'][0].strftime("%Y-%m-%d")
        #dd=Data
        PivotDPD=LastPivot[LastPivot['Date']==SearchDate]
        Idx=PivotDPD.index[0]
        PivotD=LastPivot.iloc[Idx]
        #PivotD=LastPivot.iloc[DateIndex*-1]
    else:
        PivotD=DPivot[DPivot['Symbol']==Symbol][-1:].iloc[0]
    ListData=getChartRangeList(Data1['High'].max(),Data1['Low'].min(),PivotD)
    #ListData=getChartRangeList(Data['High'].max(),Data['Low'].min(),PivotD)
    #ListData=['IPivot','L1','A0','A236','A382','A500','A786']#,'Z236','Z382','Z500','Z786']
    
    if(str(type(PivotD['Date'])).find("Time")<0):
        date1=parse(parse(PivotD['Date']).strftime("%Y-%m-%d 09:00"))
        date2=parse(parse(PivotD['Date']).strftime("%Y-%m-%d 15:30"))
    else:
        date1=parse(PivotD['Date'].strftime("%Y-%m-%d 09:00"))
        date2=parse(PivotD['Date'].strftime("%Y-%m-%d 15:30"))

    Lines=[]
    AxisText=[]
    AxisValue=[]
    AxisX=[]
    
    for la in ListData:
        Position=date2
        Symbol1="+"
        value=PivotD[la]
        color='rgb(100, 100, 100)'
        linestyle=3
        if(la.find("A")>=0):
            color='rgb(0, 255, 0)'
            linestyle=2
        if(la.find("Z")>=0):
            color='rgb(255, 0, 0)'
            linestyle=2
        if(la.find("H")>=0):
            color='rgb(0, 0, 255)'
            linestyle=1
            Position=date1
            Symbol1="-"
        if(la.find("L")>=0):
            color='rgb(255,0 , 255)'
            linestyle=1
            Position=date1
            Symbol1="-"
        
        
        Lines.append(candlestick.CreateLinesV1(date1,date2,value,color,linestyle))
        AxisText.append(la)
        AxisValue.append(value)            
        AxisX.append(candlestick.CurrentDate(candlestick.N1(Position,"10M",Symbol1)))
    
    AxisText.append(Symbol)
    AxisValue.append(max(AxisValue))            
    AxisX.append(candlestick.CurrentDate(candlestick.N1(date1,"4H","+")))
    Datesar=list(Data1['Date'])
    Xar=[]
    Xar.append(Datesar[int(len(Datesar)/2)])
    Yar=[]
    Yar.append(Data1['High'].max()*1.001)
    textAr=[]
    textAr.append(Symbol)
    
    trace0 = go.Scatter(x=AxisX,y=AxisValue,text=AxisText, mode='text')
    
    trace=go.Candlestick(x=Datesar,
                               open=Data1['Open'],
                               high=Data1['High'],
                               low=Data1['Low'],
                               close=Data1['Close'])
    data=[trace,trace0]
    #AxisText=[]
    #AxisValue=[]
    #AxisX=[]
    #data=[trace,trace0]
    Layout={}
    Layout["shapes"]=Lines
    #Layout["annotations"]=AnnotationsAr
       
    #annotations
    
    fig2 = {'data': data,'layout': Layout}

    
#
#    fig1 = go.Figure()
#    
#    List_ = list(Data1['Date'])
#    fig1.add_trace( go.Candlestick(x=List_,
#                               open=Data1['Open'],
#                               high=Data1['High'],
#                               low=Data1['Low'],
#                               close=Data1['Close']))
#    fig1.add_trace(go.Scatter(x=Xar,y=Yar,text=textAr, mode='text'))
#    
    plot(fig2,filename=filename+".html")
    


#DateIndex=4
#StockList=pd.read_csv("C:\ReadMoneycontrol\Mani 2.0\StockList.txt")
#DateIndex=126

def LoadData(minute,DateIndex):
    NiftyDay=pd.read_csv(DataDir+r"\Data\NIFTY50-day.csv")
    #minute="5minute"
    DataFrameCollection={}
    if(DateIndex<len(NiftyDay)-1):
    #while(DateIndex<len(NiftyDay)-1):
        StartDate=NiftyDay.iloc[(DateIndex)*-1]['Date']
        if(DateIndex!=1):
            EndDate=NiftyDay.iloc[(DateIndex-1)*-1]['Date']
        else:
            EndDate=candlestick.N1(parse(StartDate),"1D","+").strftime("%Y-%m-%d")
#        Nifty=pd.read_csv(DataDir+r"\Data\NIFTY50-"+minute+".csv")
#        Nifty.columns=['Date', 'Open', 'High', 'Low', 'Close', 'V']
#        NiftyD=Nifty[(Nifty['Date']>StartDate) & (Nifty['Date']<EndDate)]
#        DataFrameCollection['NIFTY']=NiftyD
#        DataFrameCollection['NIFTY'].sort_values('Date',inplace=True)
#        DataFrameCollection['NIFTY'].drop_duplicates(subset ="Date", keep = "first", inplace = True) 
#        DataFrameCollection['NIFTY'].reset_index(inplace=True,drop=True)
#        #DataFrameCollection['NIFTY'][']
#        DataFrameCollection['NIFTY']['HLC']=(DataFrameCollection['NIFTY']['High']+DataFrameCollection['NIFTY']['Low']+DataFrameCollection['NIFTY']['Close'])/3
        Comparison={}
#        Comparison["NIFTY"]=list(NiftyD['Open'])
        ki=0
        while(ki<len(StockList)): #len(StockList)
            StockName=StockList.iloc[ki]['Symbol']
            ki=ki+1
            #print(StockName)
            Stockdf=pd.read_csv(DataDir+r"\Data\\"+StockName+"-"+minute+".csv")
            Stockdf.columns=['Date', 'Open', 'High', 'Low', 'Close', 'V']
            StockD=Stockdf[(Stockdf['Date']>StartDate) & (Stockdf['Date']<EndDate)]
            DataFrameCollection[StockName]=StockD
            DataFrameCollection[StockName].sort_values('Date',inplace=True)
            DataFrameCollection[StockName].drop_duplicates(subset ="Date", keep = "first", inplace = True) 

            DataFrameCollection[StockName].reset_index(inplace=True,drop=True)
            DataFrameCollection[StockName]['HLC']=(DataFrameCollection[StockName]['High']+DataFrameCollection[StockName]['Low']+DataFrameCollection[StockName]['Close'])/3
            Comparison[StockName]=list(StockD['Open'])
    return DataFrameCollection
        


def CheckandMarkSequence(ResultDF0T,Interval):
    ar=[]
    #ResultDF03['Seq']=False
    ResultDF0T=ResultDF0T.sort_values(['Stock','SingleDate'],ascending=[True, True]).reset_index(drop=True)
    pd.options.mode.chained_assignment = None
    #Interval="3M"
    ar.append(False)
    for i in range(1, len(ResultDF0T)-1):
        CStock=ResultDF0T.iloc[i]['Stock']
        PStock=ResultDF0T.iloc[i-1]['Stock']
        if(str(ResultDF0T['CurrentDate'].dtype)!='datetime64[ns]'):
            PTime=parse(ResultDF0T.iloc[i-1]['CurrentDate'])
            CTime=parse(ResultDF0T.iloc[i]['CurrentDate'])
            NTime=parse(ResultDF0T.iloc[i+1]['CurrentDate'])
        else:
            PTime=ResultDF0T.iloc[i-1]['CurrentDate']
            CTime=ResultDF0T.iloc[i]['CurrentDate']
            NTime=ResultDF0T.iloc[i+1]['CurrentDate']
        
        if((CStock==PStock) and ((candlestick.N1(CTime,Interval,"-")==PTime) or (candlestick.N1(CTime,Interval,"+")==NTime))):
            ar.append(True)
        else:
            ar.append(False)
    ar.append(False)
    ResultDF0T['Seq']=ar
    return ResultDF0T


def getPastDataZ(ID,StockName,Input):
    global Candles,url 
    global Candles_dict,Datas
    headers={}
    headers['User-Agent'] = 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36'
    #StrTimeIntervals=['3minute','5minute','15minute','30minute','day']
    if(Input=="All"):
        StrTimeIntervals=['5minute','15minute','day']
        Increment=[3,3,3]
    else:
        StrTimeIntervals=['5minute','15minute']
        Increment=[2,2]
    #Increment=[30,60,80,90,90]
    
    #Increment=[5,5,5,5,5]
    
    #Increment=[1,1,1,1,1]
    #Increment=[3,3,3,3,3]
    #StrTimeIntervals=['day']
    #Duration=850
    Duration=5
    requests.Timeout(120)
    TimeIntervalData={}
    for TimeInterval in StrTimeIntervals: # 54261767
        
        df=pd.DataFrame()
        #print(StockName+"     Running ....."+ TimeInterval )
        #StartDate=N1(datetime.now(),'3D','-')
        StartDate=N1(datetime.now(),str(Duration)+'D','-')
        DateIncr=0        
        #while(DateIncr<3):
        while(DateIncr<Duration):
            DateIncr=DateIncr+Increment[StrTimeIntervals.index(TimeInterval)]+1
            EndDate=N1(StartDate,str(Increment[StrTimeIntervals.index(TimeInterval)])+'D','+')
            StartDateStr=StartDate.strftime("%Y-%m-%d")
            EndDateStr=EndDate.strftime("%Y-%m-%d")
            #print(str(DateIncr)+" --> "+StartDateStr+ ' - ' + EndDateStr)
            url='https://kitecharts-aws.zerodha.com/api/chart/'+str(ID)+'/'+TimeInterval+'?public_token=Pb0MyvJ435vcAjx5fxCTtEV0oD0wdcwT&user_id=RM5678&api_key=kitefront&access_token=mwFtysT9JpZk6B7ZOUH4AqbrJkhUlTnC&'+'from='+StartDateStr+'&to='+EndDateStr+'&ciqrandom=1549306657305'                               
            retry=1
            time.sleep(5)
            while(retry<5):
                Candles = requests.get('https://kitecharts-aws.zerodha.com/api/chart/'+str(ID)+'/'+TimeInterval+
                               '?public_token=Pb0MyvJ435vcAjx5fxCTtEV0oD0wdcwT&user_id=RM5678&api_key=kitefront&access_token=mwFtysT9JpZk6B7ZOUH4AqbrJkhUlTnC&'+
#                               'from=2019-01-08&to=2019-04-05&ciqrandom=1549306657305') #GOLD
                                'from='+StartDateStr+'&to='+EndDateStr+'&ciqrandom=1549306657305',headers=headers) #GOLD
                if(Candles.status_code==200):
                    retry=10
                else:
                    print("Retry " + str(retry) + " ---- "+ str(Candles.status_code))
                    time.sleep(1)
                    retry=retry+1
                    
            Candles_dict = Candles.json()['data']['candles']
            tCandles_df = pd.DataFrame(Candles_dict,columns=['Date', 'open', 'high', 'low', 'close', 'V'])
            List_ = list(tCandles_df['Date'])
            List_ = [datetime.strptime(MParseDate(x).strftime("%m/%d/%Y %I:%M %p"), "%m/%d/%Y %I:%M %p") for x in List_]
            tCandles_df['Date']=pd.Series([x for x in List_],index=tCandles_df.index)
            df=df.append(tCandles_df)
            StartDate=N1(EndDate,'1D','+')
        TimeIntervalData[TimeInterval]=df

#        df.to_csv("C:\\ReadMoneycontrol\\Mani 2.0\\incr1\\"+StockName+"-"+TimeInterval+".csv",sep=',',encoding='utf-8',index=False)
        #time.sleep(1)
    Datas[StockName]=TimeIntervalData
    return df


def MParseDate(Date):
    ts = (np.datetime64(pd.to_datetime(Date)) - np.datetime64('1970-01-01T00:00:00Z')) / np.timedelta64(1, 's')
    return N1(N1(datetime.utcfromtimestamp(ts),'5H',"+"),"30M","+")
seconds_per_unit = {"S": 1, "M": 60, "H": 3600, "D": 86400, "W": 604800}
def N1(date,s,Operation):
    if (Operation=="+"):
        return date+timedelta(seconds=int(s[:-1]) * seconds_per_unit[s[-1]])
    else:
        return date-timedelta(seconds=int(s[:-1]) * seconds_per_unit[s[-1]])



def getRealTimePivot(Datas):
    StockList=pd.read_csv(StockListFile)
    DFT=pd.DataFrame()
    ki=0
    while(ki<len(StockList)):
    #if(True):
        StockName=StockList.iloc[ki]['Symbol']
        Data1=Datas[StockName]['day']
        Data1.columns=['Date', 'Open', 'High', 'Low', 'Close', 'V']
        #str(Test['Date'].dtype)
        Stock1=candlestick.AppendPivotV1(Data1)        
        Stock1['Symbol']=StockName
        if(ki==0):
            DFT=Stock1.iloc[-2:]
        else:
            DFT=DFT.append(Stock1.iloc[-2:])
        ki=ki+1
    return DFT


def getRealTimeData(Input):
    global Datas
    Date1=datetime.now()
    StockList=pd.read_csv(RealTime)#pd.read_csv(DataDir+r"\StockListIDOriginal.txt")
    i=0
    Runthread=[]
    Datas={}
    while(i<len(StockList)):#len(StockList)):
        StockName=StockList.iloc[i]['StockName']
        ZID=StockList.iloc[i]['ZID']    
        Runthread.append(threading.Thread(target=getPastDataZ,args=(ZID,StockName,Input)))
        Runthread[-1].start()
        if(i%10==0):
            time.sleep(5)
        #getPastData(ZID,StockName)    
        i=i+1
    for thread in Runthread:
        thread.join()

#    while(len(Datas)<len(StockList)-1):
#        time.sleep(10)
#        print(len(Datas))
#        qt=6
    print("Total Seconds : " + str((datetime.now()-Date1).seconds))
    return Datas


def getSpecificIntervalData(Datas,Interval,DPivot):
    i=0
    StockList=pd.read_csv(StockListFile)
    MinDF={}
    CDate=DPivot.iloc[1]['Date']
    while(i<len(StockList)):
        Symbol=StockList.iloc[i]['Symbol']
        TDatas=Datas[Symbol][Interval]
        TDatas.columns=['Date', 'Open', 'High', 'Low', 'Close', 'V']
        MinDF[Symbol]=TDatas[TDatas['Date']>CDate]
        MinDF[Symbol].reset_index(inplace=True,drop=True)
        #print(StockList.iloc[i]['Symbol'])
        i=i+1
    return MinDF


if(False):
    Datas={}
    
    Datas=getRealTimeData()
    
    Data1=Datas['SBIN']['day']
    #DPivot=getRealTimePivot(Datas)
    Min5DF=getSpecificIntervalData(Datas,"5minute",DPivot)
    minute="5minute"
    TInterval=['3minute','5minute','15minute']
    PercentageAr=[0.0002,round(0.0002/3*5,4),round(0.0002/3*15,4)]
    OffsetAr=[5,4,2]
    iP=PercentageAr[TInterval.index(minute)]
    iO=OffsetAr[TInterval.index(minute)]
    ResultDF05=ProcessZ(iP,iO,Min5DF,1,True) 
    ResultDF05=CheckandMarkSequence(ResultDF05,"5M")
    ResultDF05=ResultDF05[(ResultDF05['HLC']!=ResultDF05['OC'])]
    ResultDF05['CDATE']=pd.to_datetime(ResultDF05['CurrentDate']).dt.strftime("%Y-%b-%d")
    
#    Min15DF=getSpecificIntervalData(Datas,"15minute",DPivot)
    #Pivot Calculation only one Time
    DPivot[DPivot['Symbol']=="GRASIM"].iloc[0]
    DPivot[DPivot['Gap']<-1][['Symbol','Gap','Date']]
if(False):
    ResultAr=[]
    TInterval=['3minute','5minute','15minute']
    PercentageAr=[0.0002,round(0.0002/3*5,4),round(0.0002/3*15,4)]
    OffsetAr=[5,4,2]
    DateIndex=6
    minute="3minute"
    #Min3DF=LoadData(minute,DateIndex)
    #iP=PercentageAr[TInterval.index(minute)]
    #iO=OffsetAr[TInterval.index(minute)]
    #ResultDF03=ProcessY(iP,iO,Min3DF,1)  
    
    minute="5minute"
    Min5DF=LoadData(minute,DateIndex)
    iP=PercentageAr[TInterval.index(minute)]    
    iO=OffsetAr[TInterval.index(minute)]
    ResultDF05=ProcessZ(iP,iO,Min5DF,1,False) 
    ResultDF05=CheckandMarkSequence(ResultDF05,"5M")
    ResultDF05=ResultDF05[(ResultDF05['HLC']!=ResultDF05['OC'])]

    ResultDF05=ResultDF05[ResultDF05['CFD']>.3]
#    ResultDF05.shape[0]
#    ResultDF05[ResultDF05['Index']<60].shape[0]
    ResultDF05=ResultDF05[ResultDF05['Index']<60]
    ResultDF05['CDATE']=pd.to_datetime(ResultDF05['CurrentDate']).dt.strftime("%Y-%b-%d")

    
    minute="15minute"
    
if(False):
    ResultAr=[]
    TInterval=['3minute','5minute','15minute']
    DateIndex=1
    minute="15minute"
    #Try the 15 minute Precentage for 5 Minute
    PercentageAr=[0.0002,round(0.0002/3*5,4),round(0.0002/3*15,4)]
    OffsetAr=[5,4,4]
    iP=PercentageAr[TInterval.index(minute)]
    iO=OffsetAr[TInterval.index(minute)]
    ResultDF15=ProcessZ(iP,iO,Min15DF,1,True) 
    ResultDF15=CheckandMarkSequence(ResultDF15,"15M")
    ResultDF15=ResultDF15[(ResultDF15['HLC']!=ResultDF15['OC'])]
    
    ResultDF05=ProcessZ(iP,iO,Min5DF,1,True) 
    ResultDF05=CheckandMarkSequence(ResultDF05,"5M")
    ResultDF05=ResultDF05[(ResultDF05['HLC']!=ResultDF05['OC'])]
    ResultDF05=ResultDF15
    T=a(ResultDF15)
    T=a(ResultDF05)
    T[(T['PercHL']==0) & (T['DiffP']<-.4)][['Stock','SingleDate','PDiffP','DiffP','Type', 'HLC','OC', 'PercHL']]
    
    T[(T['PercHL']<=0.1) & (T['PercHL']>=-.01) & (T['DiffP']<-.4)][['Stock','SingleDate','PDiffP','DiffP','Type', 'HLC','OC', 'PercHL']]
    T[(T['PercHL']<=0.1) & (T['PercHL']>=-.01) & (T['DiffP']>.4)][['Stock','SingleDate','PDiffP','DiffP','Type', 'HLC','OC', 'PercHL']]
    
    T[(T['PercHL']==0) & (T['DiffP']>.4)][['Stock','SingleDate','PDiffP','DiffP','Type', 'HLC','OC', 'PercHL']]
    ResultDF15['CurrentDate']
    Min15DF['SBIN']['Date']    



def a(Input):
    #ResultDF05['Stock']=="HDFCBANK"
    #ResultDF05.duplicated(['Stock','SingleDate'],keep=False)
    T=Input[Input.duplicated(['Stock','SingleDate'],keep=False)][['Stock',
    #T=ResultDF05[ResultDF05['Seq']==True][['Stock',
    #T=ResultDF05[(ResultDF05['G']==False) & (ResultDF05['HL']>.3) & (ResultDF05['InvertedHammer']==True)][['Stock',
    #T=ResultDF05[(ResultDF05['G']==False) & (ResultDF05['HL']>.3) & (ResultDF05['Hammer']==True)][['Stock',                                                                                                       
            'CurrentDate','SingleDate','PDiffP','DiffP','HL', 'HLC','OC', 'PercHL','G',
            'Type','Seq','HCFib','HCLevel','LCFib','LCLevel','HPFib','HPLevel','LPFib','LPLevel']]
    return T

def loadData(Symbol,interval,iDate):
    
    Data1=LoadCSVData(Symbol,interval)
    DayData1=LoadCSVData(Symbol,"day")
    DayData=DayData1[(DayData1['Date']>=iDate) & (DayData1['Date']<=N1(iDate,"16H","+"))]
    return Data1[(Data1['Date']>=iDate) & (Data1['Date']<=N1(iDate,"16H","+"))].reset_index(), len(DayData1)-DayData.index

def FilterData(iDate,Data1,DayData1):
    
    #Data1=LoadCSVData(Symbol,interval)
    #DayData1=LoadCSVData(Symbol,"day")
    DayData=DayData1[(DayData1['Date']>=iDate) & (DayData1['Date']<=N1(iDate,"23H","+"))]
    return Data1[(Data1['Date']>=iDate) & (Data1['Date']<=N1(iDate,"23H","+"))].reset_index(), len(DayData1)-DayData.index


def LoadCSVData(Symbol,interval):
    Data1=pd.read_csv(DataDir+r"\Data\\"+Symbol+"-"+interval+".csv")
    Data1.columns=['Date', 'Open', 'High', 'Low', 'Close', 'V']
    if(str(Data1['Date'].dtype)!='datetime64[ns]'):
        #List_ = [datetime.strptime(parse(x).strftime("%m/%d/%Y %I:%M %p"), "%m/%d/%Y %I:%M %p") for x in List_]
        Data1['Date']=pd.to_datetime(Data1.Date)
    else:
        List_ = list(Data1['Date'])
        List_ = [datetime.strptime(x.strftime("%m/%d/%Y %I:%M %p"), "%m/%d/%Y %I:%M %p") for x in List_]
        Data1['Date']=pd.Series([x for x in List_],index=Data1.index)
    return Data1
#Symbol="KOTAKBANK"    
#interval="5minute"
#iDate=parse("2019-Nov-11")

if(False):
    DateIndex=100
    minute="3minute"
    #Min3DF=LoadData(minute,DateIndex)
    #iP=PercentageAr[TInterval.index(minute)]
    #iO=OffsetAr[TInterval.index(minute)]
    #ResultDF03=ProcessY(iP,iO,Min3DF,1)  
    
    minute="5minute"
    Min5DF=LoadData(minute,DateIndex)
    
    StockName="PNB"
    Symbol=StockName
    Data=Min5DF[StockName].fillna(0)
    dispChart(Data,StockName,StockName,False)
    
           
    
    StockName="FEDERALBNK"
    Data1,DateIndex=loadData(StockName,"5minute",parse("2018-Mar-09"))
    dispChart(Data1,StockName,StockName,False)
    
if(False):
    ResultAr=[]
    TInterval=['3minute','5minute','15minute']
    PercentageAr=[0.0002,round(0.0002/3*5,4),round(0.0002/3*15,4)]
    OffsetAr=[5,4,2]
    minute="15minute"
    DateIndex=1
    iP=PercentageAr[TInterval.index(minute)]   
    iO=OffsetAr[TInterval.index(minute)]
    WriteHeader=True
    while(DateIndex<=300):    
        Min5DF=LoadData(minute,DateIndex)
        ResultDF05A=ProcessZ(iP,iO,Min5DF,1,False) 
        ResultDF05A=CheckandMarkSequence(ResultDF05A,"15M")
        ResultDF05A=ResultDF05A[(ResultDF05A['HLC']!=ResultDF05A['OC'])]
        ResultDF05A.to_csv("C:\ReadMoneycontrol\Mani 2.0\Report\\"+minute+'FO15Min.csv',mode='a',header=WriteHeader,index=False)
        WriteHeader=False
        DateIndex=DateIndex+1

#if(False):
def ParseResults(CheckDF):
    SData=ResultDF05
    CheckDF=SData[ ((SData['Type']=="High") & (((SData['HCFib']=="A1500") | (SData['HCFib']=="A2000") 
        | (SData['HCFib']=="A1786")
        | (SData['HCFib']=="A1618")
        | (SData['HCFib']=="A2236")
        | (SData['HCFib']=="A1236")
        | (SData['HCFib']=="A2382")
        | (SData['HCFib']=="A1382")
        | (SData['HCFib']=="A2500")) | ((SData['HCLevel']=="H1") | (SData['HCLevel']=="H2"))))
		|
		((SData['Type']=="Low") & (((SData['LCFib']=="Z1500") | (SData['LCFib']=="Z2000") 
        | (SData['LCFib']=="Z1786")
        | (SData['LCFib']=="Z1618")
        | (SData['LCFib']=="Z2236")
        | (SData['LCFib']=="Z2382")
        | (SData['LCFib']=="Z2500")) | ((SData['LCLevel']=="L1") | (SData['LCLevel']=="L2")))
      )
]
    indx=-1
    CheckDfResult=[]
    First=True
    #indx=0
    while(indx<len(CheckDF)-1): #len(CheckDF)-1
        indx+=1
        
        #indx=1
        ClosePrices=CheckDF.iloc[indx]['CC']
        MV=abs(CheckDF.iloc[indx]['CFD'])        
        SV=abs(CheckDF.iloc[indx]['CFD']*1.75)
        Margin=round(ClosePrices*MV/100,2)
        Stoploss=round(ClosePrices*SV/100,2)
        SearchDate=parse(CheckDF.iloc[indx]['CurrentDate']).strftime("%Y-%b-%d")
        candlestick.Tollerance=0.05
        StockName=CheckDF.iloc[indx]['Stock']
        
        if((First) or ((StockName!=PStockName) and (PCDATE!=CheckDF.iloc[indx]['CDATE']))):
            Data5Min,DateIndex=loadData(StockName,"5minute",parse(SearchDate))
            #Data5Min.dtypes
            Data5Min=Data5Min.rename(columns = {'Open':'open','High':'high','Low':'low','Close':'close'})
            Data3Min,DateIndex=loadData(StockName,"minute",parse(SearchDate))
            Data3Min=Data3Min.rename(columns = {'Open':'open','High':'high','Low':'low','Close':'close'})  
    
        #Margin=round(ClosePrices*(1-CheckDF.iloc[indx]['CFD']/100),2)
        #Stoploss=round(ClosePrices*(1+CheckDF.iloc[indx]['CFD']*1.5/100),2)
        T=.4
        Tollerance=round(ClosePrices*T/100,2)
        #SellP=ClosePrices
    #    SellT=ClosePrices-Margin
    #    #SellT=SellP*(1-Margin)    
    #    SellSL=ClosePrices+Stoploss
    #    #SellSL=SellP*(1+Stoploss)
    #    
    #    SellPT=Data3Min[(Data3Min['high']>=SellP-Tollerance) & (Data3Min['low']<=SellP+Tollerance)]
    #    SellTT=Data3Min[(Data3Min['high']>=SellT-Tollerance) & (Data3Min['low']<=SellT+Tollerance)]
    #    SellSLT=Data3Min[(Data3Min['high']>=SellSL-Tollerance) & (Data3Min['low']<=SellSL+Tollerance)]
    #    Data3Min[(Data3Min['high']<=SellT+Tollerance)]
    #    
        #if(CheckDF.iloc[indx]['Index']==4) :
        
        CheckStatus={}
        CheckStatus['Stock']=CheckDF.iloc[indx]['Stock']
        CheckStatus['CurrentDate']=CheckDF.iloc[indx]['CurrentDate']
        
        ResultSearch=candlestick.Check(Data5Min,"Sell",CheckDF.iloc[indx]['Index'],Margin,Stoploss,Data3Min)        
        CheckStatus['SellPrice']=ResultSearch['Price']
        CheckStatus['SellTarget']=ResultSearch['Target']
        CheckStatus['SellStopLoss']=ResultSearch['StopLoss']
        CheckStatus['SellHit']=ResultSearch['Hit']
        CheckStatus['SellProfitPrice']=round(ResultSearch['Profit'],2)
        CheckStatus['SellProfitP']=round(ResultSearch['Profit']/ClosePrices*100,2)
    #    if((ResultSearch['Hit']=="Hit") or (ResultSearch['Hit'].find("Profit")>0)):
    #        CheckStatus['SellProfit']=True
        #tdaily=Data5Min
        #Signal="Buy"
        #DateIndex=CheckDF.iloc[indx]['Index']        
        #SearchData=Data3Min
        #list(tdaily[DateIndex+1:][:1]['Date'])[0]
        ResultSearch=candlestick.Check(Data5Min,"Sell",CheckDF.iloc[indx]['Index'],Stoploss,Stoploss,Data3Min)        
        CheckStatus['SellPrice1']=ResultSearch['Price']
        CheckStatus['SellTarget1']=ResultSearch['Target']
        CheckStatus['SellStopLoss1']=ResultSearch['StopLoss']
        CheckStatus['SellHit1']=ResultSearch['Hit']
        CheckStatus['SellProfitPrice1']=round(ResultSearch['Profit'],2)
        CheckStatus['SellProfitP1']=round(ResultSearch['Profit']/ClosePrices*100,2)

        
        ResultSearch=candlestick.Check(Data5Min,"Buy",CheckDF.iloc[indx]['Index'],Margin,Stoploss,Data3Min)
        #CheckStatus={}        
        CheckStatus['BuyHit']=ResultSearch['Hit']
        CheckStatus['BuyPrice']=ResultSearch['Price']
        CheckStatus['BuyTarget']=ResultSearch['Target']
        CheckStatus['BuyStopLoss']=ResultSearch['StopLoss']
        CheckStatus['BuyProfitPrice']=round(ResultSearch['Profit'],2)
        CheckStatus['BuyProfitP']=round(ResultSearch['Profit']/ClosePrices*100,2)
        
        ResultSearch=candlestick.Check(Data5Min,"Buy",CheckDF.iloc[indx]['Index'],Stoploss,Stoploss,Data3Min)
        #CheckStatus={}        
        CheckStatus['BuyHit1']=ResultSearch['Hit']
        CheckStatus['BuyPrice1']=ResultSearch['Price']
        CheckStatus['BuyTarget1']=ResultSearch['Target']
        CheckStatus['BuyStopLoss1']=ResultSearch['StopLoss']
        CheckStatus['BuyProfitPrice1']=round(ResultSearch['Profit'],2)
        CheckStatus['BuyProfitP1']=round(ResultSearch['Profit']/ClosePrices*100,2)
        
        CheckDfResult.append(CheckStatus)
    #    if((ResultSearch['Hit']=="Hit") or (ResultSearch['Hit'].find("Profit")>0)):
    #        CheckStatus['BuyProfit']=True
        if(indx%50==0):
            CheckDfResultdf=pd.read_json(json.dumps(CheckDfResult))  
            FinalCheckResults=CheckDF[:indx].merge(CheckDfResultdf)
            FinalCheckResults['CDATE']=pd.to_datetime(FinalCheckResults['CurrentDate']).dt.strftime("%Y-%b-%d")
            FinalCheckResults.to_csv("C:\\ReadMoneycontrol\\Mani 2.0\\Temp\\NewResultsH1L1.csv",sep=',',encoding='utf-8',index=False)
        PStockName=StockName
        PCDATE=CheckDF.iloc[indx]['CDATE']
        First=False
            
    CheckDfResultdf=pd.read_json(json.dumps(CheckDfResult))  
    FinalCheckResults=CheckDF.merge(CheckDfResultdf)
    #FinalCheckResults['CDATE']=pd.to_datetime(FinalCheckResults['CurrentDate']).dt.strftime("%Y-%b-%d")
    FinalCheckResults.to_csv("C:\\ReadMoneycontrol\\Mani 2.0\\Temp\\NewResultsH1L1.csv",sep=',',encoding='utf-8',index=False)
    
    return FinalCheckResults


def ParseResultsV1(CheckDF):

    SData=Test
    SData.drop_duplicates(subset =["Stock","CurrentDate",
                                   "Type",'HCFib','HCLevel',
                                   'LCLevel','LCFib'], keep = "first", inplace = True) 

    CheckDFAll=SData[ ((SData['Type']=="High") & (((SData['HCFib']=="A1500") | (SData['HCFib']=="A2000") 
        | (SData['HCFib']=="A1786")
        | (SData['HCFib']=="A1618")
        | (SData['HCFib']=="A2236")
        | (SData['HCFib']=="A1236")
        | (SData['HCFib']=="A2382")
        | (SData['HCFib']=="A1382")
        | (SData['HCFib']=="A2500")) | ((SData['HCLevel']=="H1") | (SData['HCLevel']=="H2"))))
		|
		((SData['Type']=="Low") & (((SData['LCFib']=="Z1500") | (SData['LCFib']=="Z2000") 
        | (SData['LCFib']=="Z1786")
        | (SData['LCFib']=="Z1618")
        | (SData['LCFib']=="Z2236")
        | (SData['LCFib']=="Z2382")
        | (SData['LCFib']=="Z2500")) | ((SData['LCLevel']=="L1") | (SData['LCLevel']=="L2")))
      )
]
    #SData.shape[0]
    CheckDFAll=SData[SData['Index']<20]
    #CheckDFAll=SData
    StockList=pd.read_csv(StockListFile)
    ki=0
    Sum=0
    while(ki<len(StockList)):
        StockName=StockList.Symbol[ki]
        ki=ki+1
        CheckDF=CheckDFAll[CheckDFAll['Stock']==StockName]
        #Sum+=CheckDF[CheckDF['Stock']==StockName].shape[0]
        #print(StockName + "= " +str(CheckDF[CheckDF['Stock']==StockName].shape[0]))
        SData5Min=LoadCSVData(StockName,"15minute")
        SData5Min=SData5Min.rename(columns = {'Open':'open','High':'high','Low':'low','Close':'close'})
        SData3Min=LoadCSVData(StockName,"minute")
        SData3Min=SData3Min.rename(columns = {'Open':'open','High':'high','Low':'low','Close':'close'})
        SDataDay=LoadCSVData(StockName,"day")

        indx=-1
        CheckDfResult=[]
        First=True
        #indx=0
        while(indx<len(CheckDF)-1): #len(CheckDF)-1
            indx+=1
            
            #indx=1
            ClosePrices=CheckDF.iloc[indx]['CC']
            MV=abs(CheckDF.iloc[indx]['CFD'])        
            SV=abs(CheckDF.iloc[indx]['CFD']*1.75)
            Margin=round(ClosePrices*MV/100,2)
            Stoploss=round(ClosePrices*SV/100,2)
            SearchDate=parse(CheckDF.iloc[indx]['CurrentDate']).strftime("%Y-%b-%d")
            if(SearchDate!='2019-Oct-27'):
                candlestick.Tollerance=0.05
                #StockName=CheckDF.iloc[indx]['Stock']
                
                Data5Min1,DateIndex=FilterData(parse(SearchDate),SData5Min,SDataDay)
                Data3Min1,DateIndex=FilterData(parse(SearchDate),SData3Min,SDataDay)
                #if((First) or ((StockName!=PStockName) and (PCDATE!=CheckDF.iloc[indx]['CDATE']))):
                    #Data5Min,DateIndex=loadData(StockName,"5minute",parse(SearchDate))
                    #Data5Min.dtypes
                    #Data5Min=Data5Min.rename(columns = {'Open':'open','High':'high','Low':'low','Close':'close'})
                    #Data3Min,DateIndex=loadData(StockName,"3minute",parse(SearchDate))
                    #Data3Min=Data3Min.rename(columns = {'Open':'open','High':'high','Low':'low','Close':'close'})  
            
                #Margin=round(ClosePrices*(1-CheckDF.iloc[indx]['CFD']/100),2)
                #Stoploss=round(ClosePrices*(1+CheckDF.iloc[indx]['CFD']*1.5/100),2)
                T=.4
                Tollerance=round(ClosePrices*T/100,2)
                #SellP=ClosePrices
            #    SellT=ClosePrices-Margin
            #    #SellT=SellP*(1-Margin)    
            #    SellSL=ClosePrices+Stoploss
            #    #SellSL=SellP*(1+Stoploss)
            #    
            #    SellPT=Data3Min[(Data3Min['high']>=SellP-Tollerance) & (Data3Min['low']<=SellP+Tollerance)]
            #    SellTT=Data3Min[(Data3Min['high']>=SellT-Tollerance) & (Data3Min['low']<=SellT+Tollerance)]
            #    SellSLT=Data3Min[(Data3Min['high']>=SellSL-Tollerance) & (Data3Min['low']<=SellSL+Tollerance)]
            #    Data3Min[(Data3Min['high']<=SellT+Tollerance)]
            #    
                #if(CheckDF.iloc[indx]['Index']==4) :
                
                CheckStatus={}
                CheckStatus['Stock']=CheckDF.iloc[indx]['Stock']
                CheckStatus['CurrentDate']=CheckDF.iloc[indx]['CurrentDate']
                
                ResultSearch=candlestick.Check(Data5Min1,"Sell",CheckDF.iloc[indx]['Index'],Margin,Stoploss,Data3Min1)        
                CheckStatus['SellPrice']=ResultSearch['Price']
                CheckStatus['SellTarget']=ResultSearch['Target']
                CheckStatus['SellStopLoss']=ResultSearch['StopLoss']
                CheckStatus['SellHit']=ResultSearch['Hit']
                CheckStatus['SellProfitPrice']=round(ResultSearch['Profit'],2)
                CheckStatus['SellProfitP']=round(ResultSearch['Profit']/ClosePrices*100,2)
            #    if((ResultSearch['Hit']=="Hit") or (ResultSearch['Hit'].find("Profit")>0)):
            #        CheckStatus['SellProfit']=True
                #tdaily=Data5Min1
                #Signal="Buy"
                #DateIndex=CheckDF.iloc[indx]['Index']        
                #SearchData=Data3Min1
                #list(tdaily[DateIndex+1:][:1]['Date'])[0]
                ResultSearch=candlestick.Check(Data5Min1,"Sell",CheckDF.iloc[indx]['Index'],Stoploss,Stoploss,Data3Min1)        
                CheckStatus['SellPrice1']=ResultSearch['Price']
                CheckStatus['SellTarget1']=ResultSearch['Target']
                CheckStatus['SellStopLoss1']=ResultSearch['StopLoss']
                CheckStatus['SellHit1']=ResultSearch['Hit']
                CheckStatus['SellProfitPrice1']=round(ResultSearch['Profit'],2)
                CheckStatus['SellProfitP1']=round(ResultSearch['Profit']/ClosePrices*100,2)
        
                
                ResultSearch=candlestick.Check(Data5Min1,"Buy",CheckDF.iloc[indx]['Index'],Margin,Stoploss,Data3Min1)
                #CheckStatus={}        
                CheckStatus['BuyHit']=ResultSearch['Hit']
                CheckStatus['BuyPrice']=ResultSearch['Price']
                CheckStatus['BuyTarget']=ResultSearch['Target']
                CheckStatus['BuyStopLoss']=ResultSearch['StopLoss']
                CheckStatus['BuyProfitPrice']=round(ResultSearch['Profit'],2)
                CheckStatus['BuyProfitP']=round(ResultSearch['Profit']/ClosePrices*100,2)
                
                ResultSearch=candlestick.Check(Data5Min1,"Buy",CheckDF.iloc[indx]['Index'],Stoploss,Stoploss,Data3Min1)
                #CheckStatus={}        
                CheckStatus['BuyHit1']=ResultSearch['Hit']
                CheckStatus['BuyPrice1']=ResultSearch['Price']
                CheckStatus['BuyTarget1']=ResultSearch['Target']
                CheckStatus['BuyStopLoss1']=ResultSearch['StopLoss']
                CheckStatus['BuyProfitPrice1']=round(ResultSearch['Profit'],2)
                CheckStatus['BuyProfitP1']=round(ResultSearch['Profit']/ClosePrices*100,2)
                
                CheckDfResult.append(CheckStatus)
            #    if((ResultSearch['Hit']=="Hit") or (ResultSearch['Hit'].find("Profit")>0)):
            #        CheckStatus['BuyProfit']=True
                #if(indx%10==0):
                #    print(StockName +  " = " + str(indx) + " out of "+ str(CheckDF.shape[0]) )
                if(indx%150==0):
                    #print(StockName +  " = " + str(indx) + " out of "+ str(CheckDF.shape[0]) )
                    CheckDfResultdf=pd.read_json(json.dumps(CheckDfResult))  
                    FinalCheckResults=CheckDF[:indx].merge(CheckDfResultdf)
                    FinalCheckResults['CDATE']=pd.to_datetime(FinalCheckResults['CurrentDate']).dt.strftime("%Y-%b-%d")
                    FinalCheckResults.to_csv("C:\\ReadMoneycontrol\\Mani 2.0\\FOTemp2\\All\\"+StockName+"ResultsL1.csv",sep=',',encoding='utf-8',index=False)
                PStockName=StockName
                PCDATE=CheckDF.iloc[indx]['CDATE']
                First=False
        if(len(CheckDF)>0):
            CheckDfResultdf=pd.read_json(json.dumps(CheckDfResult))  
            FinalCheckResults=CheckDF.merge(CheckDfResultdf)
        #FinalCheckResults['CDATE']=pd.to_datetime(FinalCheckResults['CurrentDate']).dt.strftime("%Y-%b-%d")
            FinalCheckResults.to_csv("C:\\ReadMoneycontrol\\Mani 2.0\\FOTemp2\\All\\"+StockName+"ResultsL1.csv",sep=',',encoding='utf-8',index=False)
        
    return FinalCheckResults



if(False):
    FinalCheckResults2=ParseResults(ResultDF05)
    FinalCheckResults2.to_csv("C:\\ReadMoneycontrol\\Mani 2.0\\Temp\\FinalCheckResults2.csv",sep=',',encoding='utf-8',index=False)
    
    FinalCheckResults.to_html("C:\ReadMoneycontrol\Mani 2.0\Temp\Test011.html")
    FinalCheckResults=pd.read_csv(r"C:\ReadMoneycontrol\Mani 2.0\Temp\YESBANKMinuteV3.2-1.csv")
    FinalCheckResults1=pd.read_csv(r"C:\ReadMoneycontrol\Mani 2.0\Temp\INFRATELMinuteV3.2-1.csv")
    FinalCheckResults2=pd.read_csv(r"C:\ReadMoneycontrol\Mani 2.0\Temp\VEDLMinuteV3.2-1.csv")
    FinalCheckResults.drop_duplicates(subset =["Stock","CDATE"], keep = "first", inplace = True) 
    
    FinalCheckResults[FinalCheckResults['SellProfitP']<0][['Stock','Index',
                     'CurrentDate','SellTarget','SellProfitPrice','BuyTarget',
                     'BuyProfitPrice','CFD','BuyProfitP','SellProfitP']].to_html("C:\ReadMoneycontrol\Mani 2.0\Temp\Test01.html")
    FinalCheckResults[FinalCheckResults['SellSignal']==True][['Stock',
                     'CurrentDate','SellSignal','SellTarget']].groupby(['SellTarget']).count()
    #[['Stock','CurrentDate','SellSignal','SellTarget']]
    FinalCheckResults.groupby([
            'CDATE','Index'])['BuyProfitP','SellProfitP'].sum()
    
    FinalCheckResults.groupby([
            'Index','G'])['BuyProfitP','SellProfitP','BuyProfitP1','SellProfitP1'].sum()
    
    
    FinalCheckResults[FinalCheckResults['Index']<30].groupby([
            'G'])['BuyProfitP','SellProfitP','BuyProfitP1','SellProfitP1'].sum()
    
    FinalCheckResults[FinalCheckResults['Index']>30].groupby([
            'G'])['BuyProfitP','SellProfitP','BuyProfitP1','SellProfitP1'].sum()
    
    FinalCheckResults['CurrentDate'].max()
    FinalCheckResults1.groupby([
            'G'])['BuyProfitP','SellProfitP','BuyProfitP1','SellProfitP1'].sum()
    
    FinalCheckResults1[FinalCheckResults1['Index']>30].groupby([
            'G'])['BuyProfitP','SellProfitP','BuyProfitP1','SellProfitP1'].sum()
    
    FinalCheckResults2.groupby([
            'G'])['BuyProfitP','SellProfitP','BuyProfitP1','SellProfitP1'].sum()
    
    FinalCheckResults2[FinalCheckResults2['Index']<30].groupby([
            'G'])['BuyProfitP','SellProfitP','BuyProfitP1','SellProfitP1'].sum()
    
    FinalCheckResults1[FinalCheckResults1['SellProfitP']>0]['SellProfitP'].sum()
    FinalCheckResults1[FinalCheckResults1['SellProfitP']<0]['SellProfitP'].sum()
    FinalCheckResults1[FinalCheckResults1['SellProfitP']<0]['BuyProfitP'].sum()
    FinalCheckResults1[FinalCheckResults1['SellProfitP']>0]['BuyProfitP'].sum()
    
    FinalCheckResults1[FinalCheckResults1['SellProfitP1']>0]['SellProfitP1'].sum()
    FinalCheckResults1[FinalCheckResults1['SellProfitP1']<0]['SellProfitP1'].sum()
    FinalCheckResults1[FinalCheckResults1['SellProfitP1']<0]['BuyProfitP1'].sum()
    FinalCheckResults1[FinalCheckResults1['SellProfitP1']>0]['BuyProfitP1'].sum()
    
    
    FinalCheckResults1.groupby([
            'Index'])['BuyProfitP','SellProfitP','BuyProfitP1','SellProfitP1'].count()
    
    FinalCheckResults[FinalCheckResults['SellSignal']==True][['Stock',
                     'CurrentDate','BuyTarget']].groupby(['BuyTarget']).count()
    
    
    FinalCheckResults[FinalCheckResults.duplicated(['Stock','CurrentDate'],keep=False)][['Stock','CurrentDate','SellSignal','SellTarget']]
    
    Tz=FinalCheckResults1[['Index','CGap','PGap','PDiffP','DiffP','MaxHL','MaxHLIdx','MaxHLClr','MaxHLOCP','MaxHP','MaxLP','CHL', 'CHLC','COC','HL', 'HLC','OC', 'PercHL',  'RPercHL','G',
     'SPercCL','SPercHC','SPercHH','SPercHL','SPercLL','SPercOC',
     'TPercCL','TPercHC','TPercHL','TPercHO','TPercOC','TPercOL',       
     'Type','Seq','CFD','CPD','PFD','PPD','SellProfitP','BuyProfitP']]
    Tz['Label']=100
    Tz['Label']=np.select([(Tz['SellProfitP']>0) & (Tz['BuyProfitP']<0),(Tz['SellProfitP']<0) & (Tz['BuyProfitP']>0),(Tz['SellProfitP']<0) & (Tz['BuyProfitP']<0)],[-1,1,-100],Tz['Label'] )
    Tz['G1']=np.select([(Tz['G']==True) ,(Tz['G']==False)],[1,0],Tz['G'] )
    Tz['MaxHLClr1']=np.select([(Tz['MaxHLClr']=="G") ,(Tz['MaxHLClr']=="R")],[1,0],Tz['MaxHLClr'] )
    
    Tz['Seq1']=np.select([(Tz['Seq']==True) ,(Tz['Seq']==False)],[1,0],Tz['Seq'] )
    Tz['Type1']=np.select([(Tz['Type']=="High") ,(Tz['Type']=="Low")],[1,0],Tz['Type'] )
    Tz.dtypes
    #Tz['G1']=np.select([(Tz['G']==True) ,(Tz['G']==False)],[1,0],Tz['G'] )
    Tz[['BuyProfitP','Label','SellProfitP']]
    Tz.isna().any()[lambda x: x] #check is there any column with Nan value
    sum(Tz.isnull().values.ravel())
    Tz.shape[0]-Tz.dropna().shape[0] #To check no.of row shas na value
    DataSet=Tz.dropna()
    FeatureDataSet=DataSet[['Index','CGap','PGap','PDiffP','DiffP','MaxHL','MaxHLIdx','MaxHLClr1','MaxHLOCP','MaxHP','MaxLP','CHL', 'CHLC','COC','HL', 'HLC','OC', 'PercHL',  'RPercHL','G1',
     'SPercCL','SPercHC','SPercHH','SPercHL','SPercLL','SPercOC',
     'TPercCL','TPercHC','TPercHL','TPercHO','TPercOC','TPercOL',       
     'Type1','Seq1','CFD','CPD','PFD','PPD']]
    
    FeatureDataSet=DataSet[['MaxHL','MaxHLClr1','Index','G','CGap']]
    Label=DataSet['Label']
    #FeatureDataSet.shape[0]
    X_train.shape[0]
    X_test.shape[0]
    X_train, X_test, Y_train, Y_test = train_test_split(FeatureDataSet, Label, random_state=0)
    regressor = DecisionTreeRegressor(splitter="best",max_features="auto")    #splitter="best",min_samples_split=5 
    #regressor = DecisionTreeRegressor(splitter="best",min_samples_split=5,min_impurity_decrease=10 )    
    regressor.fit(X_train, Y_train)    
    Y_pred=regressor.predict(X_test)
    print("Accuracy:",metrics.accuracy_score(Y_test, Y_pred))
    
    
    clf= DecisionTreeClassifier() #criterion="gini"
    clf.fit(X_train, Y_train)
    yc_pred=clf.predict(X_test)
    print("Accuracy:",metrics.accuracy_score(Y_test, yc_pred))
    
    
    from sklearn.tree import export_graphviz
    export_graphviz(regressor, out_file =r'C:\ReadMoneycontrol\Mani 2.0\Temp\tree.dot',
                    feature_names =['Index','G'])
    
    export_graphviz(clf, out_file =r'C:\ReadMoneycontrol\Mani 2.0\Temp\tree.dot',
                    feature_names =['MaxHL','MaxHLClr1','Index','G','CGap'])
    
    
    tdf=pd.DataFrame({'Actual':Y_test, 'Predicted':y_pred,'PredictedC':yc_pred})
    tdf
    np.select([(tdf['Actual']==tdf['Predicted'])],[0],1 ).shape[0]
    Total=tdf.shape[0]
    Matching=tdf[tdf['Actual']==tdf['Predicted']].shape[0]
    Matchingc=tdf[tdf['Actual']==tdf['PredictedC']].shape[0]
    MatchingBoth=tdf[tdf['Predicted']==tdf['PredictedC']].shape[0]
    MatchingBoth1=tdf[(tdf['Predicted']==tdf['PredictedC']) & (tdf['Predicted']!=tdf['Actual'])].shape[0]
    Total-Matching
    
    print('Mean Absolute Error:', metrics.mean_absolute_error(Y_test, y_pred))
    print('Mean Squared Error:', metrics.mean_squared_error(Y_test, y_pred))
    print('Root Mean Squared Error:', np.sqrt(metrics.mean_squared_error(Y_test, y_pred)))
    metrics.accuracy_score(Y_test, y_pred)
    regressor.score(X_test,Y_test)
    
    max_depth_range = list(range(1, 10))# List to store the average RMSE for each value of max_depth:
    accuracy = []
    for depth in max_depth_range:    
        clf = DecisionTreeClassifier(max_depth = depth, 
                             random_state = 0)
        clf.fit(X_train, Y_train)    
        score = clf.score(X_test, Y_test)
        accuracy.append(score)
    
    max_depth_range = list(range(1, 10))# List to store the average RMSE for each value of max_depth:
    accuracy = []
    for depth in max_depth_range:    
        clf = DecisionTreeRegressor(max_depth = depth, 
                             random_state = 0)
        clf.fit(X_train, Y_train)    
        score = clf.score(X_test, Y_test)
        accuracy.append(score)
        
    from sklearn.tree import export_graphviz
    export_graphviz(regressor, out_file =r'C:\ReadMoneycontrol\Mani 2.0\Temp\tree.dot', 
               feature_names =['Index','CGap','PGap','PDiffP','DiffP','MaxHL','MaxHLIdx','MaxHLClr1','MaxHLOCP','MaxHP','MaxLP','CHL', 'CHLC','COC','HL', 'HLC','OC', 'PercHL',  'RPercHL','G1',
     'SPercCL','SPercHC','SPercHH','SPercHL','SPercLL','SPercOC',
     'TPercCL','TPercHC','TPercHL','TPercHO','TPercOC','TPercOL',       
     'Type1','Seq1','CFD','CPD','PFD','PPD']) 

    decision_tree(X_train, Y_train, True, max_depth=3)
    X=X_train    
    y=Y_train
    regression=True
def decision_tree(X, y, regression, max_depth=3):
    from sklearn.tree import export_graphviz
    from sklearn.externals.six import StringIO  
    from IPython.core.pylabtools import figsize
    from IPython.display import Image
    figsize(12.5, 6)
    import pydotplus
    
    if regression:
        clf = DecisionTreeRegressor(max_depth=max_depth)
    else:
        clf = DecisionTreeClassifier(max_depth=max_depth)
        
    clf.fit(X, y)
    dot_data = StringIO()  
    export_graphviz(clf, out_file=dot_data, feature_names=list(X.columns),
                    filled=True, rounded=True,)
    graph = pydotplus.graph_from_dot_data(dot_data.getvalue())  
    graph.write_png(r"C:\ReadMoneycontrol\Mani 2.0\Temp\tree.png")
    return Image(graph.create_png()) 


#
#from sklearn.cross_validation import StratifiedShuffleSplit
#import numpy as np
#import pandas as pd
#
#np.random.seed(42)
#
#test_df = pd.DataFrame({'A': np.random.random(1000),
#                        'B': np.random.random(1000),
#                        'class': np.random.randint(0, 2, 1000)})
#
#training_indeces, testing_indeces = next(iter(StratifiedShuffleSplit(test_df['class'].values,
#                                                                     n_iter=1,
#                                                                     train_size=0.75,
#                                                                     test_size=0.25)))