# -*- coding: utf-8 -*-
"""
Created on Tue Apr 30 20:19:00 2019

@author: lalitha
"""

import pandas as pd
import pandas as fibpd
import pandas as pdsymbol
import numpy as np
from stockstats import StockDataFrame

#df=GoldCandle5Min.rename(columns={"close":"Close"})

#df.columns
#df[['macd','macds']]#,'MACDdiff_12_26']]
#df=Candle
#df['rsi_6']=ta.RSI(Candle,6)
#df['rsi_12']=ta.RSI(Candle,12)
#df['rsi_24']=ta.RSI(Candle,24)
#n=0
#while(n<20):
#    n=n+1
#    #L=getSpecificData(LeadHistoryV1,LCandle,n)
#    L=getSpecificData(GoldHistoryV1,Candle,n)
#    #L=getSpecificData(SilverHistory,SCandle,n)
#    L=L.reset_index()
#    i=13
#    while(i<len(L)-1):
#        i=i+1
#        index=i
#        rsi_6, rsi_12, rsi_24 = L['rsi_6'][index], L['rsi_12'][index], L['rsi_24'][index]
#        if ((rsi_6 < 20) & (rsi_12 < 20) & (rsi_24 < 30)):
#            print("Trigger Buy : "+ str(L.iloc[i]['Date']))
#    #L[L['RSI']>=71 ]
#    #L[L['RSI']<29 ]
#    
    
#macd, signal,hist = ta.MACD(Candle['Close'],12,26,9)
def moving_average(x, n, type='simple'):
	"""
	compute an n period moving average.

	type is 'simple' | 'exponential'

	"""
	x = np.asarray(x)
	if type == 'simple':
		weights = np.ones(n)
	else:
		weights = np.exp(np.linspace(-1., 0., n))

	weights /= weights.sum()

	a = np.convolve(x, weights, mode='full')[:len(x)]
	a[:n] = a[n]
	return a

def moving_average_convergence(x, nslow=26, nfast=12):
	"""
	compute the MACD (Moving Average Convergence/Divergence) using a fast and slow exponential moving avg'
	return value is emaslow, emafast, macd which are len(x) arrays
	"""
	emaslow = moving_average(x, nslow, type='exponential')
	emafast = moving_average(x, nfast, type='exponential')
	return emaslow, emafast, emafast - emaslow

def macd(df,a,b,c):
    df['26_ema'] = moving_average(df['Close'], b,type='exponential')
    df['12_ema'] = moving_average(df['Close'], a,type='exponential')
    df['MACD'] = (df['12_ema'] - df['26_ema'])
    df['Signal'] = moving_average(df['MACD'], c,type='exponential')
    df['Crossover'] = df['MACD'] - df['Signal']
    df['Crossover1']=df['Crossover'][-1:].mean()
    return df

#df=macd(Candle,12,26,9)
#df['Close'].ewm(span=12,adjust=False).mean()
#GoldCandle5Min

def Newmacd(df,field):
    exp1 = df[field].ewm(span=12, adjust=False).mean()
    exp2 = df[field].ewm(span=26, adjust=False).mean()
    df['MACD'] = exp1-exp2
    df['Signal']= df['MACD'].ewm(span=9, adjust=False).mean()
    df['Crossover'] = df['MACD'] - df['Signal']
    return df

def macd(df, n_fast, n_slow):
    """Calculate MACD, MACD Signal and MACD difference
    
    :param df: pandas.DataFrame
    :param n_fast: 
    :param n_slow: 
    :return: pandas.DataFrame
    """
    EMAfast = pd.Series(df['Close'].ewm(span=n_fast, min_periods=n_slow).mean())
    EMAslow = pd.Series(df['Close'].ewm(span=n_slow, min_periods=n_slow).mean())
    MACD = pd.Series(EMAfast - EMAslow, name='MACD_' + str(n_fast) + '_' + str(n_slow))
    MACDsign = pd.Series(MACD.ewm(span=9, min_periods=9).mean(), name='MACDsign_' + str(n_fast) + '_' + str(n_slow))
    MACDdiff = pd.Series(MACD - MACDsign, name='MACDdiff_' + str(n_fast) + '_' + str(n_slow))
    df = df.join(MACD)
    df = df.join(MACDsign)
    df = df.join(MACDdiff)
    return df

#
#df=macd(Candle,12,26)
#df[['Date','MACD_12_26','MACDsign_12_26']]#,'MACDdiff_12_26']]
#
#df=Newmacd(Candle,"Close")
#df[['Date','MACD','Signal','Crossover']]
#
##Candle=GoldCandle5Min.rename(columns={"close":"Close"})
#Candle=G5MinData.rename(columns={"close":"Close"})
#Candle1=G5MinData
#
#stock_df = StockDataFrame.retype(Candle) # to Calculate RSI
#Candle['Date']=Candle.index
#Candle.sort_values(by=['Date'], inplace=True, ascending=True)
#Candle.reset_index()
##Candle1.sort_values(by=['Date'], inplace=True, ascending=False)
#RSI(Candle['close'],14)
#RSIValue=RSI(Candle,14)
#Candle['RSI']=RSIValue
##Candle.columns
##df['RSI']=ta.RSI(df,14)
#df=Newmacd(Candle,"close")
#Candle['MACD']=df['MACD']
#Candle['RSI']=Candle['rsi_14']
#Candle['Close']=Candle['close']
#Candle['Signal']=df['Signal']
#Candle['Crossover']=df['Crossover']
#
#
#SCandle=SilverCandle5Min.rename(columns={"close":"Close"})
#RSIValue=ta.RSI(SCandle,14)
#SCandle['RSI']=RSIValue
#df=Newmacd(Candle,"Close")
#SCandle['MACD']=df['MACD']
#SCandle['Signal']=df['Signal']
#SCandle['Crossover']=df['Crossover']
#
#LCandle=LeadCandle5Min.rename(columns={"close":"Close"})
#RSIValue=ta.RSI(LCandle,14)
#LCandle['RSI']=RSIValue


"""

a=getSpecificData(GoldHistoryV1,Candle,30)
#Candle[-20:]

a[a['RSI']>=71 ][['Date','RSI','MACD','Signal','Crossover']]
a[(a['Crossover']<0) & (a['Crossover']>-1) ][['Date','RSI','MACD','Signal','Crossover']]
a[(a['Crossover']>0) & (a['Crossover']<1) ][['Date','RSI','MACD','Signal','Crossover']]
a[a['RSI']<29 ][['Date','RSI','MACD','Signal','Crossover']]
"""

#Candle1=G5MinData
Candle=GoldCandle5Min.rename(columns={"close":"Close"})
#stock_df = StockDataFrame.retype(Candle) # to Calculate RSI
RSIValue=ta.RSI(Candle,14)
Candle['Date']=Candle.index
#Candle.sort_values(by=['Date'], inplace=True, ascending=True)
#Candle.reset_index()
df=Newmacd(Candle,"Close")
Candle['MACD']=df['MACD']
Candle['RSI']=RSIValue
#Candle['Close']=Candle['Close']
Candle['Signal']=df['Signal']
Candle['Crossover']=df['Crossover']


Candle15=GoldCandle15Min.rename(columns={"close":"Close"})
#stock_df = StockDataFrame.retype(Candle) # to Calculate RSI
RSIValue=ta.RSI(Candle15,14)
#Candle15['Date']=Candle15.index
#Candle.sort_values(by=['Date'], inplace=True, ascending=True)
#Candle.reset_index()
df=Newmacd(Candle15,"Close")
Candle15['MACD']=df['MACD']
Candle15['RSI']=RSIValue
#Candle['Close']=Candle['Close']
Candle15['Signal']=df['Signal']
Candle15['Crossover']=df['Crossover']

#Candle.head()

Threshold=5
n=1
Message=[]
Sum=0
while(n<=30):
    n=n+1
    #L=getSpecificData(LeadHistoryV1,LCandle,n)
    L=getSpecificData(GoldHistoryV1,Candle,n)
    #L=getSpecificData(SilverHistory,SCandle,n)
    SearchData=Candle
    Data=L
    L=L.reset_index()
    GMargin=75
    GStop=100
    #L[L['RSI']>=71 ]
    #L[L['RSI']<29 ]
    
    LRSI=list(L['RSI'])
    i=13
    Found=False
    First=False
    while(i<len(LRSI)-30):
        i=i+1
        TempD={}
        
        if(First==False):
            
            arTempD=[]
            SellFound=False
            Retry=0
            BuyFound=False
            First=True
        #print(str(i)+"\t"+str(L.iloc[i]['Date'])+ " - " + str(Retry))
        if(Retry>=Threshold): 
            Retry=0
            SellFound=False
            BuyFound=False
        if( (LRSI[i]>=61) and (LRSI[i]<=100)):
            
            TempD["Index"]=i
            TempD["RSI"]=LRSI[i]
            TempD["Date"]=L.iloc[i]["Date"]
            TempD["Price"]=L.iloc[i]["low"]
            arTempD.append(TempD)
            Found=True
            SellFound=True
            LSFI=i
            #print("\t"+str(Retry)+"\t"+str(L.iloc[i]['Date']) + "\t"+str(L.iloc[i]["Close"]))
        elif( (LRSI[i]>=5) and (LRSI[i]<=35) ):
            TempD["Index"]=i
            TempD["RSI"]=LRSI[i]
            TempD["Date"]=L.iloc[i]["Date"]
            TempD["Price"]=L.iloc[i]["high"]
            arTempD.append(TempD)
            Found=True
            BuyFound=True
        else:
            
            if ( True and (SellFound==True) and (Retry<Threshold)):            
                #print(str(L.iloc[i]['Date']) + "\t"+str(L.iloc[i]["Close"])+"\t"+str(arTempD[GetIndex*-1:][0]['Price'])+"\t"+str(LRSI[i]))            
                #print(Retry)
                Retry=Retry+1
                arTempDLen=len(arTempD)
                if(arTempDLen>=2):
                    GetIndex=2
                    if(arTempDLen>=3):
                        GetIndex=3
                else:
                    Retry=0
                    SellFound=False
                Po=0
                D=pd.DataFrame(arTempD[0:GetIndex]);
                if((Retry<=Threshold) and SellFound):
                    #if(L.iloc[i]["low"]<arTempD[GetIndex*-1:][0]['Price']):
                    if((L.iloc[i]["low"]<arTempD[GetIndex*-1:][0]['Price'])) :
                        Po=1
                        #print("Trigger Sell : "+ str(L.iloc[i]['Date']))
#                        Retry=0
#                        SellFound=False
                    if(L.iloc[i]["Crossover"]<0):
                        
                        LastPr=L.iloc[0:i-1][(L['Crossover']>0) & (L['Crossover']<1)][-1:]['Close']
                        CurrP=L.iloc[i]['Close']
                        if(len(list(LastPr))>0):
                            LastP=list(LastPr)[0]
                        else:
                            LastP=CurrP-50                            
                            
                        Transaction="Buy"
                        Diff=CurrP-LastP
                        if(Diff>90):
                            ModDiff=100
                            ModStopLoss=70
                            Transaction="Sell"
                        elif(Diff<15):
                            if(LRSI[i]>60):
                                Transaction="Sell"
                            ModDiff=89
                            ModStopLoss=80
                        else:
                            ModDiff=71
                            ModStopLoss=85
                            if(LRSI[i]<60):
                                Transaction="Sell"
                        #ModDiff=30
                        #ModStopLoss=25
                        if((Po==1)  ):
                            Result=candlestick.Check(Data,Transaction,i,ModDiff,ModStopLoss,SearchData)
                            Message.append(str(round(LRSI[i]))+ " - " +str(Po)+"\t "+Transaction+" : "+ str(L.iloc[i]['Date'])
                            +"\t Sell :"+str(CurrP)
                            #+"\t Target :"+str(CurrP-ModDiff)
                            #+"\t StopLoss :"+str(CurrP+ModStopLoss)
                            +"\t Profit :" + str(Result['Profit']) )
                            Sum=Sum+Result['Profit']
                        #a[(a['Crossover']>0) & (a['Crossover']<1) ][['Date','RSI','MACD','Signal','Crossover']]
                        Retry=0
                        SellFound=False
                        arTempD=[]
                        
                    
            if (False and  (BuyFound==True) and (Retry<Threshold)):            
                Retry=Retry+1
                arTempDLen=len(arTempD)
                if(arTempDLen>=2):
                    GetIndex=2
                    if(arTempDLen>=3):
                        GetIndex=arTempDLen-1
                else:
                    Retry=0
                    BuyFound=False
                T=0
                #print(str(L.iloc[i]['Date']) + "\t"+str(L.iloc[i]["Close"])+"\t"+str(arTempD[GetIndex*-1:][0]['Price'])+"\t"+str(LRSI[i]))            
                if((Retry<=Threshold) and BuyFound):
                    if(L.iloc[i]["high"]>arTempD[GetIndex*-1:][0]['Price']):                        
                        T=1
                        MaxRSI=max(LRSI[15:i-1])
                        print("Trigger Buy : "+ str(L.iloc[i]['Date'])
                        +"\t RSI:"+str(round(LRSI[i],2))
                        +"\t MaxRSI:"+str(round(MaxRSI,2))
                        +"\t i:"+str(i)
                        +"\t n:"+str(n)
                        )
                    if((L.iloc[i]["Crossover"]>0) or True):
                        LastPr=L.iloc[0:i-1][(L['Crossover']<0) & (L['Crossover']<-1)][-1:]['Close']
                        CurrP=L.iloc[i]['Close']
                        if(len(list(LastPr))>0):
                            LastP=list(LastPr)[0]
                        else:
                            LastP=CurrP+50                            
                        
                        Diff=CurrP-LastP
                        Transaction="Buy"
                        if(Diff>90):
                            ModDiff=75
                            ModStopLoss=31
                            Transaction="Sell"
                        elif(Diff<15):
                            ModDiff=70
                            ModStopLoss=33
                        else:
                            ModDiff=70
                            ModStopLoss=60
                        #ModDiff=30
                        #ModStopLoss=25
                        if((T==2)  ):
                            Result=candlestick.Check(Data,Transaction,i,ModDiff,ModStopLoss,SearchData)
                            Message.append(str(LRSI[i])+ " - " +str(T)+ "\tTrigger Buy  MACD : "+ str(L.iloc[i]['Date'])
                            +"\t Buy:"+str(CurrP)
                            +"\t Target:"+str(CurrP+ModDiff)
                            +"\t StopLoss:"+str(CurrP-ModStopLoss)
                            +"\t Profit :" + str(Result['Profit'])
                            )
                            Sum=Sum+Result['Profit']
                        #print("Trigger Buy MACD : "+ str(L.iloc[i]['Date']))
                        Retry=0
                        
                        BuyFound=False
                        arTempD=[]
    #        else:
    #            Retry=0
    #            SellFound=False
    #            TempD={}
    #            arTempD=[]
    #                
            Found=False
#pd.DataFrame(arTempD)        
for message in Message:
    print(message)
print("Total Profit:\t"+ str(Sum))