# -*- coding: utf-8 -*-
"""
Created on Wed May  1 19:57:41 2019

@author: lalitha
"""

    
import sys, os, time, datetime, warnings, configparser
import pandas as pd
import numpy as np
import talib
#import concurrent.futures
#import tushare as ts
import matplotlib.pyplot as plt

def KDJ(df):
    low_list = df['low'].rolling(center=False,window=9).min()
    low_list.fillna(value=df['low'].expanding(min_periods=1).min(), inplace=True)
    high_list = df['high'].rolling(center=False,window=9).max()
    high_list.fillna(value=df['high'].expanding(min_periods=1).max(), inplace=True)
    rsv = (df['close'] - low_list) / (high_list - low_list) * 100
    df['kdj_k'] = rsv.ewm(min_periods=0,adjust=True,ignore_na=False,com=2).mean()
    df['kdj_d'] = df['kdj_k'].ewm(min_periods=0,adjust=True,ignore_na=False,com=2).mean()
    df['kdj_j'] = 3 * df['kdj_k'] - 2 * df['kdj_d']
    return df

def RSI(df, n=14):
    prices = df['close'].values.tolist()
    deltas = np.diff(prices)
    seed = deltas[:n+1]
    up = seed[seed>=0].sum()/n
    down = -seed[seed<0].sum()/n
    rs = up/down
    rsi = np.zeros_like(prices)
    rsi[:n] = 100. - 100./(1.+rs)

    for i in range(n, len(prices)):
        delta = deltas[i-1] # cause the diff is 1 shorter

        if delta>0:
            upval = delta
            downval = 0.
        else:
            upval = 0.
            downval = -delta

        up = (up*(n-1) + upval)/n
        down = (down*(n-1) + downval)/n

        rs = up/down
        rsi[i] = 100. - 100./(1.+rs)

    key = 'rsi_' + str(n)
    df[key] = rsi
    return df

def MACD(df, short_win=12, long_win=26, macd_win=9):
    # talib计算MACD
    prices = np.array(df['close'])
    macd_tmp = talib.MACD(prices, fastperiod=short_win, slowperiod=long_win, signalperiod=macd_win)
    df['macd_dif'] = macd_tmp[0]
    df['macd_dea'] = macd_tmp[1]
    df['macd'] = macd_tmp[2]
    return df


def corssover(input_1, input_2):
    index = -1
    return (input_1[index] > input_2[index]) & (input_1[index-1] < input_2[index-1])

def ma_rule(df):
    df['ma5']   = df['close'].rolling(window=5, center=False).mean()
    df['ma10']  = df['close'].rolling(window=10, center=False).mean()
    df['ma20']  = df['close'].rolling(window=20, center=False).mean()
    df['ma30']  = df['close'].rolling(window=30, center=False).mean()
    df['ma60']  = df['close'].rolling(window=60, center=False).mean()
    df['ma120'] = df['close'].rolling(window=120, center=False).mean()
    df['ma250'] = df['close'].rolling(window=250, center=False).mean()

    index = -1
    fit_count = 0
    delta = 0.05 #ma5 / 60

    ma5, ma10, ma20, ma30, ma60, ma120, ma250 = df['ma5'][index], df['ma10'][index], df['ma20'][index], df['ma30'][index], df['ma60'][index], df['ma120'][index], df['ma250'][index]

    if abs(ma5 - ma10)  < delta: fit_count += 1
    if abs(ma5 - ma20)  < delta: fit_count += 1
    if abs(ma5 - ma30)  < delta: fit_count += 1
    if abs(ma5 - ma60)  < delta: fit_count += 1
    if abs(ma5 - ma120) < delta: fit_count += 1
    if abs(ma5 - ma250) < delta: fit_count += 1

    return fit_count > 4

def kdj_rule(df):
    try: df = KDJ(df)
    except: return False

    if len(df) < 2: return False
    index = -1
    return corssover(df['kdj_j'], df['kdj_d']) & (df['kdj_d'][index] > df['kdj_d'][index-1])
    
def kdj_rule_1(df):
    try: df = KDJ(df)
    except: return False

    return df['kdj_d'][-1] < 20

def macd_rule(df):
    try:  df = MACD(df)
    except: return False

    input_1 = 0.2
    input_2 = -0.8
    input_3 = 22 * 3
    index = -1
    df['macd_dif_1'] = df['macd_dif'].shift(1)
    df['macd_dea_1'] = df['macd_dea'].shift(1)

    return (abs(df['macd_dea'][index]) < input_1) & \
           (abs(df['macd_dif'][index]) < input_1) & \
           (df['macd_dif'][-input_3:].min() < input_2) & \
           (df['macd_dif'][index] > df['macd_dea'][index]) & \
           ((df['macd_dea_1'][index] > df['macd_dif_1'][index]) | (abs(df['macd_dea_1'][index] - df['macd_dif_1'][index]) < 0.007))

def macd_rule_1(df):
    try:  df = MACD(df)
    except: return False

    input_1 = 0
    input_2 = -0.8
    input_3 = 0.05

    dif_len = len(df['macd_dif'])
    if dif_len < 2: return False

    if abs(df['macd_dif'][-1]) > input_3:
        return False

    for idx in range(dif_len-1, 1, -1):
        if ((df['macd_dif'][idx] - df['macd_dif'][idx-1]) > input_1):
            continue

        if df['macd_dif'][idx] <= input_2:
            return True
        else: return False
        
def macd_rule_2(df, symbol):
    try:  df = MACD(df)
    except: return False

    input_1 = -3
    input_2 = -0.2

    index = -1

    return (df['macd_dif'][index] > input_1) & \
           (df['macd_dif'][index] < input_2) & \
           (df['macd_dif'][index] > df['macd_dea'][index]) & \
           ((df['macd_dea'][index-1] > df['macd_dif'][index-1]) | (abs(df['macd_dea'][index-1] - df['macd_dif'][index-1]) < 0.007))


def rsi_rule(df):
    try:  
        df = RSI(df, 6)
        df = RSI(df, 12)
        df = RSI(df, 24)
    except: return False

    index = -1
    rsi_6, rsi_12, rsi_24 = df['rsi_6'][index], df['rsi_12'][index], df['rsi_24'][index]

    return (rsi_6 < 20) & (rsi_12 < 20) & (rsi_24 < 30)
    

def judge_rule(symbol, dataset, window, selection, str):
    #if kdj_rule(dataset) & macd_rule(dataset):
    if kdj_rule_1(dataset):
        selection.append(symbol)
        
        