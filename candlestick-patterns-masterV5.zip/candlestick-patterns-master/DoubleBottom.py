# -*- coding: utf-8 -*-
"""
Created on Sun Feb  9 20:49:05 2020

@author: lalitha
"""
import pandas as pd
import numpy as np
from dateutil.parser import parse
import os
import itertools

AllStockList="C:\ReadMoneycontrol\Mani 2.0\StockListAll.txt"
DIRNIFTY="C:\ReadMoneycontrol\Mani 2.0"
StockListFile=r"C:\ReadMoneycontrol\Mani 2.0\StockListID-NEWList.csv"
OtherStock=r"C:\ReadMoneycontrol\Mani 2.0\NEWDataIncr1"
#StockListFile=AllStockList
#DataDir=DIRNIFTY
DataDir=OtherStock

StrTimeIntervals=['minute','3minute','5minute','15minute','day']
FutureDir=r"C:\ReadMoneycontrol\Mani 2.0\GapUpStrategy\Data\\"
Non_FutureDir=r"C:\ReadMoneycontrol\Mani 2.0\GapUpStrategy\Data1\\"


def futuresf():
    DataDir=DIRNIFTY
    FStocks1=pd.read_csv(AllStockList)
    StockList=FStocks1
#    Phase1(FutureDir,FStocks1)
#    Phase2(FutureDir)
#    Phase3(FutureDir,FStocks1)


def Nonfuturesf():
    DataDir=OtherStock
    NFStocks1=pd.read_csv(StockListFile)
    TargetDir=Non_FutureDir
#    Phase1(Non_FutureDir,NFStocks1)
#    Phase2(Non_FutureDir)
#    Phase3(Non_FutureDir,NFStocks1)
if(False):
    i=0
    First=True
    while(i<len(StockList)):
        StockName=StockList.iloc[i]['StockName']
        i=i+1
        MinuteFile=""
        #if(os.path.exists("C:\ReadMoneycontrol\Mani 2.0\Temp3\Corrected\\"+StockName+'AllStock.csv')==True):
        #    FilePath="C:\ReadMoneycontrol\Mani 2.0\Temp3\Corrected\\"+StockName+'AllStock.csv'
        if(os.path.exists(DataDir+"\Data\\"+StockName+'-15minute.csv')==True):
            MinuteFile=DataDir+"\Data\\"+StockName+'-15minute.csv'
            DayFile=DataDir+"\Data\\"+StockName+'-day.csv'        
        if(DayFile!=""):
    #        print(StockName)
            #FilePath="C:\ReadMoneycontrol\Mani 2.0\GapUp-ZTemp\\ASAHIINDIAAllStock.csv"
            DayDF=pd.read_csv(MinuteFile)
            DayDF['Stock']=StockName
            DayDF.columns=['Date', 'Open', 'High', 'Low', 'Close', 'V','Stock']
            DayDF['DayRSI14']=ta.RSI(DayDF,14)
            DayDF=DayDF.dropna()
            DayDF['DayRSI14'].dropna()
            DayDF['DayRSI14']=DayDF['DayRSI14'].astype(int)
            DayDF['HLP']=round((DayDF['High']-DayDF['Low'])/DayDF['Low']*100)                        
            DayDF['OCP']=round((DayDF['Close']-DayDF['Open'])/DayDF['Open']*100)
            DayDF['R']=round(DayDF['Close']*.004,0)
            DayDF['LowT']=round(DayDF['Low']/DayDF['R'],0)*DayDF['R']
            DayDF['HighT']=round(DayDF['High']/DayDF['R'],0)*DayDF['R']
            DayDF[['Date','DayRSI14']]
            DayDF['CDATE']=pd.to_datetime(DayDF['Date']).dt.strftime("%Y-%b-%d")
            DayDF['CDayHigh']=DayDF.groupby(['CDATE'])['High'].apply(lambda x: x.cummax())
            DayDF['CDayLow']=DayDF.groupby(['CDATE'])['Low'].apply(lambda x: x.cummin())
            DayDF
            LduplicateRowsDF = DayDF[DayDF.duplicated(['LowT'])]
            LAduplicateRowsDF1=LduplicateRowsDF[LduplicateRowsDF['OCP']>1]
            LAduplicateRowsDF2=DayDF[(DayDF.LowT.isin(list(LAduplicateRowsDF1.LowT))) & (DayDF['OCP']>.5)].sort_values(['Low','Date'],ascending=False)
                        
            LBduplicateRowsDF1=LduplicateRowsDF[LduplicateRowsDF['OCP']<-1]
            LBduplicateRowsDF2=DayDF[(DayDF.Low.isin(list(LBduplicateRowsDF1.Low))) & (DayDF['OCP']<-.5)].sort_values(['Low','Date'],ascending=False)
            
            HduplicateRowsDF = DayDF[DayDF.duplicated(['HighT'])]
            HAduplicateRowsDF1=HduplicateRowsDF[(HduplicateRowsDF['CDayHigh']==HduplicateRowsDF['High']) & (HduplicateRowsDF['OCP']<-0.1) & (HduplicateRowsDF['HLP']>1)]
            
            
            HAduplicateRowsDF1=HduplicateRowsDF[HduplicateRowsDF['OCP']>1]
            HAduplicateRowsDF2=DayDF[(DayDF.HighT.isin(list(HAduplicateRowsDF1.HighT))) & (DayDF['OCP']<-.01) & (HduplicateRowsDF['CDayHigh']==HduplicateRowsDF['High'])].sort_values(['High','Date'],ascending=False)
            HAduplicateRowsDF2=DayDF[(DayDF.HighT.isin(list(HAduplicateRowsDF1.HighT))) ].sort_values(['High','Date'],ascending=False)
                        
            HBduplicateRowsDF1=HduplicateRowsDF[HduplicateRowsDF['OCP']<-.5]
            HBduplicateRowsDF2=DayDF[(DayDF.High.isin(list(HBduplicateRowsDF1.High))) & (DayDF['OCP']<-.05)].sort_values(['High','Date'],ascending=False)
            #duplicateRowsDF2.sort_values(['Low','Date'])
            
            
            