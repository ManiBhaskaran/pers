
def UpdateDataFrameCollection(StockName,indx):
    global DataFrameCollection
    print(StockName+" ... Started")
    i=0
    lListP=[]
    hListP=[]
    cListP=[]
    lListS=[]
    hListS=[]
    cListS=[]
    
    RlListP=[]
    RhListP=[]
    RcListP=[]
    RlListS=[]
    RhListS=[]
    RcListS=[]
    HLCP=[]
    HLCS=[]
    Rolling=3
    
    while(i<len(DataFrameCollection[StockName])):
#        print(StockName+" ... Ended ..."+str(indx) +  " - - "+ str(i))
        sLow=list(DataFrameCollection[StockName].iloc[:i]['Low'])
        NLow=list(DataFrameCollection['NIFTY'].iloc[:i]['Low'])
        sHigh=list(DataFrameCollection[StockName].iloc[:i]['High'])
        NHigh=list(DataFrameCollection['NIFTY'].iloc[:i]['High'])        
        sClose=list(DataFrameCollection[StockName].iloc[:i]['Close'])        
        NClose=list(DataFrameCollection['NIFTY'].iloc[:i]['Close'])
        sHLC=list(DataFrameCollection[StockName].iloc[:i]['HLC'])        
        NHLC=list(DataFrameCollection['NIFTY'].iloc[:i]['HLC'])
                    
        if(i<Rolling):
           RlListP.append(0) 
           RlListS.append(0)           
        else:
            Comp1={}
            Comp1['NIFTY']=list(DataFrameCollection['NIFTY'].iloc[:i-Rolling]['Low'])
            Comp1['STOCKA']=list(DataFrameCollection[StockName].iloc[:i-Rolling]['Low'])
            RlListS.append("{0:.4f}".format(stats.spearmanr(Comp1['NIFTY'],Comp1['STOCKA'])[0]))
            RlListP.append("{0:.4f}".format(stats.pearsonr(Comp1['NIFTY'],Comp1['STOCKA'])[0]))
            #pd.DataFrame(Comp1).corr(method="pearson").iloc[1]["NIFTY"]))
            #RlListS.append("{0:.4f}".format(pd.DataFrame(Comp1).corr(method="spearman").iloc[1]["NIFTY"]))     
            if(i<Rolling+2):
                RhListP.append(0) 
                RhListS.append(0)
            else:
                Comp1={}
                #Comp1['NIFTY']=list(DataFrameCollection['NIFTY'].iloc[:i-Rolling]['High'])
                #Comp1['STOCKA']=list(DataFrameCollection[StockName].iloc[:i-Rolling]['High'])
                Comp1['NIFTY']=list(DataFrameCollection['NIFTY'].iloc[:i-Rolling-2]['Low'])
                Comp1['STOCKA']=list(DataFrameCollection[StockName].iloc[:i-Rolling-2]['Low'])            
                RhListS.append("{0:.4f}".format(stats.spearmanr(Comp1['NIFTY'],Comp1['STOCKA'])[0]))
                RhListP.append("{0:.4f}".format(stats.pearsonr(Comp1['NIFTY'],Comp1['STOCKA'])[0]))
            #RhListP.append("{0:.4f}".format(pd.DataFrame(Comp1).corr(method="pearson").iloc[1]["NIFTY"]))
            #RhListS.append("{0:.4f}".format(pd.DataFrame(Comp1).corr(method="spearman").iloc[1]["NIFTY"]))    

        Comp1={}
        Comp1['NIFTY']=NHLC
        Comp1['STOCKA']=sHLC
        #HLCP.append("{0:.4f}".format(pd.DataFrame(Comp1).corr(method="pearson").iloc[1]["NIFTY"]))
        #HLCS.append("{0:.4f}".format(pd.DataFrame(Comp1).corr(method="spearman").iloc[1]["NIFTY"]))    
        HLCS.append("{0:.4f}".format(stats.spearmanr(Comp1['NIFTY'],Comp1['STOCKA'])[0]))
        HLCP.append("{0:.4f}".format(stats.pearsonr(Comp1['NIFTY'],Comp1['STOCKA'])[0]))
        #HLCS.append("{0:.4f}".format(np.cov(Comp1['NIFTY'],Comp1['STOCKA'])[0][1]))
        #HLCS.append("{0:.4f}".format(np.std(NHLC)))
        #HLCP.append("{0:.4f}".format(np.std(sHLC)))
        #HLCP.append("{0:.4f}".format(
        Comp1={}
        Comp1['NIFTY']=NLow
        Comp1['STOCKA']=sLow
        #lListP.append("{0:.4f}".format(pd.DataFrame(Comp1).corr(method="pearson").iloc[1]["NIFTY"]))
        #lListS.append("{0:.4f}".format(pd.DataFrame(Comp1).corr(method="spearman").iloc[1]["NIFTY"]))    
        lListS.append("{0:.4f}".format(stats.spearmanr(Comp1['NIFTY'],Comp1['STOCKA'])[0]))
        lListP.append("{0:.4f}".format(stats.pearsonr(Comp1['NIFTY'],Comp1['STOCKA'])[0]))

        Comp1={}
        Comp1['NIFTY']=NHigh
        Comp1['STOCKA']=sHigh
        #hListP.append("{0:.4f}".format(pd.DataFrame(Comp1).corr(method="pearson").iloc[1]["NIFTY"]))
        #hListS.append("{0:.4f}".format(pd.DataFrame(Comp1).corr(method="spearman").iloc[1]["NIFTY"]))    
        hListS.append("{0:.4f}".format(stats.spearmanr(Comp1['NIFTY'],Comp1['STOCKA'])[0]))
        hListP.append("{0:.4f}".format(stats.pearsonr(Comp1['NIFTY'],Comp1['STOCKA'])[0]))
        
        Comp1={}
        Comp1['NIFTY']=NClose
        Comp1['STOCKA']=sClose
        cListS.append("{0:.4f}".format(stats.spearmanr(Comp1['NIFTY'],Comp1['STOCKA'])[0]))
        cListP.append("{0:.4f}".format(stats.pearsonr(Comp1['NIFTY'],Comp1['STOCKA'])[0]))

        #cListP.append("{0:.4f}".format(pd.DataFrame(Comp1).corr(method="pearson").iloc[1]["NIFTY"]))     
        #cListS.append("{0:.4f}".format(pd.DataFrame(Comp1).corr(method="spearman").iloc[1]["NIFTY"]))    
        i=i+1    
    #ta=DataFrameCollection['SBIN']
    
    
    
    DataFrameCollection[StockName]['LowP']=pd.DataFrame(lListP)
    DataFrameCollection[StockName]['LowS']=pd.DataFrame(lListS)
    DataFrameCollection[StockName]['HighP']=pd.DataFrame(hListP)
    DataFrameCollection[StockName]['HighS']=pd.DataFrame(hListS)
    DataFrameCollection[StockName]['RLowP']=pd.DataFrame(RlListP)
    DataFrameCollection[StockName]['RLowS']=pd.DataFrame(RlListS)
    DataFrameCollection[StockName]['RHighP']=pd.DataFrame(RhListP)
    DataFrameCollection[StockName]['RHighS']=pd.DataFrame(RhListS)
    DataFrameCollection[StockName]['CloseP']=pd.DataFrame(cListP)
    DataFrameCollection[StockName]['CloseS']=pd.DataFrame(cListS)
    DataFrameCollection[StockName]['HLCP']=pd.DataFrame(HLCP)
    DataFrameCollection[StockName]['HLCS']=pd.DataFrame(HLCS)
    DataFrameCollection[StockName]['StockName']=StockName
    DataFrameCollection[StockName].fillna(0)
    DataFrameCollection[StockName]=DataFrameCollection[StockName].astype({'LowP': 'float',
                       'LowS': 'float','HighP': 'float','HighS': 'float',
                       'CloseP': 'float','CloseS': 'float',
                       'HLCP' : 'float','HLCS' : 'float',
                       'RLowP' : 'float','RLowS' : 'float',
                       'RHighP' : 'float','RHighS' : 'float'
                       })
    print(StockName+" ... Ended ..."+str(indx))


