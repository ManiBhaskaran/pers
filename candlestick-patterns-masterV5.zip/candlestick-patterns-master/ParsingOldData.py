# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

import pandas as pd
import datetime
from datetime import datetime, timedelta
from dateutil.parser import parse
from candlestick import candlestick

def GetHData(DF,Interval):
    #DF=GoldDF
    Dates=list(DF.groupby(DF['Date1'])['Date1'].count().index)
    First=True
    arDaily=[]
    for Date in Dates:
        #print(Date)
    #    Date=Dates[2]
        Date1=Date.strftime("%Y-%m-%d 00:00")
        Date2=Date.strftime("%Y-%m-%d 23:59")
        Daily={}
        Temp1=DF[(DF['Date']>parse(Date1)) & (DF['Date']<parse(Date2))][['Date','open','high','low','close']]    
        #T1=Temp1
        Temp2=DF[(DF['Date']>parse(Date1)) & (DF['Date']<parse(Date2))]    
        Temp1['Date'] = pd.to_datetime(Temp1['Date'], unit='s')    
        #Temp1 = (Temp1.set_index('Date')
        #    .resample('5T').first()
        #    .reset_index()
        #   .reindex(columns=Temp1.columns)) how=ohlc_dict
        #Temp1=(Temp1.set_index('Date').resample('5T',  closed='left', label='left').first())
        logic = {
         #'Date': 'first',
         'open'  : 'first',
         'high'  : 'max',
         'low'   : 'min',
         'close' : 'last'
         }
        Temp1=Temp1.set_index('Date').resample(str(Interval)+'T').apply(logic).reset_index()
        #Temp1.iloc[0]
        #Temp1=Temp1.reset_index().reindex(columns=T1.columns)
        #Temp1.columns
        #.reset_index().reindex(columns=Temp1.columns)
        Daily['Date']=Temp2.iloc[0]['Date1']
        Daily['Open']=list(Temp2['open'][0:1])[0]
        Daily['Close']=list(Temp2['open'][-1:])[0]
        Daily['High']=Temp2['high'].max()
        Daily['Low']=Temp2['open'].min()
        
        arDaily.append(Daily)
        if(First):
            SCons=Temp1[['Date','open','high','low','close']]
            a=SCons
            First=False
        else:
            SCons=SCons.append(Temp1[['Date','open','high','low','close']])
    
    return pd.DataFrame(arDaily),SCons

def getFile(FilePath):
    Columns=['Symbol','Date','open','high','low','close','v','v2']
    DF=pd.read_csv(FilePath,header = None, names = Columns)
    List_ = list(DF['Date'])
    List1_ = [datetime.strptime(parse(x).strftime("%m/%d/%Y %I:%M %p"), "%m/%d/%Y %I:%M %p") for x in List_]    
    List2_ = [parse(parse(x).strftime("%m/%d/%Y")) for x in List_]
    DF['Date']=pd.Series([x for x in List1_],index=DF.index)
    DF['Date1']=pd.Series([x for x in List2_],index=DF.index)
    #List2_ = [x.strftime("%m/%d/%Y") for x in List_]
    return DF

def getPivots(Data1,PivotType,OHLC):
    #OHLC=3
    #Data1=SDailyData
    i=0
    Pivot=[]
    while(i<len(Data1)-1):
        Res=candlestick.getGoldPivots1(Data1.iloc[i]['Open'],Data1.iloc[i]['High'],Data1.iloc[i]['Low'],Data1.iloc[i]['Close'],PivotType,OHLC,"All")
        Res['Date']=Data1.iloc[i]['Date']
        Pivot.append(Res)
        i=i+1
    return Data1.merge(pd.DataFrame(Pivot))
    
        

"""
SilverFilePath="C:\ReadMoneycontrol\Gold\SILVER.csv"
#FilePath="C:\ReadMoneycontrol\Gold\SILVER.csv"
SilverDF=getFile(SilverFilePath)
#HResult=GetHData(SilverDF);SDailyData=HResult[0];S15MinData=HResult[1]

#S5MinData=HResult[1]
PivotType="D"
OHLC=4
#SilverHistoryDataV1=getPivots(SDailyData,PivotType,3)
#SilverHistoryDataV2=getPivots(SDailyData,PivotType,4)

#SilverHistoryDataV1.sort_values(by=['Date'], inplace=True, ascending=False)
#SilverHistoryDataV2.sort_values(by=['Date'], inplace=True, ascending=False)

#SilverHistoryDataV1.iloc[1]
#Pivotdf=pd.read_json(json.dumps(Pivot))    
#CrudeData=Data1.merge(Pivotdf)

GoldFilePath="C:\ReadMoneycontrol\Gold\GOLD.csv"
GoldDF=getFile(GoldFilePath)

HResult=GetHData(SilverDF,15);SDailyData=HResult[0];S15MinData=HResult[1]
HResult=GetHData(GoldDF,15);GDailyData=HResult[0];G15MinData=HResult[1]
HResult=GetHData(SilverDF,5);SDailyData=HResult[0];S5MinData=HResult[1]
HResult=GetHData(GoldDF,5);GDailyData=HResult[0];G5MinData=HResult[1]

"""
GoldExpiry="05FEB2019"
SilverExpiry="05DEC2018"
Symbol="GOLD"
PivotType="D"
OHLC=4
GoldHistoryV1=candlestick.GetEODDataFromMCX(Symbol,PivotType,OHLC,GoldExpiry)
GoldHistoryV2=candlestick.GetEODDataFromMCX(Symbol,PivotType,3,GoldExpiry)
"""
Symbol="SILVER"
PivotType="D"
OHLC=4
SilverHistory=candlestick.GetEODDataFromMCX(Symbol,PivotType,OHLC,SilverExpiry)
SilverHistoryV2=candlestick.GetEODDataFromMCX(Symbol,PivotType,3,SilverExpiry)
"""
#GoldHistoryDataV1=getPivots(GDailyData,PivotType,3)
#GoldHistoryDataV2=getPivots(GDailyData,PivotType,4)


#GoldHistoryDataV1.iloc[1]['IPivot']
#GoldHistoryDataV2.iloc[1]['IPivot']
#GoldHistoryDataV1.sort_values(by=['Date'], inplace=True, ascending=False)
#GoldHistoryDataV2.sort_values(by=['Date'], inplace=True, ascending=False)
##GDailyData[['Date','Open','High','Low','Close']]
#SilverHistoryDataV1[['Date','Open','High','Low','Close']]
##    Temp1.groupby(dr5minute.asof).agg({'Low': lambda s: s.min(), 
##                                         'High': lambda s: s.max(),
##                                         'Open': lambda s: s[0],
##                                         'Close': lambda s: s[-1],
##                                         'Volume': lambda s: s.sum()})        
##df['Timestamp'] = df['Timestamp'].astype(np.int64)
#    
##SilverDF.dtypes
##SilverDF.to_csv("C:\ReadMoneycontrol\Gold\SILVERV1.csv")
#
#
#GoldDFV1=GoldDF
#
#def ohlcsum(df):
#    df = df.sort()
#    return {
#       'Open': df['Open'][0],
#       'High': df['High'].max(),
#       'Low': df['Low'].min(),
#       'Close': df['Close'][-1],
#       'Volume': df['Volume'].sum()
#      }
#
#ohlc_dict = {                                                                                                             
#'Open':'first',                                                                                                    
#'High':'max',                                                                                                       
#'Low':'min',                                                                                                        
#'Close': 'last',                                                                                                    
#'Volume': 'sum'
#}
#
##Temp1=Temp1.set_index(pd.DatetimeIndex(Temp1['Date']))
##Temp1.resample('5T', how=ohlc_dict, closed='left', label='left')
#Temp1['Date']
#    DF=GoldDFV1
#    Dates=list(DF.groupby(DF['Date1'])['Date1'].count().index)
#    First=True
#    arDaily=[]
#    for Date in Dates:
#        Date=Dates[len(Dates)-1]
#        Date1=Date.strftime("%Y-%m-%d 00:00")
#        Date2=Date.strftime("%Y-%m-%d 23:59")
#        Daily={}
#        Temp1=DF[(DF['Date']>parse(Date1)) & (DF['Date']<parse(Date2))]    
#        Temp1=DF[(DF['Date']>parse(Date1)) & (DF['Date']<parse(Date2))]    
#        Temp1['Date'] = pd.to_datetime(Temp1['Date'], unit='s')    
#        Temp1 = (Temp1.set_index('Date')
#            .resample('5T').first()
#            .reset_index()
#           .reindex(columns=Temp1.columns))
#        Daily['Date']=Temp1.iloc[0]['Date1']
#        Daily['Open']=list(Temp1['open'][0:1])[0]
#        Daily['Close']=list(Temp1['open'][-1:])[0]
#        Daily['High']=Temp1['high'].max()
#        Daily['Low']=Temp1['open'].min()
#        
#        arDaily.append(Daily)
#        if(First):
#            SCons=Temp1[['Date','open','high','low','close']]
#            a=SCons
#            First=False
#        else:
#            SCons=SCons.append(Temp1[['Date','open','high','low','close']])
#    
#    return pd.DataFrame(arDaily),SCons