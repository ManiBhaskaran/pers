# -*- coding: utf-8 -*-
"""
Created on Fri Dec 27 09:48:43 2019

@author: lalitha
"""

Datas=getRealTimeData("All")   
#Data1=Datas['SBIN']['day']
DPivot=getRealTimePivot(Datas)

minute="15minute"
Min5DF=getSpecificIntervalData(Datas,minute,DPivot)
TInterval=['3minute','5minute','15minute']
PercentageAr=[0.0002,round(0.0002/3*5,4),round(0.0002/3*15,4)]
OffsetAr=[5,4,2]
iP=PercentageAr[TInterval.index(minute)]
iO=OffsetAr[TInterval.index(minute)]
Date1=datetime.now()
ResultDF05=ProcessZ(iP,iO,Min5DF,1,True) 
print("StockNameStockName : " + str((datetime.now()-Date1).microseconds))
print("StockNameStockName : " + str((datetime.now()-Date1).seconds))

ResultDF05=CheckandMarkSequence(ResultDF05,"5M")
ResultDF05=ResultDF05[(ResultDF05['HLC']!=ResultDF05['OC'])]
ResultDF05['CDATE']=pd.to_datetime(ResultDF05['CurrentDate']).dt.strftime("%Y-%b-%d")
ResultDF051=ResultDF05[ResultDF05['CFD']>.3]
Re=ResultDF05
Re=Re[Re['Index']<60]
index=0
CDATES=Re['CDATE'].unique()
SData=Re[(Re['CDATE']==CDATES[index]) & (Re['CFD']>.3)]
#SData=Re1
#T1=SData
Re.shape[0]
Re[Re['Index']<60].shape[0]
Re=Re[Re['Index']<60]
Re['CDATE']=pd.to_datetime(Re['CurrentDate']).dt.strftime("%Y-%b-%d")

SData=ResultDF05[(ResultDF05['CDATE']==CDATES[0]) & (ResultDF05['CC']>40)]
S=SData[['Type','Index','Stock','CurrentDate','TPercHO','TPercOL','DiffP','PDiffP','TPercHL','CFD','CPD',
     'CGap','PercHL','HCFib','HCLevel','LCFib','LCLevel','MaxHL','MaxHLClr','MaxHLIdx','CC']]

S['FPrice']=round(S['CC']*(1-S['CFD']/100),2)
S['FSL']=round(S['CC']*(1+S['CFD']/100*1.5),2)
S['LPrice']=round(S['CC']*(1-S['CPD']/100),2)
S['LSL']=round(S['CC']*(1+S['CPD']/100*1.5),2)

S1=S[ 
     #(S['TPercOL']>1) & 
        (S['Type']=='Low') &
        #(S['Index']<=30) &
        (S['Index']>=8) &
        (S['MaxHL']>=1) 
        &

        (S['PercHL']<S['CFD'])
        ]

S2=S[ 
     #(S['TPercHO']>1) & 
        (S['Type']=='High') &
        #(S['Index']<=30) &
        (S['Index']>=8) &
        (S['MaxHL']>=1) 
        &
        (S['PercHL']<S['CFD']) 
        ]


ScfdL=S[ (S['TPercOL']>1) & 
        (S['Type']=='Low') &
#        (S['Index']<=30) &
        (S['Index']>=4) &
        (S['PercHL']<S['CFD']) &
        (S['CFD']>1)]

ScfdH=S[ (S['TPercHO']>1) & 
        (S['Type']=='High') &
#        (S['Index']<=30) &
        (S['Index']>=4) &
        (S['PercHL']<S['CFD']) &
        (S['CFD']>1)]


SGapUpH=S[ (S['CGap']>1) & 
        (S['Type']=='High') &
        (S['Index']<=30) &
        (S['Index']>=5) ]

SGapUpL=S[ (S['CGap']>1) & 
        (S['Type']=='Low') &
        (S['Index']<=30) &
        (S['Index']>=5) ]


SGapDownH=S[ (S['CGap']<-1) & 
        (S['Type']=='High') &
        (S['Index']<=30) &
        (S['Index']>=5) ]

SGapDownL=S[ (S['CGap']<-1) & 
        (S['Type']=='Low') &
        (S['Index']<=30) &
        (S['Index']>=5) ]

#(SData1['MaxHL']>1) & (SData1['MaxHLClr']=="R") & 
Test=SData[ 
    (SData['PercHL']>-.2) & (SData['PercHL']<.2) &
     #& (SData['TPercOL']<.3) 
#          (SData['CFD']>.4) &
#    & (SData['TPercHL']>1) &
#     (SData['TPercHL']>=2) &
#     (SData['PercHL']<SData['CFD']) &
     (SData['TPercHO']>=SData['CFD']*2) &
#(SData['MaxHL']>1) &        
        (SData['Type']=="High") 
        & (((SData['HCFib']=="A1500") | (SData['HCFib']=="A2000") 
        | (SData['HCFib']=="A1786")
        | (SData['HCFib']=="A1618")
        | (SData['HCFib']=="A2236")
        | (SData['HCFib']=="A1236")
        | (SData['HCFib']=="A2382")
        | (SData['HCFib']=="A1382")
        | (SData['HCFib']=="A2500")) 
        | ((SData['HCLevel']=="H1") | (SData['HCLevel']=="H2")| (SData['HCLevel']=="H3")| (SData['HCLevel']=="H4")))
][['Index','Stock','CurrentDate','TPercHO','TPercOL','DiffP','PDiffP','TPercHL','CFD','CPD',
     'CGap','PercHL','HCFib','HCLevel','MaxHL','MaxHLClr','MaxHLIdx','CC']].sort_values('Index',ascending=False)

Test['PPoints']=round(Test['CC']*(Test['CFD']/100),2)
Test['SLPoints']=round(Test['CC']*(Test['CFD']/100*1.5),2)    
Test['FPrice']=round(Test['CC']*(1-Test['CFD']/100),2)
Test['FSL']=round(Test['CC']*(1+Test['CFD']/100*1.5),2)
Test['LPrice']=round(Test['CC']*(1-Test['CPD']/100),2)
Test['LSL']=round(Test['CC']*(1+Test['CPD']/100*1.5),2)

Test1=SData[
     (SData['PercHL']>-.2) & (SData['PercHL']<.2) &
#    (SData['PercHL']<SData['CFD']) &
     #& (SData['TPercHO']<.3) 
     (SData['TPercOL']>=SData['CFD']*2) &
#     (SData['CFD']>.4) &
#     (SData['MaxHL']>1) &
#     &
        (SData['Type']=="Low") 
#        & (
#        (
#        (SData['LCFib']=="Z1500") 
#        | (SData['LCFib']=="Z2000") 
#        | (SData['LCFib']=="Z1786")
#        | (SData['LCFib']=="Z1000")
#        | (SData['LCFib']=="Z1236")
#        | (SData['LCFib']=="Z786")
#        | (SData['LCFib']=="Z236")
#        | (SData['LCFib']=="Z1618")
#        | (SData['LCFib']=="Z2236")
#        | (SData['LCFib']=="Z2382")
#        | (SData['LCFib']=="Z2500")) 
#        | ((SData['LCLevel']=="L1") | (SData['LCLevel']=="L2") 
#        |  (SData['LCLevel']=="L3") | (SData['LCLevel']=="L4")))
#      
     ][['Index','Stock','CurrentDate','TPercHO','TPercOL','DiffP','PDiffP','TPercHL','CFD','CPD',
     'CGap','PercHL','LCFib','LCLevel','MaxHL','MaxHLClr','MaxHLIdx','CC']].sort_values('Index',ascending=False)
Test1['PPoints']=round(Test1['CC']*(Test1['CFD']/100),2)
Test1['SLPoints']=round(Test1['CC']*(Test1['CFD']/100*1.5),2)
Test1['Price']=round(Test1['CC']*(1+Test1['CFD']/100),2)
Test1['SL']=round(Test1['CC']*(1-Test1['CFD']/100*1.5),2)
Test1['LPrice']=round(Test1['CC']*(1+Test1['CPD']/100),2)
Test1['LSL']=round(Test1['CC']*(1-Test1['CPD']/100*1.5),2)







Test=SData[ 
    (SData['PercHL']>-.01) & (SData['PercHL']<.2) &
#    (SData['Index']>20) &
    (SData['Index']<=20) &
    (SData['CFD']<=1) &
    (SData['CC']<1200) &
    (SData['CGap']>-.01) & (SData['CGap']<1) &
    #(SData['CC']<=600) &
     (SData['TPercOL']<SData['TPercHO']) &
#          (SData['CFD']>.4) &
#    & (SData['TPercHL']>1) &
#     (SData['TPercHL']>=2) &
#     (SData['PercHL']<SData['CFD']) &
#     (SData['TPercHO']>=SData['CFD']*2) &
     (SData['TPercHO']>=SData['CFD']*1.5) &
     (SData['MaxHL']>1) &        
        (SData['Type']=="High") 
        & (SData['HCLevel']!="H1")
        & (((SData['HCFib']=="A1500") | (SData['HCFib']=="A2000") 
        | (SData['HCFib']=="A1786")
        | (SData['HCFib']=="A1618")
        | (SData['HCFib']=="A2236")
        | (SData['HCFib']=="A1236")
        | (SData['HCFib']=="A2382")
        | (SData['HCFib']=="A1382")
        | (SData['HCFib']=="A2500")) 
##(SData['HCLevel']=="H1") | 
        | ((SData['HCLevel']=="H2")| (SData['HCLevel']=="H3")| (SData['HCLevel']=="H4")))
]
Test1=SData[
#     (SData['PercHL']>-.2) & (SData['PercHL']<.2) &
#    (SData['PercHL']<SData['CFD']) &
     #& (SData['TPercHO']<.3) 
     (SData['TPercOL']>=SData['CFD']*2) &
#     (SData['CFD']>.4) &
     (SData['MaxHL']>1) &
     (SData['Index']<=40) &
#     &
        (SData['Type']=="Low") &
        (SData['LCLevel']!="L1")
        & (
        (
        (SData['LCFib']=="Z1500") 
        | (SData['LCFib']=="Z2000") 
        | (SData['LCFib']=="Z1786")
        | (SData['LCFib']=="Z1000")
        | (SData['LCFib']=="Z1236")
        | (SData['LCFib']=="Z786")
        | (SData['LCFib']=="Z236")
        | (SData['LCFib']=="Z1618")
        | (SData['LCFib']=="Z2236")
        | (SData['LCFib']=="Z2382")
        | (SData['LCFib']=="Z2500")) 
        | ((SData['LCLevel']=="L2") 
        |  (SData['LCLevel']=="L3") | (SData['LCLevel']=="L4")))
#      
     ]
Test.groupby([
            'Index'])['BuyProfitP','SellProfitP','BuyProfitP1','SellProfitP1'].count()


SP=Test[Test['SellProfitP']>0].shape[0]
BP=Test[Test['BuyProfitP']>0].shape[0]
TotalTest=Test.shape[0]
print("SellProfit Count :- "+str(SP) + " out of " +str(TotalTest) + "  --   "+str(round(100-(TotalTest-SP)/SP*100,2)))
print("BuyProfit Count :- "+str(BP) + " out of " +str(TotalTest) + "  --   "+str(round(100-(TotalTest-BP)/BP*100,2)))
#print("BuyProfit Count :- "+str(Test[Test['BuyProfitP']>0].shape[0]) + " out of " +str(Test.shape[0]))
print("SellProfit1 Count :- "+str(Test[Test['SellProfitP1']>0].shape[0]) + " out of " +str(Test.shape[0]))
print("BuyProfit1 Count :- "+str(Test[Test['BuyProfitP1']>0].shape[0]) + " out of " +str(Test.shape[0]))
Test[['BuyProfitP','SellProfitP','BuyProfitP1','SellProfitP1']].sum()

DatasCP=Datas.copy()
i=0
First=True
while(i<len(StockList)-1):
    StockName=StockList.Symbol[i]
    DatasCP[StockName]['5minute'].columns=['Date', 'Open', 'High', 'Low', 'Close', 'V']
    DatasCP[StockName]['15minute'].columns=['Date', 'Open', 'High', 'Low', 'Close', 'V']
    DatasCP[StockName]['day'].columns=['Date', 'Open', 'High', 'Low', 'Close', 'V']
    Day=DatasCP[StockName]['day'].iloc[len(DatasCP[StockName]['day'])-2]
    CDay=DatasCP[StockName]['day'].iloc[len(DatasCP[StockName]['day'])-1]
    DHL=round(float(Day['High']-Day['Low']),2)
    L=float(Day.Low)    
    DatasCP[StockName]['5minute']['HighFib']=round((DatasCP[StockName]['5minute']['High']-L)*1000/DHL)
    DatasCP[StockName]['5minute']['LowFib']=round((DatasCP[StockName]['5minute']['Low']-L)*1000/DHL)
    DatasCP[StockName]['5minute']['OpenFib']=round((DatasCP[StockName]['5minute']['Open']-L)*1000/DHL)
    DatasCP[StockName]['5minute']['CloseFib']=round((DatasCP[StockName]['5minute']['Close']-L)*1000/DHL)
    DatasCP[StockName]['5minute']['StockName']=StockName
    DatasCP[StockName]['5minute']['minute']='5minute'
    DatasCP[StockName]['15minute']['HighFib']=round((DatasCP[StockName]['15minute']['High']-L)*1000/DHL)
    DatasCP[StockName]['15minute']['LowFib']=round((DatasCP[StockName]['15minute']['Low']-L)*1000/DHL)
    DatasCP[StockName]['15minute']['OpenFib']=round((DatasCP[StockName]['15minute']['Open']-L)*1000/DHL)
    DatasCP[StockName]['15minute']['CloseFib']=round((DatasCP[StockName]['15minute']['Close']-L)*1000/DHL)
    DatasCP[StockName]['15minute']['StockName']=StockName
    DatasCP[StockName]['15minute']['minute']='15minute'
    S15Min=DatasCP[StockName]['15minute']
    S5Min=DatasCP[StockName]['5minute']
    iDate=CDay['Date']
    PDate=Day['Date']
    PS15Min=S15Min[(S15Min['Date']>=PDate) & (S15Min['Date']<=N1(PDate,"16H","+"))].reset_index()                
    PS5Min=S5Min[(S5Min['Date']>=PDate) & (S5Min['Date']<=N1(PDate,"16H","+"))].reset_index()            
    S15Min=S15Min[(S15Min['Date']>=iDate) & (S15Min['Date']<=N1(iDate,"16H","+"))].reset_index()        
    S5Min=S5Min[(S5Min['Date']>=iDate) & (S5Min['Date']<=N1(iDate,"16H","+"))].reset_index()   
    
    
    S15Min['PHighIndex']=PS15Min[PS15Min['High']==PS15Min['High'].max()].index[0]
    S15Min['PLowIndex']=PS15Min[PS15Min['Low']==PS15Min['Low'].min()].index[0]    
    S5Min['PHighIndex']=PS5Min[PS5Min['High']==PS15Min['High'].max()].index[0]
    S5Min['PLowIndex']=PS5Min[PS5Min['Low']==PS15Min['Low'].min()].index[0]
    
    if(First):
        Consolidate=S5Min
        Consolidate=Consolidate.append(S15Min)
        First=False
    else:
        Consolidate=Consolidate.append(S15Min)
        Consolidate=Consolidate.append(S5Min)
    i=i+1

a=Consolidate[
        #(Consolidate['StockName']=='SBIN') & 
              (Consolidate['minute']=="5minute")
#                & (
#                        ((Consolidate['HighFib']>=450) & (Consolidate['HighFib']<=550) )
#                        |
#                        ((Consolidate['LowFib']>=450) & (Consolidate['LowFib']<=550) )
#                        )
                & (Consolidate.index==0)]
A1=Consolidate[
        (Consolidate['StockName']=='ZEEL') & 
              (Consolidate['minute']=="5minute")
              ].sort_values("V",ascending=False)

b=Consolidate[
        #(Consolidate['StockName']=='SBIN') & 
              (Consolidate['minute']=="15minute")
                & (
                        ((Consolidate['HighFib']<=-250) & (Consolidate['HighFib']>=-550) )
                        |
                        ((Consolidate['LowFib']<=-250) & (Consolidate['LowFib']>=-550) )
                        )
                & (Consolidate.index==0)]


c=Consolidate[
        #(Consolidate['StockName']=='SBIN') & 
              (Consolidate['minute']=="5minute")
                & (
                        ((Consolidate['HighFib']>=600) & (Consolidate['HighFib']<=800) )
                        |
                        ((Consolidate['LowFib']>=600) & (Consolidate['LowFib']<=800) )
                        )
                & (Consolidate.index==0)]

Stock='SBIN'
SBIN5Min=LoadCSVData(Stock,"5minute")
SBIN5Min['CDATE']=pd.to_datetime(SBIN5Min['Date']).dt.strftime("%Y-%b-%d")
SBINDay=LoadCSVData(Stock,"day")
SBINDay['CDATE']=pd.to_datetime(SBINDay['Date']).dt.strftime("%Y-%b-%d")

SBIN5Min.drop_duplicates(subset =["Date"], keep = "first", inplace = True) 
SBINDay['HL']=SBINDay['High'].shift(1)-SBINDay['Low'].shift(1)
SBINDay['PLow']=SBINDay['Low'].shift(1)
SBINDay['PHigh']=SBINDay['High'].shift(1)
SBINDay['PClose']=SBINDay['Close'].shift(1)
SBINDay['POpen']=SBINDay['Open'].shift(1)
merged = SBIN5Min.merge(SBINDay, on=['CDATE'], how='left')
CustomMerge=merged[['Date_x','HL','PLow','PHigh','PClose','POpen']]
CustomMerge.columns=['Date', 'HL', 'PLow','PHigh','PClose','POpen']
SBIN5Min=SBIN5Min.merge(CustomMerge, on=['Date'], how='left')
#SBIN5Min['HL']=merged['HL']
#SBIN5Min['PLow']=merged['PLow']       
SBIN5Min['HighFib']=round((SBIN5Min['High']-SBIN5Min['PLow'])*1000/SBIN5Min['HL'])
SBIN5Min['LowFib']=round((SBIN5Min['Low']-SBIN5Min['PLow'])*1000/SBIN5Min['HL'])
SBIN5Min['OpenFib']=round((SBIN5Min['Open']-SBIN5Min['PLow'])*1000/SBIN5Min['HL'])
SBIN5Min['CloseFib']=round((SBIN5Min['Close']-SBIN5Min['PLow'])*1000/SBIN5Min['HL'])
SBIN5Min['Indx']=((SBIN5Min['Date']-pd.to_datetime(pd.to_datetime(SBIN5Min['CDATE']).dt.strftime("%Y-%m-%d 09:15"))).dt.seconds/60/5).astype(int)
SBIN5Min.drop(SBIN5Min[SBIN5Min['Indx'] > 74].index, inplace = True) 
offset=4
SBIN5Min=SBIN5Min.sort_values('Date',ascending=False)
SBIN5Min['MaxP']=SBIN5Min['High'].shift(1).rolling(10).max()
SBIN5Min['MinP']=SBIN5Min['Low'].shift(1).rolling(10).min()
SBIN5Min['MaxP1']=SBIN5Min['High'].shift(1).rolling(20).max()
SBIN5Min['MinP1']=SBIN5Min['Low'].shift(1).rolling(20).min()
SBIN5Min['MaxP2']=SBIN5Min['High'].shift(1).rolling(30).max()
SBIN5Min['MinP2']=SBIN5Min['Low'].shift(1).rolling(30).min()

SBIN5Min['Max10']=SBIN5Min['High'].shift(9)
SBIN5Min['Min10']=SBIN5Min['Low'].shift(9)

SBIN5Min=SBIN5Min.sort_values('Date',ascending=True)
SBIN5Min['Peak']=(
          (SBIN5Min['High'].shift(8)<SBIN5Min['High'].shift(4)) 
        & (SBIN5Min['High'].shift(7)>SBIN5Min['High'].shift(8)) 
        #& (SBIN5Min['High'].shift(7)<SBIN5Min['High'].shift(4)) 
        & (SBIN5Min['High'].shift(4)>SBIN5Min['High'])
        & (SBIN5Min['Low'].shift(4)>SBIN5Min['Low'])
        & (SBIN5Min['Low'].shift(2)>SBIN5Min['Low'].shift(1))
        & (SBIN5Min['Low'].shift(1)>SBIN5Min['Low']))
SBIN5Min['PeakHFib']=SBIN5Min['HighFib'].shift(4)
SBIN5Min['PeakHFib-P']=SBIN5Min['HighFib'].shift(16)        
SBIN5Min['Trough']=(
        (SBIN5Min['Low'].shift(8)>SBIN5Min['Low'].shift(4)) 
        #& (SBIN5Min['Low'].shift(7)<SBIN5Min['Low'].shift(8)) 
        #& (SBIN5Min['Low'].shift(7)>SBIN5Min['Low'].shift(4)) 
        & (SBIN5Min['Low'].shift(4)<SBIN5Min['Low'])
        & (SBIN5Min['High'].shift(4)<SBIN5Min['High'])
        & (SBIN5Min['High'].shift(2)<SBIN5Min['High'].shift(1))
        & (SBIN5Min['High'].shift(1)<SBIN5Min['High'])
        )
SBIN5Min['TroughLFib']=(SBIN5Min['LowFib'].shift(4))
SBIN5Min['TroughLFib-P']=(SBIN5Min['LowFib'].shift(16))

CDATES=SBIN5Min['CDATE'].unique()

SBIN5Min['CDATE'].shift(6).rolling(72).max()

FibLevels=[0,236,382,500,618,786,1000,1236,1382,1500,1618,1786,2000,2236,2382,2500,2618,2786,3000,3236,3382,3500,3618,3786,4000,-236,-382,-500,-618,-786,-1000,-1236,-1382,-1500,-1618,-1786,-2000,-2236,-2382,-2500,-2618,-2786,-3000,-3236,-3382,-3500,-3618,-3786,-4000]    
FibLevels.sort()
Findex=FibLevels.index(1236)
C=SBIN5Min[
        ((SBIN5Min['Peak']==True)
          & ( SBIN5Min['PeakHFib'].between(FibLevels[Findex]-20,FibLevels[Findex]+20)))
          & (SBIN5Min['PeakHFib-P']<FibLevels[Findex])
          & (SBIN5Min['Indx']>16)
        |
        (
          (SBIN5Min['Trough']==True) 
         &(
            ( SBIN5Min['TroughLFib'].between(FibLevels[Findex-1]-20,FibLevels[Findex-1]+20))
           |( SBIN5Min['TroughLFib'].between(FibLevels[Findex-2]-20,FibLevels[Findex-2]+20))
           | ( SBIN5Min['TroughLFib'].between(FibLevels[Findex-3]-20,FibLevels[Findex-3]+20))
           | ( SBIN5Min['TroughLFib'].between(FibLevels[Findex-4]-20,FibLevels[Findex-4]+20))
         )             
        )

        
        
        ][['Date', 'Open', 'High', 'Low', 'Close', 'V', 'Peak',       
        'MaxP', 'MinP','MaxP1', 'MinP1',
        'HighFib', 'LowFib', 'OpenFib', 'CloseFib',
        'TroughLFib', 'PeakHFib', 'PeakHFib-P',
       'TroughLFib-P']]


Findex=FibLevels.index(-236)
D=SBIN5Min[
        ((SBIN5Min['Peak']==True)
          & (( SBIN5Min['PeakHFib'].between(FibLevels[Findex+1]-20,FibLevels[Findex+1]+20))
          | ( SBIN5Min['PeakHFib'].between(FibLevels[Findex+2]-20,FibLevels[Findex+2]+20))
          | ( SBIN5Min['PeakHFib'].between(FibLevels[Findex+3]-20,FibLevels[Findex+3]+20))
          | ( SBIN5Min['PeakHFib'].between(FibLevels[Findex+4]-20,FibLevels[Findex+4]+20))          
        )  )
        
        |
        
        (
                
          (SBIN5Min['Trough']==True) 
         # & (SBIN5Min['Indx']>16) 
         #& (SBIN5Min['TroughLFib-P']>FibLevels[Findex])
         & (SBIN5Min['TroughLFib'].between(FibLevels[Findex]-20,FibLevels[Findex]+20))
        )
        ][['Date', 'Open', 'High', 'Low', 'Close', 'V', 'Peak',       
        'MaxP', 'MinP','MaxP1', 'MinP1',
        'HighFib', 'LowFib', 'OpenFib', 'CloseFib',
        'TroughLFib', 'PeakHFib', 'PeakHFib-P',
       'TroughLFib-P']]



C=SBIN5Min[
        ((SBIN5Min['Peak']==True)
         & ( SBIN5Min['PeakHFib'].between(-236-20,-236+20)))
        
        ][['Date', 'Open', 'High', 'Low', 'Close', 'V', 'Peak',       
        'MaxP', 'MinP','MaxP1', 'MinP1',
        'HighFib', 'LowFib', 'OpenFib', 'CloseFib',
        'TroughLFib', 'PeakHFib', 'PeakHFib-P',
       'TroughLFib-P']]

C=SBIN5Min[
        ((SBIN5Min['Peak']==True)
         & ( (SBIN5Min['PeakHFib']>=382-20) & (SBIN5Min['PeakHFib']<=382+20)))
        & (SBIN5Min['Indx']>16)
        & (SBIN5Min['PeakHFib-P']<382)
        |
        (
          (SBIN5Min['Trough']==True) 
         &(
            ((SBIN5Min['TroughLFib']>=0-20) & (SBIN5Min['TroughLFib']<=0+20))
           |((SBIN5Min['TroughLFib']<=-236-20) & (SBIN5Min['TroughLFib']>=-236+20))
           | ((SBIN5Min['TroughLFib']>=382-20) & (SBIN5Min['TroughLFib']<=382+20))
           | ((SBIN5Min['TroughLFib']>=236-20) & (SBIN5Min['TroughLFib']<=236+20))
           | ((SBIN5Min['TroughLFib']>=382-20) & (SBIN5Min['TroughLFib']<=382+20))
           | ((SBIN5Min['TroughLFib']>=500-20) & (SBIN5Min['TroughLFib']<=500+20))
           | ((SBIN5Min['TroughLFib']>=618-20) & (SBIN5Min['TroughLFib']<=618+20))
         )             
        )

        
        
        ][['Date', 'Open', 'High', 'Low', 'Close', 'V', 'Peak',       
        'MaxP', 'MinP','MaxP1', 'MinP1',
        'HighFib', 'LowFib', 'OpenFib', 'CloseFib',
        'TroughLFib', 'PeakHFib', 'PeakHFib-P',
       'TroughLFib-P']]


C=SBIN5Min[
        ((SBIN5Min['Peak']==True)
         & ( (SBIN5Min['PeakHFib']>=618-20) & (SBIN5Min['PeakHFib']<=618+20)))
        |
        (
          (SBIN5Min['Trough']==True) 
         &(
            ((SBIN5Min['TroughLFib']>=0-20) & (SBIN5Min['TroughLFib']<=0+20))
           |((SBIN5Min['TroughLFib']<=-236-20) & (SBIN5Min['TroughLFib']>=-236+20))
           | ((SBIN5Min['TroughLFib']>=382-20) & (SBIN5Min['TroughLFib']<=382+20))
           | ((SBIN5Min['TroughLFib']>=236-20) & (SBIN5Min['TroughLFib']<=236+20))
           | ((SBIN5Min['TroughLFib']>=382-20) & (SBIN5Min['TroughLFib']<=382+20))
           | ((SBIN5Min['TroughLFib']>=500-20) & (SBIN5Min['TroughLFib']<=500+20))
           | ((SBIN5Min['TroughLFib']>=618-20) & (SBIN5Min['TroughLFib']<=618+20))
         )             
        )

        
        
        ][['Date', 'Open', 'High', 'Low', 'Close', 'V', 'Peak',       
        'MaxP', 'MinP','MaxP1', 'MinP1',
        'HighFib', 'LowFib', 'OpenFib', 'CloseFib',
        'TroughLFib', 'PeakHFib', 'PeakHFib-P',
       'TroughLFib-P']]



#SBIN5Min['High'].apply(isPeak1, args =(SBIN5Min['High'],len(SBIN5Min['High']),1,1,SBIN5Min['High'].shift(4),))

#a=isPeak(Data['High'][:i], len(Data['High'][:i]), Data.iloc[i-offset]['High'], i-(offset*2), i)




Z=SBIN5Min[(SBIN5Min['Open']<=SBIN5Min['High'])
& ((SBIN5Min['PClose']-SBIN5Min['Open'])/SBIN5Min['Open']*100<1)
& ((SBIN5Min['High']-SBIN5Min['Open'])/SBIN5Min['Open']*100>1)
& (SBIN5Min['V']>=10000)
& (SBIN5Min['Indx']==0)]
Z['LowP1']=round((Z['Close']-Z['MinP'])/Z['MinP']*100,2)
Z['LowP2']=round((Z['Close']-Z['MinP1'])/Z['MinP1']*100,2)
Z['LowP3']=round((Z['Close']-Z['MinP2'])/Z['MinP2']*100,2)
Z['LowP10']=round((Z['Close']-Z['Min10'])/Z['Min10']*100,2)
Z['HighP1']=round((Z['Close']-Z['MaxP'])/Z['MaxP']*100,2)
Z['HighP2']=round((Z['Close']-Z['MaxP1'])/Z['MaxP1']*100,2)
Z['HighP3']=round((Z['Close']-Z['MaxP2'])/Z['MaxP2']*100,2)
Z['HighP10']=round((Z['Close']-Z['Max10'])/Z['Max10']*100,2)
Z1=Z[['Date','V','LowP1','LowP2','LowP3','LowP10','HighP1','HighP2','HighP3','HighP10']]
Z2=Z[['Date', 'Open', 'High', 'Low', 'Close', 'V',  'MaxP', 'MinP', 'MaxP1', 'MinP1', 'MaxP2', 'MinP2', 'Max10',
       'Min10', 'LowP1', 'LowP2', 'LowP3', 'LowP10', 'HighP1', 'HighP2',
       'HighP3', 'HighP10']]

Z[['LowP10','HighP10']].mean()
Z[['LowP10','HighP10']].sum()