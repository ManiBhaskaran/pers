# candlestick-patterns
Candlestick patterns detector
