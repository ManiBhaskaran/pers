# -*- coding: utf-8 -*-
"""
Created on Sat Feb  2 20:10:29 2019

@author: lalitha
"""


def Check(tdaily,Signal,DateIndex,Margin,Stoploss,SearchData):
    SingleStatus={}
    global Profit
    #tdaily=CrudeDf30Min
    #SearchData=CrudeDf15Min
    #Margin=0.005
    #DateIndex=482
    #Signal="Buy"
    DefaultDate=datetime.datetime.now()
    tdaily['BuyTime']=pd.Series(DefaultDate,index=tdaily.index)
    tdaily['BuyTargetTime']=pd.Series(DefaultDate,index=tdaily.index)
    tdaily['BuyStopLossTime']=pd.Series(DefaultDate,index=tdaily.index)
    tdaily['SellTime']=pd.Series(DefaultDate,index=tdaily.index)
    tdaily['SellTargetTime']=pd.Series(DefaultDate,index=tdaily.index)
    tdaily['SellStopLossTime']=pd.Series(DefaultDate,index=tdaily.index)
    tdaily['LastPrice']=pd.Series(None,index=tdaily.index)
    tdaily['BuyHit']=pd.Series(0,index=tdaily.index)
    tdaily['SellHit']=pd.Series(0,index=tdaily.index)
#if True:
    #daily.iloc[DateIndex]['Date']
    tdaily.iloc[DateIndex]
    aDate=list(tdaily[DateIndex+1:][:1]['Date'])[0]
    #print(aDate)
    LastDate=parse(tdaily.iloc[DateIndex]['Date'].strftime('%Y-%m-%d 23:59:00')) 
    #print(LastDate)
    #SpecificDate=data[ (data['Date/Time']>daily.iloc[DateIndex-1]['Date']) 
    #& (data['Date/Time']<daily.iloc[DateIndex-2]['Date'])]
    SpecificDate=SearchData[(SearchData['Date']>=aDate) & (SearchData['Date']<LastDate)]
    #(data['Date']>daily.iloc[100]['Date'] and
    #data.set_index('Date/Time')
    #SpecificDate['Date/Time']
    #print(len(SpecificDate))
    isBuyProcess=True
    isSellProcess=True
    
    Tollerance=.01
    #if(Signal=="Buy"):
    #BuyP=tdaily.iloc[DateIndex]['close']+Tollerance
    BuyP=tdaily.iloc[DateIndex+1]['open']
    BuyT=BuyP*(1+Margin)
    #BuySL=tdaily.iloc[DateIndex-2]['low']
    BuySL=BuyP*(1-Stoploss)
    
    BuyPT=SpecificDate[(SpecificDate['high']>=BuyP-Tollerance) & (SpecificDate['low']<=BuyP+Tollerance)]
    BuyTT=SpecificDate[(SpecificDate['high']>=BuyT-Tollerance) & (SpecificDate['low']<=BuyT+Tollerance)]
    BuySLT=SpecificDate[(SpecificDate['high']>=BuySL-Tollerance) & (SpecificDate['low']<=BuySL+Tollerance)]
    
#else:    
    #SellP=tdaily.iloc[DateIndex]['close']-Tollerance
    SellP=tdaily.iloc[DateIndex+1]['open']
    SellT=SellP*(1-Margin)
    #SellSL=tdaily.iloc[DateIndex-2]['high']
    SellSL=SellP*(1+Stoploss)
    
    SellPT=SpecificDate[(SpecificDate['high']>=SellP-Tollerance) & (SpecificDate['low']<=SellP+Tollerance)]
    SellTT=SpecificDate[(SpecificDate['high']>=SellT-Tollerance) & (SpecificDate['low']<=SellT+Tollerance)]
    SellSLT=SpecificDate[(SpecificDate['high']>=SellSL-Tollerance) & (SpecificDate['low']<=SellSL+Tollerance)]
    #data=data1
    #data.loc[SpecificDate]['Date/Time']
    
    SingleStatus['Date']=tdaily.iloc[DateIndex]['Date'].strftime("%m/%d/%Y %I:%M %p")
    SingleStatus['Percentage']=Margin
    if(Signal=="Buy"):
        SingleStatus['Signal']="Buy"        
        SingleStatus['Price']=BuyP       
        SingleStatus['Target']=BuyT      
        SingleStatus['StopLoss']=BuySL        
        isSellProcess=False
        print(str(BuyP) +  "  ===============  " + str(BuyT) + " ======== "+ str(BuySL))
    else:
        isBuyProcess=False
        SingleStatus['Signal']="Sell"
        SingleStatus['Price']=SellP       
        SingleStatus['Target']=SellT      
        SingleStatus['StopLoss']=SellSL 
        print(str(SellP) +  "  ===============  " + str(SellT) + " ======== "+ str(SellSL))
    
    
    
    BuyHit=False
    SellHit=False
    LastPriceBuyHit=False
    LastPriceSellHit=False
    LastPriceHit=False
    LastPrice=0
    #if len(BuyPT)>0:
    #    print("Buy Price At : " + str(BuyPT.iloc[0]['Date/Time']))
    #    if len(BuyTT)>0:
    #        print("Buy Target At : "+ str(BuyTT.iloc[0]['Date/Time']))
    #        print("Total Profit :" + str(BuyT-BuyP))
    #    if len(BuySLT)>0:
    #        print("Buy Stop loss At : " + str(BuySLT.iloc[0]['Date']))
    #        print("Total Loss:" + str(BuySL-BuyP))
    
    

    #if( len(BuyPT)>0 and len(SellPT)>0):
    #    isBuyProcess=(BuyPT.iloc[0]['Date']<SellPT.iloc[0]['Date'])
    #    isSellProcess=(BuyPT.iloc[0]['Date']>SellPT.iloc[0]['Date'])
   
    if(len(BuyPT)>0):
        tdaily['BuyTime'][DateIndex]=BuyPT.iloc[0]['Date']
        if(Signal=="Buy"):
            SingleStatus['Time']=BuyPT.iloc[0]['Date'].strftime("%m/%d/%Y %I:%M %p")
    if(len(BuyTT)>0):
        tdaily['BuyTargetTime'][DateIndex]=BuyTT.iloc[0]['Date']
        if(Signal=="Buy"):
            SingleStatus['TargetTime']=BuyTT.iloc[0]['Date'].strftime("%m/%d/%Y %I:%M %p")
    if(len(BuySLT)>0):
        tdaily['BuyStopLossTime'][DateIndex]=BuySLT.iloc[0]['Date']    
        if(Signal=="Buy"):
            SingleStatus['StopLossTime']=BuySLT.iloc[0]['Date'].strftime("%m/%d/%Y %I:%M %p")
    if(len(SellPT)>0):
        tdaily['SellTime'][DateIndex]=SellPT.iloc[0]['Date']
        if(Signal=="Sell"):
            SingleStatus['Time']=SellPT.iloc[0]['Date'].strftime("%m/%d/%Y %I:%M %p")
    if(len(SellTT)>0):
        tdaily['SellTargetTime'][DateIndex]=SellTT.iloc[0]['Date']
        if(Signal=="Sell"):
            SingleStatus['TargetTime']=SellTT.iloc[0]['Date'].strftime("%m/%d/%Y %I:%M %p")
    if(len(SellSLT)>0):
        tdaily['SellStopLossTime'][DateIndex]=SellSLT.iloc[0]['Date']    
        if(Signal=="Sell"):
            SingleStatus['StopLossTime']=SellSLT.iloc[0]['Date'].strftime("%m/%d/%Y %I:%M %p")
            
        
    if (len(BuyPT)>0 and isBuyProcess):
        print("Buy Price at : " + str(BuyPT.iloc[0]['Date']))
        tdaily['BuyTime'][DateIndex]=BuyPT.iloc[0]['Date']
        if len(BuyTT)>0:
            print("Buy Target at : " + str(BuyTT.iloc[0]['Date']))
            tdaily['BuyTargetTime'][DateIndex]=BuyTT.iloc[0]['Date']
            if len(BuySLT)<=0:
                if(BuyPT.iloc[0]['Date']<=BuyTT.iloc[0]['Date']):
                    print("*********Buy Total Profit :" + str(BuyT-BuyP))
                    BuyHit=True
                    tdaily['BuyHit'][DateIndex]=BuyT-BuyP
                else:
                    print("Total Value : "+ str(SpecificDate.iloc[len(SpecificDate)-1]['open']-BuyP))
                    tdaily['BuyHit'][DateIndex]=SpecificDate.iloc[len(SpecificDate)-1]['open']-BuyP
                    LastPriceHit=True
                    LastPrice=SpecificDate.iloc[len(SpecificDate)-1]['open']
            else:
                if(BuyPT.iloc[0]['Date']<=BuyTT.iloc[0]['Date']) and (BuyTT.iloc[0]['Date']<=BuySLT.iloc[0]['Date']):
                    print("*****Buy Total Profit :" + str(BuyT-BuyP))
                    BuyHit=True
                    tdaily['BuyHit'][DateIndex]=BuyT-BuyP
                else:
                    print("100 Buy Stop Losst at : "+str(BuySLT.iloc[0]['Date']))
                    tdaily['BuyStopLossTime'][DateIndex]=BuySLT.iloc[0]['Date']
                    if((BuyPT.iloc[0]['Date']<=BuyTT.iloc[0]['Date']) and (BuySLT.iloc[0]['Date']<=BuyTT.iloc[0]['Date'])):
                        print("100.1 Buy Total Loss:" + str(BuySL-BuyP))
                        BuyHit=False
                        tdaily['BuyHit'][DateIndex]=BuyT-BuyP
                    else:
                        print("Buy Total loss :" + str(BuyT-BuyP))
                        BuyHit=True
                        tdaily['BuyHit'][DateIndex]=BuySL-BuyP
            
        elif (len(BuySLT)>0):
            print("2Buy Stop Loss at : " + str(BuySLT.iloc[0]['Date']))
            tdaily['BuyStopLossTime'][DateIndex]=BuySLT.iloc[0]['Date']
            print("Buy Total loss :" + str(BuySL-BuyP))
            tdaily['BuyHit'][DateIndex]=BuySL-BuyP
            if len(BuyTT)>0:
                if(BuySLT.iloc[0]['Date']<=BuyTT.iloc[0]['Date']):
                    print("Buy Total loss :" + str(BuySL-BuyP))
                    tdaily['BuyHit'][DateIndex]=BuySL-BuyP
                    tdaily['BuyStopLossTime'][DateIndex]=BuySLT.iloc[0]['Date']
        else:
            print("Total Value : "+ str(SpecificDate.iloc[len(SpecificDate)-1]['open']-BuyP))
            tdaily['BuyHit'][DateIndex]=SpecificDate.iloc[len(SpecificDate)-1]['open']-BuyP
            LastPriceHit=True
            LastPrice=SpecificDate.iloc[len(SpecificDate)-1]['open']
            
    if len(SpecificDate) >0:       
        tdaily['LastPrice'][DateIndex]=SpecificDate.iloc[len(SpecificDate)-1]['open']
        #LastPriceHit=True
        #LastPrice=SpecificDate.iloc[len(SpecificDate)-1]['open']
    
    if (isSellProcess and len(SellPT)>0):
        print("Sell Price at : " + str(SellPT.iloc[0]['Date']))
        tdaily['SellTime'][DateIndex]=SellPT.iloc[0]['Date']
        if len(SellTT)>0:
            print("Sell Target at : " + str(SellTT.iloc[0]['Date']))
            
            tdaily['SellTargetTime'][DateIndex]=SellTT.iloc[0]['Date']
            if len(SellSLT)<=0:
                if(SellPT.iloc[0]['Date']<=SellTT.iloc[0]['Date']):
                    print("Sell Total Profit :" + str(SellP-SellT))
                    SellHit=True
                    tdaily['SellHit'][DateIndex]=SellP-SellT
                else:
                    print("Total Value : "+ str(SellP-SpecificDate.iloc[len(SpecificDate)-1]['open']))
                    tdaily['SellHit'][DateIndex]=SpecificDate.iloc[len(SpecificDate)-1]['open']-SellP
                    LastPriceHit=True
                    LastPrice=SpecificDate.iloc[len(SpecificDate)-1]['open']
            else:                
                if(SellPT.iloc[0]['Date']<=SellTT.iloc[0]['Date']) and (SellTT.iloc[0]['Date']<=SellSLT.iloc[0]['Date']):
                    print("Sell Total Profit :" + str(SellP-SellT))
                    SellHit=True
                    tdaily['SellHit'][DateIndex]=SellP-SellT
                else:    
                    print("Sell Stop Losst at 6: "+str(SellSLT.iloc[0]['Date']))
                    tdaily['SellStopLossTime'][DateIndex]=SellSLT.iloc[0]['Date']
                    if((SellPT.iloc[0]['Date']<=SellTT.iloc[0]['Date']) & (SellSLT.iloc[0]['Date']<=SellTT.iloc[0]['Date'])):
                        print("Sell Total loss 7:" + str(SellSL-SellP))
                        tdaily['SellHit'][DateIndex]=SellP-SellT
                    else:
                        
                        print("Sell Total Profit :-" + str(SellP-SellT))                        
                        SellHit=True
                        tdaily['SellHit'][DateIndex]=SellP-SellSL
            
        elif (len(SellSLT)>0):
            print("Sell Stop Loss at : " + str(SellSLT.iloc[0]['Date']))
            tdaily['SellStopLossTime'][DateIndex]=SellSLT.iloc[0]['Date']
            print("Sell Total loss 8:" + str(SellP-SellSL))
            tdaily['SellHit'][DateIndex]=SellP-SellSL
            if len(SellTT)>0:
                if(SellSLT.iloc[0]['Date']<=SellTT.iloc[0]['Date']):
                    print("Sell Total loss 9:" + str(SellP-SellSL))
                    tdaily['SellHit'][DateIndex]=SellP-SellSL
        else:
            print("Total Value : "+ str(SellP-SpecificDate.iloc[len(SpecificDate)-1]['open']))
            tdaily['SellHit'][DateIndex]=SpecificDate.iloc[len(SpecificDate)-1]['open']-SellP
            LastPriceHit=True
            LastPrice=SpecificDate.iloc[len(SpecificDate)-1]['open']
    
    if(Signal=="Buy"):
        if(BuyHit==True):
            SingleStatus['Hit']="Hit"
            SingleStatus['Profit']=BuyT-BuyP
            Profit=Profit+(BuyT-BuyP)
        else:
            if(LastPriceHit==True):
                SingleStatus['LastPrice']=LastPrice
                if(LastPrice>BuyP):
                    BuyHit=True
                    SingleStatus['Hit']="LastPrice-Profit"                    
                    SingleStatus['Profit']=LastPrice-BuyP
                    
                    Profit=Profit+(LastPrice-BuyP)
                else:
                    SingleStatus['Hit']="LastPrice-Loss"                    
                    SingleStatus['Profit']=LastPrice-BuyP
                    Profit=Profit+(LastPrice-BuyP)
            else:
                SingleStatus['Hit']="StopLoss"
                Profit=Profit+(BuySL-BuyP)
                SingleStatus['Profit']=(BuySL-BuyP)
        #return BuyHit
    else:
        if(SellHit==True):
            SingleStatus['Hit']="Hit"
            SingleStatus['Profit']=(SellP-SellT)
            Profit=Profit+(SellP-SellT)
        else:
            if(LastPriceHit==True):
                SingleStatus['LastPrice']=LastPrice
                if(LastPrice<BuyP):
                    SellHit=True
                    SingleStatus['Hit']="LastPrice-Profit"                    
                    SingleStatus['Profit']=(BuyP-LastPrice)
                    Profit=Profit+(BuyP-LastPrice)
                else:
                    SingleStatus['Hit']="LastPriceHit-Loss"
                    SingleStatus['Profit']=(BuyP-LastPrice)
                    Profit=Profit+(BuyP-LastPrice)
            else:
                SingleStatus['Hit']="StopLoss"
                Profit=Profit+(SellP-SellSL)
                SingleStatus['Profit']=(SellP-SellSL)
        #return SellHit
    return SingleStatus
    #return tdaily
        #print("No Target hit")
