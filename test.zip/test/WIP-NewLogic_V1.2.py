# -*- coding: utf-8 -*-
"""
Created on Sun Apr  5 18:12:37 2020

@author: lalitha
"""
import threading
import itertools
import jhtalib as ta
import requests
from dateutil.parser import parse
import datetime
import plotly.graph_objs as go
from plotly import __version__
from plotly.offline import download_plotlyjs, init_notebook_mode, plot, iplot
import numpy as np
import plotly.io as pio
import os
import pandas as pd
import json
import time
from dateutil.parser import parse
from candlestick import candlestick
#import datetime
from datetime import datetime, timedelta
DIRNIFTYStockList="C:\ReadMoneycontrol\Mani 2.0\StockList.txt"
DIRFOStockList="C:\ReadMoneycontrol\Mani 2.0\StockList-New.txt"
DIRNIFTYStockListID="C:\ReadMoneycontrol\Mani 2.0\StockListIDOriginal.txt"
DIRFOStockListID="C:\ReadMoneycontrol\Mani 2.0\StockListID-NEW.csv"
StockListAll=r"C:\Users\mbhaskar111918\OneDrive - GROUP DIGITAL WORKPLACE\Documents\D_DRIVE_IN49805787L\SHARED\backup\Confidential\candlestick-patterns-masterV5\candlestick-patterns-master\Test\StockListAll.txt"


DIRNIFTY=r"C:\Users\mbhaskar111918\Data\incr1"
DIRFO="C:\ReadMoneycontrol\Mani 2.0\\2"
proxies = {
 "http": "http://X119285:Password20.4@proxy-sgt.si.socgen:8080",
 "https": "http://X119285:Password20.4@proxy-sgt.si.socgen:8080",
}

def MParseDate(Date):
    ts = (np.datetime64(pd.to_datetime(Date)) - np.datetime64('1970-01-01T00:00:00Z')) / np.timedelta64(1, 's')
    return N1(N1(datetime.utcfromtimestamp(ts),'5H',"+"),"30M","+")
seconds_per_unit = {"S": 1, "M": 60, "H": 3600, "D": 86400, "W": 604800}
def N1(date,s,Operation):
    if (Operation=="+"):
        return date+timedelta(seconds=int(s[:-1]) * seconds_per_unit[s[-1]])
    else:
        return date-timedelta(seconds=int(s[:-1]) * seconds_per_unit[s[-1]])

#
##SBIN5Min['ATRSTPH_26']=SBIN5Min['ATRSTPH'].shift(26)
##SBIN5Min['ATRSTPL_26']=SBIN5Min['ATRSTPL'].shift(26)
##Sdf=candlestick.Ichimoku(SBIN5Min,9,26,52,-26)
##SBIN5Min.merge(Sdf)
##s=ATR(SBIN5Min,14)
#
#df=SBIN5Min.iloc[-948:-364]
#df.reset_index(inplace = True) 
##TR1=np.maximum(df['High']-df['Low'],df['Close'].shift(1)-df['Low'])
##TR=np.maximum(TR1,df['High']-df['Close'].shift(1))
#df['ATR']=ta.ATR(df,14)
#df['HATR']=df['ATR']*3+df['High']
#df['LATR']=df['Low']-df['ATR']*3
#Sdf=candlestick.Ichimoku(df,9,26,52,-26)
#df.merge(Sdf)
#n=10
#TR_s = pd.Series(TR)  
#a_ATR=pd.DataFrame.ewm(TR_s, span = n, min_periods = n,axis=0).mean()

#ATR = pd.Series(pd.DataFrame.ewm(TR_s, span = n, min_periods = n), name = 'ATR_' + str(n))  
#Average True Range  
def ATR(df, n):  
    i = 0  
    TR_l = [0]  
    while i < df.index[-1]:  
        TR = max(df.iloc[i + 1]['High'], df.iloc[i]['Close']) - min(df.iloc[i + 1]['Low'], df.iloc[i]['Close'])  
        TR_l.append(TR)  
        i = i + 1  
    TR_s = pd.Series(TR_l)  
    ATR = pd.Series(pd.ewma(TR_s, span = n, min_periods = n), name = 'ATR_' + str(n))  
    df = df.join(ATR)  
    return df


#Keltner Channel  
def KELCH(df, n):  
    KelChM = pd.Series(pd.rolling_mean((df['High'] + df['Low'] + df['Close']) / 3, n), name = 'KelChM_' + str(n))  
    KelChU = pd.Series(pd.rolling_mean((4 * df['High'] - 2 * df['Low'] + df['Close']) / 3, n), name = 'KelChU_' + str(n))  
    KelChD = pd.Series(pd.rolling_mean((-2 * df['High'] + 4 * df['Low'] + df['Close']) / 3, n), name = 'KelChD_' + str(n))  
    df = df.join(KelChM)  
    df = df.join(KelChU)  
    df = df.join(KelChD)  
    return df

def getAtrRatio(df, period=14):
        """
            平均波动率：ATR(14)/MA(14)
        """
        highs = df['High']
        lows = df['Low']
        closes = df['Close']

        atr = ta.ATR(highs, lows, closes, period)
        
        ma = ta.MA(closes, timeperiod=period)

        volatility = atr/ma

        s = pd.Series(volatility, index=df.index, name='volatility').dropna()

        return s 
    
def _getAtrExtreme(cls, highs, lows, closes, atrPeriod=14, slowPeriod=30, fastPeriod=3):
        """
            获取TTI ATR Exterme通道, which is based on 《Volatility-Based Technical Analysis》
            TTI is 'Trading The Invisible'

            @return: fasts, slows
        """
        # talib 的源码，它的 ATR 不是 N 日简单平均，而是类似 EMA 的方法计算的指数平均
        atr = talib.ATR(highs, lows, closes, timeperiod=atrPeriod)

        highsMean = talib.EMA(highs, 5)
        lowsMean = talib.EMA(lows, 5)
        closesMean = talib.EMA(closes, 5)

        atrExtremes = np.where(closes > closesMean,
                               ((highs - highsMean)/closes * 100) * (atr/closes * 100),
                               ((lows - lowsMean)/closes * 100) * (atr/closes * 100)
                               )

        fasts = talib.MA(atrExtremes, fastPeriod)
        slows = talib.EMA(atrExtremes, slowPeriod)

        return fasts, slows, np.std(atrExtremes[-slowPeriod:])
    
def HA(df, ohlc=['Open', 'High', 'Low', 'Close']):
    """
    Function to compute Heiken Ashi Candles (HA)
    
    Args :
        df : Pandas DataFrame which contains ['date', 'open', 'high', 'low', 'close', 'volume'] columns
        ohlc: List defining OHLC Column names (default ['Open', 'High', 'Low', 'Close'])
        
    Returns :
        df : Pandas DataFrame with new columns added for 
            Heiken Ashi Close (HA_$ohlc[3])
            Heiken Ashi Open (HA_$ohlc[0])
            Heiken Ashi High (HA_$ohlc[1])
            Heiken Ashi Low (HA_$ohlc[2])
    """

    ha_open = 'HA_' + ohlc[0]
    ha_high = 'HA_' + ohlc[1]
    ha_low = 'HA_' + ohlc[2]
    ha_close = 'HA_' + ohlc[3]
    
    df[ha_close] = (df[ohlc[0]] + df[ohlc[1]] + df[ohlc[2]] + df[ohlc[3]]) / 4

    df[ha_open] = 0.00
    for i in range(0, len(df)):
        if i == 0:
            df[ha_open].iat[i] = (df[ohlc[0]].iat[i] + df[ohlc[3]].iat[i]) / 2
        else:
            df[ha_open].iat[i] = (df[ha_open].iat[i - 1] + df[ha_close].iat[i - 1]) / 2
            
    df[ha_high]=df[[ha_open, ha_close, ohlc[1]]].max(axis=1)
    df[ha_low]=df[[ha_open, ha_close, ohlc[2]]].min(axis=1)

    return df

def SMA(df, base, target, period):
    """
    Function to compute Simple Moving Average (SMA)
    
    Args :
        df : Pandas DataFrame which contains ['date', 'open', 'high', 'low', 'close', 'volume'] columns
        base : String indicating the column name from which the SMA needs to be computed from
        target : String indicates the column name to which the computed data needs to be stored
        period : Integer indicates the period of computation in terms of number of candles
        
    Returns :
        df : Pandas DataFrame with new column added with name 'target'
    """

    df[target] = df[base].rolling(window=period).mean()
    df[target].fillna(0, inplace=True)

    return df

def STDDEV(df, base, target, period):
    """
    Function to compute Standard Deviation (STDDEV)
    
    Args :
        df : Pandas DataFrame which contains ['date', 'open', 'high', 'low', 'close', 'volume'] columns
        base : String indicating the column name from which the SMA needs to be computed from
        target : String indicates the column name to which the computed data needs to be stored
        period : Integer indicates the period of computation in terms of number of candles
        
    Returns :
        df : Pandas DataFrame with new column added with name 'target'
    """

    df[target] = df[base].rolling(window=period).std()
    df[target].fillna(0, inplace=True)

    return df

def EMA(df, base, target, period, alpha=False):
    """
    Function to compute Exponential Moving Average (EMA)
    
    Args :
        df : Pandas DataFrame which contains ['date', 'open', 'high', 'low', 'close', 'volume'] columns
        base : String indicating the column name from which the EMA needs to be computed from
        target : String indicates the column name to which the computed data needs to be stored
        period : Integer indicates the period of computation in terms of number of candles
        alpha : Boolean if True indicates to use the formula for computing EMA using alpha (default is False)
        
    Returns :
        df : Pandas DataFrame with new column added with name 'target'
    """

    con = pd.concat([df[:period][base].rolling(window=period).mean(), df[period:][base]])
    
    if (alpha == True):
        # (1 - alpha) * previous_val + alpha * current_val where alpha = 1 / period
        df[target] = con.ewm(alpha=1 / period, adjust=False).mean()
    else:
        # ((current_val - previous_val) * coeff) + previous_val where coeff = 2 / (period + 1)
        df[target] = con.ewm(span=period, adjust=False).mean()
    
    df[target].fillna(0, inplace=True)
    return df

def ATR(df, period, ohlc=['Open', 'High', 'Low', 'Close']):
    """
    Function to compute Average True Range (ATR)
    
    Args :
        df : Pandas DataFrame which contains ['date', 'open', 'high', 'low', 'close', 'volume'] columns
        period : Integer indicates the period of computation in terms of number of candles
        ohlc: List defining OHLC Column names (default ['Open', 'High', 'Low', 'Close'])
        
    Returns :
        df : Pandas DataFrame with new columns added for 
            True Range (TR)
            ATR (ATR_$period)
    """
    atr = 'ATR_' + str(period)

    # Compute true range only if it is not computed and stored earlier in the df
    if not 'TR' in df.columns:
        df['h-l'] = df[ohlc[1]] - df[ohlc[2]]
        df['h-yc'] = abs(df[ohlc[1]] - df[ohlc[3]].shift())
        df['l-yc'] = abs(df[ohlc[2]] - df[ohlc[3]].shift())
         
        df['TR'] = df[['h-l', 'h-yc', 'l-yc']].max(axis=1)
         
        df.drop(['h-l', 'h-yc', 'l-yc'], inplace=True, axis=1)

    # Compute EMA of true range using ATR formula after ignoring first row
    EMA(df, 'TR', atr, period, alpha=True)
    
    return df

def SuperTrend(df, period, multiplier, ohlc=['Open', 'High', 'Low', 'Close']):
    """
    Function to compute SuperTrend
    
    Args :
        df : Pandas DataFrame which contains ['date', 'open', 'high', 'low', 'close', 'volume'] columns
        period : Integer indicates the period of computation in terms of number of candles
        multiplier : Integer indicates value to multiply the ATR
        ohlc: List defining OHLC Column names (default ['Open', 'High', 'Low', 'Close'])
        
    Returns :
        df : Pandas DataFrame with new columns added for 
            True Range (TR), ATR (ATR_$period)
            SuperTrend (ST_$period_$multiplier)
            SuperTrend Direction (STX_$period_$multiplier)
    """

    ATR(df, period, ohlc=ohlc)
    atr = 'ATR_' + str(period)
    st = 'ST_' + str(period) + '_' + str(multiplier)
    stx = 'STX_' + str(period) + '_' + str(multiplier)
    
    """
    SuperTrend Algorithm :
    
        BASIC UPPERBAND = (HIGH + LOW) / 2 + Multiplier * ATR
        BASIC LOWERBAND = (HIGH + LOW) / 2 - Multiplier * ATR
        
        FINAL UPPERBAND = IF( (Current BASICUPPERBAND < Previous FINAL UPPERBAND) or (Previous Close > Previous FINAL UPPERBAND))
                            THEN (Current BASIC UPPERBAND) ELSE Previous FINALUPPERBAND)
        FINAL LOWERBAND = IF( (Current BASIC LOWERBAND > Previous FINAL LOWERBAND) or (Previous Close < Previous FINAL LOWERBAND)) 
                            THEN (Current BASIC LOWERBAND) ELSE Previous FINAL LOWERBAND)
        
        SUPERTREND = IF((Previous SUPERTREND = Previous FINAL UPPERBAND) and (Current Close <= Current FINAL UPPERBAND)) THEN
                        Current FINAL UPPERBAND
                    ELSE
                        IF((Previous SUPERTREND = Previous FINAL UPPERBAND) and (Current Close > Current FINAL UPPERBAND)) THEN
                            Current FINAL LOWERBAND
                        ELSE
                            IF((Previous SUPERTREND = Previous FINAL LOWERBAND) and (Current Close >= Current FINAL LOWERBAND)) THEN
                                Current FINAL LOWERBAND
                            ELSE
                                IF((Previous SUPERTREND = Previous FINAL LOWERBAND) and (Current Close < Current FINAL LOWERBAND)) THEN
                                    Current FINAL UPPERBAND
    """
    
    # Compute basic upper and lower bands
    df['basic_ub'] = (df[ohlc[1]] + df[ohlc[2]]) / 2 + multiplier * df[atr]
    df['basic_lb'] = (df[ohlc[1]] + df[ohlc[2]]) / 2 - multiplier * df[atr]

    # Compute final upper and lower bands
    df['final_ub'] = 0.00
    df['final_lb'] = 0.00
    for i in range(period, len(df)):
        df['final_ub'].iat[i] = df['basic_ub'].iat[i] if df['basic_ub'].iat[i] < df['final_ub'].iat[i - 1] or df[ohlc[3]].iat[i - 1] > df['final_ub'].iat[i - 1] else df['final_ub'].iat[i - 1]
        df['final_lb'].iat[i] = df['basic_lb'].iat[i] if df['basic_lb'].iat[i] > df['final_lb'].iat[i - 1] or df[ohlc[3]].iat[i - 1] < df['final_lb'].iat[i - 1] else df['final_lb'].iat[i - 1]
       
    # Set the Supertrend value
    df[st] = 0.00
    for i in range(period, len(df)):
        df[st].iat[i] = df['final_ub'].iat[i] if df[st].iat[i - 1] == df['final_ub'].iat[i - 1] and df[ohlc[3]].iat[i] <= df['final_ub'].iat[i] else \
                        df['final_lb'].iat[i] if df[st].iat[i - 1] == df['final_ub'].iat[i - 1] and df[ohlc[3]].iat[i] >  df['final_ub'].iat[i] else \
                        df['final_lb'].iat[i] if df[st].iat[i - 1] == df['final_lb'].iat[i - 1] and df[ohlc[3]].iat[i] >= df['final_lb'].iat[i] else \
                        df['final_ub'].iat[i] if df[st].iat[i - 1] == df['final_lb'].iat[i - 1] and df[ohlc[3]].iat[i] <  df['final_lb'].iat[i] else 0.00 
                 
    # Mark the trend direction up/down
    df[stx] = np.where((df[st] > 0.00), np.where((df[ohlc[3]] < df[st]), 'down',  'up'), np.NaN)

    # Remove basic and final bands from the columns
    df.drop(['basic_ub', 'basic_lb', 'final_ub', 'final_lb'], inplace=True, axis=1)
    
    df.fillna(0, inplace=True)

    return df

def MACD(df, fastEMA=12, slowEMA=26, signal=9, base='Close'):
    """
    Function to compute Moving Average Convergence Divergence (MACD)
    
    Args :
        df : Pandas DataFrame which contains ['date', 'open', 'high', 'low', 'close', 'volume'] columns
        fastEMA : Integer indicates faster EMA
        slowEMA : Integer indicates slower EMA
        signal : Integer indicates the signal generator for MACD
        base : String indicating the column name from which the MACD needs to be computed from (Default Close)
        
    Returns :
        df : Pandas DataFrame with new columns added for 
            Fast EMA (ema_$fastEMA)
            Slow EMA (ema_$slowEMA)
            MACD (macd_$fastEMA_$slowEMA_$signal)
            MACD Signal (signal_$fastEMA_$slowEMA_$signal)
            MACD Histogram (MACD (hist_$fastEMA_$slowEMA_$signal)) 
    """

    fE = "ema_" + str(fastEMA)
    sE = "ema_" + str(slowEMA)
    macd = "macd_" + str(fastEMA) + "_" + str(slowEMA) + "_" + str(signal)
    sig = "signal_" + str(fastEMA) + "_" + str(slowEMA) + "_" + str(signal)
    hist = "hist_" + str(fastEMA) + "_" + str(slowEMA) + "_" + str(signal)

    # Compute fast and slow EMA    
    EMA(df, base, fE, fastEMA)
    EMA(df, base, sE, slowEMA)
    
    # Compute MACD
    df[macd] = np.where(np.logical_and(np.logical_not(df[fE] == 0), np.logical_not(df[sE] == 0)), df[fE] - df[sE], 0)
    
    # Compute MACD Signal
    EMA(df, macd, sig, signal)
    
    # Compute MACD Histogram
    df[hist] = np.where(np.logical_and(np.logical_not(df[macd] == 0), np.logical_not(df[sig] == 0)), df[macd] - df[sig], 0)
    
    return df

def BBand(df, base='Close', period=20, multiplier=2):
    """
    Function to compute Bollinger Band (BBand)
    
    Args :
        df : Pandas DataFrame which contains ['date', 'open', 'high', 'low', 'close', 'volume'] columns
        base : String indicating the column name from which the MACD needs to be computed from (Default Close)
        period : Integer indicates the period of computation in terms of number of candles
        multiplier : Integer indicates value to multiply the SD
        
    Returns :
        df : Pandas DataFrame with new columns added for 
            Upper Band (UpperBB_$period_$multiplier)
            Lower Band (LowerBB_$period_$multiplier)
    """
    
    upper = 'UpperBB_' + str(period) + '_' + str(multiplier)
    lower = 'LowerBB_' + str(period) + '_' + str(multiplier)
    
    sma = df[base].rolling(window=period, min_periods=period - 1).mean()
    sd = df[base].rolling(window=period).std()
    df[upper] = sma + (multiplier * sd)
    df[lower] = sma - (multiplier * sd)
    
    df[upper].fillna(0, inplace=True)
    df[lower].fillna(0, inplace=True)
    
    return df

def RSI(df, base="Close", period=21):
    """
    Function to compute Relative Strength Index (RSI)
    
    Args :
        df : Pandas DataFrame which contains ['date', 'open', 'high', 'low', 'close', 'volume'] columns
        base : String indicating the column name from which the MACD needs to be computed from (Default Close)
        period : Integer indicates the period of computation in terms of number of candles
        
    Returns :
        df : Pandas DataFrame with new columns added for 
            Relative Strength Index (RSI_$period)
    """
 
    delta = df[base].diff()
    up, down = delta.copy(), delta.copy()

    up[up < 0] = 0
    down[down > 0] = 0
    
    rUp = up.ewm(com=period - 1,  adjust=False).mean()
    rDown = down.ewm(com=period - 1, adjust=False).mean().abs()

    df['RSI_' + str(period)] = 100 - 100 / (1 + rUp / rDown)
    df['RSI_' + str(period)].fillna(0, inplace=True)

    return df

def Ichimoku(df, ohlc=['Open', 'High', 'Low', 'Close'], param=[9, 26, 52, 26]):
    """
    Function to compute Ichimoku Cloud parameter (Ichimoku)
    
    Args :
        df : Pandas DataFrame which contains ['date', 'open', 'high', 'low', 'close', 'volume'] columns
        ohlc: List defining OHLC Column names (default ['Open', 'High', 'Low', 'Close'])
        param: Periods to be used in computation (default [tenkan_sen_period, kijun_sen_period, senkou_span_period, chikou_span_period] = [9, 26, 52, 26])
        
    Returns :
        df : Pandas DataFrame with new columns added for ['Tenkan Sen', 'Kijun Sen', 'Senkou Span A', 'Senkou Span B', 'Chikou Span']
    """
    
    high = df[ohlc[1]]
    low = df[ohlc[2]]
    close = df[ohlc[3]]
    
    tenkan_sen_period = param[0]
    kijun_sen_period = param[1]
    senkou_span_period = param[2]
    chikou_span_period = param[3]
    
    tenkan_sen_column = 'Tenkan Sen'
    kijun_sen_column = 'Kijun Sen'
    senkou_span_a_column = 'Senkou Span A'
    senkou_span_b_column = 'Senkou Span B'
    chikou_span_column = 'Chikou Span'
    
    # Tenkan-sen (Conversion Line)
    tenkan_sen_high = high.rolling(window=tenkan_sen_period).max()
    tenkan_sen_low = low.rolling(window=tenkan_sen_period).min()
    df[tenkan_sen_column] = (tenkan_sen_high + tenkan_sen_low) / 2
    
    # Kijun-sen (Base Line)
    kijun_sen_high = high.rolling(window=kijun_sen_period).max()
    kijun_sen_low = low.rolling(window=kijun_sen_period).min()
    df[kijun_sen_column] = (kijun_sen_high + kijun_sen_low) / 2
    
    # Senkou Span A (Leading Span A)
    df[senkou_span_a_column] = ((df[tenkan_sen_column] + df[kijun_sen_column]) / 2).shift(kijun_sen_period)
    
    # Senkou Span B (Leading Span B)
    senkou_span_high = high.rolling(window=senkou_span_period).max()
    senkou_span_low = low.rolling(window=senkou_span_period).min()
    df[senkou_span_b_column] = ((senkou_span_high + senkou_span_low) / 2).shift(kijun_sen_period)
    
    # The most current closing price plotted chikou_span_period time periods behind
    df[chikou_span_column] = close.shift(-1 * chikou_span_period)
    
    return df



def STOK(close, low, high, n): 
 STOK = ((close - pd.rolling_min(low, n)) / (pd.rolling.max(high, n) - pd.rolling_min(low, n))) * 100
 return STOK

def STOD(close, low, high, n):
 STOK = ((close - pd.rolling_min(low, n)) / (pd.rolling_max(high, n) - pd.rolling_min(low, n))) * 100
 STOD = pd.rolling_mean(STOK, 3)
 return STOD

def STOCDK(df,period):
    df['L14'] = df['Low'].rolling(window=period).min()
    
    #Create the "H14" column in the DataFrame
    df['H14'] = df['High'].rolling(window=period).max()
    
    #Create the "%K" column in the DataFrame
    df['%K'] = 100*((df['Close'] - df['L14']) / (df['H14'] - df['L14']) )
    
    #Create the "%D" column in the DataFrame
    df['%D'] = df['%K'].rolling(window=3).mean()
#df.tail()


def getPastData(ID,StockName,interval):
#    global Candles,url 
#    global Candles_dict 
    global mdf,mdfst,ddfst
    headers1={}
    Cookie="__cfduid=d742e80f3b3e29bf1896fffb390db31521567509566; _ga=GA1.2.1163935487.1570611192; kf_session=C0Hl9t5uREbMz3aeZnpRZ5B7nsb7VARq; public_token=meotnXqFVDWBl6gyU21xwB9zTR7Pnegp; user_id=RM5678; enctoken=pg2Ku6aGhIoi0+Am17IGcQ5CmhHMv9b4ujZVghS/42akCArw/ju9wrxK3nGDg1aeTRMGygawVIfA3fO3kSojT7FKuCgUGA=="
    authorization="enctoken pg2Ku6aGhIoi0+Am17IGcQ5CmhHMv9b4ujZVghS/42akCArw/ju9wrxK3nGDg1aeTRMGygawVIfA3fO3kSojT7FKuCgUGA=="
   
    headers1 = {
            #'Content-type': 'application/x-www-form-urlencoded',
#                ":authority": "kite.zerodha.com",
#                ":method": "GET",
#                ":path": "/oms/instruments/historical/7712001/15minute?user_id=RM5678&oi=1&from=2020-02-04&to=2020-02-18&ciqrandom=1582039082895",
#                ":scheme": "https",
               #'Accept': 'application/json, text/plain, */*',
               #"accept":"*/*",
               #"accept-encoding":"gzip, deflate, br",
               #"accept-language":"en-US,en;q=0.9",
               'authorization': authorization,
               'cookie':Cookie
               
               #,'x-csrftoken':'ydYuAU0A7nEJzXNJkAj58uiBc5pc9rWj'
               ,'referer':'https://kite.zerodha.com/static/build/chart.html?v=2.4.0'
               #,"sec-fetch-dest": "empty"
               #,"sec-fetch-mode": "cors"
               #,"sec-fetch-site": "same-origin"
               ,"user-agent": "Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.106 Safari/537.36"
               }
    
    #headers['User-Agent'] = 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36'
    if(Test==False):
        StrTimeIntervals=['minute','3minute','5minute','15minute','30minute','60minute','2hour','3hour','day']
    else:
        StrTimeIntervals=[interval]
    #StrTimeIntervals=['minute','3minute','5minute','15minute','day']
    #StrTimeIntervals=['60minute','2hour','3hour','day']
    #Increment=[20,60,90,120,250]
    #StrTimeIntervals=['minute']
    #StrTimeIntervals=['3minute']
    #Increment=[20,30,60,80,120,180]
    #Increment=,10]
    #Increment=[20]
    Increment=[20,20,20,20,20,20,20,20,20]
    #Increment=[18,18,18,18,18,18,18,18,18]
    #Increment=[1,1,1,1,1]
    #Increment=[3,3,3,3,3]
    #StrTimeIntervals=['day']
    Duration=10
    #Duration=18
    requests.Timeout(120)
    for TimeInterval in StrTimeIntervals: # 54261767
        #TimeInterval="minute"
        
        #mdf=pd.DataFrame()
        #print(StockName+"     Running ....."+ TimeInterval )
        #StartDate=N1(datetime.now(),'3D','-')
        #StartDate=N1(datetime.now(),str(2380)+'D','-')
        StartDate=N1(datetime.now(),str(Duration)+'D','-')
        DateIncr=0        
        #while(DateIncr<3):
        while(DateIncr<Duration):
            DateIncr=DateIncr+Increment[StrTimeIntervals.index(TimeInterval)]+1
            EndDate=N1(StartDate,str(Increment[StrTimeIntervals.index(TimeInterval)])+'D','+')
            StartDateStr=StartDate.strftime("%Y-%m-%d")
            EndDateStr=EndDate.strftime("%Y-%m-%d")
            #print(str(DateIncr)+" --> "+StartDateStr+ ' - ' + EndDateStr)
            #url='https://kitecharts-aws.zerodha.com/api/chart/'+str(ID)+'/'+TimeInterval+'?public_token=Pb0MyvJ435vcAjx5fxCTtEV0oD0wdcwT&user_id=RM5678&api_key=kitefront&access_token=mwFtysT9JpZk6B7ZOUH4AqbrJkhUlTnC&'+'from='+StartDateStr+'&to='+EndDateStr+'&ciqrandom=1549306657305'                               
            url='https://kite.zerodha.com/oms/instruments/historical/'+str(ID)+'/'+TimeInterval+'?user_id=RM5678&oi=1&from='+StartDateStr+'&to='+EndDateStr+'&ciqrandom=1581744034200'
            retry=1
            time.sleep(5)
            while(retry<5):
#                Candles = requests.get('https://kitecharts-aws.zerodha.com/api/chart/'+str(ID)+'/'+TimeInterval+
#                               '?public_token=Pb0MyvJ435vcAjx5fxCTtEV0oD0wdcwT&user_id=RM5678&api_key=kitefront&access_token=mwFtysT9JpZk6B7ZOUH4AqbrJkhUlTnC&'+
##                               'from=2019-01-08&to=2019-04-05&ciqrandom=1549306657305') #GOLD
#                                'from='+StartDateStr+'&to='+EndDateStr+'&ciqrandom=1549306657305',headers=headers) #GOLD
                Candles = requests.get(url,headers=headers,proxies=proxies)
                if(Candles.status_code==200):
                    retry=10
                else:
                    print("Retry " + str(retry) + " ---- "+ str(Candles.status_code))
                    time.sleep(1)
                    retry=retry+1
                    
            Candles_dict = Candles.json()['data']['candles']
            
            tCandles_df = pd.DataFrame(Candles_dict,columns=['Date', 'open', 'high', 'low', 'close', 'V','Z'])
            tCandles_df.columns=['Date', 'Open', 'High', 'Low', 'Close', 'V','Z']
           #  Data1.columns=['Date', 'Open', 'High', 'Low', 'Close', 'V']
            #tCandles_df['Stock']=StockName
            tCandles_df = tCandles_df[['Date','Open', 'High', 'Low', 'Close', 'V']]
            
            
            if(str(tCandles_df['Date'].dtype)!='datetime64[ns]'):
    #    List_ = [datetime.strptime(parse(x).strftime("%m/%d/%Y %I:%M %p"), "%m/%d/%Y %I:%M %p") for x in List_]
                tCandles_df['Date']=pd.to_datetime(tCandles_df.Date)
            else:
                List_ = list(tCandles_df['Date'])
                List_ = [datetime.strptime(MParseDate(x).strftime("%m/%d/%Y %I:%M %p"), "%m/%d/%Y %I:%M %p") for x in List_]
                tCandles_df['Date']=pd.Series([x for x in List_],index=tCandles_df.index)
#            tempst={}
#            tempst[StockName]=pd.DataFrame.to_dict(tCandles_df)
#            tempar=[]
#            tempar.append(tempst)
            if(interval=="minute"):                
                #mdf=mdf.append(pd.DataFrame(tempar))
                #mdf[StockName]=tCandles_df
                mdfst[StockName]=tCandles_df
            else:
                #ddf=ddf.append(tCandles_df)
                ddfst[StockName]=tCandles_df
            StartDate=N1(EndDate,'1D','+')
        df.sort_values(['Date'],ascending=True)
        df.to_csv(StockDIR+StockName+"-"+TimeInterval+".csv",sep=',',encoding='utf-8',index=False)

Header={}
with open(os.getcwd()+"\\Test\\Headers.txt","r") as ins:
    array = []
    for line in ins:
        array.append(line)
        l=line.split(": ")
        Header[l[0]]=l[1].lstrip().replace('\n','')
headers=Header

def process(StockName,i):
    global Final
    SBIN5Min=mdfst[StockName].reset_index()#candlestick.LoadCSVDatax(DIRNIFTY,StockName,"minute")
#    SBIN5Min=mdfst[StockName][-700:].reset_index()#candlestick.LoadCSVDatax(DIRNIFTY,StockName,"minute")
    SuperTrend(SBIN5Min,10,5)
    SuperTrend(SBIN5Min,21,3)
#    ATR(SBIN5Min,21)
    #SBIN5Min['ATRSTPH']=SBIN5Min['Close']+round(SBIN5Min['ATR_21'],0)*3
    #SBIN5Min['ATRSTPL']=SBIN5Min['Close']-round(SBIN5Min['ATR_21'],0)*3
    SBIN5Min['EMAC26']=SBIN5Min['Close'].ewm(span=26, adjust=False).mean()
    SBIN5Min['PATRSL_26']=SBIN5Min['ST_21_3'].shift(26)
    SBIN5Min['PATRSL_26_X']=SBIN5Min['STX_21_3'].shift(26)
    SBIN5Min['PATRSL_10']=SBIN5Min['ST_21_3'].shift(10)
    SBIN5Min['PATRSL_10_X']=SBIN5Min['STX_21_3'].shift(10)
    SBIN5Min['PATRSL_16']=SBIN5Min['ST_21_3'].shift(16)
    SBIN5Min['PATRSL_00_X']=SBIN5Min['PATRSL_16'].rolling(10).mean()
    SBIN5Min['SIGNALM']=(round(SBIN5Min['PATRSL_26'],2)==round(SBIN5Min['PATRSL_00_X'],2))
    SBIN5Min['RSI14']=ta.RSI(SBIN5Min,14)
    SBIN5Min['SIGNAL']=SBIN5Min['STX_10_5']
    SBIN5Min['CheckSIGNAL']=SBIN5Min['SIGNAL']!=SBIN5Min['SIGNAL'].shift(1)
    SBIN5Min['CCOL']=SBIN5Min['PATRSL_26']
    SBIN5Min['CCOLSIGNAL']=SBIN5Min['PATRSL_26_X']
    STOCDK(SBIN5Min,52)
    SBIN5Min['EMAK50']=SBIN5Min['%K'].ewm(span=50, adjust=False).mean()
#    SBIN5Min['Date']=SBIN5Min['Date'].apply(lambda x: MParseDate(x).strftime("%m/%d/%Y %I:%M %p"))
#    SBIN5Min['Date']=pd.to_datetime(SBIN5Min['Date'])
    SBIN5Min['SESignal']=(
            (SBIN5Min['%K'].shift(1)>SBIN5Min['EMAK50'].shift(1))  &
            (SBIN5Min['%K']<SBIN5Min['EMAK50'])  &
            (SBIN5Min['%K'].shift(1)>80)  &
            (SBIN5Min['EMAK50'].shift(1)>80)  
            )
    
    SBIN5Min['BESignal']=(
        (SBIN5Min['%K'].shift(1)<SBIN5Min['EMAK50'].shift(1))  &
        (SBIN5Min['%K']>SBIN5Min['EMAK50'])  &
        (SBIN5Min['%K'].shift(1)<20)  &
        (SBIN5Min['EMAK50'].shift(1)<20)  
        )

    
    df=candlestick.atlstoploss_crosscount(SBIN5Min)
    df['Stock']=StockName
    df1=df[(df['BESignal']==True)|(df['SESignal']==True)|((df['CheckSIGNAL']==True) & (df['AtlstoplossCrosscount']<7) 
    & (df['AtlstoplossCrosscount']>=0))][
    ['Stock','Date','Open','High','Low','Close','RSI14','SESignal','BESignal','SIGNALM','SIGNAL','CheckSIGNAL','PATRSL_26','PATRSL_26_X','PATRSL_00_X','AtlstoplossCrosscount','EMAC26']]
    if(i==Start):
        Final=df1
    else:
        Final=Final.append(df1)
    


def process1(StockName,i):
    global Final
#    SBIN5Min=mdfst[StockName].reset_index()#candlestick.LoadCSVDatax(DIRNIFTY,StockName,"minute")
##    SBIN5Min=mdfst[StockName][-700:].reset_index()#candlestick.LoadCSVDatax(DIRNIFTY,StockName,"minute")
#    SuperTrend(SBIN5Min,10,5)
#    SuperTrend(SBIN5Min,21,3)
##    ATR(SBIN5Min,21)
#    #SBIN5Min['ATRSTPH']=SBIN5Min['Close']+round(SBIN5Min['ATR_21'],0)*3
#    #SBIN5Min['ATRSTPL']=SBIN5Min['Close']-round(SBIN5Min['ATR_21'],0)*3
#    SBIN5Min['EMAC26']=SBIN5Min['Close'].ewm(span=26, adjust=False).mean()
#    SBIN5Min['PATRSL_26']=SBIN5Min['ST_21_3'].shift(26)
#    SBIN5Min['PATRSL_26_X']=SBIN5Min['STX_21_3'].shift(26)
#    SBIN5Min['PATRSL_10']=SBIN5Min['ST_21_3'].shift(10)
#    SBIN5Min['PATRSL_10_X']=SBIN5Min['STX_21_3'].shift(10)
#    SBIN5Min['PATRSL_16']=SBIN5Min['ST_21_3'].shift(16)
#    SBIN5Min['PATRSL_00_X']=SBIN5Min['PATRSL_16'].rolling(10).mean()
#    SBIN5Min['SIGNALM']=(round(SBIN5Min['PATRSL_26'],2)==round(SBIN5Min['PATRSL_00_X'],2))
#    SBIN5Min['RSI14']=ta.RSI(SBIN5Min,14)
#    SBIN5Min['SIGNAL']=SBIN5Min['STX_10_5']
#    SBIN5Min['CheckSIGNAL']=SBIN5Min['SIGNAL']!=SBIN5Min['SIGNAL'].shift(1)
#    SBIN5Min['CCOL']=SBIN5Min['PATRSL_26']
#    SBIN5Min['CCOLSIGNAL']=SBIN5Min['PATRSL_26_X']
#    STOCDK(SBIN5Min,52)
#    SBIN5Min['EMAK50']=SBIN5Min['%K'].ewm(span=50, adjust=False).mean()
##    SBIN5Min['Date']=SBIN5Min['Date'].apply(lambda x: MParseDate(x).strftime("%m/%d/%Y %I:%M %p"))
##    SBIN5Min['Date']=pd.to_datetime(SBIN5Min['Date'])
#    SBIN5Min['SESignal']=(
#            (SBIN5Min['%K'].shift(1)>SBIN5Min['EMAK50'].shift(1))  &
#            (SBIN5Min['%K']<SBIN5Min['EMAK50'])  &
#            (SBIN5Min['%K'].shift(1)>80)  &
#            (SBIN5Min['EMAK50'].shift(1)>80)  
#            )
#    
#    SBIN5Min['BESignal']=(
#        (SBIN5Min['%K'].shift(1)<SBIN5Min['EMAK50'].shift(1))  &
#        (SBIN5Min['%K']>SBIN5Min['EMAK50'])  &
#        (SBIN5Min['%K'].shift(1)<20)  &
#        (SBIN5Min['EMAK50'].shift(1)<20)  
#        )
#
#    
#    df=candlestick.atlstoploss_crosscount(SBIN5Min)
#    df['Stock']=StockName
#    df1=df[(df['BESignal']==True)|(df['SESignal']==True)|((df['CheckSIGNAL']==True) & (df['AtlstoplossCrosscount']<7) 
#    & (df['AtlstoplossCrosscount']>=0))][
#    ['Stock','Date','Open','High','Low','Close','RSI14','SESignal','BESignal','SIGNALM','SIGNAL','CheckSIGNAL','PATRSL_26','PATRSL_26_X','PATRSL_00_X','AtlstoplossCrosscount','EMAC26']]
    
    SBIN5Min=candlestick.LoadCSVDatax(DIRNIFTY,StockName,"minute")
    SBINDay=candlestick.LoadCSVDatax(DIRNIFTY,StockName,"day")
    
    SBINDay['Date']=SBINDay['Date'].apply(lambda x: MParseDate(x).strftime("%m/%d/%Y %I:%M %p"))
    SBINDay['Date']=pd.to_datetime(SBINDay['Date'])
    SBIN5Min['Date']=SBIN5Min['Date'].apply(lambda x: MParseDate(x).strftime("%m/%d/%Y %I:%M %p"))
    SBIN5Min['Date']=pd.to_datetime(SBIN5Min['Date'])


    SBINDay['CDATE']=pd.to_datetime(SBINDay['Date']).dt.strftime("%Y-%b-%d")
    SBIN5Min['CDATE']=pd.to_datetime(SBIN5Min['Date']).dt.strftime("%Y-%b-%d")
    SBINDay['PDayLow']=SBINDay['Low'].shift(1)
    SBINDay['PDayHigh']=SBINDay['High'].shift(1)
    SBINDay['PDayClose']=SBINDay['Close'].shift(1)
    SBINDay['PDayOpen']=SBINDay['Open'].shift(1)
    
    SBINDay["IPivot"]=candlestick.MaRound((SBINDay['Close'].shift(1)+SBINDay['High'].shift(1)+SBINDay['Low'].shift(1))/3)
    SBINDay["H4"]=candlestick.MaRound(SBINDay["IPivot"]+((SBINDay['High'].shift(1)-SBINDay['Low'].shift(1))*3))   
    SBINDay["H3A"]=candlestick.MaRound(SBINDay["IPivot"]+((SBINDay['High'].shift(1)-SBINDay['Low'].shift(1))*2.5))   
    SBINDay["H3"]=candlestick.MaRound(SBINDay["IPivot"]+((SBINDay['High'].shift(1)-SBINDay['Low'].shift(1))*2))   
    SBINDay["H2A"]=candlestick.MaRound(SBINDay["IPivot"]+((SBINDay['High'].shift(1)-SBINDay['Low'].shift(1))*1.5))   
    SBINDay["H2"]=candlestick.MaRound(SBINDay["IPivot"]+((SBINDay['High'].shift(1)-SBINDay['Low'].shift(1))))      
    SBINDay["H1"]=candlestick.MaRound(2*SBINDay["IPivot"]-SBINDay["Low"].shift(1))    
    SBINDay["IPivot-H"]=round((SBINDay["IPivot"]+SBINDay["H1"])/2,2)
    SBINDay["L4"]=candlestick.MaRound(SBINDay["IPivot"]-((SBINDay['High'].shift(1)-SBINDay['Low'].shift(1))*3))
    SBINDay["L3A"]=candlestick.MaRound(SBINDay["IPivot"]-((SBINDay['High'].shift(1)-SBINDay['Low'].shift(1))*2.5))
    SBINDay["L3"]=candlestick.MaRound(SBINDay["IPivot"]-((SBINDay['High'].shift(1)-SBINDay['Low'].shift(1))*2))
    SBINDay["L2A"]=candlestick.MaRound(SBINDay["IPivot"]-((SBINDay['High'].shift(1)-SBINDay['Low'].shift(1))*1.5))   
    SBINDay["L2"]=candlestick.MaRound(SBINDay["IPivot"]-((SBINDay['High'].shift(1)-SBINDay['Low'].shift(1))))      
    SBINDay["L1"]=candlestick.MaRound(2*SBINDay["IPivot"]-SBINDay["High"].shift(1))        
    SBINDay["IPivot-L"]=round((SBINDay["IPivot"]+SBINDay["L1"])/2,2)
    
    merged = SBIN5Min.merge(SBINDay, on=['CDATE'], how='left')
    CustomMerge=merged[['Date_x','PDayLow','PDayHigh','PDayClose','PDayOpen',                        
                        'H1','H2','H2A','H3','H3A','H4','IPivot-H',"IPivot",
                        "L1","L2",'L2A',"L3",'L3A',"L4",'IPivot-L']]
    CustomMerge.columns=['Date', 'PDayLow','PDayHigh','PDayClose','PDayOpen',                         
                         'H1','H2','H2A','H3','H3A','H4','IPivot-H',"IPivot",
                        "L1","L2",'L2A',"L3",'L3A',"L4",'IPivot-L']
    SBIN5Min=SBIN5Min.merge(CustomMerge, on=['Date'], how='left')
    SBIN5Min['MaxP10']=SBIN5Min['High'].shift(1).rolling(10).max()
    SBIN5Min['MinP10']=SBIN5Min['Low'].shift(1).rolling(10).min()
    SBIN5Min['MaxP5']=SBIN5Min['High'].shift(1).rolling(5).max()
    SBIN5Min['MinP5']=SBIN5Min['Low'].shift(1).rolling(5).min()
    SBIN5Min['MaxP15']=SBIN5Min['High'].shift(1).rolling(15).max()
    SBIN5Min['MinP15']=SBIN5Min['Low'].shift(1).rolling(15).min()
    SBIN5Min['MaxP20']=SBIN5Min['High'].shift(1).rolling(20).max()
    SBIN5Min['MinP20']=SBIN5Min['Low'].shift(1).rolling(20).min()
    SBIN5Min['MaxP30']=SBIN5Min['High'].shift(1).rolling(30).max()
    SBIN5Min['MinP30']=SBIN5Min['Low'].shift(1).rolling(30).min()
    SBIN5Min['PMaxP10']=SBIN5Min['High'].shift(30).rolling(10).max()
    SBIN5Min['PMinP10']=SBIN5Min['Low'].shift(30).rolling(10).min()
    SBIN5Min['PMaxP5']=SBIN5Min['High'].shift(30).rolling(5).max()
    SBIN5Min['PMinP5']=SBIN5Min['Low'].shift(30).rolling(5).min()
    SBIN5Min['PMaxP15']=SBIN5Min['High'].shift(30).rolling(15).max()
    SBIN5Min['PMinP15']=SBIN5Min['Low'].shift(30).rolling(15).min()
    SBIN5Min['PMaxP20']=SBIN5Min['High'].shift(30).rolling(20).max()
    SBIN5Min['PMinP20']=SBIN5Min['Low'].shift(30).rolling(20).min()
    SBIN5Min['PMaxP30']=SBIN5Min['High'].shift(30).rolling(30).max()
    SBIN5Min['PMinP30']=SBIN5Min['Low'].shift(30).rolling(30).min()
    SuperTrend(SBIN5Min,10,5)
    SuperTrend(SBIN5Min,21,3)
    STOCDK(SBIN5Min,52)
    SBIN5Min['EMAK50']=SBIN5Min['%K'].ewm(span=50, adjust=False).mean()
#    SBIN5Min['Date']=SBIN5Min['Date'].apply(lambda x: MParseDate(x).strftime("%m/%d/%Y %I:%M %p"))
#    SBIN5Min['Date']=pd.to_datetime(SBIN5Min['Date'])
    SBIN5Min['SSignal']=(
            (SBIN5Min['%K'].shift(1)>SBIN5Min['EMAK50'].shift(1))  &
            (SBIN5Min['%K']<SBIN5Min['EMAK50'])  &
            (SBIN5Min['%K'].shift(1)>70)  &
            (SBIN5Min['EMAK50'].shift(1)>70)  
            )
    
    SBIN5Min['BSignal']=(
        (SBIN5Min['%K'].shift(1)<SBIN5Min['EMAK50'].shift(1))  &
        (SBIN5Min['%K']>SBIN5Min['EMAK50'])  &
        (SBIN5Min['%K'].shift(1)<30)  &
        (SBIN5Min['EMAK50'].shift(1)<30)  
        )
            
    SBIN5Min['BSignalL']=SBIN5Min['BSignal'].shift(1).rolling(30).max()       
    SBIN5Min['SSignalL']=SBIN5Min['SSignal'].shift(1).rolling(30).max()       
            
                        
#    ATR(SBIN5Min,21)
    #SBIN5Min['ATRSTPH']=SBIN5Min['Close']+round(SBIN5Min['ATR_21'],0)*3
    #SBIN5Min['ATRSTPL']=SBIN5Min['Close']-round(SBIN5Min['ATR_21'],0)*3
    SBIN5Min['EMAC26']=SBIN5Min['Close'].ewm(span=26, adjust=False).mean()
    SBIN5Min['PATRSL_26']=SBIN5Min['ST_21_3'].shift(26)
    SBIN5Min['PATRSL_26_X']=SBIN5Min['STX_21_3'].shift(26)
    SBIN5Min['PATRSL_10']=SBIN5Min['ST_21_3'].shift(10)
    SBIN5Min['PATRSL_10_X']=SBIN5Min['STX_21_3'].shift(10)
    SBIN5Min['PATRSL_16']=SBIN5Min['ST_21_3'].shift(16)
    #SBIN5Min['PATRSL_16_X']=SBIN5Min['STX_21_3'].shift(16)
    SBIN5Min['PATRSL_00_X']=SBIN5Min['PATRSL_16'].rolling(10).mean()
    SBIN5Min['SIGNALM']=(round(SBIN5Min['PATRSL_26'],2)==round(SBIN5Min['PATRSL_00_X'],2))
    SBIN5Min['SIGNAL']=SBIN5Min['STX_10_5']
    SBIN5Min['CheckSIGNAL']=SBIN5Min['SIGNAL']!=SBIN5Min['SIGNAL'].shift(1)
    SBIN5Min['CCOL']=SBIN5Min['PATRSL_26']
    SBIN5Min['CCOLSIGNAL']=SBIN5Min['PATRSL_26_X']
    
    df=candlestick.atlstoploss_crosscount(SBIN5Min)
    df['Stock']=StockName
 #   df['Date']=df['Date'].apply(lambda x: MParseDate(x).strftime("%m/%d/%Y %I:%M %p"))
    df1=df[(df['CheckSIGNAL']==True)]
    if(i==Start):
        Final=df1
    else:
        Final=Final.append(df1)
    
    

StockList=pd.read_csv(r"C:\Users\mbhaskar111918\OneDrive - GROUP DIGITAL WORKPLACE\Documents\D_DRIVE_IN49805787L\SHARED\backup\Confidential\candlestick-patterns-masterV5\candlestick-patterns-master\Test\StockListAll.txt")

A=3
if(A==0):
    Start=0
    End=round(len(StockList)/2)
elif(A==1):
    Start=round(len(StockList)/2)
    End=len(StockList)
else:
    Start=0
    End=len(StockList)
#End=2
Date1=datetime.now()
StockList=pd.read_csv(r"C:\Users\mbhaskar111918\OneDrive - GROUP DIGITAL WORKPLACE\Documents\D_DRIVE_IN49805787L\SHARED\backup\Confidential\candlestick-patterns-masterV5\candlestick-patterns-master\Test\StockListAll.txt")
StockDIR=r"C:\Users\mbhaskar111918\Data\incr1\\"
mdf=pd.DataFrame()
mdfst={}
ddfst={}
Runthread=[]
NoofStock=19 
Test=True
i=Start+10000
while(i<End):
    StockName=StockList.iloc[i]['StockName']
    #print(StockName+"     Running ....." )
    ZID=StockList.iloc[i]['ZID']
    ID=ZID
    Runthread.append(threading.Thread(target=getPastData,args=(ZID,StockName,"minute")))
    Runthread[-1].start()
  
    #getPastData(ZID,StockName)
    if((i%NoofStock==0) & (i!=0)):
        for thread in Runthread:
            thread.join()
            Runthread=[]

    i=i+1
for thread in Runthread:
    thread.join() 
    
Date3=datetime.now()

    
i=Start#len(StockList)-1
#Date1=datetime.now()
print("Processing.....")
Runthread=[]
while(i<End):
    StockName=StockList.iloc[i]['StockName']
    #print(StockName)
    if(i==Start):
        process1(StockName,i)
    else:
        Runthread.append(threading.Thread(target=process1,args=(StockName,i)))
        Runthread[-1].start()
#        if((i%40==0) & (i!=0)):
#            for thread in Runthread:
#                thread.join()
#            Runthread=[]
    i=i+1
for thread in Runthread:
    thread.join()       

Date2=datetime.now()
print("download..Total Time :"+str(divmod((Date3-Date1).total_seconds(),60)))
print("Total Time :"+str(divmod((Date2-Date1).total_seconds(),60)))

i=500#len(StockList)-1
Date1=datetime.now()
while(i<len(StockList)):
#if(True):
    StockName=StockList.iloc[i]['StockName']
    StockName="HINDALCO"
    SBIN5Min=candlestick.LoadCSVDatax(DIRNIFTY,StockName,"minute")
    SBINDay=candlestick.LoadCSVDatax(DIRNIFTY,StockName,"day")
    
    SBINDay['Date']=SBINDay['Date'].apply(lambda x: MParseDate(x).strftime("%m/%d/%Y %I:%M %p"))
    SBINDay['Date']=pd.to_datetime(SBINDay['Date'])
    SBIN5Min['Date']=SBIN5Min['Date'].apply(lambda x: MParseDate(x).strftime("%m/%d/%Y %I:%M %p"))
    SBIN5Min['Date']=pd.to_datetime(SBIN5Min['Date'])


    SBINDay['CDATE']=pd.to_datetime(SBINDay['Date']).dt.strftime("%Y-%b-%d")
    SBIN5Min['CDATE']=pd.to_datetime(SBIN5Min['Date']).dt.strftime("%Y-%b-%d")
    SBINDay['PDayLow']=SBINDay['Low'].shift(1)
    SBINDay['PDayHigh']=SBINDay['High'].shift(1)
    SBINDay['PDayClose']=SBINDay['Close'].shift(1)
    SBINDay['PDayOpen']=SBINDay['Open'].shift(1)
    
    SBINDay["IPivot"]=candlestick.MaRound((SBINDay['Close'].shift(1)+SBINDay['High'].shift(1)+SBINDay['Low'].shift(1))/3)
    SBINDay["H4"]=candlestick.MaRound(SBINDay["IPivot"]+((SBINDay['High'].shift(1)-SBINDay['Low'].shift(1))*3))   
    SBINDay["H3A"]=candlestick.MaRound(SBINDay["IPivot"]+((SBINDay['High'].shift(1)-SBINDay['Low'].shift(1))*2.5))   
    SBINDay["H3"]=candlestick.MaRound(SBINDay["IPivot"]+((SBINDay['High'].shift(1)-SBINDay['Low'].shift(1))*2))   
    SBINDay["H2A"]=candlestick.MaRound(SBINDay["IPivot"]+((SBINDay['High'].shift(1)-SBINDay['Low'].shift(1))*1.5))   
    SBINDay["H2"]=candlestick.MaRound(SBINDay["IPivot"]+((SBINDay['High'].shift(1)-SBINDay['Low'].shift(1))))      
    SBINDay["H1"]=candlestick.MaRound(2*SBINDay["IPivot"]-SBINDay["Low"].shift(1))    
    SBINDay["IPivot-H"]=round((SBINDay["IPivot"]+SBINDay["H1"])/2,2)
    SBINDay["L4"]=candlestick.MaRound(SBINDay["IPivot"]-((SBINDay['High'].shift(1)-SBINDay['Low'].shift(1))*3))
    SBINDay["L3A"]=candlestick.MaRound(SBINDay["IPivot"]-((SBINDay['High'].shift(1)-SBINDay['Low'].shift(1))*2.5))
    SBINDay["L3"]=candlestick.MaRound(SBINDay["IPivot"]-((SBINDay['High'].shift(1)-SBINDay['Low'].shift(1))*2))
    SBINDay["L2A"]=candlestick.MaRound(SBINDay["IPivot"]-((SBINDay['High'].shift(1)-SBINDay['Low'].shift(1))*1.5))   
    SBINDay["L2"]=candlestick.MaRound(SBINDay["IPivot"]-((SBINDay['High'].shift(1)-SBINDay['Low'].shift(1))))      
    SBINDay["L1"]=candlestick.MaRound(2*SBINDay["IPivot"]-SBINDay["High"].shift(1))        
    SBINDay["IPivot-L"]=round((SBINDay["IPivot"]+SBINDay["L1"])/2,2)
    
    merged = SBIN5Min.merge(SBINDay, on=['CDATE'], how='left')
    CustomMerge=merged[['Date_x','PDayLow','PDayHigh','PDayClose','PDayOpen',                        
                        'H1','H2','H2A','H3','H3A','H4','IPivot-H',"IPivot",
                        "L1","L2",'L2A',"L3",'L3A',"L4",'IPivot-L']]
    CustomMerge.columns=['Date', 'PDayLow','PDayHigh','PDayClose','PDayOpen',                         
                         'H1','H2','H2A','H3','H3A','H4','IPivot-H',"IPivot",
                        "L1","L2",'L2A',"L3",'L3A',"L4",'IPivot-L']
    SBIN5Min=SBIN5Min.merge(CustomMerge, on=['Date'], how='left')
    SBIN5Min['MaxP10']=SBIN5Min['High'].shift(1).rolling(10).max()
    SBIN5Min['MinP10']=SBIN5Min['Low'].shift(1).rolling(10).min()
    SBIN5Min['MaxP5']=SBIN5Min['High'].shift(1).rolling(5).max()
    SBIN5Min['MinP5']=SBIN5Min['Low'].shift(1).rolling(5).min()
    SBIN5Min['MaxP15']=SBIN5Min['High'].shift(1).rolling(15).max()
    SBIN5Min['MinP15']=SBIN5Min['Low'].shift(1).rolling(15).min()
    SBIN5Min['MaxP20']=SBIN5Min['High'].shift(1).rolling(20).max()
    SBIN5Min['MinP20']=SBIN5Min['Low'].shift(1).rolling(20).min()
    SBIN5Min['MaxP30']=SBIN5Min['High'].shift(1).rolling(30).max()
    SBIN5Min['PMinP30']=SBIN5Min['Low'].shift(30).rolling(30).min()
    SBIN5Min['PMaxP10']=SBIN5Min['High'].shift(30).rolling(10).max()
    SBIN5Min['PMinP10']=SBIN5Min['Low'].shift(30).rolling(10).min()
    SBIN5Min['PMaxP5']=SBIN5Min['High'].shift(30).rolling(5).max()
    SBIN5Min['PMinP5']=SBIN5Min['Low'].shift(30).rolling(5).min()
    SBIN5Min['PMaxP15']=SBIN5Min['High'].shift(30).rolling(15).max()
    SBIN5Min['PMinP15']=SBIN5Min['Low'].shift(30).rolling(15).min()
    SBIN5Min['PMaxP20']=SBIN5Min['High'].shift(30).rolling(20).max()
    SBIN5Min['PMinP20']=SBIN5Min['Low'].shift(30).rolling(20).min()
    SBIN5Min['PMaxP30']=SBIN5Min['High'].shift(30).rolling(30).max()
    SBIN5Min['PMinP30']=SBIN5Min['Low'].shift(30).rolling(30).min()
    SuperTrend(SBIN5Min,10,5)
    SuperTrend(SBIN5Min,21,3)
    STOCDK(SBIN5Min,52)
    SBIN5Min['EMAK50']=SBIN5Min['%K'].ewm(span=50, adjust=False).mean()
#    SBIN5Min['Date']=SBIN5Min['Date'].apply(lambda x: MParseDate(x).strftime("%m/%d/%Y %I:%M %p"))
#    SBIN5Min['Date']=pd.to_datetime(SBIN5Min['Date'])
    SBIN5Min['SSignal']=(
            (SBIN5Min['%K'].shift(1)>SBIN5Min['EMAK50'].shift(1))  &
            (SBIN5Min['%K']<SBIN5Min['EMAK50'])  &
            (SBIN5Min['%K'].shift(1)>70)  &
            (SBIN5Min['EMAK50'].shift(1)>70)  
            )
    
    SBIN5Min['BSignal']=(
        (SBIN5Min['%K'].shift(1)<SBIN5Min['EMAK50'].shift(1))  &
        (SBIN5Min['%K']>SBIN5Min['EMAK50'])  &
        (SBIN5Min['%K'].shift(1)<30)  &
        (SBIN5Min['EMAK50'].shift(1)<30)  
        )
            
    SBIN5Min['BSignalL']=SBIN5Min['BSignal'].shift(1).rolling(30).max()       
    SBIN5Min['SSignalL']=SBIN5Min['SSignal'].shift(1).rolling(30).max()       
            
                        
#    ATR(SBIN5Min,21)
    #SBIN5Min['ATRSTPH']=SBIN5Min['Close']+round(SBIN5Min['ATR_21'],0)*3
    #SBIN5Min['ATRSTPL']=SBIN5Min['Close']-round(SBIN5Min['ATR_21'],0)*3
    SBIN5Min['EMAC26']=SBIN5Min['Close'].ewm(span=26, adjust=False).mean()
    SBIN5Min['PATRSL_26']=SBIN5Min['ST_21_3'].shift(26)
    SBIN5Min['PATRSL_26_X']=SBIN5Min['STX_21_3'].shift(26)
    SBIN5Min['PATRSL_10']=SBIN5Min['ST_21_3'].shift(10)
    SBIN5Min['PATRSL_10_X']=SBIN5Min['STX_21_3'].shift(10)
    SBIN5Min['PATRSL_16']=SBIN5Min['ST_21_3'].shift(16)
    #SBIN5Min['PATRSL_16_X']=SBIN5Min['STX_21_3'].shift(16)
    SBIN5Min['PATRSL_00_X']=SBIN5Min['PATRSL_16'].rolling(10).mean()
    SBIN5Min['SIGNALM']=(round(SBIN5Min['PATRSL_26'],2)==round(SBIN5Min['PATRSL_00_X'],2))
    SBIN5Min['SIGNAL']=SBIN5Min['STX_10_5']
    SBIN5Min['CheckSIGNAL']=SBIN5Min['SIGNAL']!=SBIN5Min['SIGNAL'].shift(1)
    SBIN5Min['CCOL']=SBIN5Min['PATRSL_26']
    SBIN5Min['CCOLSIGNAL']=SBIN5Min['PATRSL_26_X']
    
    df=candlestick.atlstoploss_crosscount(SBIN5Min)
    df['Stock']=StockName
 #   df['Date']=df['Date'].apply(lambda x: MParseDate(x).strftime("%m/%d/%Y %I:%M %p"))
    df1=df[(df['CheckSIGNAL']==True)]
    
    
    df1=df[(df['CheckSIGNAL']==True) & (df['AtlstoplossCrosscount']<40) & (df['AtlstoplossCrosscount']>=0) & (df['PATRSL_26_X']!=df['SIGNAL'])][['Stock','Date','Open','High','Low','Close','SIGNALM','SIGNAL','CheckSIGNAL','PATRSL_26','PATRSL_26_X','PATRSL_00_X','AtlstoplossCrosscount','EMAC26']]
#    if(i==0):
#        Final=df1
#    else:
#        Final=Final.append(df1)
#    
    
    #df.to_csv("C:\ReadMoneycontrol\Mani 2.0\ForStudy\\"+StockName+"_Full.csv",sep=',',encoding='utf-8',index=False)
    #df1.to_csv("C:\ReadMoneycontrol\Mani 2.0\ForStudy\\"+StockName+"_Filtered.csv",sep=',',encoding='utf-8',index=False)
    i=i+1
#Final['CDATE']=Final['Date'].apply(lambda x: x.strftime("%Y-%b-%d"))
##Final1=Final[Final['CDATE']=='2020-Apr-08']
#
#Final['Date']=Final['Date'].apply(lambda x: MParseDate(x).strftime("%m/%d/%Y %I:%M %p"))
#Final['Date']=pd.to_datetime(Final['Date'])
#Final1=Final[['Stock','Date','Open','High','Low','Close','RSI14','CheckSIGNAL','SESignal','BESignal','SIGNALM','SIGNAL','PATRSL_26','PATRSL_26_X','PATRSL_00_X','AtlstoplossCrosscount','EMAC26','CDATE']]
#Final2=Final1
Final2=Final1[(Final1['CDATE']=='2020-Apr-16') & (Final1['CheckSIGNAL']==True)]
Final2=Final[(Final['CDATE']=='2020-Apr-23') & (Final['CheckSIGNAL']==True)
            & ( ( (Final['SIGNAL']=='up') & (Final['BSignalL']==1)) |
                    ( (Final['SIGNAL']=='down') & (Final['SSignalL']==1))
               )     
                    ]

MaxField="MaxP20"
MinField="MinP20"
PMaxField="PMaxP10"
PMinField="PMaxP10"
Final3=Final2[
        (Final2[MaxField]>Final2['H2']) &
        (Final2[MaxField]<Final2['H3']) &
        (Final2[PMinField]<Final2['H2']) &
        (Final2['Close']<Final2['H2']) &
        ( (Final2['SIGNAL']=='down') & (Final2['SSignalL']==1)) &
        (Final2['AtlstoplossCrosscount']>=-1) 
        
        
        ][['Stock','Date',PMaxField,'H2','H3','SIGNALM']]

Final4=Final2[
        (Final2[MaxField]>Final2['H1']) &
        (Final2[MaxField]<Final2['H2']) &
        (Final2[PMinField]<Final2['H1']) &
        (Final2['Close']<Final2['H1']) &
        
        ( (Final2['SIGNAL']=='down') & (Final2['SSignalL']==1))&
        (Final2['AtlstoplossCrosscount']>=-1) 
        ][['Stock','Date',MaxField,'H1','H2','SIGNALM']]

Final3=Final2[
        (Final2[MaxField]>Final2['IPivot']) &
        (Final2[MaxField]<Final2['H1']) &
        (Final2[PMinField]<Final2['IPivot']) &
        (Final2['Close']<Final2['IPivot']) &
        ( (Final2['SIGNAL']=='down') & (Final2['SSignalL']==1)) &
        (Final2['AtlstoplossCrosscount']>=-1)        
        
        ][['Stock','Date',MaxField,'IPivot','H1','SIGNALM']]

Final3=Final2[
        (Final2[MaxField]>Final2['L1']) &
        (Final2[MaxField]<Final2['IPivot']) &
        (Final2[PMinField]<Final2['L1']) &
        (Final2['Close']<Final2['L1']) &
        ( (Final2['SIGNAL']=='down') & (Final2['SSignalL']==1)) &
        (Final2['AtlstoplossCrosscount']>=-1) 
        
        
        ][['Stock','Date',MaxField,'IPivot','L1','SIGNALM']]
        
#        ][['Stock','Date','MaxP30','H1','H2','AtlstoplossCrosscount']]

Final5=Final2[
        (Final2[MinField]<Final2['IPivot']) &
        (Final2[MinField]>Final2['L1']) &
        (Final2[PMaxField]>Final2['IPivot']) &
        (Final2['Close']>Final2['IPivot']) &
        
         ( (Final2['SIGNAL']=='up') & (Final2['BSignalL']==1))&
        (Final2['AtlstoplossCrosscount']>=0) 
        ][['Stock','Date','IPivot-L','L1','IPivot','SIGNALM']]

#Final5=Final2[
#        (Final2[MinField]<Final2['H1']) &
#        (Final2[MinField]>Final2['IPivot']) &
#        #(Final2[PMaxField]>Final2['H1']) &
#        (Final2['Close']>Final2['H1']) &
#        
#         ( (Final2['SIGNAL']=='up') & (Final2['BSignalL']==1))&
#        (Final2['AtlstoplossCrosscount']>=0) 
#        ][['Stock','Date','IPivot-L','L1','IPivot','SIGNALM']]


Final5=Final2[
        (Final2[MinField]<Final2['L1']) &
        (Final2[MinField]>Final2['L2']) &
        (Final2[PMaxField]>Final2['L1']) &
        (Final2['Close']>Final2['L1']) &
        
         ( (Final2['SIGNAL']=='up') & (Final2['BSignalL']==1))&
        (Final2['AtlstoplossCrosscount']>=-1) 
        ][['Stock','Date','IPivot-L','SIGNALM']]

Final5=Final2[
        (Final2[MinField]<Final2['L2']) &
        (Final2[MinField]>Final2['L3']) &
        (Final2[PMaxField]>Final2['L2']) &
        (Final2['Close']>Final2['L2']) &
        
         ( (Final2['SIGNAL']=='up') & (Final2['BSignalL']==1))&
        (Final2['AtlstoplossCrosscount']>=-1) 
        ][['Stock','Date','IPivot-L','L1','L2','SIGNALM']]
        
 #       ][['Stock','Date','MaxP30','H1','H2','AtlstoplossCrosscount']]
# & (Final1['PATRSL_26_X']!=Final1['SIGNAL'])]

#List_ = list(tCandles_df['Date'])
#            List_ = [datetime.strptime(MParseDate(x).strftime("%m/%d/%Y %I:%M %p"), "%m/%d/%Y %I:%M %p") for x in List_]
#            tCandles_df['Date']=pd.Series([x for x in List_],index=tCandles_df.index)
            
#Date2=datetime.datetime.now()
#print("Total Time :"+str(divmod((Date2-Date1).total_seconds(),60)))
#
#Date1=datetime.datetime.now()
#SBIN5Min=candlestick.LoadCSVDatax(DIRNIFTY,StockName,"minute")
#SuperTrend(SBIN5Min,10,5)
#SuperTrend(SBIN5Min,21,3)
#Date2=datetime.datetime.now()
#print("Total Time :"+str(divmod((Date2-Date1).total_seconds(),60)))
#
#Date1=datetime.datetime.now()
#SBIN5Min['EMAC26']=SBIN5Min['Close'].ewm(span=26, adjust=False).mean()
#SBIN5Min['PATRSL_26']=SBIN5Min['ST_21_3'].shift(26)
#SBIN5Min['PATRSL_26_X']=SBIN5Min['STX_21_3'].shift(26)
#SBIN5Min['SIGNAL']=SBIN5Min['STX_10_5']
#SBIN5Min['CheckSIGNAL']=SBIN5Min['SIGNAL']!=SBIN5Min['SIGNAL'].shift(1)
#SBIN5Min['CCOL']=SBIN5Min['PATRSL_26']
#SBIN5Min['CCOLSIGNAL']=SBIN5Min['PATRSL_26_X']
#Date2=datetime.datetime.now()
#print("Total Time :"+str(divmod((Date2-Date1).total_seconds(),60)))
#
#Date1=datetime.datetime.now()
#df=candlestick.atlstoploss_crosscount(SBIN5Min)
#Date2=datetime.datetime.now()
#print("Total Time :"+str(divmod((Date2-Date1).total_seconds(),60)))
