# -*- coding: utf-8 -*-
"""
Created on Sat Oct 19 17:36:08 2019

@author: lalitha
"""
import threading
import time
import requests
import datetime
import pandas as pd
import json
#from datetime import timedelta  
from datetime import datetime, timedelta
import requests
from ehp import *
from dateutil.parser import parse
import numpy as np
import plotly.graph_objs as go
from plotly import __version__
from plotly.offline import download_plotlyjs, init_notebook_mode, plot, iplot
import numpy as np
import plotly.io as pio
import os
from plotly.tools import FigureFactory as FF
import time
Test=True

proxies = {
 "http": "http://X119285:Password20.4@proxy-sgt.si.socgen:8080",
 "https": "http://X119285:Password20.4@proxy-sgt.si.socgen:8080",
}

def getLiveData():
    global CrudeDf30Min
    global CrudeDf15Min
    StrTimeIntervals=['15minute','30minute']
    for TimeInterval in StrTimeIntervals: # 54261767
        Candles = requests.get('https://kitecharts-aws.zerodha.com/api/chart/54334983/'+TimeInterval+'?public_token=Pb0MyvJ435vcAjx5fxCTtEV0oD0wdcwT&user_id=RM5678&api_key=kitefront&access_token=mwFtysT9JpZk6B7ZOUH4AqbrJkhUlTnC&from=2019-01-08&to=2019-04-05&ciqrandom=1549306657305') #GOLD
        Candles_dict = Candles.json()['data']['candles']
        Candles_df = pd.DataFrame(Candles_dict,columns=['Date', 'open', 'high', 'low', 'close', 'V'])
        #candles5min_df['T'] = pd.to_datetime(candles5min_df['T'], unit='ms')
        #List_ = list(Candles_df['Date'])
        #List_ = [parse(x) for x in List_]
        #Candles_df['Date']=pd.Series([x for x in List_],index=Candles_df.index)
        List_ = list(Candles_df['Date'])
    #List_ = [parse(x).strftime for x in List_]
        List_ = [datetime.strptime(MParseDate(x).strftime("%m/%d/%Y %I:%M %p"), "%m/%d/%Y %I:%M %p") for x in List_]
        Candles_df['Date']=pd.Series([x for x in List_],index=Candles_df.index)
        if(TimeInterval=="15minute"):
            CrudeDf15Min=Candles_df
            CrudeDf15Min=ProcessCandles(CrudeDf15Min)
            List_ = list(CrudeDf15Min['Date'])
            #parse(List_[0] ).hour
            CrudeDf15Min['Hour'] = pd.Series([x.hour for x in List_],index=CrudeDf15Min.index)

        else:
            CrudeDf30Min=Candles_df
            CrudeDf30Min=ProcessCandles(CrudeDf30Min)
            List_ = list(CrudeDf30Min['Date'])
#parse(List_[0] ).hour
            CrudeDf30Min['Hour'] = pd.Series([x.hour for x in List_],index=CrudeDf30Min.index)


def MParseDate(Date):
    ts = (np.datetime64(pd.to_datetime(Date)) - np.datetime64('1970-01-01T00:00:00Z')) / np.timedelta64(1, 's')
    return N1(N1(datetime.utcfromtimestamp(ts),'5H',"+"),"30M","+")
seconds_per_unit = {"S": 1, "M": 60, "H": 3600, "D": 86400, "W": 604800}
def N1(date,s,Operation):
    if (Operation=="+"):
        return date+timedelta(seconds=int(s[:-1]) * seconds_per_unit[s[-1]])
    else:
        return date-timedelta(seconds=int(s[:-1]) * seconds_per_unit[s[-1]])


def getPastData(ID,StockName):
#    global Candles,url 
#    global Candles_dict 
    headers1={}
    Cookie="__cfduid=d742e80f3b3e29bf1896fffb390db31521567509566; _ga=GA1.2.1163935487.1570611192; kf_session=C0Hl9t5uREbMz3aeZnpRZ5B7nsb7VARq; public_token=meotnXqFVDWBl6gyU21xwB9zTR7Pnegp; user_id=RM5678; enctoken=pg2Ku6aGhIoi0+Am17IGcQ5CmhHMv9b4ujZVghS/42akCArw/ju9wrxK3nGDg1aeTRMGygawVIfA3fO3kSojT7FKuCgUGA=="
    authorization="enctoken pg2Ku6aGhIoi0+Am17IGcQ5CmhHMv9b4ujZVghS/42akCArw/ju9wrxK3nGDg1aeTRMGygawVIfA3fO3kSojT7FKuCgUGA=="
   
    headers1 = {
            #'Content-type': 'application/x-www-form-urlencoded',
#                ":authority": "kite.zerodha.com",
#                ":method": "GET",
#                ":path": "/oms/instruments/historical/7712001/15minute?user_id=RM5678&oi=1&from=2020-02-04&to=2020-02-18&ciqrandom=1582039082895",
#                ":scheme": "https",
               #'Accept': 'application/json, text/plain, */*',
               #"accept":"*/*",
               #"accept-encoding":"gzip, deflate, br",
               #"accept-language":"en-US,en;q=0.9",
               'authorization': authorization,
               'cookie':Cookie
               
               #,'x-csrftoken':'ydYuAU0A7nEJzXNJkAj58uiBc5pc9rWj'
               ,'referer':'https://kite.zerodha.com/static/build/chart.html?v=2.4.0'
               #,"sec-fetch-dest": "empty"
               #,"sec-fetch-mode": "cors"
               #,"sec-fetch-site": "same-origin"
               ,"user-agent": "Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.106 Safari/537.36"
               }
    
    #headers['User-Agent'] = 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36'
    if(Test==False):
        StrTimeIntervals=['minute','3minute','5minute','15minute','30minute','60minute','2hour','3hour','day']
    else:
        StrTimeIntervals=['minute','day']
    #StrTimeIntervals=['minute','3minute','5minute','15minute','day']
    #StrTimeIntervals=['60minute','2hour','3hour','day']
    #Increment=[20,60,90,120,250]
    #StrTimeIntervals=['minute']
    #StrTimeIntervals=['3minute']
    #Increment=[20,30,60,80,120,180]
    #Increment=,10]
    #Increment=[20]
    Increment=[20,20,20,20,20,20,20,20,20]
    #Increment=[18,18,18,18,18,18,18,18,18]
    #Increment=[1,1,1,1,1]
    #Increment=[3,3,3,3,3]
    #StrTimeIntervals=['day']
    Duration=6
    #Duration=18
    requests.Timeout(120)
    for TimeInterval in StrTimeIntervals: # 54261767
        #TimeInterval="minute"
        
        df=pd.DataFrame()
        #print(StockName+"     Running ....."+ TimeInterval )
        #StartDate=N1(datetime.now(),'3D','-')
        #StartDate=N1(datetime.now(),str(2380)+'D','-')
        StartDate=N1(datetime.now(),str(Duration)+'D','-')
        DateIncr=0        
        #while(DateIncr<3):
        while(DateIncr<Duration):
            DateIncr=DateIncr+Increment[StrTimeIntervals.index(TimeInterval)]+1
            EndDate=N1(StartDate,str(Increment[StrTimeIntervals.index(TimeInterval)])+'D','+')
            StartDateStr=StartDate.strftime("%Y-%m-%d")
            EndDateStr=EndDate.strftime("%Y-%m-%d")
            #print(str(DateIncr)+" --> "+StartDateStr+ ' - ' + EndDateStr)
            #url='https://kitecharts-aws.zerodha.com/api/chart/'+str(ID)+'/'+TimeInterval+'?public_token=Pb0MyvJ435vcAjx5fxCTtEV0oD0wdcwT&user_id=RM5678&api_key=kitefront&access_token=mwFtysT9JpZk6B7ZOUH4AqbrJkhUlTnC&'+'from='+StartDateStr+'&to='+EndDateStr+'&ciqrandom=1549306657305'                               
            url='https://kite.zerodha.com/oms/instruments/historical/'+str(ID)+'/'+TimeInterval+'?user_id=RM5678&oi=1&from='+StartDateStr+'&to='+EndDateStr+'&ciqrandom=1581744034200'
            retry=1
            time.sleep(5)
            while(retry<5):
#                Candles = requests.get('https://kitecharts-aws.zerodha.com/api/chart/'+str(ID)+'/'+TimeInterval+
#                               '?public_token=Pb0MyvJ435vcAjx5fxCTtEV0oD0wdcwT&user_id=RM5678&api_key=kitefront&access_token=mwFtysT9JpZk6B7ZOUH4AqbrJkhUlTnC&'+
##                               'from=2019-01-08&to=2019-04-05&ciqrandom=1549306657305') #GOLD
#                                'from='+StartDateStr+'&to='+EndDateStr+'&ciqrandom=1549306657305',headers=headers) #GOLD
                Candles = requests.get(url,headers=headers,proxies=proxies)
                if(Candles.status_code==200):
                    retry=10
                else:
                    print("Retry " + str(retry) + " ---- "+ str(Candles.status_code))
                    time.sleep(1)
                    retry=retry+1
                    
            Candles_dict = Candles.json()['data']['candles']
            tCandles_df = pd.DataFrame(Candles_dict,columns=['Date', 'open', 'high', 'low', 'close', 'V','Z'])
            tCandles_df = tCandles_df[['Date', 'open', 'high', 'low', 'close', 'V']]
            
            if(str(tCandles_df['Date'].dtype)!='datetime64[ns]'):
    #    List_ = [datetime.strptime(parse(x).strftime("%m/%d/%Y %I:%M %p"), "%m/%d/%Y %I:%M %p") for x in List_]
                tCandles_df['Date']=pd.to_datetime(tCandles_df.Date)
            else:
                List_ = list(tCandles_df['Date'])
                List_ = [datetime.strptime(MParseDate(x).strftime("%m/%d/%Y %I:%M %p"), "%m/%d/%Y %I:%M %p") for x in List_]
                tCandles_df['Date']=pd.Series([x for x in List_],index=tCandles_df.index)
            df=df.append(tCandles_df)
            StartDate=N1(EndDate,'1D','+')
        df.sort_values(['Date'],ascending=True)
        df.to_csv(StockDIR+StockName+"-"+TimeInterval+".csv",sep=',',encoding='utf-8',index=False)
        #time.sleep(1)
    #return df
#        if(TimeInterval=="15minute"):
#            CrudeDf15Min=Candles_df
#            CrudeDf15Min=ProcessCandles(CrudeDf15Min)
#            List_ = list(CrudeDf15Min['Date'])
#            #parse(List_[0] ).hour
#            CrudeDf15Min['Hour'] = pd.Series([x.hour for x in List_],index=CrudeDf15Min.index)
#
#        else:
#            CrudeDf30Min=Candles_df
#            CrudeDf30Min=ProcessCandles(CrudeDf30Min)
#            List_ = list(CrudeDf30Min['Date'])
##parse(List_[0] ).hour
#            CrudeDf30Min['Hour'] = pd.Series([x.hour for x in List_],index=CrudeDf30Min.index)


def getPastDayData(ID,StockName):
#    global Candles,url 
#    global Candles_dict 

    StrTimeIntervals=['day']
    #Increment=[30,60,80,90,90]
    Increment=[9]
    #StrTimeIntervals=['day']
    requests.Timeout(120)
    for TimeInterval in StrTimeIntervals: # 54261767
        df=pd.DataFrame()
        print(StockName+"     Running ....."+ TimeInterval )
        StartDate=N1(datetime.now(),'8D','-')
        DateIncr=0        
        while(DateIncr<8):
            DateIncr=DateIncr+Increment[StrTimeIntervals.index(TimeInterval)]+1
            EndDate=N1(StartDate,str(Increment[StrTimeIntervals.index(TimeInterval)])+'D','+')
            StartDateStr=StartDate.strftime("%Y-%m-%d")
            EndDateStr=EndDate.strftime("%Y-%m-%d")
            print(str(DateIncr)+" --> "+StartDateStr+ ' - ' + EndDateStr)
            url='https://kitecharts-aws.zerodha.com/api/chart/'+str(ID)+'/'+TimeInterval+'?public_token=Pb0MyvJ435vcAjx5fxCTtEV0oD0wdcwT&user_id=RM5678&api_key=kitefront&access_token=mwFtysT9JpZk6B7ZOUH4AqbrJkhUlTnC&'+'from='+StartDateStr+'&to='+EndDateStr+'&ciqrandom=1549306657305'                               
            retry=1
            time.sleep(2)
            while(retry<5):
                Candles = requests.get('https://kitecharts-aws.zerodha.com/api/chart/'+str(ID)+'/'+TimeInterval+
                               '?public_token=Pb0MyvJ435vcAjx5fxCTtEV0oD0wdcwT&user_id=RM5678&api_key=kitefront&access_token=mwFtysT9JpZk6B7ZOUH4AqbrJkhUlTnC&'+
#                               'from=2019-01-08&to=2019-04-05&ciqrandom=1549306657305') #GOLD
                                'from='+StartDateStr+'&to='+EndDateStr+'&ciqrandom=1549306657305') #GOLD
                if(Candles.status_code==200):
                    retry=10
                else:
                    print("Retry " + str(retry) + " ---- "+ str(Candles.status_code))
                    time.sleep(10)
                    retry=retry+1
                    
            Candles_dict = Candles.json()['data']['candles']
            tCandles_df = pd.DataFrame(Candles_dict,columns=['Date', 'open', 'high', 'low', 'close', 'V'])
            List_ = list(tCandles_df['Date'])
            List_ = [datetime.strptime(MParseDate(x).strftime("%m/%d/%Y %I:%M %p"), "%m/%d/%Y %I:%M %p") for x in List_]
            tCandles_df['Date']=pd.Series([x for x in List_],index=tCandles_df.index)
            df=df.append(tCandles_df)
            StartDate=N1(EndDate,'1D','+')
        df['STOCK']=StockName
        df.to_csv("C:\\ReadMoneycontrol\\Mani 2.0\\incr\\DAILY"+"-"+TimeInterval+".csv",sep=',',encoding='utf-8',index=False,mode='a')
    return df


def getStockID():
    StockList=pd.read_csv("C:\ReadMoneycontrol\Mani 2.0\StockList-New.txt")
    headers = {'Content-type': 'application/x-www-form-urlencoded', 'Accept': 'application/json, text/plain, */*',
               'cookie':'_ga=GA1.2.2049447225.1545498156; __cfduid=d475c88a56e3eb88adf0ff0f32d7f14be1574230314; kf_session=00Wq8sekHRrGA0LDyQSkn56o0WruEMyI'
               ,'x-csrftoken':'ydYuAU0A7nEJzXNJkAj58uiBc5pc9rWj'
               ,'referer':'https://kite.zerodha.com/chart/web/ciq/NSE/VEDL/784129'}
    i=0
    DatasAr=[]
    
    while(i<len(StockList)):
        Datas={}
        
        StockName=StockList.iloc[i]['Symbol']
        Datas['StockName']=StockName
        i=i+1
        data="segment=NSE&tradingsymbol="+StockName.replace("&","%26")+"&watch_id=1970820&weight=1"
        Response = requests.post('https://kite.zerodha.com/api/marketwatch/1970820/items',
                             headers=headers,data=data) #GOLD
        Datas['ZID']=Response.json()['data']['instrument_token']
        DatasAr.append(Datas)
        
        requests.delete('https://kite.zerodha.com/api/marketwatch/1970820/' + str(Datas['ZID']),headers=headers)
        #a=requests.delete('https://kite.zerodha.com/api/marketwatch/1970820/897537' ,headers=headers)
        time.sleep(1)    
    pd.DataFrame(DatasAr).to_csv("C:\ReadMoneycontrol\Mani 2.0\StockListID-NEW.csv",sep=',',encoding='utf-8',index=False)

Header={}
with open(os.getcwd()+"\\Headers.txt","r") as ins:
    array = []
    for line in ins:
        array.append(line)
        l=line.split(": ")
        Header[l[0]]=l[1].lstrip().replace('\n','')
headers=Header
Test=True
a=1
#StockList=pd.read_csv("C:\ReadMoneycontrol\Mani 2.0\StockListIDOriginal.txt")
if(a==1):
    StockList=pd.read_csv(r"C:\Users\mbhaskar111918\OneDrive - GROUP DIGITAL WORKPLACE\Documents\D_DRIVE_IN49805787L\SHARED\backup\Confidential\candlestick-patterns-masterV5\candlestick-patterns-master\Test\StockListAll.txt")
    StockDIR=r"C:\Users\mbhaskar111918\Data\incr1\\"
    if(Test==False):
        NoofStock=19
    else:
        NoofStock=12
        
elif(a==2):
    #StockList=pd.read_csv("C:\ReadMoneycontrol\Mani 2.0\StockListAll.txt")
    StockList=pd.read_csv("C:\ReadMoneycontrol\Mani 2.0\StockListID-NEWList.csv")
    StockDIR=r"C:\ReadMoneycontrol\Mani 2.0\NEWDataIncr1\incr1\\"
    NoofStock=19 #19
elif(a==3):
    StockList=pd.read_csv("C:\\ReadMoneycontrol\\Mani 2.0\\BANKNIFTY20409_STOCKID.csv")
    StockDIR=r"C:\ReadMoneycontrol\Mani 2.0\BankNifty\April-20\09-Apr\\"
    NoofStock=19
elif(a==4):
    StockList=pd.read_csv("C:\\ReadMoneycontrol\\Mani 2.0\\NIFTY20409_STOCKID.csv")
    StockDIR=r"C:\ReadMoneycontrol\Mani 2.0\Nifty50\April-20\09-Apr\\"
    NoofStock=19
elif(a==5):
    StockList=pd.read_csv("C:\\ReadMoneycontrol\\Mani 2.0\\IndexFuture.csv")
    StockDIR=r"C:\ReadMoneycontrol\Mani 2.0\IndexFuture\April-20\\"
    NoofStock=19
#StockList=pd.read_csv("C:\ReadMoneycontrol\Mani 2.0\StockListID-NEWList.csv")
#StockList=pd.read_csv("C:\ReadMoneycontrol\Mani 2.0\StockListID-New.csv")
Runthread=[]
i=0
while(i<len(StockList)):
    StockName=StockList.iloc[i]['StockName']
    print(StockName+"     Running ....." )
    ZID=StockList.iloc[i]['ZID']
    ID=ZID
    Runthread.append(threading.Thread(target=getPastData,args=(ZID,StockName)))
    Runthread[-1].start()
    
    #getPastData(ZID,StockName)
    if((i%NoofStock==0) & (i!=0)):
        for thread in Runthread:
            thread.join()
            Runthread=[]

    i=i+1
for thread in Runthread:
    thread.join()    
#i=0
#while(i<len(StockList)):
#    StockName=StockList.iloc[i]['StockName']
#    #StockDay=pd.read_csv("C:\ReadMoneycontrol\Mani 2.0\Data\\"+StockName+'-day.csv')
#    
#    if(os.path.exists("C:\ReadMoneycontrol\Mani 2.0\\2\incr1\\"+StockName+'-day.csv')==False):
#        print(StockName)
#    
#    i=i+1

#StockList=pd.read_csv("C:\ReadMoneycontrol\Mani 2.0\StockListIDOriginal.txt")
i=10000
while(i<len(StockList)):
    StockName=StockList.iloc[i]['StockName']
    ZID=StockList.iloc[i]['ZID']
    threading.Thread(target=getPastDayData,args=(ZID,StockName)).start()
    time.sleep(1)
#    getPastDayData(ZID,StockName)
    i=i+1

#getPastData(256265,'NIFTY')
#https://kite.zerodha.com/api/marketwatch/1970820/738139158
#Delete